# SynthAI Foundry + Model Weaver Replit Drop

## PRIMARY — preserve as the application spine
`PRIMARY/Foundry-Glyphs/`
Source: Foundry-Glyphs (2).zip
This is the host to extend. Do not replace it with donor UIs.

## DONORS — inspect/selectively port; do not wholesale merge
`DONORS/Model-Weaver/`
Source: Model-Weaver.zip
Use for model-weaving/evolution/model-management ideas and implementation donors.

`DONORS/Generative-Process-Cluster/`
Source: Generative-Process-Cluster (1).zip
Use for the existing 64-state/channel/emergent-capability substrate and morphing-engine ontology.

`DONORS/merged/`
Source: merged-resonance-foundry.zip
Use selectively for capabilities absent from PRIMARY (addressing/storage/network integrations if still applicable).

## REFERENCE — specific recovered components
- `synthia-combined-patched-v2.html`: recovered Model Weaver / Neural Builder control flow. WARNING: its random demo training is NOT production training.
- `morph_generative_model (13).py`: real PyTorch training/backprop/checkpoint/sequence-generation donor.
- `PHASE2_README.md`: GNN/training architecture reference.
- `FOUNDRY-COMPLETE-README.md`: Foundry architecture/lineage/rollback reference.
- `foundry-engine.js`: standalone Foundry-engine donor.
- `semantic_completion.js`: small semantic completion/training reference.
- `vqvae.js`: discrete state compression reference (not a finished image VQ-VAE).
- `molecule.js`: low-level molecule/swarm transport/router reference; not the DEG repo.

## NORMATIVE FILES
- `MODEL_CONTRACT.md`: model/QQMOD architecture requirements.
- `PASTE_INTO_REPLIT.txt`: implementation request.
- `EXTERNAL/DEG_GEO_DEG.md`: external grammar-learning references.

## Pre-modification verification
Run a clean install in PRIMARY, then:
- `npm run check`
- `npm run build`
- start the app and exercise existing primary flows

The packaging environment did not have a complete dependency install: local `npm run check` reported missing `node` and `vite/client` type definitions. That is a dependency-state limitation, NOT a verified source-code failure. Establish a clean Replit baseline before changes and report the exact baseline result.
