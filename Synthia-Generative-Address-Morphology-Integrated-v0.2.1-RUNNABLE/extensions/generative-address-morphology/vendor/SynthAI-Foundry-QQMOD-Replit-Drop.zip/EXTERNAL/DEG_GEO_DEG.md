# External structural-learning references

Do not copy these chemistry projects wholesale into the runtime. Read/adapt their structural mechanisms and respect their licenses.

DEG — Data-Efficient Graph Grammar Learning for Molecular Generation
https://github.com/gmh14/data_efficient_grammar
Use conceptually for: repeated substructure/motif discovery -> grammar production rules -> reusable structure generation.

Geo-DEG — Hierarchical Grammar-Induced Geometry
https://github.com/gmh14/Geo-DEG
Use conceptually for: organize grammar-derived structures/functions into relational/reachable geometry for routing and composition.
