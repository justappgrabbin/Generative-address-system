// semantic_completion.js
// Rebuild of the completion half of Fayyaz et al. 2022: "the neocortex reasonably fills in the
// missing parts based on general semantic information" when a stored trace is incomplete.
// Their model chains a PixelCNN-style autoregressive network on top of the VQ-VAE's discrete
// codes. A PixelCNN factorizes p(pixels) = prod_i p(pixel_i | pixel_<i) using causal masking.
// Our "pixels" are the 9 categorical layers, so the same factorization is:
//   p(dimension, center, gate, line, color, tone, base, sign, house)
//     = p(dimension) * p(center|dimension) * p(gate|dimension,center) * ...
// implemented as 9 small classifiers chained in a fixed causal order, trained with teacher
// forcing and run autoregressively at completion time. No external ML/AI library.

const { LAYERS, Dense, softmax, oneHot } = require('./vqvae.js');

function reluGrad(pre) { return pre.map(v => (v > 0 ? 1 : 0)); }
function relu(x) { return x.map(v => Math.max(0, v)); }

class SemanticCompletion {
  constructor(hiddenDim = 32) {
    this.hiddenDim = hiddenDim;
    // classifier i sees the concatenated one-hots of layers [0..i-1]; input dim grows with i.
    let prefixDim = 0;
    this.stages = LAYERS.map((layer, i) => {
      const stage = {
        inDim: prefixDim,
        l1: prefixDim > 0 ? new Dense(prefixDim, hiddenDim) : null,
        l2: new Dense(prefixDim > 0 ? hiddenDim : 1, layer.k), // dimension layer (i=0) has no context: bias-only prior
      };
      prefixDim += layer.k;
      return stage;
    });
  }

  _prefixVec(coord, uptoIdx) {
    const vec = [];
    for (let i = 0; i < uptoIdx; i++) vec.push(...oneHot(LAYERS[i].k, coord[LAYERS[i].name]));
    return vec;
  }

  // forward for stage i given the true/known prefix -> {probs, cache}
  _forwardStage(i, prefixVec) {
    const stage = this.stages[i];
    if (stage.inDim === 0) {
      const logits = stage.l2.forward([1]); // learned constant prior over categories
      return { probs: softmax(logits), cache: { input: [1] } };
    }
    const h1pre = stage.l1.forward(prefixVec);
    const h1 = relu(h1pre);
    const logits = stage.l2.forward(h1);
    return { probs: softmax(logits), cache: { h1pre, h1, input: prefixVec } };
  }

  trainStep(coord, lr = 0.05) {
    let totalCE = 0;
    LAYERS.forEach((layer, i) => {
      const prefix = this._prefixVec(coord, i);
      const { probs, cache } = this._forwardStage(i, prefix);
      const target = coord[layer.name];
      totalCE += -Math.log(Math.max(probs[target], 1e-9));
      const dLogits = probs.slice(); dLogits[target] -= 1;

      const stage = this.stages[i];
      if (stage.inDim === 0) {
        stage.l2.backward(cache.input, dLogits, lr);
      } else {
        const dH1 = stage.l2.backward(cache.h1, dLogits, lr);
        const dH1pre = dH1.map((g, j) => g * reluGrad(cache.h1pre)[j]);
        stage.l1.backward(cache.input, dH1pre, lr);
      }
    });
    return totalCE;
  }

  train(experiences, epochs = 300, lr = 0.05) {
    const log = [];
    for (let e = 0; e < epochs; e++) {
      let total = 0;
      for (const coord of experiences) total += this.trainStep(coord, lr);
      if (e % Math.max(1, Math.floor(epochs / 10)) === 0 || e === epochs - 1) {
        log.push({ epoch: e, ce: total / experiences.length });
      }
    }
    return log;
  }

  // partial: object with SOME layer names set to an integer index; others left undefined/null.
  // Returns { coord, confidence } where coord has every layer filled in and confidence is the
  // per-layer probability the network assigned to the value it used (1.0 for given/known layers).
  complete(partial, { sample = false, temperature = 1.0 } = {}) {
    const coord = {};
    const confidence = {};
    LAYERS.forEach((layer, i) => {
      const known = partial[layer.name];
      if (known !== undefined && known !== null) {
        coord[layer.name] = known;
        confidence[layer.name] = 1.0;
        return;
      }
      const prefix = this._prefixVec(coord, i);
      const { probs } = this._forwardStage(i, prefix);
      let choice;
      if (sample) {
        const adj = probs.map(p => Math.pow(p, 1 / temperature));
        const s = adj.reduce((a, b) => a + b, 0);
        let r = Math.random() * s, acc = 0;
        choice = adj.length - 1;
        for (let k = 0; k < adj.length; k++) { acc += adj[k]; if (r <= acc) { choice = k; break; } }
      } else {
        choice = probs.indexOf(Math.max(...probs));
      }
      coord[layer.name] = choice;
      confidence[layer.name] = probs[choice];
    });
    return { coord, confidence };
  }
}

module.exports = { SemanticCompletion };
