/**
 * MOLECULE.JS
 * Channel 43/23 — Structuring
 * 
 * Dumb travelers. No decisions. No thinking.
 * They snap to a position, ping a section, report back.
 * When enough pings happen, the graph grows on its own.
 * 
 * Plugs directly into syntia_state matrix:
 *   state.matrix[gate-1].lines[line-1]
 */

// ─── MOLECULE ────────────────────────────────────────────────
// One molecule = one line position in one gate.
// It holds color/tone/base and knows how to ping.

export class Molecule {
  constructor(gate, line) {
    if (gate < 1 || gate > 64) throw new Error(`Gate must be 1-64, got ${gate}`);
    if (line < 1 || line > 6)  throw new Error(`Line must be 1-6, got ${line}`);

    this.gate  = gate;
    this.line  = line;
    this.color = 1;   // 1-6
    this.tone  = 1;   // 1-6
    this.base  = 1;   // 1-5
    this.state = 'idle';   // idle | snapped | traveling | arrived | dissolved
    this.history = [];
    this.createdAt = Date.now();
  }

  // Set the knobs. That's it.
  snap(color, tone, base) {
    this.history.push({ color: this.color, tone: this.tone, base: this.base, ts: Date.now() });
    this.color = Math.min(6, Math.max(1, color));
    this.tone  = Math.min(6, Math.max(1, tone));
    this.base  = Math.min(5, Math.max(1, base));
    this.state = 'snapped';
    return this.address();
  }

  // Human-readable address — matches your existing currentAddressString format
  address() {
    return `G${this.gate}·L${this.line}·C${this.color}·T${this.tone}·B${this.base}`;
  }

  // Ping a section. Returns the packet. Doesn't wait for response.
  ping(sectionId) {
    this.state = 'traveling';
    return {
      molecule: this.address(),
      gate: this.gate,
      line: this.line,
      color: this.color,
      tone: this.tone,
      base: this.base,
      section: sectionId,
      ts: Date.now()
    };
  }

  // Write this molecule's line value into the syntia_state matrix
  // value = 0.0 to 1.0 (activation strength)
  writeToMatrix(stateMatrix, value = 0.8) {
    const node = stateMatrix[this.gate - 1];
    if (!node) return false;
    node.lines[this.line - 1] = value;
    this.state = 'arrived';
    return true;
  }

  // Read current activation from matrix
  readFromMatrix(stateMatrix) {
    const node = stateMatrix[this.gate - 1];
    if (!node) return 0;
    return node.lines[this.line - 1];
  }

  dissolve() {
    this.state = 'dissolved';
  }
}


// ─── MOLECULE PACK ───────────────────────────────────────────
// Six molecules per gate — one per line.
// This is the full yao set for one hexagram position.

export class MoleculePack {
  constructor(gate) {
    this.gate = gate;
    this.molecules = Array.from({ length: 6 }, (_, i) => new Molecule(gate, i + 1));
  }

  // Snap all 6 lines at once from an address object
  snapFromAddress(address) {
    this.molecules.forEach(m => m.snap(address.color, address.tone, address.base));
    return this.molecules.map(m => m.address());
  }

  // Snap individual line
  snapLine(line, color, tone, base) {
    return this.molecules[line - 1].snap(color, tone, base);
  }

  // Write all lines into matrix
  writeToMatrix(stateMatrix, values = null) {
    // values = array of 6 activation levels, or null for default 0.8
    this.molecules.forEach((m, i) => {
      const v = values ? values[i] : 0.8;
      m.writeToMatrix(stateMatrix, v);
    });
  }

  // Read current state from matrix
  readFromMatrix(stateMatrix) {
    return this.molecules.map(m => m.readFromMatrix(stateMatrix));
  }

  // Ping a section with the full pack
  pingSection(sectionId) {
    return this.molecules.map(m => m.ping(sectionId));
  }

  // How many lines are active (> 0.1 threshold, matches your graph_runtime)
  activeCount(stateMatrix) {
    return this.readFromMatrix(stateMatrix).filter(v => v > 0.1).length;
  }
}


// ─── MOLECULE SWARM ──────────────────────────────────────────
// Multiple packs traveling to multiple sections.
// This is what actually connects things.
// Does not think. Does not decide. Just sends and collects.

export class MoleculeSwarm {
  constructor() {
    this.packs   = new Map();   // gate -> MoleculePack
    this.log     = [];          // arrival log
    this.maxLog  = 500;
  }

  // Get or create a pack for a gate
  pack(gate) {
    if (!this.packs.has(gate)) {
      this.packs.set(gate, new MoleculePack(gate));
    }
    return this.packs.get(gate);
  }

  // Send molecules from a gate to a section
  // Returns packets — caller decides what to do with them
  send(gate, sectionId, address = null) {
    const p = this.pack(gate);
    if (address) p.snapFromAddress(address);

    const packets = p.pingSection(sectionId);

    packets.forEach(packet => {
      this.log.push(packet);
      if (this.log.length > this.maxLog) this.log.shift();
    });

    return packets;
  }

  // Write a gate's current snap into the state matrix
  // This is the "arrival" — molecule reaches its destination
  arrive(gate, stateMatrix, values = null) {
    const p = this.pack(gate);
    p.writeToMatrix(stateMatrix, values);
    return p.activeCount(stateMatrix);
  }

  // Full cycle: snap → send → arrive
  // This is the molecule doing its one job
  traverse(gate, sectionId, address, stateMatrix) {
    const p = this.pack(gate);
    if (address) p.snapFromAddress(address);

    const packets = p.pingSection(sectionId);
    const activeCount = p.activeCount(stateMatrix) > 0
      ? p.activeCount(stateMatrix)
      : (p.writeToMatrix(stateMatrix), p.activeCount(stateMatrix));

    packets.forEach(packet => {
      this.log.push({ ...packet, arrived: true, activeCount });
      if (this.log.length > this.maxLog) this.log.shift();
    });

    return {
      address: p.molecules[0].address(),
      packets,
      activeCount,
      gate,
      section: sectionId
    };
  }

  // How many gates have active molecules
  activeGates(stateMatrix) {
    let count = 0;
    for (const [gate, pack] of this.packs) {
      if (pack.activeCount(stateMatrix) > 0) count++;
    }
    return count;
  }

  // Recent arrivals — what connected recently
  recent(limit = 20) {
    return this.log.slice(-limit);
  }

  // Clear dissolved molecules
  cleanup() {
    for (const [gate, pack] of this.packs) {
      const allDissolved = pack.molecules.every(m => m.state === 'dissolved');
      if (allDissolved) this.packs.delete(gate);
    }
  }
}


// ─── CHANNEL 43/23 DISPATCHER ────────────────────────────────
// The structuring channel.
// Knows the five/six sections. Routes molecules to the right one.
// This is the only thing that knows about sections.
// Molecules themselves don't care where they're going.

export class Dispatcher4323 {
  constructor(sections, stateMatrix) {
    this.sections    = sections;    // array of section ids you define
    this.matrix      = stateMatrix; // syntia_state.matrix
    this.swarm       = new MoleculeSwarm();
    this.connections = new Map();   // sectionId -> Set of gate addresses
  }

  // Dispatch a molecule to a section
  // If no section given, routes by gate's center affinity
  dispatch(gate, address, sectionId = null) {
    const target = sectionId || this._routeByGate(gate);
    const result = this.swarm.traverse(gate, target, address, this.matrix);

    // Track connections
    if (!this.connections.has(target)) this.connections.set(target, new Set());
    this.connections.get(target).add(result.address);

    return result;
  }

  // Broadcast one gate to all sections
  broadcast(gate, address) {
    return this.sections.map(s => this.dispatch(gate, address, s));
  }

  // How many unique connections exist per section
  connectionMap() {
    const map = {};
    for (const [section, addrs] of this.connections) {
      map[section] = addrs.size;
    }
    return map;
  }

  // Simple routing: spread gates evenly across sections
  _routeByGate(gate) {
    const idx = (gate - 1) % this.sections.length;
    return this.sections[idx];
  }
}


// ─── USAGE ───────────────────────────────────────────────────
// Drop this into your existing syntia_build:
//
// import { Dispatcher4323 } from './molecule.js';
// import { createState } from './syntia_state.js';
//
// const state = createState();
//
// const dispatcher = new Dispatcher4323(
//   ['stellarproximology', 'getguagan', 'you-n-i-verse', 'synthia', 'admin'],
//   state.matrix
// );
//
// // Send gate 43 (Structuring) to your hub section
// const result = dispatcher.dispatch(43, state.address, 'stellarproximology');
// console.log(result.address);   // G43·L1·C1·T1·B1
// console.log(result.activeCount); // how many lines lit up
//
// // See what's connected
// console.log(dispatcher.connectionMap());
//
// // Let graph_runtime see the new activations
// graphRuntime.runMorphCycle();
