// vqvae.js
// Vector-Quantized Variational Autoencoder, implemented from scratch (no TF.js, no API calls).
// Rebuild of the storage half of Fayyaz et al. 2022 ("A Model of Semantic Completion in
// Generative Episodic Memory", Neural Comput 34(9):1841-1870, PMID 35896150): the hippocampus
// stores a compressed, discretized trace of an experience rather than the raw experience itself.
//
// Domain mapping: an "experience" here is one full sentence-coordinate —
//   dimension.center.gate.line.color.tone.base.sign.house
// Each layer is categorical, so instead of pixel intensities we quantize a 9-layer coordinate.

const LAYERS = [
  { name: 'dimension', k: 5 },
  { name: 'center',    k: 9 },
  { name: 'gate',      k: 64 },
  { name: 'line',      k: 6 },
  { name: 'color',     k: 6 },
  { name: 'tone',      k: 6 },
  { name: 'base',      k: 6 },
  { name: 'sign',      k: 12 },
  { name: 'house',     k: 12 },
];
const INPUT_DIM = LAYERS.reduce((s, l) => s + l.k, 0); // 130

// ---------- tiny linear-algebra helpers (flat arrays, no dependencies) ----------
function zeros(n) { return new Array(n).fill(0); }
function randMat(rows, cols, scale) {
  const m = new Array(rows);
  for (let i = 0; i < rows; i++) {
    m[i] = new Array(cols);
    for (let j = 0; j < cols; j++) m[i][j] = (Math.random() * 2 - 1) * scale;
  }
  return m;
}
function matVec(W, x) { // W: [out][in], x: [in] -> [out]
  const out = zeros(W.length);
  for (let i = 0; i < W.length; i++) {
    let s = 0;
    const row = W[i];
    for (let j = 0; j < row.length; j++) s += row[j] * x[j];
    out[i] = s;
  }
  return out;
}
function addInPlace(a, b) { for (let i = 0; i < a.length; i++) a[i] += b[i]; return a; }
function relu(x) { return x.map(v => Math.max(0, v)); }
function reluGrad(pre) { return pre.map(v => (v > 0 ? 1 : 0)); }
function softmax(x) {
  const m = Math.max(...x);
  const ex = x.map(v => Math.exp(v - m));
  const s = ex.reduce((a, b) => a + b, 0);
  return ex.map(v => v / s);
}
function oneHot(k, idx) { const v = zeros(k); v[idx] = 1; return v; }

// ---------- a single dense (fully-connected) layer with manual backprop ----------
class Dense {
  constructor(inDim, outDim, scale) {
    this.W = randMat(outDim, inDim, scale || Math.sqrt(2 / inDim));
    this.b = zeros(outDim);
  }
  forward(x) {
    const pre = addInPlace(matVec(this.W, x), this.b);
    return pre;
  }
  // dOutPre: gradient w.r.t. this layer's pre-activation output (already includes any
  // downstream activation-derivative). Returns gradient w.r.t. input x.
  backward(x, dOutPre, lr) {
    const dX = zeros(x.length);
    for (let i = 0; i < this.W.length; i++) {
      const g = dOutPre[i];
      if (g === 0) continue;
      const row = this.W[i];
      for (let j = 0; j < row.length; j++) {
        dX[j] += row[j] * g;
        row[j] -= lr * g * x[j];
      }
      this.b[i] -= lr * g;
    }
    return dX;
  }
}

function encodeCoordinate(coord) {
  // coord: {dimension: idx, center: idx, ...} -> flat one-hot concat, length INPUT_DIM
  const vec = [];
  for (const layer of LAYERS) vec.push(...oneHot(layer.k, coord[layer.name]));
  return vec;
}

class VQVAE {
  constructor(latentDim = 24, hiddenDim = 48, codebookSize = 32) {
    this.latentDim = latentDim;
    this.hiddenDim = hiddenDim;
    this.codebookSize = codebookSize;

    this.encL1 = new Dense(INPUT_DIM, hiddenDim);
    this.encL2 = new Dense(hiddenDim, latentDim);
    this.codebook = randMat(codebookSize, latentDim, 1.0);
    this.decL1 = new Dense(latentDim, hiddenDim);
    // one softmax head per layer, all reading the shared decoder hidden state
    this.heads = LAYERS.map(l => new Dense(hiddenDim, l.k));
  }

  encode(x) {
    const h1pre = this.encL1.forward(x);
    const h1 = relu(h1pre);
    const z = this.encL2.forward(h1);
    return { x, h1pre, h1, z };
  }

  quantize(z) {
    let best = 0, bestDist = Infinity;
    for (let i = 0; i < this.codebook.length; i++) {
      let d = 0;
      for (let j = 0; j < z.length; j++) { const diff = z[j] - this.codebook[i][j]; d += diff * diff; }
      if (d < bestDist) { bestDist = d; best = i; }
    }
    return { index: best, zq: this.codebook[best].slice() };
  }

  decode(zq) {
    const h2pre = this.decL1.forward(zq);
    const h2 = relu(h2pre);
    const logitsPerLayer = this.heads.map(head => head.forward(h2));
    return { h2pre, h2, logitsPerLayer };
  }

  // Full forward pass for one coordinate. Returns everything needed for backward + inspection.
  forward(coord) {
    const x = encodeCoordinate(coord);
    const enc = this.encode(x);
    const q = this.quantize(enc.z);
    const dec = this.decode(q.zq);
    const probsPerLayer = dec.logitsPerLayer.map(softmax);
    return { x, enc, q, dec, probsPerLayer };
  }

  // One SGD step on one experience. beta = commitment loss weight.
  trainStep(coord, lr = 0.03, beta = 0.25) {
    const { x, enc, q, dec, probsPerLayer } = this.forward(coord);

    // --- reconstruction loss: cross-entropy per layer, gradient at each head's pre-activation
    // is simply (softmax_probs - one_hot_target) — the standard softmax+CE shortcut.
    let dH2 = zeros(this.hiddenDim);
    let ceLoss = 0;
    LAYERS.forEach((layer, li) => {
      const target = coord[layer.name];
      const p = probsPerLayer[li];
      ceLoss += -Math.log(Math.max(p[target], 1e-9));
      const dLogits = p.slice(); dLogits[target] -= 1;
      dH2 = addInPlace(dH2, this.heads[li].backward(dec.h2, dLogits, lr));
    });
    const dH2pre = dH2.map((g, i) => g * reluGrad(dec.h2pre)[i]);
    const dZq = this.decL1.backward(q.zq, dH2pre, lr);

    // --- VQ losses (van den Oord et al. formulation, adapted straight-through):
    // codebook loss moves the chosen embedding toward z (detach z)
    // commitment loss moves z toward the chosen embedding (detach embedding)
    const embedding = this.codebook[q.index];
    let vqLoss = 0;
    for (let j = 0; j < embedding.length; j++) {
      const diff = enc.z[j] - embedding[j];
      vqLoss += diff * diff;
      embedding[j] += lr * diff;                 // codebook loss step (pulls embedding -> z)
    }
    // straight-through: gradient from decoder flows to z as if zq == z, plus commitment term
    const dZ = dZq.map((g, j) => g + beta * 2 * (enc.z[j] - embedding[j]));

    // --- backprop through encoder ---
    const dH1 = this.encL2.backward(enc.h1, dZ, lr);
    const dH1pre = dH1.map((g, i) => g * reluGrad(enc.h1pre)[i]);
    this.encL1.backward(x, dH1pre, lr);

    return { ceLoss, vqLoss, codeIndex: q.index };
  }

  train(experiences, epochs = 200, lr = 0.03) {
    const log = [];
    for (let e = 0; e < epochs; e++) {
      let totalCE = 0, totalVQ = 0;
      for (const coord of experiences) {
        const { ceLoss, vqLoss } = this.trainStep(coord, lr);
        totalCE += ceLoss; totalVQ += vqLoss;
      }
      if (e % Math.max(1, Math.floor(epochs / 10)) === 0 || e === epochs - 1) {
        log.push({ epoch: e, ce: totalCE / experiences.length, vq: totalVQ / experiences.length });
      }
    }
    return log;
  }

  // Encode + quantize an experience -> discrete trace id (the "hippocampal index" for it)
  traceOf(coord) {
    const { q } = this.forward(coord);
    return q.index;
  }

  // Reconstruct a full coordinate (argmax per layer) from a stored/quantized trace index
  reconstructFromTrace(index) {
    const dec = this.decode(this.codebook[index]);
    const out = {};
    LAYERS.forEach((layer, li) => {
      const probs = softmax(dec.logitsPerLayer[li]);
      out[layer.name] = probs.indexOf(Math.max(...probs));
    });
    return out;
  }
}

module.exports = { LAYERS, INPUT_DIM, VQVAE, Dense, softmax, oneHot, encodeCoordinate };
