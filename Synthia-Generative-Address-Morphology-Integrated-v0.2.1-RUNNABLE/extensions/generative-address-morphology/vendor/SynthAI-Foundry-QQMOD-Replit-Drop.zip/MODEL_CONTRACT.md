# QQMOD / SynthAI Neural Model Contract

This file is normative. Do not replace this architecture with one large generic LLM.

## 1. Stable host vs neural cartridges

The Foundry/Synthia host remains ordinary deterministic software. Identity, state, addressing, memory, permissions, routing, lineage, persistence, testing, rollback, and automaton control DO NOT belong inside an LLM.

Neural models are replaceable functional cartridges mounted by the host.

## 2. Model classes

### A. Shared micro-language substrate
Build one small causal language substrate for surface generation/continuation. It must be parameterizable and resource-aware.

Requirements:
- causal/autoregressive, never bidirectional for future-token generation
- byte-level or similarly vocabulary-light tokenization; no giant hard-coded word dictionary
- learned token/position representation
- tied input/output embeddings when architecture allows
- configurable depth, width, heads/state size, and context
- deterministic initialization option/seed
- report REAL parameter count, serialized bytes, and measured inference latency
- adapter injection points for specialization
- export/reload path suitable for local inference (prefer ONNX where technically sound)

Do not train a huge language model in this integration run. A tiny smoke configuration is sufficient to prove the pipeline.

### B. Specialist cartridges
Prefer small models over complete language-model clones:
- router/classifier
- semantic comparator
- verifier/scorer
- code specialist adapter
- conversation/style adapter
- visual/morph transition model
- state predictor
- relationship detector
- transformation model

A capability should normally create a small adapter/head/function, not another complete base model.

### C. Channel functions
The 36 channel relationships are FUNCTION SOCKETS, not 36 LLMs.
A socket may contain:
- no neural model
- a symbolic/rule function
- a tiny neural transition function
- an adapter to the shared substrate
- a composed function
Only create a neural cartridge when evidence/use warrants it.

## 3. QQMOD principle

Tiny core + shared substrate + swappable specialist cartridges + compressed experience + external knowledge.

Do not duplicate factual knowledge into every model. Knowledge belongs in RAG / structured memory / graph stores and is supplied as context.

## 4. VQ / discrete memory

REFERENCE/vqvae.js is a state-coordinate VQ/VAE-style donor, NOT a finished image VQ-VAE.
Use vector quantization/discrete codes for compact reusable state/experience representations where appropriate. Do not claim it compresses sprite pixels unless an actual image encoder/decoder is implemented and tested.

## 5. DEG / Geo-DEG role

Adapt the ideas, not the chemistry application wholesale.

DEG-style:
examples -> recurring structural motifs -> grammar/production rules -> reusable function templates

Geo-DEG-style:
learned structures/functions -> reachable relational geometry -> routing/composition

External references:
- https://github.com/gmh14/data_efficient_grammar
- https://github.com/gmh14/Geo-DEG

## 6. 64-state binary substrate

A hexagram state is six binary line values: 2^6 = 64 states.
Represent BOTH concepts explicitly:
- `hexagramBits`: six binary values (or equivalent uint6/0..63 encoding)
- `lineIndex`: addressed line position 1..6

Do not conflate line POSITION (1..6) with line BIT VALUE (0/1).
If canonical gate numbers use King Wen ordering, maintain an explicit reversible gateNumber <-> sixBitPattern mapping. Do not assume gate number equals binary integer order.

## 7. Model Weaver Automaton

Model Weaver is the persistent neural-manufacturing automaton, not one neural network.

Required lifecycle:
OBSERVE -> CLASSIFY NEED -> SELECT/INDUCE FUNCTION -> STAMP -> TRAIN -> VALIDATE -> PACKAGE -> MOUNT -> MONITOR -> RETRAIN/REPLACE

It owns:
- architecture/template selection
- training evidence
- grammar provenance
- model lineage
- model manifests
- validation results
- promotion/rejection
- mount/unmount state
- replacement/retraining triggers

## 8. Training correctness

DO NOT use the recovered demo's random x/random y training as evidence of learning.
DO NOT use y=x*0.9 or y=x*0.95 synthetic targets as a production training objective.
DO NOT invent confidence, parameter count, model size, latency, or quality metrics.

Training must use real examples or an explicit deterministic self-supervised objective.

For the micro-language smoke test, use real text from project documentation as a tiny causal next-token dataset. The goal is pipeline proof, not intelligence claims.

For specialist models, use typed input/output examples from actual traces.

For morph/channel functions, use observed/verified source->target transitions or structured supervision.

Use train/validation separation when enough examples exist. Persist provenance for every training sample/batch.

## 9. Cartridge manifest

Every neural cartridge must have at minimum:
- cartridgeId
- name/version
- capability/type
- architecture family + config
- input/output contract
- tensor shapes/dtypes
- parameter count (measured)
- serialized size (measured)
- memory/latency metrics when measurable
- training-data/evidence provenance
- deterministic seed/build metadata
- validation metrics
- model artifact path/hash
- optional ONNX artifact path/hash
- Foundry glyph identity/lineage
- substrate bindings: dimension/gate/channel/etc when applicable
- compatible shared-base hash/version for adapters

## 10. Shared base + adapters

Where language specialization is needed, prefer:
shared micro-language base + small adapters/heads.

Specialization acceptance test:
1. hash/freeze shared base
2. stamp two adapters from the same adapter template
3. train each on different real tiny datasets
4. prove adapter weights diverge
5. prove shared base hash does not change
6. unload/reload each adapter
7. prove each still produces its own inference result

## 11. Promotion gates

A model/cartridge is NOT promoted because a file exists or the UI says success.
It must prove:
- architecture instantiates
- real training step changes intended trainable parameters
- validation/inference executes
- save succeeds
- unload succeeds
- reload succeeds
- post-reload inference matches pre-unload output within numeric tolerance for the same deterministic input
- manifest and hashes are written
- no existing Foundry behavior was broken

If an export format cannot represent the selected architecture correctly, report that gap; do not fake an ONNX file.

## 12. First-run scope

This integration run builds the FACTORY and proves it with tiny models.
It does NOT need to train a useful general-purpose LLM.
It does NOT need to implement full sprite morphing yet.
It DOES need to leave a clean interface through which the sprite morph engine can later submit transition examples and request stamped channel functions.
