import { pgTable, text, varchar, integer, bigint, timestamp, jsonb, bytea, primaryKey, index, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// Quality states enum
export const qualityStates = ["draft", "tested", "production"] as const;
export type QualityState = typeof qualityStates[number];

// Glyph types enum
export const glyphTypes = ["fragment", "app", "asset"] as const;
export type GlyphType = typeof glyphTypes[number];

// Fragment kinds enum
export const fragmentKinds = ["component", "logic", "style", "asset"] as const;
export type FragmentKind = typeof fragmentKinds[number];

// Producer info
export const producerSchema = z.object({
  tool: z.string(),
  host: z.string(),
  user: z.string(),
});
export type Producer = z.infer<typeof producerSchema>;

// Origin info with lineage
export const originSchema = z.object({
  parents: z.array(z.string()).default([]),
  recipe: z.string().optional(),
});
export type Origin = z.infer<typeof originSchema>;

// Signature info
export const signatureSchema = z.object({
  alg: z.string(),
  keyId: z.string(),
  sig: z.string(),
}).optional();
export type Signature = z.infer<typeof signatureSchema>;

// Glyph catalog table
export const glyphs = pgTable("glyph", {
  id: text("id").primaryKey(), // blake3:<hex>
  schemaVersion: integer("schema_version").notNull().default(1),
  type: text("type").notNull().$type<GlyphType>(),
  name: text("name").notNull(),
  quality: text("quality").notNull().$type<QualityState>().default("draft"),
  producedAt: timestamp("produced_at").notNull().defaultNow(),
  producer: jsonb("producer").notNull().$type<Producer>(),
  origin: jsonb("origin").$type<Origin>(),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull(),
  casSha256: text("cas_sha256").notNull(),
  casBucket: text("cas_bucket").notNull().default("default"),
  signAlg: text("sign_alg"),
  signKeyId: text("sign_key_id"),
  signSig: text("sign_sig"),
  language: text("language").default("ts"),
  kind: text("kind").$type<FragmentKind>(),
  entry: text("entry"),
  exports: jsonb("exports").$type<string[]>(),
  deps: jsonb("deps").$type<Record<string, string>>(),
});

// Lineage edges table
export const edges = pgTable("edge", {
  parentId: text("parent_id").notNull().references(() => glyphs.id),
  childId: text("child_id").notNull().references(() => glyphs.id),
  role: text("role").default("depends"),
}, (table) => ({
  pk: primaryKey({ columns: [table.parentId, table.childId] }),
  childIdx: index("edge_child_idx").on(table.childId),
}));

// Attestations / promotions table
export const attestations = pgTable("attestation", {
  id: varchar("id").primaryKey(),
  glyphId: text("glyph_id").notNull().references(() => glyphs.id),
  fromQuality: text("from_quality").$type<QualityState>(),
  toQuality: text("to_quality").$type<QualityState>(),
  signerKeyId: text("signer_key_id").notNull(),
  signature: text("signature").notNull(),
  evidenceUri: text("evidence_uri"),
  at: timestamp("at").notNull().defaultNow(),
});

// Recipes & locks table
export const recipes = pgTable("recipe", {
  glyphId: text("glyph_id").primaryKey().references(() => glyphs.id),
  body: jsonb("body").notNull(),
  lock: jsonb("lock").notNull(),
});

// Audit log table (append-only)
export const auditLogs = pgTable("audit", {
  id: varchar("id").primaryKey(),
  at: timestamp("at").notNull().defaultNow(),
  actor: text("actor").notNull(),
  action: text("action").notNull(),
  glyphId: text("glyph_id"),
  payload: jsonb("payload"),
}, (table) => ({
  actorIdx: index("audit_actor_idx").on(table.actor),
}));

// Insert schemas
export const insertGlyphSchema = createInsertSchema(glyphs).omit({ id: true });
export const insertEdgeSchema = createInsertSchema(edges);
export const insertAttestationSchema = createInsertSchema(attestations).omit({ id: true, at: true });
export const insertRecipeSchema = createInsertSchema(recipes);
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, at: true });

// Types
export type Glyph = typeof glyphs.$inferSelect;
export type InsertGlyph = z.infer<typeof insertGlyphSchema>;
export type Edge = typeof edges.$inferSelect;
export type InsertEdge = z.infer<typeof insertEdgeSchema>;
export type Attestation = typeof attestations.$inferSelect;
export type InsertAttestation = z.infer<typeof insertAttestationSchema>;
export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

// Dashboard stats type
export interface DashboardStats {
  totalGlyphs: number;
  draftCount: number;
  testedCount: number;
  productionCount: number;
  fragmentCount: number;
  appCount: number;
  recentBuilds: number;
  recentPromotions: number;
}

// Lineage node for graph visualization
export interface LineageNode {
  id: string;
  name: string;
  type: GlyphType;
  quality: QualityState;
}

export interface LineageEdge {
  source: string;
  target: string;
  role: string;
}

export interface LineageGraph {
  nodes: LineageNode[];
  edges: LineageEdge[];
}

// ═══════════════════════════════════════════════════════════════════════════════
// RESONANCE ENGINE - Human Design Alignment Scoring (Ra Uru Hu Canonical Math)
// ═══════════════════════════════════════════════════════════════════════════════

// Chart layer types
export const chartLayers = ["body", "mind", "heart"] as const;
export type ChartLayer = typeof chartLayers[number];

// Zodiac signs
export const zodiacSigns = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
] as const;
export type ZodiacSign = typeof zodiacSigns[number];

// Human Design Centers
export const hdCenters = [
  "Head", "Ajna", "Throat", "Identity", "Heart", "Spleen", "Sacral", "SolarPlexus", "Root"
] as const;
export type HDCenter = typeof hdCenters[number];

// Human Design Types
export const hdTypes = ["Manifestor", "Generator", "ManifestingGenerator", "Projector", "Reflector"] as const;
export type HDType = typeof hdTypes[number];

// HD Activation (Gate.Line.Color.Tone.Base)
export interface HDActivation {
  gate: number;       // 1-64
  line: number;       // 1-6
  color: number;      // 1-6
  tone: number;       // 1-6
  base: number;       // 1-5
  eclipticDeg: number; // 0-360
  sign: ZodiacSign;
  degree: number;
  minute: number;
  second: number;
}

// Birth data input
export interface BirthData {
  date: string;       // ISO date string
  time: string;       // HH:MM format
  timezone: string;   // e.g., "America/Los_Angeles"
  latitude: number;
  longitude: number;
  location: string;   // City, Country
}

// Natal Blueprint - Three chart layers
export interface NatalBlueprint {
  birthData: BirthData;
  body: ChartLayerData;   // Tropical
  mind: ChartLayerData;   // Sidereal (Fagan-Bradley)
  heart: ChartLayerData;  // Draconic
  hdType: HDType;
  definition: "Single" | "Split" | "TripleSplit" | "QuadrupleSplit" | "None";
  activatedChannels: number[];
  activatedCenters: HDCenter[];
}

// Chart layer data
export interface ChartLayerData {
  layer: ChartLayer;
  ayanamsa?: number;      // For sidereal
  nodeShift?: number;     // For draconic
  sun: HDActivation;
  moon: HDActivation;
  mercury: HDActivation;
  venus: HDActivation;
  mars: HDActivation;
  jupiter: HDActivation;
  saturn: HDActivation;
  uranus: HDActivation;
  neptune: HDActivation;
  pluto: HDActivation;
  northNode: HDActivation;
  southNode: HDActivation;
  ascendant: HDActivation;
  descendant: HDActivation;
  midheaven: HDActivation;
  imumCoeli: HDActivation;
}

// Field Misalignment Error Types
export interface MissingHarmonicNode {
  pairIdx: number;
  expected: number;
  actual: number;
  gap: number;
}

export interface ResonanceImbalance {
  bodies: [string, string];
  natalDiff: number;
  currentDiff: number;
  deviation: number;
}

export interface ChartDisorder {
  body: string;
  sidereal: number;
  tropical: number;
  draconic: number;
  variance: number;
  dominant?: ChartLayer;
}

// Field Diagnosis Result
export interface FieldDiagnosis {
  missingNodes: MissingHarmonicNode[];
  chargeImbalance: ResonanceImbalance[];
  chartDisorder: ChartDisorder[];
  coherenceScore: number;        // 0-100
  hdAlignment: number;           // 0-1
  iChingProbability: number;     // 0-1
  frictionFactor: number;        // 0-1
  resonanceScore: number;        // Calculated: (hdAlignment * iChingProbability) / frictionFactor
  approved: boolean;             // Score >= threshold
}

// Resonance Score Request
export interface ResonanceScoreRequest {
  birthData: BirthData;
  targetGlyphId?: string;        // Optional glyph to score alignment with
  groupMembers?: BirthData[];    // For group coherence scoring
}

// Resonance Score Response
export interface ResonanceScoreResponse {
  blueprint: NatalBlueprint;
  diagnosis: FieldDiagnosis;
  compositeSentence: string;
  correctionSentence?: string;
  recommendations: string[];
}

// Group Coherence Result
export interface GroupCoherence {
  members: NatalBlueprint[];
  sharedGates: number[];
  convergencePoints: Array<{
    gate: number;
    members: string[];
    layer: ChartLayer;
  }>;
  groupCoherenceScore: number;
  frictionPairs: Array<{
    member1: string;
    member2: string;
    frictionFactor: number;
    conflictingGates: number[];
  }>;
  synergyBonus: number;
  groupResonanceScore: number;
}

// I Ching Hexagram
export interface IChingHexagram {
  number: number;           // 1-64
  name: string;
  chineseName: string;
  lines: [boolean, boolean, boolean, boolean, boolean, boolean]; // 6 lines, yin=false, yang=true
  trigrams: {
    upper: string;
    lower: string;
  };
  meaning: string;
  hdGate: number;           // Corresponding HD gate
}

// Mandala Constants (Ra Uru Hu's original math)
export const MANDALA_CONSTANTS = {
  GATE_ARC: 5 + 37/60 + 30/3600,           // 5°37'30" per gate
  LINE_ARC: (5 + 37/60 + 30/3600) / 6,     // 0.9375° per line
  COLOR_ARC: (5 + 37/60 + 30/3600) / 36,   // 0.15625° per color
  TONE_ARC: (5 + 37/60 + 30/3600) / 216,   // 0.026041667° per tone
  BASE_ARC: (5 + 37/60 + 30/3600) / 1080,  // 0.005208333° per base
  FAGAN_BRADLEY_EPOCH: 1950,
  FAGAN_BRADLEY_BASE: 24 + 2/60 + 31/3600, // 24°02'31"
  PRECESSION_RATE: 50.2388475 / 3600,      // arcseconds/year to degrees
} as const;

// Gate sequence on the mandala (counter-clockwise from 0° Aries)
export const GATE_SEQUENCE: Array<{ start: number; gate: number }> = [
  { start: 0, gate: 25 }, { start: 3.875, gate: 17 }, { start: 9.5, gate: 21 },
  { start: 15.125, gate: 51 }, { start: 20.75, gate: 42 }, { start: 26.375, gate: 3 },
  { start: 32, gate: 27 }, { start: 37.625, gate: 24 }, { start: 43.25, gate: 2 },
  { start: 48.875, gate: 23 }, { start: 54.5, gate: 8 }, { start: 60.125, gate: 20 },
  { start: 65.75, gate: 16 }, { start: 71.375, gate: 35 }, { start: 77, gate: 45 },
  { start: 82.625, gate: 12 }, { start: 88.25, gate: 15 }, { start: 93.875, gate: 52 },
  { start: 99.5, gate: 39 }, { start: 105.125, gate: 53 }, { start: 110.75, gate: 62 },
  { start: 116.375, gate: 56 }, { start: 122, gate: 31 }, { start: 127.625, gate: 33 },
  { start: 133.25, gate: 7 }, { start: 138.875, gate: 4 }, { start: 144.5, gate: 29 },
  { start: 150.125, gate: 59 }, { start: 155.75, gate: 40 }, { start: 161.375, gate: 64 },
  { start: 167, gate: 47 }, { start: 172.625, gate: 6 }, { start: 178.25, gate: 46 },
  { start: 183.875, gate: 18 }, { start: 189.5, gate: 48 }, { start: 195.125, gate: 57 },
  { start: 200.75, gate: 32 }, { start: 206.375, gate: 50 }, { start: 212, gate: 28 },
  { start: 217.625, gate: 44 }, { start: 223.25, gate: 1 }, { start: 228.875, gate: 43 },
  { start: 234.5, gate: 14 }, { start: 240.125, gate: 34 }, { start: 245.75, gate: 9 },
  { start: 251.375, gate: 5 }, { start: 257, gate: 26 }, { start: 262.625, gate: 11 },
  { start: 268.25, gate: 10 }, { start: 273.875, gate: 58 }, { start: 279.5, gate: 38 },
  { start: 285.125, gate: 54 }, { start: 290.75, gate: 61 }, { start: 296.375, gate: 60 },
  { start: 302, gate: 41 }, { start: 307.625, gate: 19 }, { start: 313.25, gate: 13 },
  { start: 318.875, gate: 49 }, { start: 324.5, gate: 30 }, { start: 330.125, gate: 55 },
  { start: 335.75, gate: 37 }, { start: 341.375, gate: 63 }, { start: 347, gate: 22 },
  { start: 352.625, gate: 36 }, { start: 358.25, gate: 25 },
];

// Gate meanings for sentence generation
export const GATE_MEANINGS: Record<number, { name: string; theme: string; center: HDCenter }> = {
  1: { name: "Self-Expression", theme: "creative individuality", center: "Identity" },
  2: { name: "Direction", theme: "receptive knowing", center: "Identity" },
  3: { name: "Ordering", theme: "innovative mutation", center: "Sacral" },
  4: { name: "Answers", theme: "formulaic solutions", center: "Ajna" },
  5: { name: "Patterns", theme: "universal rhythms", center: "Sacral" },
  6: { name: "Friction", theme: "emotional conflict resolution", center: "SolarPlexus" },
  7: { name: "Role of the Self", theme: "logical leadership", center: "Identity" },
  8: { name: "Contribution", theme: "creative modeling", center: "Throat" },
  9: { name: "Focus", theme: "detailed concentration", center: "Sacral" },
  10: { name: "Behavior", theme: "self-love expression", center: "Identity" },
  11: { name: "Ideas", theme: "conceptual harmony", center: "Ajna" },
  12: { name: "Caution", theme: "articulated mutation", center: "Throat" },
  13: { name: "Listener", theme: "empathic gathering", center: "Identity" },
  14: { name: "Power Skills", theme: "abundant direction", center: "Sacral" },
  15: { name: "Extremes", theme: "rhythmic diversity", center: "Identity" },
  16: { name: "Skills", theme: "enthusiastic experimentation", center: "Throat" },
  17: { name: "Opinions", theme: "logical following", center: "Ajna" },
  18: { name: "Correction", theme: "judgmental perfection", center: "Spleen" },
  19: { name: "Wanting", theme: "sensitive approach", center: "Root" },
  20: { name: "Now", theme: "present contemplation", center: "Throat" },
  21: { name: "Hunter", theme: "controlling ego", center: "Heart" },
  22: { name: "Openness", theme: "emotional grace", center: "SolarPlexus" },
  23: { name: "Assimilation", theme: "verbal translation", center: "Throat" },
  24: { name: "Rationalization", theme: "mental return", center: "Ajna" },
  25: { name: "Spirit", theme: "innocent love", center: "Identity" },
  26: { name: "Taming Power", theme: "egoist salesmanship", center: "Heart" },
  27: { name: "Nourishment", theme: "caring preservation", center: "Sacral" },
  28: { name: "Game Player", theme: "purposeful risk", center: "Spleen" },
  29: { name: "Perseverance", theme: "committed saying yes", center: "Sacral" },
  30: { name: "Feelings", theme: "fiery desire", center: "SolarPlexus" },
  31: { name: "Influence", theme: "democratic leadership", center: "Throat" },
  32: { name: "Continuity", theme: "transformative endurance", center: "Spleen" },
  33: { name: "Privacy", theme: "reflective retreat", center: "Throat" },
  34: { name: "Power", theme: "pure sacral response", center: "Sacral" },
  35: { name: "Change", theme: "adventurous progress", center: "Throat" },
  36: { name: "Crisis", theme: "emotional inexperience", center: "SolarPlexus" },
  37: { name: "Friendship", theme: "family bargains", center: "SolarPlexus" },
  38: { name: "Fighter", theme: "stubborn opposition", center: "Root" },
  39: { name: "Provocation", theme: "emotional tension", center: "Root" },
  40: { name: "Aloneness", theme: "willful deliverance", center: "Heart" },
  41: { name: "Decrease", theme: "contracting fantasy", center: "Root" },
  42: { name: "Increase", theme: "completing cycles", center: "Sacral" },
  43: { name: "Insight", theme: "breakthrough awareness", center: "Ajna" },
  44: { name: "Alertness", theme: "pattern recognition", center: "Spleen" },
  45: { name: "Gatherer", theme: "monarchic gathering", center: "Throat" },
  46: { name: "Love of Body", theme: "serendipitous discovery", center: "Identity" },
  47: { name: "Realization", theme: "oppressive abstraction", center: "Ajna" },
  48: { name: "Depth", theme: "fearful inadequacy", center: "Spleen" },
  49: { name: "Revolution", theme: "principled rejection", center: "SolarPlexus" },
  50: { name: "Values", theme: "responsible guardianship", center: "Spleen" },
  51: { name: "Shock", theme: "competitive initiative", center: "Heart" },
  52: { name: "Stillness", theme: "concentrated inaction", center: "Root" },
  53: { name: "Beginnings", theme: "developmental pressure", center: "Root" },
  54: { name: "Ambition", theme: "driving ascension", center: "Root" },
  55: { name: "Spirit", theme: "emotional abundance", center: "SolarPlexus" },
  56: { name: "Stimulation", theme: "storytelling wanderer", center: "Throat" },
  57: { name: "Intuition", theme: "gentle penetration", center: "Spleen" },
  58: { name: "Vitality", theme: "joyous correction", center: "Root" },
  59: { name: "Sexuality", theme: "intimate dispersion", center: "Sacral" },
  60: { name: "Limitation", theme: "accepting mutation", center: "Root" },
  61: { name: "Mystery", theme: "inner truth pressure", center: "Head" },
  62: { name: "Details", theme: "careful expression", center: "Throat" },
  63: { name: "Doubt", theme: "logical questioning", center: "Head" },
  64: { name: "Confusion", theme: "mental pressure", center: "Head" },
};

// ═══════════════════════════════════════════════════════════════════════════════
// SELF-EVOLUTION ENGINE - User-Gated Evolution System
// ═══════════════════════════════════════════════════════════════════════════════

// Evolution stages
export const evolutionStages = ["analyzing", "proposing", "awaiting_approval", "applying", "completed", "rejected"] as const;
export type EvolutionStage = typeof evolutionStages[number];

// Evolution types
export const evolutionTypes = ["feature", "ui", "performance", "component", "page", "integration"] as const;
export type EvolutionType = typeof evolutionTypes[number];

// Evolution priority
export const evolutionPriorities = ["critical", "high", "medium", "low"] as const;
export type EvolutionPriority = typeof evolutionPriorities[number];

// Proposed improvement
export interface ProposedImprovement {
  id: string;
  type: EvolutionType;
  priority: EvolutionPriority;
  title: string;
  description: string;
  benefit: string;
  implementation: string;
  estimatedComplexity: number;
  affectedComponents: string[];
  resonanceImpact: number;
}

// Evolution proposal
export interface EvolutionProposal {
  id: string;
  stage: EvolutionStage;
  createdAt: string;
  updatedAt: string;
  version: string;
  currentFeatures: string[];
  improvements: ProposedImprovement[];
  selectedImprovement?: ProposedImprovement;
  generatedCode?: string;
  overseerDecision?: {
    approved: boolean;
    resonanceScore: number;
    coherenceScore: number;
    reasoning: string[];
    frozen: boolean;
  };
  userApproval?: {
    approved: boolean;
    approvedAt?: string;
    rejectedAt?: string;
    reason?: string;
  };
  applicationResult?: {
    success: boolean;
    artifactId?: string;
    error?: string;
    appliedAt: string;
  };
}

// Evolution history entry
export interface EvolutionHistoryEntry {
  id: string;
  version: string;
  improvement: ProposedImprovement;
  appliedAt: string;
  artifactId: string;
  rollbackAvailable: boolean;
}

// Evolution analysis request
export interface EvolutionAnalysisRequest {
  targetScope?: "glyphs" | "pages" | "system" | "all";
  includeResonanceCheck: boolean;
}

// Evolution analysis response
export interface EvolutionAnalysisResponse {
  proposalId: string;
  stage: EvolutionStage;
  currentFeatures: string[];
  improvements: ProposedImprovement[];
  systemHealth: {
    totalComponents: number;
    testedComponents: number;
    productionComponents: number;
    resonanceAverage: number;
  };
}

// User approval request
export interface UserApprovalRequest {
  proposalId: string;
  improvementId: string;
  approved: boolean;
  reason?: string;
}

// Evolution application request
export interface EvolutionApplicationRequest {
  proposalId: string;
  improvementId: string;
  dryRun?: boolean;
}


// ============================================================
// RESONANCE NETWORK (Pathways to Purpose) — domain layer
// ============================================================

// Human Design Energy Types
export const EnergyType = z.enum([
  "manifestor",
  "generator", 
  "manifesting_generator",
  "projector",
  "reflector"
]);
export type EnergyType = z.infer<typeof EnergyType>;

// Human Design Strategy
export const Strategy = z.enum([
  "inform",
  "wait_to_respond",
  "wait_for_invitation",
  "wait_lunar_cycle"
]);
export type Strategy = z.infer<typeof Strategy>;

// Program Week Phase
export const ProgramPhase = z.enum([
  "discovery",
  "assessment", 
  "placement",
  "activation",
  "optimization",
  "sustain"
]);
export type ProgramPhase = z.infer<typeof ProgramPhase>;

// Role assignments based on energy
export const GroupRole = z.enum([
  "initiator",
  "builder", 
  "amplifier",
  "advisor",
  "synthesizer",
  "stabilizer"
]);
export type GroupRole = z.infer<typeof GroupRole>;

// I Ching Hexagram base structure
export const HexagramLineSchema = z.enum(["yin", "yang", "changing_yin", "changing_yang"]);
export type HexagramLine = z.infer<typeof HexagramLineSchema>;

// Birth data for HD calculation
export const NetworkBirthDataSchema = z.object({
  year: z.number().min(1900).max(2100),
  month: z.number().min(1).max(12),
  day: z.number().min(1).max(31),
  hour: z.number().min(0).max(23),
  minute: z.number().min(0).max(59),
  timezone: z.string()
});
export type NetworkBirthData = z.infer<typeof NetworkBirthDataSchema>;

// Human Design Profile
export const HumanDesignProfileSchema = z.object({
  type: EnergyType,
  strategy: Strategy,
  authority: z.string(),
  profile: z.string(),
  definedCenters: z.array(z.string()),
  openCenters: z.array(z.string()),
  gates: z.array(z.number().min(1).max(64)),
  channels: z.array(z.string())
});
export type HumanDesignProfile = z.infer<typeof HumanDesignProfileSchema>;

// I Ching Hexagram
export const HexagramSchema = z.object({
  number: z.number().min(1).max(64),
  name: z.string(),
  chineseName: z.string(),
  meaning: z.string(),
  lines: z.array(HexagramLineSchema).length(6),
  judgment: z.string(),
  image: z.string()
});
export type Hexagram = z.infer<typeof HexagramSchema>;

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  email: text("email"),
  birthData: jsonb("birth_data").$type<NetworkBirthData>(),
  hdProfile: jsonb("hd_profile").$type<HumanDesignProfile>(),
  interests: text("interests").array(),
  skills: text("skills").array(),
  resonanceScore: real("resonance_score").default(50),
  createdAt: timestamp("created_at").defaultNow()
});

// Custom schema for user creation from form
export const insertUserSchema = z.object({
  username: z.string().min(3),
  displayName: z.string().min(2),
  email: z.string().email().optional().or(z.literal("")),
  birthData: NetworkBirthDataSchema.optional(),
  interests: z.array(z.string()).optional(),
  skills: z.array(z.string()).optional(),
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Groups table
export const groups = pgTable("groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  niche: text("niche").notNull(),
  phase: text("phase").notNull().default("discovery"),
  resonanceScore: real("resonance_score").default(50),
  dailyTarget: real("daily_target").default(100),
  totalEarnings: real("total_earnings").default(0),
  memberIds: text("member_ids").array(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  createdAt: true
});
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Group = typeof groups.$inferSelect;

// Group Memberships with roles
export const memberships = pgTable("memberships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  groupId: varchar("group_id").notNull(),
  role: text("role").notNull(),
  roleFitScore: real("role_fit_score").default(0),
  contributionScore: real("contribution_score").default(0),
  joinedAt: timestamp("joined_at").defaultNow()
});

export const insertMembershipSchema = createInsertSchema(memberships).omit({
  id: true,
  joinedAt: true
});
export type InsertMembership = z.infer<typeof insertMembershipSchema>;
export type Membership = typeof memberships.$inferSelect;

// I Ching Castings
export const castings = pgTable("castings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  groupId: varchar("group_id"),
  hexagram: jsonb("hexagram").$type<Hexagram>(),
  question: text("question"),
  interpretation: text("interpretation"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertCastingSchema = createInsertSchema(castings).omit({
  id: true,
  createdAt: true
});
export type InsertCasting = z.infer<typeof insertCastingSchema>;
export type Casting = typeof castings.$inferSelect;

// Resonance Matches
export const matches = pgTable("matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  user1Id: varchar("user1_id").notNull(),
  user2Id: varchar("user2_id").notNull(),
  resonanceScore: real("resonance_score").notNull(),
  synergyFactors: jsonb("synergy_factors").$type<string[]>(),
  frictionFactors: jsonb("friction_factors").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true
});
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// Financial Opportunities
export const opportunities = pgTable("opportunities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  targetAmount: real("target_amount").notNull(),
  currentAmount: real("current_amount").default(0),
  synergyBonus: real("synergy_bonus").default(0),
  status: text("status").default("active"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertOpportunitySchema = createInsertSchema(opportunities).omit({
  id: true,
  createdAt: true
});
export type InsertOpportunity = z.infer<typeof insertOpportunitySchema>;
export type Opportunity = typeof opportunities.$inferSelect;

// Static data for I Ching
export const HEXAGRAM_DATA: Record<number, { name: string; chineseName: string; meaning: string; judgment: string; image: string }> = {
  1: { name: "The Creative", chineseName: "Qian", meaning: "Pure yang energy, creative force", judgment: "The Creative works sublime success, furthering through perseverance.", image: "Heaven above heaven - the creative force doubled" },
  2: { name: "The Receptive", chineseName: "Kun", meaning: "Pure yin energy, nurturing force", judgment: "The Receptive brings sublime success, perseverance of a mare.", image: "Earth above earth - the receptive nature" },
  3: { name: "Difficulty at the Beginning", chineseName: "Zhun", meaning: "Initial struggles lead to growth", judgment: "Success through perseverance. Appoint helpers.", image: "Water over thunder - chaos before order" },
  11: { name: "Peace", chineseName: "Tai", meaning: "Harmony between heaven and earth", judgment: "The small departs, the great approaches. Success.", image: "Earth over heaven - perfect balance" },
  15: { name: "Modesty", chineseName: "Qian", meaning: "Humility brings success", judgment: "The modest person has good fortune.", image: "Earth over mountain - a hidden treasure" },
  23: { name: "Splitting Apart", chineseName: "Bo", meaning: "Dissolution and decay", judgment: "It does not further to go anywhere.", image: "Mountain over earth - erosion and collapse" },
  40: { name: "Deliverance", chineseName: "Jie", meaning: "Release from tension", judgment: "Swift return brings good fortune.", image: "Thunder over water - liberation" },
  58: { name: "The Joyous", chineseName: "Dui", meaning: "Joy through connection", judgment: "The joyous succeeds through perseverance.", image: "Lake over lake - shared joy multiplies" },
  64: { name: "Before Completion", chineseName: "Wei Ji", meaning: "Transition point, almost there", judgment: "Success in small matters.", image: "Fire over water - opposites in tension" }
};

// Human Design Centers
export const HD_CENTERS = [
  "Head", "Ajna", "Throat", "G-Center", "Heart/Will", 
  "Sacral", "Solar Plexus", "Spleen", "Root"
] as const;

// Energy type descriptions
export const ENERGY_TYPE_INFO: Record<EnergyType, { description: string; strategy: string; strengths: string[] }> = {
  manifestor: {
    description: "Pure initiators who start things and make an impact",
    strategy: "Inform before acting",
    strengths: ["Starting new projects", "Breaking patterns", "Independence"]
  },
  generator: {
    description: "Builders with sustainable life force energy",
    strategy: "Wait to respond",
    strengths: ["Sustained work", "Mastery", "Satisfaction when aligned"]
  },
  manifesting_generator: {
    description: "Multi-passionate builders who initiate and respond",
    strategy: "Wait to respond, then inform",
    strengths: ["Multi-tasking", "Speed", "Finding shortcuts"]
  },
  projector: {
    description: "Guides who see systems and direct energy",
    strategy: "Wait for the invitation",
    strengths: ["Managing others", "System insight", "Efficiency"]
  },
  reflector: {
    description: "Mirrors who sample and reflect group energy",
    strategy: "Wait a lunar cycle",
    strengths: ["Reading environments", "Wisdom", "Objectivity"]
  }
};

// Role descriptions
export const ROLE_INFO: Record<GroupRole, { description: string; bestFor: EnergyType[] }> = {
  initiator: {
    description: "Starts new ventures and creates momentum",
    bestFor: ["manifestor", "manifesting_generator"]
  },
  builder: {
    description: "Does sustained work to bring ideas to life",
    bestFor: ["generator", "manifesting_generator"]
  },
  amplifier: {
    description: "Increases group energy and visibility",
    bestFor: ["generator", "projector"]
  },
  advisor: {
    description: "Provides guidance and strategic direction",
    bestFor: ["projector"]
  },
  synthesizer: {
    description: "Connects ideas and sees the big picture",
    bestFor: ["projector", "reflector"]
  },
  stabilizer: {
    description: "Maintains harmony and consistent output",
    bestFor: ["generator", "reflector"]
  }
};
