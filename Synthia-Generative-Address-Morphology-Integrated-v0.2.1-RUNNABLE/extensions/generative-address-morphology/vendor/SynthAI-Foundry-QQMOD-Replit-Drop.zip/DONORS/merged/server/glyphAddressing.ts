/**
 * GLYPH ADDRESSING — bridges a Foundry glyph (a code fragment/app/asset)
 * to the real gate.line.color.tone.base address space and mirrors it
 * into Supabase (code_drops -> system_graph -> morph_addresses -> os_glyphs).
 *
 * IMPORTANT — what this does NOT do:
 * It does not compute gate/line/color/tone/base from ephemeris degrees.
 * That math (address_space_engine.py / address_resolver.py) is for birth
 * charts, which have a real degree position. A code fragment has no degree —
 * its address has to come from *semantic classification* of what the
 * fragment actually does, checked against the verified gate-keyword table.
 *
 * That table isn't loaded here yet (gate_neural_ops in Supabase exists but
 * is empty — 0 rows as of this build). So `classifyGateFromBehavior` below
 * is a STUB. It throws on purpose. Wire it to the real table before this
 * goes further than manual/placeholder addressing.
 */
import { supabase } from "./supabaseClient";
import { DIMENSIONS, type Dimension } from "../glyphGenerator"; // real dimension symbols, no emoji

export interface FragmentAnalysis {
  filename: string;
  language: string;
  purposeSummary: string;
  detectedCapabilities: string[];
  dependencies: string[];
}

export interface AssignedAddress {
  gate: number | null;      // null until classifyGateFromBehavior is real
  line: number | null;
  color: number | null;
  tone: number | null;
  base: number | null;
  dimension: keyof typeof DIMENSIONS | null;
  ontologicalAddress: string; // "gate.line.color.tone.base.dimension" or partial
  glyphSymbol: string | null; // from glyphGenerator.ts, e.g. '⟡'
}

/**
 * STUB — do not treat this as real. It exists so the pipeline shape is
 * correct end-to-end, but every gate it returns is a placeholder (always
 * null) until it's wired to the verified gate_neural_ops keyword table.
 */
function classifyGateFromBehavior(_analysis: FragmentAnalysis): {
  gate: number | null;
  line: number | null;
  color: number | null;
  tone: number | null;
  base: number | null;
  dimension: keyof typeof DIMENSIONS | null;
} {
  // Intentionally unimplemented — see file header.
  return { gate: null, line: null, color: null, tone: null, base: null, dimension: null };
}

export function assignAddress(analysis: FragmentAnalysis): AssignedAddress {
  const { gate, line, color, tone, base, dimension } = classifyGateFromBehavior(analysis);

  const parts = [gate, line, color, tone, base].map(v => (v === null ? "0" : String(v)));
  const ontologicalAddress = `${parts.join(".")}.${dimension ?? "?"}`;

  const glyphSymbol = dimension ? DIMENSIONS[dimension]?.symbol ?? null : null;

  return { gate, line, color, tone, base, dimension, ontologicalAddress, glyphSymbol };
}

/**
 * Mirrors a locally-created Foundry glyph into the shared Supabase tables
 * so the Resonance Network and glyph game can see it too. Additive only —
 * never deletes or overwrites existing rows in those tables.
 */
export async function mirrorGlyphToSupabase(params: {
  localGlyphId: string; // the local blake3/hash id, kept for cross-reference
  analysis: FragmentAnalysis;
  address: AssignedAddress;
  rawContent?: string;
}) {
  if (!supabase) {
    console.warn("[glyphAddressing] Supabase not configured — skipping mirror for", params.localGlyphId);
    return null;
  }

  const { analysis, address, rawContent, localGlyphId } = params;

  // 1. code_drops — the raw ingestion record
  const { data: drop, error: dropErr } = await supabase
    .from("code_drops")
    .insert({
      filename: analysis.filename,
      content_hash: localGlyphId,
      language: analysis.language,
      detected_capabilities: analysis.detectedCapabilities,
      recommended_mode: null,
      confidence: address.gate === null ? 0 : 0.5, // honest: low confidence until real classification exists
      ontological_address: address.ontologicalAddress,
      status: address.gate === null ? "analyzed" : "addressed",
    })
    .select()
    .single();

  if (dropErr) {
    console.error("[glyphAddressing] code_drops insert failed:", dropErr.message);
    return null;
  }

  // 2. system_graph — registry node, unique on ontological_address
  const { error: graphErr } = await supabase
    .from("system_graph")
    .insert({
      code_drop_id: drop.id,
      node_name: analysis.filename,
      node_type: "foundry_glyph",
      ontological_address: address.ontologicalAddress,
      capabilities: analysis.detectedCapabilities,
      health_status: "healthy",
    });
  if (graphErr && !graphErr.message.includes("duplicate")) {
    console.error("[glyphAddressing] system_graph insert failed:", graphErr.message);
  }

  // 3. morph_addresses — only insert real gate data once classification is real
  let addressRowId: string | null = null;
  if (address.gate !== null) {
    const { data: addrRow, error: addrErr } = await supabase
      .from("morph_addresses")
      .insert({
        entity_type: "foundry_glyph",
        entity_id: localGlyphId,
        gate: address.gate,
        line: address.line,
        color: address.color,
        tone: address.tone,
        base: address.base,
        dimension: address.dimension,
        source: "foundry-glyphs",
      })
      .select()
      .single();
    if (addrErr) {
      console.error("[glyphAddressing] morph_addresses insert failed:", addrErr.message);
    } else {
      addressRowId = addrRow.id;
    }
  }

  // 4. os_glyphs — the glyph record itself, symbol from glyphGenerator.ts (no emoji)
  const { error: glyphErr } = await supabase
    .from("os_glyphs")
    .insert({
      artifact_id: null,
      address_id: addressRowId,
      glyph_key: localGlyphId,
      glyph_type: "foundry_fragment",
      dimension: address.dimension,
      entry_point: analysis.filename,
      confidence: address.gate === null ? 0 : 0.5,
      content: address.glyphSymbol,
    });
  if (glyphErr) {
    console.error("[glyphAddressing] os_glyphs insert failed:", glyphErr.message);
  }

  return { dropId: drop.id, addressRowId };
}
