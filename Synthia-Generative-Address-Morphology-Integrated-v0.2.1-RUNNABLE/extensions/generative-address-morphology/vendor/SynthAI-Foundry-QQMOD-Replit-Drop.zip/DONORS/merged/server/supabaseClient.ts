/**
 * Supabase link for Foundry-Glyphs.
 * Points at the SynthAi Foundry Official project (already provisioned,
 * already has the real tables: code_drops, system_graph, morph_addresses, os_glyphs).
 * This does NOT replace the local Drizzle schema (glyph/edge/attestation/recipe/audit) —
 * those stay as-is per "don't take anything out." This is additive: every glyph
 * created locally also gets mirrored into the shared Supabase tables so the
 * Resonance Network and glyph game can see it too.
 */
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.SUPABASE_URL || "https://leisphnjslcuepflefri.supabase.co";
const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY; // set this in env — do not hardcode the real key here

if (!SUPABASE_KEY) {
  console.warn("[supabaseClient] SUPABASE_ANON_KEY not set — Supabase mirroring is disabled until it is.");
}

export const supabase = SUPABASE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_KEY)
  : null;
