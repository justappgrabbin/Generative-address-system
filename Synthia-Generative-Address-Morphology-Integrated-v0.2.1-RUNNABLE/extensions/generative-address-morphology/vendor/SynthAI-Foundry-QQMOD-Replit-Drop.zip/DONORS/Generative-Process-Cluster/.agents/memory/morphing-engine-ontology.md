---
name: Morphing engine ontology
description: The user's intended computational hierarchy and product framing for the morphing engine.
---

The morphing engine should present Human Design as an internal structural metaphor, not as an astrology product. Fixed primitives or templates combine into increasingly capable computational jobs; the user’s successful outcomes are meaningful inputs that help the system evolve. Bigrams are the smallest inputs, trigrams are intermediate compositions, hexagrams are the fixed state variables, channels are edge functions, and combinations of channels create emergent capabilities.

**Why:** The user explicitly corrected the initial astrology-forward interpretation and wants a normal, practical app that can eventually help build software, games, writing tools, and other things.

**How to apply:** Keep planetary, zodiac, and esoteric terminology out of the primary UI and conversational voice. Use plain product language such as primitives, jobs, state variables, channels, results, and emergent capabilities.