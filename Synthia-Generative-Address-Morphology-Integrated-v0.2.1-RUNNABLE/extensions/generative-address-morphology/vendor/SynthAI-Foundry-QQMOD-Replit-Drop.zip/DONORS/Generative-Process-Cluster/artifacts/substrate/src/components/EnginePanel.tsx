import { useState } from 'react';
import type { Gate, Win, Channel, Emergent } from '@workspace/api-client-react';
import { HexagramIcon } from './ZodiacWheel';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

function getGateColor(level: number): string {
  if (level === 0) return 'rgba(26, 42, 58, 0.5)';
  if (level <= 2) return 'rgba(26, 42, 58, 0.7)';
  if (level <= 5) return '#1e4d6b';
  if (level <= 8) return '#0ea5e9';
  if (level <= 11) return '#f59e0b';
  return '#fef3c7';
}

export const EnginePanel = ({ 
  gates,
  wins,
  channels,
  emergents,
  selectedGateNumber,
  setSelectedGateNumber,
  onLogWin,
  onUpdateIntention,
  isLoggingWin,
}: { 
  gates: Gate[];
  wins: Win[];
  channels: Channel[];
  emergents: Emergent[];
  selectedGateNumber: number | null;
  setSelectedGateNumber: (n: number | null) => void;
  onLogWin: (gateNumber: number, description: string) => Promise<any>;
  onUpdateIntention: (gateNumber: number, intention: string) => Promise<any>;
  isLoggingWin: boolean;
}) => {
  const [winDescription, setWinDescription] = useState('');
  const [winStep, setWinStep] = useState<'description' | 'selectGate'>('description');
  const { toast } = useToast();

  const selectedGate = gates.find(g => g.gateNumber === selectedGateNumber);

  const handleLogWin = async () => {
    if (!winDescription.trim()) {
      toast({ title: 'Enter a win description', variant: 'destructive' });
      return;
    }
    
    if (winStep === 'description') {
      setWinStep('selectGate');
      return;
    }

    if (!selectedGateNumber) {
      toast({ title: 'Select a gate', variant: 'destructive' });
      return;
    }

    try {
      const result = await onLogWin(selectedGateNumber, winDescription);
      
      toast({ 
        title: `Gate ${selectedGateNumber} → Level ${result.gate.level}`,
        description: result.channelActivated 
          ? 'CHANNEL ACTIVATED' 
          : result.emergentTriggered 
            ? 'EMERGENT TRIGGERED'
            : `+1 level`,
      });

      setWinDescription('');
      setWinStep('description');
      setSelectedGateNumber(null);
    } catch (err) {
      toast({ title: 'Failed to log win', variant: 'destructive' });
    }
  };

  const handleUpdateIntention = async (intention: string) => {
    if (!selectedGateNumber) return;
    
    try {
      await onUpdateIntention(selectedGateNumber, intention);
      toast({ title: 'Intention saved' });
    } catch (err) {
      toast({ title: 'Failed to save intention', variant: 'destructive' });
    }
  };

  const activeChannels = channels.filter(c => c.status === 'active' || c.status === 'firing');

  return (
    <div className="w-[35%] h-full bg-card/80 backdrop-blur-xl border-l border-border flex flex-col overflow-hidden shadow-2xl relative z-20">
      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {/* Win Logger */}
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground uppercase tracking-widest border-b border-border pb-2">
              Log Win
            </div>
            
            {winStep === 'description' ? (
              <div className="space-y-3">
                <Textarea
                  data-testid="input-win-description"
                  placeholder="Describe your win..."
                  value={winDescription}
                  onChange={(e) => setWinDescription(e.target.value)}
                  className="min-h-[100px] bg-background/50 border-border text-foreground resize-none"
                />
                <Button 
                  data-testid="button-next-step"
                  onClick={handleLogWin}
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={!winDescription.trim()}
                >
                  Next: Select Gate
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-sm text-muted-foreground p-3 bg-background/50 rounded border border-border">
                  {winDescription}
                </div>
                
                <div className="grid grid-cols-8 gap-1">
                  {gates.map(gate => (
                    <button
                      key={gate.gateNumber}
                      data-testid={`button-select-gate-${gate.gateNumber}`}
                      onClick={() => setSelectedGateNumber(gate.gateNumber)}
                      className="aspect-square flex items-center justify-center text-[10px] font-bold rounded transition-all border-2"
                      style={{
                        backgroundColor: getGateColor(gate.level),
                        borderColor: selectedGateNumber === gate.gateNumber ? '#ffffff' : 'transparent',
                        opacity: selectedGateNumber === gate.gateNumber ? 1 : 0.7,
                      }}
                    >
                      {gate.gateNumber}
                    </button>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Button 
                    data-testid="button-back"
                    onClick={() => setWinStep('description')}
                    variant="outline"
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button 
                    data-testid="button-log-win"
                    onClick={handleLogWin}
                    className="flex-1 bg-primary hover:bg-primary/90"
                    disabled={!selectedGateNumber || isLoggingWin}
                  >
                    {isLoggingWin ? 'Logging...' : 'Log Win'}
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Active Channels */}
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground uppercase tracking-widest border-b border-border pb-2">
              Active Channels
            </div>
            
            {activeChannels.length === 0 ? (
              <div className="text-xs text-muted-foreground italic p-3 bg-background/30 rounded">
                No active channels yet — log wins to activate gates
              </div>
            ) : (
              <div className="space-y-2">
                {activeChannels.map((ch, i) => (
                  <div 
                    key={i}
                    data-testid={`channel-${ch.gateA}-${ch.gateB}`}
                    className="text-xs bg-background/50 border border-border p-3 rounded space-y-2 relative overflow-hidden"
                  >
                    <div 
                      className="absolute top-0 left-0 w-full h-full pointer-events-none"
                      style={{
                        backgroundColor: ch.status === 'firing' ? '#f59e0b' : '#0ea5e9',
                        opacity: ch.status === 'firing' ? 0.1 : 0.05,
                      }}
                    />
                    
                    <div className="flex justify-between items-center z-10 relative">
                      <span className="font-bold">G{ch.gateA} ↔ G{ch.gateB}</span>
                      <span 
                        className="text-[10px] px-2 py-0.5 rounded font-bold"
                        style={{
                          backgroundColor: ch.status === 'firing' ? '#f59e0b' : '#0ea5e9',
                          color: '#000',
                        }}
                      >
                        {ch.status === 'firing' ? 'FIRING' : 'ACTIVE'}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center z-10 relative">
                      <span className="text-muted-foreground">{ch.channelName}</span>
                      <HexagramIcon binary={ch.edgeOutput} size={14} />
                    </div>
                    
                    {ch.edgeOutputGate && (
                      <div className="text-[10px] text-green-400 z-10 relative">
                        Output resonates with Gate {ch.edgeOutputGate}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Gate Intention Editor */}
          {selectedGate && (
            <div className="space-y-3 p-4 border border-primary/30 rounded bg-primary/5 animate-in fade-in slide-in-from-right-4">
              <div className="text-xs text-muted-foreground uppercase tracking-widest border-b border-border pb-2">
                Gate {selectedGate.gateNumber} Intention
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Level</span>
                  <span className="text-sm font-bold" style={{ color: getGateColor(selectedGate.level) }}>
                    {selectedGate.level} / 12
                  </span>
                </div>
                
                <div className="w-full h-2 bg-background/50 rounded-full overflow-hidden">
                  <div 
                    className="h-full transition-all duration-500"
                    style={{
                      width: `${(selectedGate.level / 12) * 100}%`,
                      backgroundColor: getGateColor(selectedGate.level),
                    }}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <div className="text-muted-foreground">Upper Trigram</div>
                    <div className="font-mono">{selectedGate.upperTrigramName}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Lower Trigram</div>
                    <div className="font-mono">{selectedGate.lowerTrigramName}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Bigram Count</div>
                    <div className="font-mono">{selectedGate.bigramCount}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Binary</div>
                    <div className="font-mono">{selectedGate.binaryState}</div>
                  </div>
                </div>

                <Input
                  data-testid="input-gate-intention"
                  placeholder="Set your intention for this gate..."
                  defaultValue={selectedGate.intention || ''}
                  onBlur={(e) => {
                    if (e.target.value !== selectedGate.intention) {
                      handleUpdateIntention(e.target.value);
                    }
                  }}
                  className="bg-background/50 border-border text-foreground"
                />
              </div>
            </div>
          )}

          {/* Win Feed */}
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground uppercase tracking-widest border-b border-border pb-2">
              Recent Wins
            </div>
            
            {wins.length === 0 ? (
              <div className="text-xs text-muted-foreground italic p-3 bg-background/30 rounded">
                No wins logged yet
              </div>
            ) : (
              <div className="space-y-2">
                {wins.slice(0, 10).map(win => (
                  <div 
                    key={win.id}
                    data-testid={`win-${win.id}`}
                    className="text-xs bg-background/50 border border-border p-2 rounded space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <HexagramIcon binary={win.bigramValue.padStart(6, '0')} size={12} />
                        <span className="font-bold">Gate {win.gateNumber}</span>
                      </div>
                      <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded">
                        L{win.levelBefore} → L{win.levelAfter}
                      </span>
                    </div>
                    <div className="text-muted-foreground">{win.description}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Emergent History */}
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground uppercase tracking-widest border-b border-border pb-2">
              Emergent Events
            </div>
            
            {emergents.length === 0 ? (
              <div className="text-xs text-muted-foreground italic p-3 bg-background/30 rounded">
                No emergent events yet
              </div>
            ) : (
              <div className="space-y-2">
                {emergents.slice(0, 5).map(em => (
                  <div 
                    key={em.id}
                    data-testid={`emergent-${em.id}`}
                    className="text-xs p-3 rounded border-2"
                    style={{
                      backgroundColor: em.type === 'messi' ? 'rgba(251, 191, 36, 0.1)' : 'rgba(124, 58, 237, 0.1)',
                      borderColor: em.type === 'messi' ? '#fbbf24' : '#7c3aed',
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span 
                        className="font-bold uppercase"
                        style={{ color: em.type === 'messi' ? '#fbbf24' : '#7c3aed' }}
                      >
                        {em.type === 'messi' ? 'MESSI FLOW' : 'AUTO NOVEL'}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        Gate {em.sharedGate}
                      </span>
                    </div>
                    <div className="text-muted-foreground">{em.description}</div>
                    <div className="text-[10px] text-muted-foreground mt-1">
                      [{em.channelAGates.join('-')}] × [{em.channelBGates.join('-')}]
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};
