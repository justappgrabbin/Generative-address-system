// Morphing Engine — core computation for the ontological substrate
// Bigrams → Trigrams → Hexagrams → Channels (edge functions) → Emergents

import type { Gate } from "@workspace/db";

// ─── Hexagram binary states (King Wen sequence) ───────────────────────────────
export const HEXAGRAMS: Record<number, string> = {
  1: "111111", 2: "000000", 3: "100010", 4: "010001",
  5: "111010", 6: "010111", 7: "010000", 8: "000010",
  9: "111011", 10: "110111", 11: "111000", 12: "000111",
  13: "101111", 14: "111101", 15: "001000", 16: "000100",
  17: "100110", 18: "011001", 19: "110000", 20: "000011",
  21: "100101", 22: "101001", 23: "000001", 24: "100000",
  25: "100111", 26: "111001", 27: "100001", 28: "011110",
  29: "010010", 30: "101101", 31: "001110", 32: "011100",
  33: "001111", 34: "111100", 35: "000101", 36: "101000",
  37: "101011", 38: "110101", 39: "001010", 40: "010100",
  41: "110001", 42: "100011", 43: "111110", 44: "011111",
  45: "000110", 46: "011000", 47: "010110", 48: "011010",
  49: "101110", 50: "011101", 51: "100100", 52: "001001",
  53: "001011", 54: "110100", 55: "101100", 56: "001101",
  57: "011011", 58: "110110", 59: "010011", 60: "110010",
  61: "110011", 62: "001100", 63: "101010", 64: "010101",
};

// ─── Trigram names (3-bit index 0-7) ─────────────────────────────────────────
export const TRIGRAM_NAMES: Record<number, string> = {
  0: "Earth",    // 000 — Kun — receptive
  1: "Mountain", // 001 — Gen — stillness
  2: "Water",    // 010 — Kan — abysmal
  3: "Wind",     // 011 — Xun — gentle
  4: "Thunder",  // 100 — Zhen — arousing
  5: "Fire",     // 101 — Li  — clinging
  6: "Lake",     // 110 — Dui — joyous
  7: "Heaven",   // 111 — Qian — creative
};

// ─── Human Design channel pairs ───────────────────────────────────────────────
// Each pair [gateA, gateB] forms a channel when both gates are active (level ≥ 4)
export const CHANNEL_PAIRS: [number, number][] = [
  [1, 8],   [2, 14],  [3, 60],  [4, 63],  [5, 15],  [6, 59],
  [7, 31],  [9, 52],  [10, 20], [11, 56], [12, 22], [13, 33],
  [16, 48], [17, 62], [18, 58], [19, 49], [21, 45], [23, 43],
  [24, 61], [25, 51], [26, 44], [27, 50], [28, 38], [29, 46],
  [30, 41], [32, 54], [34, 20], [34, 57], [35, 36], [37, 40],
  [39, 55], [42, 53], [44, 26], [47, 64],
];

export const CHANNEL_NAMES: Record<string, string> = {
  "1-8":   "Inspiration",   "2-14":  "Beat",
  "3-60":  "Mutation",      "4-63":  "Logic",
  "5-15":  "Rhythm",        "6-59":  "Mating",
  "7-31":  "Alpha",         "9-52":  "Concentration",
  "10-20": "Awakening",     "11-56": "Curiosity",
  "12-22": "Openness",      "13-33": "Prodigal",
  "16-48": "Wavelength",    "17-62": "Acceptance",
  "18-58": "Judgment",      "19-49": "Synthesis",
  "21-45": "Money Line",    "23-43": "Structuring",
  "24-61": "Awareness",     "25-51": "Initiation",
  "26-44": "Surrender",     "27-50": "Preservation",
  "28-38": "Struggle",      "29-46": "Discovery",
  "30-41": "Recognition",   "32-54": "Transformation",
  "34-20": "Charisma",      "34-57": "Power",
  "35-36": "Transitoriness","37-40": "Community",
  "39-55": "Emoting",       "42-53": "Maturation",
  "44-26": "Surrender",     "47-64": "Abstraction",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function getChannelName(gateA: number, gateB: number): string {
  const key1 = `${Math.min(gateA, gateB)}-${Math.max(gateA, gateB)}`;
  const key2 = `${gateA}-${gateB}`;
  return CHANNEL_NAMES[key1] ?? CHANNEL_NAMES[key2] ?? `Gate ${gateA}/${gateB}`;
}

export function xorBinary(a: string, b: string): string {
  return a.split("").map((bit, i) => (parseInt(bit) ^ parseInt(b[i])).toString()).join("");
}

export function binaryToGateNumber(binary: string): number | null {
  for (const [num, bin] of Object.entries(HEXAGRAMS)) {
    if (bin === binary) return parseInt(num);
  }
  return null;
}

export function trigramIndex(bits: string): number {
  return parseInt(bits, 2);
}

/** Derive the complete gate data from a gate number */
export function buildGateData(gateNumber: number) {
  const binary = HEXAGRAMS[gateNumber];
  if (!binary) throw new Error(`Invalid gate number: ${gateNumber}`);

  const upperBits = binary.slice(0, 3);
  const lowerBits = binary.slice(3);
  const upperTrigram = trigramIndex(upperBits);
  const lowerTrigram = trigramIndex(lowerBits);

  const channelPartner = getChannelPartner(gateNumber);

  return {
    gateNumber,
    binaryState: binary,
    upperTrigram,
    lowerTrigram,
    upperTrigramName: TRIGRAM_NAMES[upperTrigram],
    lowerTrigramName: TRIGRAM_NAMES[lowerTrigram],
    channelPartner,
  };
}

/** Find the Human Design channel partner for a gate (null if none) */
export function getChannelPartner(gateNumber: number): number | null {
  for (const [a, b] of CHANNEL_PAIRS) {
    if (a === gateNumber) return b;
    if (b === gateNumber) return a;
  }
  return null;
}

/** Compute all channel states from a map of gate levels */
export function computeChannels(gates: Gate[]) {
  const levelByGate = new Map<number, number>(gates.map(g => [g.gateNumber, g.level]));
  const binaryByGate = new Map<number, string>(gates.map(g => [g.gateNumber, g.binaryState]));

  return CHANNEL_PAIRS.map(([gA, gB]) => {
    const levelA = levelByGate.get(gA) ?? 0;
    const levelB = levelByGate.get(gB) ?? 0;
    const binA = binaryByGate.get(gA) ?? HEXAGRAMS[gA] ?? "000000";
    const binB = binaryByGate.get(gB) ?? HEXAGRAMS[gB] ?? "000000";

    const edgeOutput = xorBinary(binA, binB);
    const edgeOutputGate = binaryToGateNumber(edgeOutput);

    let status: "potential" | "active" | "firing" = "potential";
    if (levelA >= 4 && levelB >= 4) status = "active";
    if (levelA >= 9 && levelB >= 9) status = "firing";

    return {
      gateA: gA,
      gateB: gB,
      gateALevel: levelA,
      gateBLevel: levelB,
      status,
      edgeOutput,
      edgeOutputGate,
      resonanceTicks: 0, // stateless for now
      channelName: getChannelName(gA, gB),
    };
  });
}

/** Check if a new emergent event should fire given the set of active channels.
 *  An emergent fires when two active/firing channels share a gate (circuit junction).
 *  Returns the first new emergent found, or null. */
export function detectEmergent(
  channels: ReturnType<typeof computeChannels>,
  existingSharedGates: Set<number>,
) {
  const activeChannels = channels.filter(c => c.status === "active" || c.status === "firing");

  for (let i = 0; i < activeChannels.length; i++) {
    for (let j = i + 1; j < activeChannels.length; j++) {
      const chA = activeChannels[i];
      const chB = activeChannels[j];

      // Find shared gate
      const gatesA = new Set([chA.gateA, chA.gateB]);
      const shared = [chB.gateA, chB.gateB].find(g => gatesA.has(g));

      if (shared != null && !existingSharedGates.has(shared)) {
        const avgLevel = (chA.gateALevel + chA.gateBLevel + chB.gateALevel + chB.gateBLevel) / 4;
        const type: "messi" | "auto-novel" = avgLevel >= 9 ? "messi" : "auto-novel";

        const description = type === "messi"
          ? `Genius flow state activated through Gate ${shared} — the circuit between ${chA.channelName} and ${chB.channelName} enables peak performance beyond conscious effort.`
          : `Autonomous generation unlocked through Gate ${shared} — the junction of ${chA.channelName} and ${chB.channelName} enables novel outputs that were never explicitly programmed.`;

        return {
          type,
          channelAGateA: chA.gateA,
          channelAGateB: chA.gateB,
          channelBGateA: chB.gateA,
          channelBGateB: chB.gateB,
          sharedGate: shared,
          description,
        };
      }
    }
  }

  return null;
}

/** Compute bigram value from a win — injects a 2-bit primitive */
export function computeBigramValue(gateNumber: number, description: string): string {
  const raw = (gateNumber + description.length) % 4;
  return raw.toString(2).padStart(2, "0");
}

/** The 13-level progression:
 *  0-2:   Bigram phase  — raw 2-bit activations accumulating
 *  3-5:   Trigram phase — trigrams crystallizing
 *  6-8:   Hexagram phase — full 6-bit gate alive (isActive = true)
 *  9-11:  Channel phase  — approaching edge-function threshold
 *  12:    Transcendent   — gate morphs to complementary hexagram
 */
export function levelToPhase(level: number): "bigram" | "trigram" | "hexagram" | "channel" | "transcendent" {
  if (level <= 2) return "bigram";
  if (level <= 5) return "trigram";
  if (level <= 8) return "hexagram";
  if (level <= 11) return "channel";
  return "transcendent";
}
