import { PlanetState, ActiveChannel } from '../hooks/useSimulation';
import { HexagramIcon } from './ZodiacWheel';

export const SidePanel = ({ 
  planets, 
  channels,
  dh,
  tickCount,
  phantomsCount,
  selectedPlanet
}: { 
  planets: PlanetState[], 
  channels: ActiveChannel[],
  dh: number,
  tickCount: number,
  phantomsCount: number,
  selectedPlanet: PlanetState | null
}) => {

  return (
    <div className="w-80 h-full bg-card/80 backdrop-blur-xl border-l border-border flex flex-col p-4 overflow-hidden shadow-2xl relative z-20">
      <div className="text-xs text-muted-foreground uppercase tracking-widest mb-4 flex justify-between">
        <span>Substrate v0.9</span>
        <span className="text-primary font-bold animate-pulse">LIVE</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2 mb-6">
        <div className="bg-background/50 border border-border p-2 rounded">
          <div className="text-[10px] text-muted-foreground uppercase">Higuchi D_H</div>
          <div className="text-xl text-cyan-400">{dh.toFixed(4)}</div>
        </div>
        <div className="bg-background/50 border border-border p-2 rounded">
          <div className="text-[10px] text-muted-foreground uppercase">Tick / Phantoms</div>
          <div className="text-xl text-purple-400">{tickCount} <span className="text-sm">/ {phantomsCount}</span></div>
        </div>
      </div>

      {/* Selected Planet Detail */}
      {selectedPlanet && (
        <div className="mb-6 p-4 border border-primary/30 rounded bg-primary/5 animate-in fade-in slide-in-from-right-4">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl" style={{ color: selectedPlanet.color }}>{selectedPlanet.symbol}</span>
            <div>
              <div className="text-lg font-bold" style={{ color: selectedPlanet.color }}>{selectedPlanet.glyph}</div>
              <div className="text-xs text-muted-foreground">
                {selectedPlanet.address.degree}° {selectedPlanet.address.minute}' {selectedPlanet.address.second}"
              </div>
            </div>
            <div className="ml-auto">
              <HexagramIcon binary={selectedPlanet.address.binary} size={32} className="text-foreground" />
            </div>
          </div>
          <div className="font-mono text-sm grid grid-cols-[1fr_auto] gap-1">
            <span className="text-muted-foreground">Gate</span> <span className="text-white">{selectedPlanet.address.gate}</span>
            <span className="text-muted-foreground">Line</span> <span className="text-white">{selectedPlanet.address.line}</span>
            <span className="text-muted-foreground">Color</span> <span className="text-white">{selectedPlanet.address.color}</span>
            <span className="text-muted-foreground">Tone</span> <span className="text-white">{selectedPlanet.address.tone}</span>
            <span className="text-muted-foreground">Base</span> <span className="text-white">{selectedPlanet.address.base}</span>
            <div className="col-span-2 h-px bg-border my-1" />
            <span className="text-muted-foreground">Bin</span> <span className="text-white tracking-widest">{selectedPlanet.address.binary}</span>
          </div>
        </div>
      )}

      {/* Stream */}
      <div className="flex-1 overflow-y-auto pr-2 -mr-2 space-y-4">
        <div>
          <div className="text-xs text-muted-foreground uppercase tracking-widest mb-2 border-b border-border pb-1">Nodes</div>
          <div className="space-y-1">
            {planets.map(p => (
              <div key={p.id} className="text-xs flex items-center justify-between p-1 hover:bg-white/5 rounded">
                <div className="flex items-center gap-2">
                  <span style={{ color: p.color }}>{p.symbol}</span>
                  <span className="opacity-80">G{p.address.gate.toString().padStart(2, '0')}.{p.address.line}.{p.address.color}</span>
                </div>
                <span className="opacity-50 font-mono tracking-wider">{p.address.binary}</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="text-xs text-muted-foreground uppercase tracking-widest mb-2 border-b border-border pb-1">Active Channels</div>
          {channels.length === 0 ? (
            <div className="text-xs text-muted-foreground italic">No resonance</div>
          ) : (
            <div className="space-y-2">
              {channels.map((ch, i) => (
                <div key={i} className="text-xs bg-background/50 border border-border p-2 rounded flex flex-col gap-1 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-primary/5 pointer-events-none" style={{ opacity: Math.min(ch.resonance / 10, 1) }} />
                  <div className="flex justify-between items-center z-10">
                    <span className="text-muted-foreground">G{ch.gateA} ⟷ G{ch.gateB}</span>
                    <span className="text-[10px] bg-primary/20 text-primary px-1 rounded">{ch.resonance} ticks</span>
                  </div>
                  <div className="flex justify-between items-center z-10">
                    <span>Out: {ch.outputBinary}</span>
                    <HexagramIcon binary={ch.outputBinary} />
                  </div>
                  {ch.outputGate && (
                    <div className="text-[10px] text-green-400 z-10">Resonates with Gate {ch.outputGate}</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
