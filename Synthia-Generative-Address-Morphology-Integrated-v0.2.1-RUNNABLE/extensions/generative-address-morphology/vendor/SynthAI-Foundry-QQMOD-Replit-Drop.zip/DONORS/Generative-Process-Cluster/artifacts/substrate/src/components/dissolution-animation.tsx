import { motion } from 'framer-motion';
import type { DissolutionEvent } from '@/types/process';

interface DissolutionAnimationProps {
  event: DissolutionEvent;
}

export function DissolutionAnimation({ event }: DissolutionAnimationProps) {
  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      {/* Crack lines */}
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute h-0.5 bg-destructive origin-left"
          style={{
            left: event.x,
            top: event.y,
            width: 60,
            rotate: (360 / 8) * i,
          }}
          initial={{ scaleX: 0, opacity: 1 }}
          animate={{ scaleX: 1, opacity: 0 }}
          transition={{
            duration: 0.6,
            ease: 'easeOut',
          }}
        />
      ))}
      
      {/* Fragments flying out */}
      {event.fragmentTypes.map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full bg-primary"
          style={{
            left: event.x,
            top: event.y,
            boxShadow: '0 0 10px currentColor',
          }}
          initial={{
            x: 0,
            y: 0,
            scale: 0,
            opacity: 1,
          }}
          animate={{
            x: Math.cos(i * Math.PI * 2 / event.fragmentTypes.length) * 80,
            y: Math.sin(i * Math.PI * 2 / event.fragmentTypes.length) * 80,
            scale: [0, 1.5, 1],
            opacity: [1, 1, 0],
          }}
          transition={{
            duration: 1.5,
            ease: 'easeOut',
          }}
        />
      ))}
      
      {/* Implosion ring */}
      <motion.div
        className="absolute rounded-full border-2 border-destructive"
        style={{
          left: event.x,
          top: event.y,
          translateX: '-50%',
          translateY: '-50%',
        }}
        initial={{ width: 120, height: 120, opacity: 0.8 }}
        animate={{
          width: 0,
          height: 0,
          opacity: 0,
        }}
        transition={{
          duration: 0.5,
          ease: 'easeIn',
        }}
      />
    </div>
  );
}
