import { motion } from 'framer-motion';
import type { FusionEvent } from '@/types/process';

interface FusionAnimationProps {
  event: FusionEvent;
}

export function FusionAnimation({ event }: FusionAnimationProps) {
  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      {/* Spiral particles */}
      {event.sourceIds.map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-3 h-3 rounded-full bg-primary"
          style={{
            left: event.x,
            top: event.y,
            boxShadow: '0 0 20px currentColor',
          }}
          initial={{
            x: Math.cos(i * Math.PI * 2 / event.sourceIds.length) * 60,
            y: Math.sin(i * Math.PI * 2 / event.sourceIds.length) * 60,
            scale: 1,
            opacity: 1,
          }}
          animate={{
            x: 0,
            y: 0,
            scale: 0,
            opacity: 0,
            rotate: 720,
          }}
          transition={{
            duration: 1.2,
            ease: [0.645, 0.045, 0.355, 1],
          }}
        />
      ))}
      
      {/* Flash */}
      <motion.div
        className="absolute rounded-full bg-white"
        style={{
          left: event.x,
          top: event.y,
          translateX: '-50%',
          translateY: '-50%',
        }}
        initial={{ width: 0, height: 0, opacity: 0 }}
        animate={{
          width: 100,
          height: 100,
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 0.5,
          delay: 1.0,
          ease: 'easeOut',
        }}
      />
      
      {/* Shockwave ring */}
      <motion.div
        className="absolute rounded-full border-4 border-primary"
        style={{
          left: event.x,
          top: event.y,
          translateX: '-50%',
          translateY: '-50%',
        }}
        initial={{ width: 0, height: 0, opacity: 0 }}
        animate={{
          width: 200,
          height: 200,
          opacity: [0, 0.8, 0],
        }}
        transition={{
          duration: 0.8,
          delay: 1.2,
          ease: 'easeOut',
        }}
      />
    </div>
  );
}
