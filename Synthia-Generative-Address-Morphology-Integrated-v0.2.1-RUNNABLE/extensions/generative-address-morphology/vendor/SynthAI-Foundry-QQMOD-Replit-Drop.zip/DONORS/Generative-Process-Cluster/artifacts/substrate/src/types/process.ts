export type PrimitiveType = 'oscillator' | 'counter' | 'signal' | 'gate' | 'memory';
export type Tier1Type = 'rhythm-generator' | 'pattern-recognizer' | 'broadcaster' | 'threshold-logic';
export type Tier2Type = 'temporal-sequencer' | 'field-emitter' | 'unknown-composite';
export type Tier3Type = 'apex-entity';

export type ProcessType = PrimitiveType | Tier1Type | Tier2Type | Tier3Type;

export interface Process {
  id: string;
  type: ProcessType;
  tier: 0 | 1 | 2 | 3;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  age: number;
  bonds: string[]; // IDs of bonded processes
  bondTimes: Map<string, number>; // When each bond was formed
  phase: number; // For animation cycles
  state: number; // Internal state value
  name?: string; // For generated composites
  energy?: number; // For tier 3 dissolution
}

export interface Bond {
  id: string;
  processIds: [string, string];
  createdAt: number;
}

export interface FusionEvent {
  id: string;
  x: number;
  y: number;
  sourceIds: string[];
  targetType: ProcessType;
  startTime: number;
}

export interface DissolutionEvent {
  id: string;
  x: number;
  y: number;
  sourceId: string;
  fragmentTypes: PrimitiveType[];
  startTime: number;
}
