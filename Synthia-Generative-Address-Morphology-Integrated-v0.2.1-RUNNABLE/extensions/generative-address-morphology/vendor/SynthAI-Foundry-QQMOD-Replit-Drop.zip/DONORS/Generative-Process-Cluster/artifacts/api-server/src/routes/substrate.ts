import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, gatesTable, winsTable, emergentsTable } from "@workspace/db";
import { SeedSubstrateResponse } from "@workspace/api-zod";
import { buildGateData, computeChannels } from "../lib/morphing-engine";

const router: IRouter = Router();

router.get("/substrate", async (_req, res): Promise<void> => {
  const [gates, wins, emergents] = await Promise.all([
    db.select().from(gatesTable).orderBy(gatesTable.gateNumber),
    db.select().from(winsTable),
    db.select().from(emergentsTable).orderBy(desc(emergentsTable.createdAt)),
  ]);
  const channels = computeChannels(gates);
  const activeChannels = channels.filter(c => c.status !== "potential");

  res.json({
    gates,
    activeChannels,
    potentialChannels: channels.filter(c => c.status === "potential"),
    emergents: emergents.map(e => ({
      id: e.id,
      type: e.type,
      channelAGates: [e.channelAGateA, e.channelAGateB],
      channelBGates: [e.channelBGateA, e.channelBGateB],
      sharedGate: e.sharedGate,
      description: e.description,
      createdAt: e.createdAt,
    })),
    totalWins: wins.length,
    totalBigrams: wins.length,
    activatedGateCount: gates.filter(g => g.level >= 6).length,
    firingChannelCount: channels.filter(c => c.status === "firing").length,
  });
});

router.post("/substrate/seed", async (_req, res): Promise<void> => {
  const current = await db.select({ gateNumber: gatesTable.gateNumber }).from(gatesTable);
  const existing = new Set(current.map(g => g.gateNumber));
  const missing = Array.from({ length: 64 }, (_, i) => i + 1).filter(n => !existing.has(n));

  if (missing.length > 0) {
    await db.insert(gatesTable).values(
      missing.map(gateNumber => ({
        ...buildGateData(gateNumber),
        level: 0,
        bigramCount: 0,
        intention: null,
        isActive: false,
        channelActive: false,
      })),
    );
  }

  res.json(SeedSubstrateResponse.parse({ seeded: missing.length, existing: existing.size }));
});

export default router;