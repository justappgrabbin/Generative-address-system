import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import {
  useGetSubstrate,
  useListGates,
  useListWins,
  useListActiveChannels,
  useListEmergents,
  useGetLatestEmergent,
  useSeedSubstrate,
  useLogWin,
  useUpdateGate,
  getGetSubstrateQueryKey,
  getListGatesQueryKey,
  getListWinsQueryKey,
  getListActiveChannelsQueryKey,
  getListEmergentsQueryKey,
  getGetLatestEmergentQueryKey,
} from '@workspace/api-client-react';

export function useSubstrate() {
  const queryClient = useQueryClient();
  const seedMutation = useSeedSubstrate();

  // Main substrate state with auto-refresh every 5s
  const substrate = useGetSubstrate({
    query: {
      refetchInterval: 5000,
      queryKey: getGetSubstrateQueryKey(),
    },
  });

  const gates = useListGates({
    query: {
      refetchInterval: 5000,
      queryKey: getListGatesQueryKey(),
    },
  });

  const wins = useListWins({
    query: {
      queryKey: getListWinsQueryKey(),
    },
  });

  const activeChannels = useListActiveChannels({
    query: {
      refetchInterval: 3000,
      queryKey: getListActiveChannelsQueryKey(),
    },
  });

  const emergents = useListEmergents({
    query: {
      queryKey: getListEmergentsQueryKey(),
    },
  });

  const latestEmergent = useGetLatestEmergent({
    query: {
      refetchInterval: 2000,
      queryKey: getGetLatestEmergentQueryKey(),
    },
  });

  // Auto-seed on first load if no gates exist
  useEffect(() => {
    if (substrate.data && substrate.data.gates.length === 0 && !seedMutation.isPending) {
      seedMutation.mutate(undefined, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetSubstrateQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListGatesQueryKey() });
        },
      });
    }
  }, [substrate.data, seedMutation, queryClient]);

  const logWinMutation = useLogWin();
  const updateGateMutation = useUpdateGate();

  const logWin = (gateNumber: number, description: string) => {
    return logWinMutation.mutateAsync(
      { gateNumber, data: { description } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetSubstrateQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListGatesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListWinsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListActiveChannelsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListEmergentsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetLatestEmergentQueryKey() });
        },
      }
    );
  };

  const updateGateIntention = (gateNumber: number, intention: string) => {
    return updateGateMutation.mutateAsync(
      { gateNumber, data: { intention } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetSubstrateQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListGatesQueryKey() });
        },
      }
    );
  };

  return {
    substrate: substrate.data,
    gates: gates.data || [],
    wins: wins.data || [],
    activeChannels: activeChannels.data || [],
    emergents: emergents.data || [],
    latestEmergent: latestEmergent.data?.emergent || null,
    isLoading: substrate.isLoading || gates.isLoading,
    isSeeding: seedMutation.isPending,
    logWin,
    updateGateIntention,
    logWinMutation,
    updateGateMutation,
  };
}
