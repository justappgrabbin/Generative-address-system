import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { HEXAGRAMS } from './constants';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getAddress(arcDegrees: number) {
  const norm = arcDegrees % 360;
  
  const gateVal = Math.floor(norm / 5.625) + 1;
  const lineVal = Math.floor((norm % 5.625) / 0.9375) + 1;
  const colorVal = Math.floor((norm % 0.9375) / 0.15625) + 1;
  const toneVal = Math.floor((norm % 0.15625) / 0.026042) + 1;
  const baseVal = Math.floor((norm % 0.026042) / 0.005208) + 1;
  
  return {
    gate: gateVal,
    line: lineVal,
    color: colorVal,
    tone: toneVal,
    base: baseVal,
    binary: HEXAGRAMS[gateVal as keyof typeof HEXAGRAMS] || '000000',
    degree: Math.floor(norm),
    minute: Math.floor((norm % 1) * 60),
    second: Math.floor((((norm % 1) * 60) % 1) * 60)
  };
}

export function xorBinary(a: string, b: string): string {
  let res = '';
  for (let i = 0; i < 6; i++) {
    res += (parseInt(a[i]) ^ parseInt(b[i])).toString();
  }
  return res;
}

export function findGateByBinary(bin: string): number | null {
  for (const [gate, val] of Object.entries(HEXAGRAMS)) {
    if (val === bin) return parseInt(gate);
  }
  return null;
}
