import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, winsTable } from "@workspace/db";

const router: IRouter = Router();

// GET /wins — recent wins feed (last 50)
router.get("/wins", async (_req, res): Promise<void> => {
  const wins = await db
    .select()
    .from(winsTable)
    .orderBy(desc(winsTable.createdAt))
    .limit(50);
  res.json(wins);
});

export default router;
