import { useState } from "react";
import { useSubstrate } from "../hooks/useSubstrate";
import { MorphingWorkbench } from "../components/MorphingWorkbench";

export default function Substrate() {
  const substrate = useSubstrate();
  const [selectedGateNumber, setSelectedGateNumber] = useState<number | null>(1);

  if (substrate.isLoading || substrate.isSeeding || substrate.gates.length === 0) {
    return (
      <div className="loading-screen">
        <div className="loading-mark"><span /></div>
        <div><strong>Starting your substrate</strong><p>Preparing 64 computational state variables…</p></div>
      </div>
    );
  }

  return (
    <MorphingWorkbench
      gates={substrate.gates}
      wins={substrate.wins}
      channels={substrate.activeChannels}
      emergents={substrate.emergents}
      selectedGateNumber={selectedGateNumber}
      setSelectedGateNumber={setSelectedGateNumber}
      onLogWin={substrate.logWin}
      onUpdateIntention={substrate.updateGateIntention}
      isLoggingWin={substrate.logWinMutation.isPending}
    />
  );
}