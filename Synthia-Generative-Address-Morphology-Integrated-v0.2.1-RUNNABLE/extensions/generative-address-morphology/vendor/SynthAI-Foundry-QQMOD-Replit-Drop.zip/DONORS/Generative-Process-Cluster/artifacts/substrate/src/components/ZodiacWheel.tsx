import { memo } from 'react';
import type { Gate, Channel } from '@workspace/api-client-react';

export const HexagramIcon = ({ binary, size = 16, className = "" }: { binary: string, size?: number, className?: string }) => {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={`fill-current ${className}`}>
      {binary.split('').map((bit, i) => {
        const y = 20 - i * 4;
        if (bit === '1') {
          return <rect key={i} x="2" y={y} width="20" height="2" />;
        } else {
          return (
            <g key={i}>
              <rect x="2" y={y} width="8" height="2" />
              <rect x="14" y={y} width="8" height="2" />
            </g>
          );
        }
      })}
    </svg>
  );
};

const TRIGRAM_NAMES = ['Earth', 'Mountain', 'Water', 'Wind', 'Thunder', 'Fire', 'Lake', 'Heaven'];
const TRIGRAM_BINARIES = ['000', '001', '010', '011', '100', '101', '110', '111'];

function getGateColor(level: number): string {
  if (level === 0) return 'rgba(26, 42, 58, 0.3)';
  if (level <= 2) return 'rgba(26, 42, 58, 0.5)';
  if (level <= 5) return 'rgba(30, 77, 107, 0.7)';
  if (level <= 8) return '#0ea5e9';
  if (level <= 11) return '#f59e0b';
  return '#fef3c7';
}

function getGateRadius(level: number): number {
  if (level === 0) return 2;
  if (level <= 2) return 3;
  if (level <= 5) return 4;
  if (level <= 8) return 6;
  if (level <= 11) return 8;
  return 10;
}

export const ZodiacWheel = memo(({ 
  gates, 
  channels, 
  depth, 
  onGateClick,
  selectedGateNumber,
  latestEmergent,
}: { 
  gates: Gate[];
  channels: Channel[];
  depth: number;
  onGateClick: (gateNumber: number) => void;
  selectedGateNumber: number | null;
  latestEmergent: any;
}) => {
  const center = 400;
  
  const rings = [
    { r: 350, name: "Gate" },
    { r: 310, name: "Line" },
    { r: 270, name: "Color" },
    { r: 230, name: "Tone" },
    { r: 190, name: "Base" },
  ];

  const getCoords = (arc: number, r: number) => {
    const rad = (arc - 90) * (Math.PI / 180);
    return {
      x: center + r * Math.cos(rad),
      y: center + r * Math.sin(rad)
    };
  };

  // Calculate trigram activity (how many gates use each trigram)
  const trigramActivity = new Array(8).fill(0);
  gates.forEach(gate => {
    if (gate.level >= 6) {
      trigramActivity[gate.upperTrigram]++;
      trigramActivity[gate.lowerTrigram]++;
    }
  });

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <div className="canvas-noise z-0 opacity-10"></div>
      
      <svg 
        viewBox="0 0 800 800" 
        className="w-full h-full max-w-[90vh] max-h-[90vh] z-10 transition-transform duration-1000 ease-in-out"
        style={{ transform: `scale(${1 + depth * 0.15})` }}
      >
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          <filter id="glow-strong">
            <feGaussianBlur stdDeviation="8" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Zodiac divisions */}
        {[...Array(12)].map((_, i) => {
          const c1 = getCoords(i * 30, 100);
          const c2 = getCoords(i * 30, 380);
          return (
            <g key={`house-${i}`}>
              <line x1={c1.x} y1={c1.y} x2={c2.x} y2={c2.y} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
              <text 
                x={getCoords(i * 30 + 15, 370).x} 
                y={getCoords(i * 30 + 15, 370).y} 
                fill="rgba(255,255,255,0.2)" 
                fontSize="12" 
                textAnchor="middle"
                alignmentBaseline="middle"
              >
                {['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'][i]}
              </text>
            </g>
          );
        })}

        {/* Rings */}
        {rings.map((ring, i) => {
          const isActive = i === depth;
          return (
            <circle 
              key={ring.name}
              cx={center} cy={center} r={ring.r}
              fill="none"
              stroke={isActive ? "rgba(255,255,255,0.15)" : "rgba(255,255,255,0.03)"}
              strokeWidth={isActive ? "20" : "10"}
              className="transition-all duration-500"
            />
          );
        })}

        {/* Trigram octagon (inner ring) - only visible at Color/Tone/Base depth */}
        {depth >= 2 && (
          <g opacity={depth >= 2 ? 1 : 0} className="transition-opacity duration-500">
            {TRIGRAM_NAMES.map((name, idx) => {
              const angle = (idx * 45);
              const pos = getCoords(angle, 150);
              const activity = trigramActivity[idx];
              const opacity = 0.3 + (activity * 0.1);
              
              return (
                <g key={`trigram-${idx}`}>
                  <circle 
                    cx={pos.x} 
                    cy={pos.y} 
                    r="12" 
                    fill="rgba(30, 77, 107, 0.3)" 
                    stroke="#0ea5e9"
                    strokeWidth="1"
                    opacity={opacity}
                  />
                  <text
                    x={pos.x}
                    y={pos.y + 25}
                    fill="#0ea5e9"
                    fontSize="9"
                    textAnchor="middle"
                    opacity={opacity}
                  >
                    {name}
                  </text>
                </g>
              );
            })}
          </g>
        )}

        {/* Channel arcs */}
        {channels.map((ch, idx) => {
          const arcA = (ch.gateA - 1) * 5.625 + 2.8125;
          const arcB = (ch.gateB - 1) * 5.625 + 2.8125;
          const pA = getCoords(arcA, 350);
          const pB = getCoords(arcB, 350);
          
          const path = `M ${pA.x} ${pA.y} Q ${center} ${center} ${pB.x} ${pB.y}`;
          
          const isFiring = ch.status === 'firing';
          const isActive = ch.status === 'active';
          
          if (ch.status === 'potential') return null;
          
          return (
            <g key={`ch-${idx}`}>
              <path 
                d={path}
                fill="none"
                stroke={isFiring ? '#f59e0b' : '#0ea5e9'}
                strokeWidth={isFiring ? 3 : 1.5}
                opacity={isFiring ? 0.8 : 0.4}
                filter={isFiring ? "url(#glow)" : undefined}
              />
              {isFiring && (
                <circle r="3" fill="#f59e0b" filter="url(#glow-strong)">
                  <animateMotion 
                    dur="2s" 
                    repeatCount="indefinite" 
                    path={path}
                  />
                </circle>
              )}
            </g>
          );
        })}

        {/* Gates on outer ring */}
        {gates.map(gate => {
          const arc = (gate.gateNumber - 1) * 5.625 + 2.8125;
          const c = getCoords(arc, 350);
          const color = getGateColor(gate.level);
          const radius = getGateRadius(gate.level);
          const isSelected = selectedGateNumber === gate.gateNumber;
          
          return (
            <g 
              key={`gate-${gate.gateNumber}`}
              className="cursor-pointer transition-transform hover:scale-125" 
              onClick={() => onGateClick(gate.gateNumber)}
              style={{ transformOrigin: `${c.x}px ${c.y}px` }}
            >
              {gate.level >= 6 && (
                <circle 
                  cx={c.x} 
                  cy={c.y} 
                  r={radius + 6} 
                  fill={color} 
                  fillOpacity="0.15" 
                  filter="url(#glow)" 
                />
              )}
              
              <circle 
                cx={c.x} 
                cy={c.y} 
                r={radius} 
                fill={color}
                stroke={isSelected ? '#ffffff' : 'none'}
                strokeWidth={isSelected ? 2 : 0}
              />
              
              {gate.level === 12 && (
                <circle 
                  cx={c.x} 
                  cy={c.y} 
                  r={radius + 10} 
                  fill="none"
                  stroke="#fef3c7"
                  strokeWidth="1"
                  opacity="0.5"
                >
                  <animate 
                    attributeName="r" 
                    from={radius + 10} 
                    to={radius + 18} 
                    dur="2s" 
                    repeatCount="indefinite" 
                  />
                  <animate 
                    attributeName="opacity" 
                    from="0.5" 
                    to="0" 
                    dur="2s" 
                    repeatCount="indefinite" 
                  />
                </circle>
              )}

              {gate.level >= 6 && (
                <g transform={`translate(${c.x - 6}, ${c.y - 18})`}>
                  <HexagramIcon binary={gate.binaryState} size={12} className="text-white" />
                </g>
              )}
            </g>
          );
        })}

        {/* Emergent center zone */}
        {latestEmergent && (
          <g>
            {latestEmergent.type === 'messi' && (
              <g>
                <circle 
                  cx={center} 
                  cy={center} 
                  r="0" 
                  fill="none"
                  stroke="#fbbf24"
                  strokeWidth="2"
                >
                  <animate attributeName="r" from="0" to="100" dur="3s" repeatCount="indefinite" />
                  <animate attributeName="opacity" from="1" to="0" dur="3s" repeatCount="indefinite" />
                </circle>
                <text
                  x={center}
                  y={center}
                  fill="#fbbf24"
                  fontSize="16"
                  fontWeight="bold"
                  textAnchor="middle"
                  alignmentBaseline="middle"
                  filter="url(#glow-strong)"
                >
                  FLOW STATE
                </text>
              </g>
            )}
            
            {latestEmergent.type === 'auto-novel' && (
              <g>
                <circle 
                  cx={center} 
                  cy={center} 
                  r="0" 
                  fill="none"
                  stroke="#7c3aed"
                  strokeWidth="2"
                >
                  <animate attributeName="r" from="0" to="100" dur="3s" repeatCount="indefinite" />
                  <animate attributeName="opacity" from="1" to="0" dur="3s" repeatCount="indefinite" />
                </circle>
                <text
                  x={center}
                  y={center}
                  fill="#7c3aed"
                  fontSize="14"
                  fontWeight="bold"
                  textAnchor="middle"
                  alignmentBaseline="middle"
                  filter="url(#glow-strong)"
                >
                  AUTONOMOUS GEN
                </text>
              </g>
            )}
          </g>
        )}
      </svg>
    </div>
  );
});

ZodiacWheel.displayName = 'ZodiacWheel';
