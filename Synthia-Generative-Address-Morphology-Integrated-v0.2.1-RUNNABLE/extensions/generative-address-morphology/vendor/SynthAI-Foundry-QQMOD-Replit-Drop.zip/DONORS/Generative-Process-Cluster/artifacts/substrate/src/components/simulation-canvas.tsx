import { useRef, useEffect, useState } from 'react';
import type { Process, Bond, FusionEvent, DissolutionEvent } from '@/types/process';
import { getProcessColor, getProcessRadius, getProximityThreshold, checkFusionCompatibility, generateCompositeName, getRandomPrimitiveType, PRIMITIVE_TYPES } from '@/lib/process-config';
import { FusionAnimation } from './fusion-animation';
import { DissolutionAnimation } from './dissolution-animation';

interface SimulationCanvasProps {
  speed: number;
  onStatsUpdate: (stats: { t0: number; t1: number; t2: number; t3: number }) => void;
}

export function SimulationCanvas({ speed, onStatsUpdate }: SimulationCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const processesRef = useRef<Map<string, Process>>(new Map());
  const bondsRef = useRef<Map<string, Bond>>(new Map());
  const frameRef = useRef<number>(0);
  const ticksRef = useRef<number>(0);
  const lastStatsUpdateRef = useRef<number>(0);
  const hoveredProcessRef = useRef<string | null>(null);
  const mouseRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  
  const [fusionEvents, setFusionEvents] = useState<FusionEvent[]>([]);
  const [dissolutionEvents, setDissolutionEvents] = useState<DissolutionEvent[]>([]);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; process: Process } | null>(null);

  // Initialize simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    // Seed initial processes
    for (let i = 0; i < 20; i++) {
      createProcess(
        getRandomPrimitiveType(),
        Math.random() * canvas.width,
        Math.random() * canvas.height
      );
    }
  }, []);

  // Handle resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Create a new process
  const createProcess = (type: string, x: number, y: number, tier = 0 as 0 | 1 | 2 | 3, customName?: string) => {
    const id = `${type}-${Date.now()}-${Math.random()}`;
    const process: Process = {
      id,
      type: type as any,
      tier,
      x,
      y,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      radius: getProcessRadius(tier),
      color: getProcessColor(type as any, tier),
      age: 0,
      bonds: [],
      bondTimes: new Map(),
      phase: Math.random() * Math.PI * 2,
      state: 0,
      name: customName,
      energy: tier === 3 ? 1000 : undefined,
    };
    processesRef.current.set(id, process);
    return process;
  };

  // Handle canvas click
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    createProcess(getRandomPrimitiveType(), x, y);
  };

  // Handle mouse move for tooltip
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    mouseRef.current = { x, y };
    
    // Find hovered process
    let found: Process | null = null;
    for (const process of processesRef.current.values()) {
      const dx = process.x - x;
      const dy = process.y - y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < process.radius) {
        found = process;
        break;
      }
    }
    
    if (found) {
      hoveredProcessRef.current = found.id;
      setTooltip({ x: e.clientX, y: e.clientY, process: found });
    } else {
      hoveredProcessRef.current = null;
      setTooltip(null);
    }
  };

  const handleMouseLeave = () => {
    hoveredProcessRef.current = null;
    setTooltip(null);
  };

  // Main simulation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      ticksRef.current += speed;
      
      // Update processes
      updateProcesses(canvas);
      
      // Update bonds
      updateBonds();
      
      // Check for fusions
      checkFusions();
      
      // Render
      render(ctx, canvas);
      
      // Update stats every 500ms
      if (Date.now() - lastStatsUpdateRef.current > 500) {
        updateStats();
        lastStatsUpdateRef.current = Date.now();
      }
      
      frameRef.current = requestAnimationFrame(animate);
    };

    frameRef.current = requestAnimationFrame(animate);

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, [speed]);

  const updateProcesses = (canvas: HTMLCanvasElement) => {
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    for (const process of processesRef.current.values()) {
      // Brownian motion
      process.vx += (Math.random() - 0.5) * 0.1 * speed;
      process.vy += (Math.random() - 0.5) * 0.1 * speed;
      
      // Gentle center attraction
      const dx = centerX - process.x;
      const dy = centerY - process.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > 100) {
        process.vx += (dx / dist) * 0.02 * speed;
        process.vy += (dy / dist) * 0.02 * speed;
      }
      
      // Damping
      process.vx *= 0.98;
      process.vy *= 0.98;
      
      // Update position
      process.x += process.vx * speed;
      process.y += process.vy * speed;
      
      // Bounce off edges
      if (process.x < process.radius) {
        process.x = process.radius;
        process.vx *= -0.8;
      }
      if (process.x > canvas.width - process.radius) {
        process.x = canvas.width - process.radius;
        process.vx *= -0.8;
      }
      if (process.y < process.radius) {
        process.y = process.radius;
        process.vy *= -0.8;
      }
      if (process.y > canvas.height - process.radius) {
        process.y = canvas.height - process.radius;
        process.vy *= -0.8;
      }
      
      // Update phase and state
      process.phase += 0.02 * speed;
      process.state = (process.state + 0.01 * speed) % 1;
      process.age += speed;
      
      // Tier 3 energy decay
      if (process.tier === 3 && process.energy !== undefined) {
        process.energy -= 0.1 * speed;
        if (process.energy <= 0) {
          triggerDissolution(process);
        }
      }
    }
  };

  const updateBonds = () => {
    const newBonds = new Map<string, Bond>();
    const processes = Array.from(processesRef.current.values());
    
    for (let i = 0; i < processes.length; i++) {
      const p1 = processes[i];
      const threshold = getProximityThreshold(Math.min(p1.tier, 2) as 0 | 1 | 2);
      
      for (let j = i + 1; j < processes.length; j++) {
        const p2 = processes[j];
        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < threshold) {
          const bondId = [p1.id, p2.id].sort().join('-');
          const existingBond = bondsRef.current.get(bondId);
          
          if (existingBond) {
            newBonds.set(bondId, existingBond);
          } else {
            const bond: Bond = {
              id: bondId,
              processIds: [p1.id, p2.id],
              createdAt: ticksRef.current,
            };
            newBonds.set(bondId, bond);
            
            // Update process bond lists
            if (!p1.bonds.includes(p2.id)) {
              p1.bonds.push(p2.id);
              p1.bondTimes.set(p2.id, ticksRef.current);
            }
            if (!p2.bonds.includes(p1.id)) {
              p2.bonds.push(p1.id);
              p2.bondTimes.set(p1.id, ticksRef.current);
            }
          }
        }
      }
    }
    
    // Clean up broken bonds
    for (const process of processesRef.current.values()) {
      process.bonds = process.bonds.filter(bondedId => {
        const bondId = [process.id, bondedId].sort().join('-');
        return newBonds.has(bondId);
      });
    }
    
    bondsRef.current = newBonds;
  };

  const checkFusions = () => {
    const processed = new Set<string>();
    
    for (const process of processesRef.current.values()) {
      if (processed.has(process.id)) continue;
      if (process.bonds.length === 0) continue;
      
      // Check if any bond is old enough (3 seconds = ~180 ticks at 60fps)
      const oldBonds = process.bonds.filter(bondedId => {
        const bondTime = process.bondTimes.get(bondedId);
        return bondTime !== undefined && (ticksRef.current - bondTime) > 180;
      });
      
      if (oldBonds.length === 0) continue;
      
      // Gather bonded processes
      const cluster = [process, ...oldBonds.map(id => processesRef.current.get(id)!).filter(Boolean)];
      const clusterTypes = cluster.map(p => p.type);
      
      // Check for fusion compatibility
      const fusionResult = checkFusionCompatibility(clusterTypes);
      
      if (fusionResult) {
        // Determine tier
        const maxTier = Math.max(...cluster.map(p => p.tier));
        const newTier = (maxTier + 1) as 0 | 1 | 2 | 3;
        
        // Calculate fusion center
        const centerX = cluster.reduce((sum, p) => sum + p.x, 0) / cluster.length;
        const centerY = cluster.reduce((sum, p) => sum + p.y, 0) / cluster.length;
        
        // Create fusion event
        const fusionEvent: FusionEvent = {
          id: `fusion-${Date.now()}`,
          x: centerX,
          y: centerY,
          sourceIds: cluster.map(p => p.id),
          targetType: fusionResult,
          startTime: Date.now(),
        };
        
        setFusionEvents(prev => [...prev, fusionEvent]);
        
        // Mark for deletion
        cluster.forEach(p => processed.add(p.id));
        
        // Schedule new process creation after animation
        setTimeout(() => {
          cluster.forEach(p => processesRef.current.delete(p.id));
          createProcess(fusionResult, centerX, centerY, newTier);
          setFusionEvents(prev => prev.filter(e => e.id !== fusionEvent.id));
        }, 1500);
      } else if (cluster.length >= 2 && cluster.every(p => p.tier >= 1)) {
        // Unknown composite from tier 1+
        const maxTier = Math.max(...cluster.map(p => p.tier));
        const newTier = (Math.min(maxTier + 1, 3)) as 0 | 1 | 2 | 3;
        
        const centerX = cluster.reduce((sum, p) => sum + p.x, 0) / cluster.length;
        const centerY = cluster.reduce((sum, p) => sum + p.y, 0) / cluster.length;
        
        const compositeName = generateCompositeName(clusterTypes);
        const compositeType = newTier === 3 ? 'apex-entity' : 'unknown-composite';
        
        const fusionEvent: FusionEvent = {
          id: `fusion-${Date.now()}`,
          x: centerX,
          y: centerY,
          sourceIds: cluster.map(p => p.id),
          targetType: compositeType as any,
          startTime: Date.now(),
        };
        
        setFusionEvents(prev => [...prev, fusionEvent]);
        cluster.forEach(p => processed.add(p.id));
        
        setTimeout(() => {
          cluster.forEach(p => processesRef.current.delete(p.id));
          createProcess(compositeType, centerX, centerY, newTier, compositeName);
          setFusionEvents(prev => prev.filter(e => e.id !== fusionEvent.id));
        }, 1500);
      }
    }
  };

  const triggerDissolution = (process: Process) => {
    const fragmentTypes: any[] = [];
    for (let i = 0; i < 5; i++) {
      fragmentTypes.push(getRandomPrimitiveType());
    }
    
    const event: DissolutionEvent = {
      id: `dissolution-${Date.now()}`,
      x: process.x,
      y: process.y,
      sourceId: process.id,
      fragmentTypes,
      startTime: Date.now(),
    };
    
    setDissolutionEvents(prev => [...prev, event]);
    
    setTimeout(() => {
      processesRef.current.delete(process.id);
      
      // Create fragments
      fragmentTypes.forEach((type, i) => {
        const angle = (Math.PI * 2 * i) / fragmentTypes.length;
        const dist = 50;
        createProcess(
          type,
          process.x + Math.cos(angle) * dist,
          process.y + Math.sin(angle) * dist
        );
      });
      
      setDissolutionEvents(prev => prev.filter(e => e.id !== event.id));
    }, 1500);
  };

  const render = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
    // Clear
    ctx.fillStyle = '#050508';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw bonds
    for (const bond of bondsRef.current.values()) {
      const p1 = processesRef.current.get(bond.processIds[0]);
      const p2 = processesRef.current.get(bond.processIds[1]);
      if (!p1 || !p2) continue;
      
      const age = ticksRef.current - bond.createdAt;
      const dashOffset = (age * speed * 0.5) % 20;
      
      ctx.strokeStyle = blendColors(p1.color, p2.color);
      ctx.lineWidth = 1;
      ctx.setLineDash([10, 10]);
      ctx.lineDashOffset = -dashOffset;
      ctx.globalAlpha = 0.4;
      
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }
    
    // Draw processes
    for (const process of processesRef.current.values()) {
      drawProcess(ctx, process);
    }
  };

  const drawProcess = (ctx: CanvasRenderingContext2D, process: Process) => {
    const pulseIntensity = Math.sin(process.phase) * 0.3 + 0.7;
    const isHovered = hoveredProcessRef.current === process.id;
    
    ctx.save();
    ctx.translate(process.x, process.y);
    
    // Glow layers
    const glowRadius = process.radius * (isHovered ? 3 : 2.5);
    const gradient = ctx.createRadialGradient(0, 0, process.radius * 0.5, 0, 0, glowRadius);
    gradient.addColorStop(0, `${process.color}${Math.floor(pulseIntensity * 100).toString(16).padStart(2, '0')}`);
    gradient.addColorStop(0.5, `${process.color}40`);
    gradient.addColorStop(1, `${process.color}00`);
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(0, 0, glowRadius, 0, Math.PI * 2);
    ctx.fill();
    
    // Core shape
    ctx.fillStyle = process.color;
    ctx.globalAlpha = 0.8;
    
    switch (process.type) {
      case 'oscillator':
        // Breathing circle
        const r = process.radius * pulseIntensity;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
        break;
        
      case 'counter':
        // Filling ring
        ctx.beginPath();
        ctx.arc(0, 0, process.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, process.radius * 0.7, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * process.state, false);
        ctx.lineTo(0, 0);
        ctx.fill();
        break;
        
      case 'signal':
        // Radiating dot
        ctx.beginPath();
        ctx.arc(0, 0, process.radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
        break;
        
      case 'gate':
        // Diamond
        ctx.rotate(process.phase * 0.1);
        ctx.beginPath();
        ctx.moveTo(0, -process.radius);
        ctx.lineTo(process.radius, 0);
        ctx.lineTo(0, process.radius);
        ctx.lineTo(-process.radius, 0);
        ctx.closePath();
        ctx.fill();
        break;
        
      case 'memory':
        // Rotating square
        ctx.rotate(process.phase * 0.05);
        ctx.fillRect(-process.radius * 0.7, -process.radius * 0.7, process.radius * 1.4, process.radius * 1.4);
        break;
        
      default:
        // Higher tier - complex shapes
        if (process.tier === 1) {
          // Star-like
          drawStar(ctx, 6, process.radius, process.radius * 0.5);
        } else if (process.tier === 2) {
          // Mandala
          drawMandala(ctx, 8, process.radius);
        } else if (process.tier === 3) {
          // Radiant apex
          drawRadiantStar(ctx, 12, process.radius, process.phase);
        }
    }
    
    ctx.restore();
  };

  const drawStar = (ctx: CanvasRenderingContext2D, points: number, outer: number, inner: number) => {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const angle = (Math.PI * i) / points;
      const r = i % 2 === 0 ? outer : inner;
      const x = Math.cos(angle) * r;
      const y = Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  };

  const drawMandala = (ctx: CanvasRenderingContext2D, petals: number, radius: number) => {
    for (let i = 0; i < petals; i++) {
      const angle = (Math.PI * 2 * i) / petals;
      ctx.save();
      ctx.rotate(angle);
      ctx.beginPath();
      ctx.ellipse(radius * 0.5, 0, radius * 0.4, radius * 0.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  };

  const drawRadiantStar = (ctx: CanvasRenderingContext2D, rays: number, radius: number, phase: number) => {
    for (let i = 0; i < rays; i++) {
      const angle = (Math.PI * 2 * i) / rays + phase * 0.1;
      ctx.save();
      ctx.rotate(angle);
      ctx.globalAlpha = 0.6;
      ctx.fillRect(0, -radius * 0.1, radius * 1.2, radius * 0.2);
      ctx.restore();
    }
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.5, 0, Math.PI * 2);
    ctx.fill();
  };

  const blendColors = (c1: string, c2: string): string => {
    // Simple color blending
    return c1; // Simplified for now
  };

  const updateStats = () => {
    const stats = { t0: 0, t1: 0, t2: 0, t3: 0 };
    for (const process of processesRef.current.values()) {
      stats[`t${process.tier}` as keyof typeof stats]++;
    }
    onStatsUpdate(stats);
  };

  // Expose seed function
  useEffect(() => {
    (window as any).__seedProcesses = (count: number = 5) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      const centerX = Math.random() * canvas.width;
      const centerY = Math.random() * canvas.height;
      
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count;
        const dist = 50 + Math.random() * 50;
        createProcess(
          getRandomPrimitiveType(),
          centerX + Math.cos(angle) * dist,
          centerY + Math.sin(angle) * dist
        );
      }
    };
  }, []);

  return (
    <>
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair"
        onClick={handleCanvasClick}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        data-testid="simulation-canvas"
      />
      
      {fusionEvents.map(event => (
        <FusionAnimation key={event.id} event={event} />
      ))}
      
      {dissolutionEvents.map(event => (
        <DissolutionAnimation key={event.id} event={event} />
      ))}
      
      {tooltip && (
        <div
          className="fixed pointer-events-none z-50 px-3 py-2 text-xs bg-card/95 backdrop-blur border border-border rounded"
          style={{ left: tooltip.x + 15, top: tooltip.y + 15 }}
        >
          <div className="font-bold">{tooltip.process.name || tooltip.process.type}</div>
          <div className="text-muted-foreground">Tier {tooltip.process.tier}</div>
          <div className="text-muted-foreground">Age: {Math.floor(tooltip.process.age)} ticks</div>
          {tooltip.process.bonds.length > 0 && (
            <div className="text-muted-foreground">Bonds: {tooltip.process.bonds.length}</div>
          )}
        </div>
      )}
    </>
  );
}
