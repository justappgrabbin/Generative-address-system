import { Router, type IRouter } from "express";
import { db, gatesTable } from "@workspace/db";
import { computeChannels } from "../lib/morphing-engine";

const router: IRouter = Router();

// GET /channels — all channels with their status
router.get("/channels", async (_req, res): Promise<void> => {
  const gates = await db.select().from(gatesTable);
  const channels = computeChannels(gates);
  res.json(channels);
});

// GET /channels/active — only active or firing channels
router.get("/channels/active", async (_req, res): Promise<void> => {
  const gates = await db.select().from(gatesTable);
  const channels = computeChannels(gates).filter(
    c => c.status === "active" || c.status === "firing",
  );
  res.json(channels);
});

export default router;
