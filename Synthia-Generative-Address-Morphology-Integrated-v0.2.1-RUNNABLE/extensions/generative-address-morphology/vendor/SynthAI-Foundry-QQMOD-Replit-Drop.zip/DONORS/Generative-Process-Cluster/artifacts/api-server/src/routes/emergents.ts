import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, emergentsTable } from "@workspace/db";

const router: IRouter = Router();

// GET /emergents
router.get("/emergents", async (_req, res): Promise<void> => {
  const emergents = await db
    .select()
    .from(emergentsTable)
    .orderBy(desc(emergentsTable.createdAt));

  res.json(
    emergents.map(e => ({
      id: e.id,
      type: e.type,
      channelAGates: [e.channelAGateA, e.channelAGateB],
      channelBGates: [e.channelBGateA, e.channelBGateB],
      sharedGate: e.sharedGate,
      description: e.description,
      createdAt: e.createdAt,
    })),
  );
});

// GET /emergents/latest
router.get("/emergents/latest", async (_req, res): Promise<void> => {
  const [emergent] = await db
    .select()
    .from(emergentsTable)
    .orderBy(desc(emergentsTable.createdAt))
    .limit(1);

  res.json({
    emergent: emergent
      ? {
          id: emergent.id,
          type: emergent.type,
          channelAGates: [emergent.channelAGateA, emergent.channelAGateB],
          channelBGates: [emergent.channelBGateA, emergent.channelBGateB],
          sharedGate: emergent.sharedGate,
          description: emergent.description,
          createdAt: emergent.createdAt,
        }
      : null,
  });
});

export default router;
