import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, gatesTable, winsTable, emergentsTable } from "@workspace/db";
import {
  GetGateParams,
  UpdateGateParams,
  UpdateGateBody,
  LogWinParams,
  LogWinBody,
} from "@workspace/api-zod";
import {
  buildGateData,
  computeBigramValue,
  computeChannels,
  detectEmergent,
  levelToPhase,
} from "../lib/morphing-engine";

const router: IRouter = Router();

// GET /gates — all 64 gate state machines
router.get("/gates", async (req, res): Promise<void> => {
  const gates = await db.select().from(gatesTable).orderBy(gatesTable.gateNumber);
  res.json(gates);
});

// GET /gates/:gateNumber
router.get("/gates/:gateNumber", async (req, res): Promise<void> => {
  const params = GetGateParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [gate] = await db
    .select()
    .from(gatesTable)
    .where(eq(gatesTable.gateNumber, params.data.gateNumber));

  if (!gate) {
    res.status(404).json({ error: "Gate not found" });
    return;
  }

  res.json(gate);
});

// PATCH /gates/:gateNumber — set intention
router.patch("/gates/:gateNumber", async (req, res): Promise<void> => {
  const params = UpdateGateParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateGateBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [gate] = await db
    .update(gatesTable)
    .set({ intention: body.data.intention ?? null })
    .where(eq(gatesTable.gateNumber, params.data.gateNumber))
    .returning();

  if (!gate) {
    res.status(404).json({ error: "Gate not found" });
    return;
  }

  res.json(gate);
});

// POST /gates/:gateNumber/win — inject a bigram, level up the gate
router.post("/gates/:gateNumber/win", async (req, res): Promise<void> => {
  const params = LogWinParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = LogWinBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { gateNumber } = params.data;
  const { description } = body.data;

  const [gate] = await db
    .select()
    .from(gatesTable)
    .where(eq(gatesTable.gateNumber, gateNumber));

  if (!gate) {
    res.status(404).json({ error: "Gate not found" });
    return;
  }

  const levelBefore = gate.level;
  const bigramValue = computeBigramValue(gateNumber, description);

  // Level up — cap at 12
  const newLevel = Math.min(gate.level + 1, 12);
  const newBigramCount = gate.bigramCount + 1;
  const newIsActive = newLevel >= 6;

  const [updatedGate] = await db
    .update(gatesTable)
    .set({
      level: newLevel,
      bigramCount: newBigramCount,
      isActive: newIsActive,
    })
    .where(eq(gatesTable.gateNumber, gateNumber))
    .returning();

  // Record the win
  const [win] = await db
    .insert(winsTable)
    .values({
      gateNumber,
      description,
      bigramValue,
      levelBefore,
      levelAfter: newLevel,
    })
    .returning();

  // Check if a channel activated — load all gates and compute channels
  const allGates = await db.select().from(gatesTable);
  const channels = computeChannels(allGates);

  // Update channelActive flags for all gates in active/firing channels
  const activeGates = new Set<number>();
  for (const ch of channels) {
    if (ch.status === "active" || ch.status === "firing") {
      activeGates.add(ch.gateA);
      activeGates.add(ch.gateB);
    }
  }

  // Update channelActive on our gate if it changed
  const wasChannelActive = gate.channelActive;
  const isNowChannelActive = activeGates.has(gateNumber);
  if (wasChannelActive !== isNowChannelActive) {
    await db
      .update(gatesTable)
      .set({ channelActive: isNowChannelActive })
      .where(eq(gatesTable.gateNumber, gateNumber));
    if (updatedGate) updatedGate.channelActive = isNowChannelActive;
  }

  const channelActivated = !wasChannelActive && isNowChannelActive;

  // Check for new emergent events
  const existingEmergents = await db.select().from(emergentsTable);
  const existingSharedGates = new Set(existingEmergents.map(e => e.sharedGate));

  const emergentData = detectEmergent(channels, existingSharedGates);
  let emergentTriggered = false;

  if (emergentData) {
    await db.insert(emergentsTable).values(emergentData);
    emergentTriggered = true;
    req.log.info({ emergentData }, "Emergent event triggered");
  }

  res.status(201).json({
    win,
    gate: updatedGate,
    channelActivated,
    emergentTriggered,
  });
});

export default router;
