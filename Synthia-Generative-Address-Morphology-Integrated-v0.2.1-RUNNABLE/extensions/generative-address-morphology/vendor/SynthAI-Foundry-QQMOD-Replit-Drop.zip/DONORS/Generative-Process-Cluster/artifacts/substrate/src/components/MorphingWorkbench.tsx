import { useMemo, useState } from "react";
import type { Channel, Emergent, Gate, Win } from "@workspace/api-client-react";
import { ArrowUpRight, Check, ChevronRight, CircleDot, Plus, Sparkles, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const PHASES = [
  { label: "Primitive", range: "0–2", color: "#64748b" },
  { label: "Pattern", range: "3–5", color: "#38bdf8" },
  { label: "Tool", range: "6–8", color: "#a78bfa" },
  { label: "Channel", range: "9–11", color: "#f59e0b" },
  { label: "Morph", range: "12", color: "#34d399" },
];

function phaseFor(level: number) {
  if (level <= 2) return PHASES[0];
  if (level <= 5) return PHASES[1];
  if (level <= 8) return PHASES[2];
  if (level <= 11) return PHASES[3];
  return PHASES[4];
}

function GateCell({
  gate,
  selected,
  onClick,
}: {
  gate: Gate;
  selected: boolean;
  onClick: () => void;
}) {
  const phase = phaseFor(gate.level);
  return (
    <button
      type="button"
      onClick={onClick}
      className={`gate-cell ${selected ? "gate-cell-selected" : ""}`}
      style={{ "--gate-accent": phase.color } as React.CSSProperties}
      aria-label={`Gate ${gate.gateNumber}, level ${gate.level}`}
    >
      <span className="gate-number">{String(gate.gateNumber).padStart(2, "0")}</span>
      <span className="gate-bits">{gate.binaryState}</span>
      <span className="gate-level">L{gate.level}</span>
    </button>
  );
}

function MiniBinary({ value }: { value: string }) {
  return (
    <span className="mini-binary" aria-label={`binary ${value}`}>
      {value.split("").map((bit, index) => (
        <span key={`${bit}-${index}`} className={bit === "1" ? "bit-on" : "bit-off"} />
      ))}
    </span>
  );
}

function ChannelCard({ channel }: { channel: Channel }) {
  const firing = channel.status === "firing";
  return (
    <div className={`channel-card ${firing ? "channel-card-firing" : ""}`}>
      <div className="channel-card-top">
        <div className="channel-route">
          <span>G{channel.gateA}</span>
          <ChevronRight size={13} />
          <span>G{channel.gateB}</span>
        </div>
        <span className={`status-pill ${firing ? "status-pill-firing" : ""}`}>
          {firing ? "Firing" : "Active"}
        </span>
      </div>
      <div className="channel-card-name">{channel.channelName}</div>
      <div className="channel-card-output">
        <span>Edge output</span>
        <MiniBinary value={channel.edgeOutput} />
        <span className="mono output-gate">
          {channel.edgeOutputGate ? `G${channel.edgeOutputGate}` : "new"}
        </span>
      </div>
    </div>
  );
}

type Props = {
  gates: Gate[];
  wins: Win[];
  channels: Channel[];
  emergents: Emergent[];
  selectedGateNumber: number | null;
  setSelectedGateNumber: (number: number | null) => void;
  onLogWin: (gateNumber: number, description: string) => Promise<unknown>;
  onUpdateIntention: (gateNumber: number, intention: string) => Promise<unknown>;
  isLoggingWin: boolean;
};

export function MorphingWorkbench({
  gates,
  wins,
  channels,
  emergents,
  selectedGateNumber,
  setSelectedGateNumber,
  onLogWin,
  onUpdateIntention,
  isLoggingWin,
}: Props) {
  const [description, setDescription] = useState("");
  const [intention, setIntention] = useState("");
  const [activeView, setActiveView] = useState<"overview" | "jobs" | "templates">("overview");
  const { toast } = useToast();
  const selectedGate = gates.find((gate) => gate.gateNumber === selectedGateNumber);

  const activeChannels = channels.filter((channel) => channel.status !== "potential");
  const firingChannels = channels.filter((channel) => channel.status === "firing").length;
  const averageLevel = useMemo(
    () => (gates.length ? gates.reduce((sum, gate) => sum + gate.level, 0) / gates.length : 0),
    [gates],
  );

  const handleSelectGate = (gateNumber: number) => {
    setSelectedGateNumber(gateNumber);
    const gate = gates.find((item) => item.gateNumber === gateNumber);
    setIntention(gate?.intention ?? "");
  };

  const handleLogWin = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!description.trim() || !selectedGateNumber) {
      toast({
        title: "Add a description and choose a gate",
        description: "A completed job needs both before it can shape the engine.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = (await onLogWin(selectedGateNumber, description.trim())) as {
        gate?: Gate;
        channelActivated?: boolean;
        emergentTriggered?: boolean;
      };
      toast({
        title: `Gate ${selectedGateNumber} advanced`,
        description: result.channelActivated
          ? "A new channel is now active."
          : result.emergentTriggered
            ? "A new capability emerged from the active channels."
            : "The result was added to the substrate.",
      });
      setDescription("");
    } catch {
      toast({ title: "Could not save that result", description: "Try again in a moment.", variant: "destructive" });
    }
  };

  const handleSaveIntention = async () => {
    if (!selectedGateNumber) return;
    try {
      await onUpdateIntention(selectedGateNumber, intention);
      toast({ title: "Gate intention saved" });
    } catch {
      toast({ title: "Could not save the intention", variant: "destructive" });
    }
  };

  return (
    <main className="workspace-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><span /></div>
          <div>
            <div className="brand-name">substrate</div>
            <div className="brand-caption">morphing engine</div>
          </div>
        </div>
        <nav className="topnav" aria-label="Workspace">
          {[
            ["overview", "Overview"],
            ["jobs", "Jobs"],
            ["templates", "Templates"],
          ].map(([value, label]) => (
            <button
              type="button"
              key={value}
              className={activeView === value ? "nav-item nav-item-active" : "nav-item"}
              onClick={() => setActiveView(value as typeof activeView)}
            >
              {label}
            </button>
          ))}
        </nav>
        <div className="topbar-status"><span className="live-dot" /> Engine online</div>
      </header>

      <div className="workspace-content">
        <section className="content-column">
          {activeView === "overview" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">Your workspace</div>
                  <h1>Make something new.</h1>
                  <p>Small tools combine into capabilities you did not have before.</p>
                </div>
                <div className="heading-actions">
                  <span className="sync-label"><span className="live-dot" /> Live state</span>
                  <Button variant="outline" className="plain-button" onClick={() => handleSelectGate(1)}>
                    <Plus size={16} /> New job
                  </Button>
                </div>
              </div>

              <div className="metric-strip">
                <div><span className="metric-label">State variables</span><strong>{gates.length || 64}<small>/64</small></strong></div>
                <div><span className="metric-label">Average progress</span><strong>{Math.round(averageLevel / 12 * 100)}<small>%</small></strong></div>
                <div><span className="metric-label">Active channels</span><strong>{activeChannels.length}<small>{firingChannels ? ` · ${firingChannels} firing` : ""}</small></strong></div>
                <div><span className="metric-label">Successful jobs</span><strong>{wins.length}</strong></div>
              </div>

              <div className="section-heading">
                <div><span className="eyebrow">Computational substrate</span><h2>64 state variables</h2></div>
                <span className="helper-text">Select a gate to inspect or add a result</span>
              </div>

              <div className="substrate-card">
                <div className="phase-legend">
                  {PHASES.map((phase) => (
                    <div key={phase.label}><i style={{ background: phase.color }} /><span>{phase.label}</span><em>{phase.range}</em></div>
                  ))}
                </div>
                <div className="gate-grid">
                  {gates.map((gate) => (
                    <GateCell
                      key={gate.gateNumber}
                      gate={gate}
                      selected={selectedGateNumber === gate.gateNumber}
                      onClick={() => handleSelectGate(gate.gateNumber)}
                    />
                  ))}
                </div>
                <div className="substrate-footer">
                  <span><Terminal size={14} /> Primitive → pattern → tool → channel → morph</span>
                  <span className="mono">13 levels per variable</span>
                </div>
              </div>

              <div className="section-heading channels-heading">
                <div><span className="eyebrow">Composition layer</span><h2>Channels <span className="count-badge">{activeChannels.length}</span></h2></div>
                <span className="helper-text">Edge functions created by paired tools</span>
              </div>
              {activeChannels.length ? (
                <div className="channels-grid">{activeChannels.slice(0, 6).map((channel) => <ChannelCard key={`${channel.gateA}-${channel.gateB}`} channel={channel} />)}</div>
              ) : (
                <div className="empty-card">
                  <div className="empty-icon"><CircleDot size={18} /></div>
                  <div><strong>No channels yet</strong><p>Advance two compatible gates to level 4 to create the first edge function.</p></div>
                  <ArrowUpRight size={16} className="muted-icon" />
                </div>
              )}
            </>
          )}

          {activeView === "jobs" && (
            <div className="simple-view">
              <div className="page-heading"><div><div className="eyebrow">Execution history</div><h1>Jobs</h1><p>Every successful result becomes material for the next composition.</p></div></div>
              <div className="job-list">
                {wins.length ? wins.map((win) => (
                  <div className="job-row" key={win.id}><div className="job-check"><Check size={14} /></div><div><strong>{win.description}</strong><span>Gate {win.gateNumber} · Level {win.levelBefore} → {win.levelAfter}</span></div><span className="mono job-bigram">{win.bigramValue}</span></div>
                )) : <div className="empty-card"><div><strong>No jobs logged yet</strong><p>Use the result logger to give the engine something real to work with.</p></div></div>}
              </div>
            </div>
          )}

          {activeView === "templates" && (
            <div className="simple-view">
              <div className="page-heading"><div><div className="eyebrow">Starter systems</div><h1>Templates</h1><p>Fixed primitives are the starting points. Their combinations are not fixed.</p></div></div>
              <div className="template-grid">
                {["Web app", "Game loop", "Data tool", "Writing partner"].map((template) => <button type="button" key={template} className="template-card" onClick={() => toast({ title: `${template} template selected`, description: "Choose a gate to give this system a place in the substrate." })}><div className="template-icon"><Sparkles size={16} /></div><strong>{template}</strong><span>Compose from primitives <ArrowUpRight size={14} /></span></button>)}
              </div>
            </div>
          )}
        </section>

        <aside className="engine-panel">
          <div className="panel-heading"><div><div className="eyebrow">Shape the engine</div><h2>Log a result</h2></div><span className="panel-kicker">+ bigram</span></div>
          <p className="panel-intro">Tell the engine what worked. It uses your result as a small computational input and advances the selected state variable.</p>
          <form className="result-form" onSubmit={handleLogWin}>
            <Textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="What did you accomplish?" className="result-textarea" />
            <div className="form-label-row"><label>Choose a state variable</label><span className="mono">{selectedGateNumber ? `G${String(selectedGateNumber).padStart(2, "0")}` : "none selected"}</span></div>
            <div className="mini-gate-grid">{gates.map((gate) => <button type="button" key={gate.gateNumber} onClick={() => handleSelectGate(gate.gateNumber)} className={`mini-gate ${selectedGateNumber === gate.gateNumber ? "mini-gate-selected" : ""}`} style={{ "--gate-accent": phaseFor(gate.level).color } as React.CSSProperties}>{gate.gateNumber}</button>)}</div>
            <Button type="submit" className="submit-button" disabled={isLoggingWin}><Check size={16} /> {isLoggingWin ? "Saving…" : "Log successful result"}</Button>
          </form>

          {selectedGate && (
            <div className="selected-gate">
              <div className="selected-gate-header"><div><div className="eyebrow">Selected variable</div><h3>Gate {selectedGate.gateNumber}</h3></div><span className="phase-tag" style={{ color: phaseFor(selectedGate.level).color }}>{phaseFor(selectedGate.level).label}</span></div>
              <div className="level-line"><span>Progress</span><span className="mono">{selectedGate.level}/12</span></div>
              <div className="level-track"><span style={{ width: `${selectedGate.level / 12 * 100}%`, background: phaseFor(selectedGate.level).color }} /></div>
              <div className="selected-meta"><span>Binary <b className="mono">{selectedGate.binaryState}</b></span><span>Inputs <b>{selectedGate.bigramCount}</b></span></div>
              <Input value={intention} onChange={(event) => setIntention(event.target.value)} placeholder="What are you building with this?" className="intention-input" />
              <Button type="button" variant="outline" className="save-button" onClick={handleSaveIntention}>Save intention</Button>
            </div>
          )}

          <div className="panel-section"><div className="panel-section-title"><span className="eyebrow">Recent results</span><span className="mono">{wins.length}</span></div>
            {wins.slice(0, 4).map((win) => <div className="activity-row" key={win.id}><div className="activity-marker"><Check size={12} /></div><div><strong>{win.description}</strong><span>Gate {win.gateNumber} · L{win.levelBefore} → L{win.levelAfter}</span></div></div>)}
            {!wins.length && <p className="quiet-copy">Your completed jobs will appear here.</p>}
          </div>

          <div className="panel-section"><div className="panel-section-title"><span className="eyebrow">Emergent capabilities</span><span className="mono">{emergents.length}</span></div>
            {emergents.slice(0, 2).map((emergent) => <div className={`emergent-row ${emergent.type === "messi" ? "emergent-gold" : ""}`} key={emergent.id}><div className="emergent-label">{emergent.type === "messi" ? "Flow" : "Auto novel"}</div><p>{emergent.description}</p></div>)}
            {!emergents.length && <p className="quiet-copy">Two active channels will unlock a new capability here.</p>}
          </div>
        </aside>
      </div>
    </main>
  );
}