import { Button } from '@/components/ui/button';

export const Controls = ({
  speedMult,
  setSpeedMult,
  playing,
  setPlaying,
  depth,
  setDepth,
  seedPhantom,
  reset
}: {
  speedMult: number;
  setSpeedMult: (v: number) => void;
  playing: boolean;
  setPlaying: (v: boolean) => void;
  depth: number;
  setDepth: (v: number) => void;
  seedPhantom: () => void;
  reset: () => void;
}) => {
  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 z-20">
      
      {/* Fractal Depth Ladder */}
      <div className="flex bg-card/80 backdrop-blur-xl border border-border rounded-full p-1 shadow-2xl">
        {['GATE', 'LINE', 'COLOR', 'TONE', 'BASE'].map((level, i) => (
          <button
            key={level}
            onClick={() => setDepth(i)}
            className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all ${
              depth === i 
                ? 'bg-primary text-primary-foreground shadow-[0_0_15px_rgba(255,255,255,0.3)]' 
                : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
            }`}
          >
            {level}
          </button>
        ))}
      </div>

      {/* Playback Controls */}
      <div className="flex items-center gap-2 bg-card/80 backdrop-blur-xl border border-border rounded-lg p-2 shadow-2xl">
        <Button variant="outline" size="sm" onClick={() => setPlaying(!playing)} className="w-20">
          {playing ? 'PAUSE' : 'PLAY'}
        </Button>
        
        <div className="h-6 w-px bg-border mx-1" />
        
        {[0.5, 1, 2, 5, 10].map(s => (
          <Button 
            key={s} 
            variant={speedMult === s ? "secondary" : "ghost"} 
            size="sm" 
            className="text-xs px-2 h-7"
            onClick={() => setSpeedMult(s)}
          >
            {s}x
          </Button>
        ))}

        <div className="h-6 w-px bg-border mx-1" />

        <Button variant="ghost" size="sm" onClick={seedPhantom} className="text-purple-400 hover:text-purple-300 hover:bg-purple-400/10 text-xs">
          SEED PHANTOM
        </Button>
        <Button variant="ghost" size="sm" onClick={reset} className="text-destructive hover:text-destructive-foreground hover:bg-destructive text-xs">
          RESET
        </Button>
      </div>
    </div>
  );
};
