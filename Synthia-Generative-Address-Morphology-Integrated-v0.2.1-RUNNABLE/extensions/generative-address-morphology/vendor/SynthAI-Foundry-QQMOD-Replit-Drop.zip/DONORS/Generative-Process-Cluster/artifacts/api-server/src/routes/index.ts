import { Router, type IRouter } from "express";
import healthRouter from "./health";
import gatesRouter from "./gates";
import winsRouter from "./wins";
import channelsRouter from "./channels";
import emergentsRouter from "./emergents";
import substrateRouter from "./substrate";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gatesRouter);
router.use(winsRouter);
router.use(channelsRouter);
router.use(emergentsRouter);
router.use(substrateRouter);

export default router;
