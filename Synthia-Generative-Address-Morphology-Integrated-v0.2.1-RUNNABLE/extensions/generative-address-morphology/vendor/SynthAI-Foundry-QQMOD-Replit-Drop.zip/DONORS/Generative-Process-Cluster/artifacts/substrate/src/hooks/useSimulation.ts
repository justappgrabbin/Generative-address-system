import { useEffect, useRef, useState, useCallback } from 'react';
import { PLANETS, CHANNELS, HEXAGRAMS } from '../lib/constants';
import { getAddress, xorBinary, findGateByBinary } from '../lib/utils';
import { computeHiguchiDimension } from '../lib/higuchi';

export type PlanetState = {
  id: string;
  symbol: string;
  glyph: string;
  color: string;
  arc: number;
  address: ReturnType<typeof getAddress>;
  speed: number;
  seed: number;
};

export type PhantomGate = {
  id: string;
  gate: number;
  binary: string;
  ticksLeft: number;
};

export type ActiveChannel = {
  gateA: number;
  gateB: number;
  planetAId?: string;
  planetBId?: string;
  outputBinary: string;
  outputGate: number | null;
  resonance: number; // how long it's been active
};

export function useSimulation() {
  const [speedMult, setSpeedMult] = useState(1);
  const [playing, setPlaying] = useState(true);
  const [depth, setDepth] = useState(0); // 0=Gate, 1=Line, etc
  const [tickCount, setTickCount] = useState(0);
  
  // State updated every 500ms for UI
  const [uiState, setUiState] = useState({
    planets: [] as PlanetState[],
    phantoms: [] as PhantomGate[],
    channels: [] as ActiveChannel[],
    dh: 1.0,
    conwayGrid: new Array(64).fill(0)
  });
  
  const stateRef = useRef({
    planets: PLANETS.map(p => ({
      ...p,
      arc: p.seed,
      address: getAddress(p.seed)
    })),
    phantoms: [] as PhantomGate[],
    channels: [] as ActiveChannel[],
    dh: 1.0,
    lastTime: performance.now(),
    tickTimer: 0,
    tickCount: 0,
    conwayGrid: new Array(64).fill(0) // 1 if occupied, 0 if empty
  });
  
  const reset = useCallback(() => {
    stateRef.current.planets = PLANETS.map(p => ({
      ...p,
      arc: p.seed,
      address: getAddress(p.seed)
    }));
    stateRef.current.phantoms = [];
    stateRef.current.channels = [];
    stateRef.current.tickCount = 0;
    setTickCount(0);
  }, []);

  const seedPhantom = useCallback(() => {
    // Find biggest gap
    const activeGates = stateRef.current.planets.map(p => p.address.gate).sort((a, b) => a - b);
    let maxGap = 0;
    let gapStart = 0;
    for (let i = 0; i < activeGates.length; i++) {
      const g1 = activeGates[i];
      const g2 = activeGates[(i + 1) % activeGates.length];
      let gap = g2 - g1;
      if (gap < 0) gap += 64;
      if (gap > maxGap) {
        maxGap = gap;
        gapStart = g1;
      }
    }
    const targetGate = (gapStart + Math.floor(maxGap / 2)) % 64 || 64;
    
    stateRef.current.phantoms.push({
      id: `p_${Date.now()}`,
      gate: targetGate,
      binary: HEXAGRAMS[targetGate as keyof typeof HEXAGRAMS] || '000000',
      ticksLeft: 5
    });
  }, []);

  useEffect(() => {
    let animId: number;
    
    const loop = (time: number) => {
      const dt = Math.min((time - stateRef.current.lastTime) / 1000, 0.1);
      stateRef.current.lastTime = time;
      
      if (playing) {
        // Move planets
        stateRef.current.planets.forEach(p => {
          p.arc = (p.arc + p.speed * speedMult * dt * 10) % 360;
          p.address = getAddress(p.arc);
        });
        
        stateRef.current.tickTimer += dt;
        if (stateRef.current.tickTimer >= 0.5) {
          stateRef.current.tickTimer = 0;
          
          // CONWAY TICK
          stateRef.current.tickCount++;
          setTickCount(stateRef.current.tickCount);
          
          const grid = new Array(64).fill(0);
          const currentGates = new Map<number, PlanetState | PhantomGate>();
          
          stateRef.current.planets.forEach(p => {
            grid[p.address.gate - 1] = 1;
            currentGates.set(p.address.gate, p);
          });
          
          // Decay phantoms
          stateRef.current.phantoms = stateRef.current.phantoms
            .map(ph => ({ ...ph, ticksLeft: ph.ticksLeft - 1 }))
            .filter(ph => {
              if (ph.ticksLeft <= 0) return false;
              if (grid[ph.gate - 1] === 1) return false; // Overwritten by real planet
              return true;
            });
            
          stateRef.current.phantoms.forEach(ph => {
            grid[ph.gate - 1] = 1;
            currentGates.set(ph.gate, ph);
          });
          
          // Next generation of grid for DH and phantoms
          const nextGrid = [...grid];
          // Simple cellular automata rule
          for (let i = 0; i < 64; i++) {
            const left = grid[(i - 1 + 64) % 64];
            const right = grid[(i + 1) % 64];
            const neighbors = left + right; // only 2 neighbors in 1D ring
            
            // "An EMPTY gate adjacent to exactly 2 active gates: spawns a new PHANTOM gate"
            // Wait, prompt says: "A gate with 3+ active neighbors" - but this is a 1D ring!
            // Actually it says "Conway rules applied to the 64-slot ring... adjacent to exactly 3 active gates". 
            // In a 1D ring you only have 2 adjacent neighbors. So standard Conway is impossible. 
            // Let's use a 1D rule: if empty and both neighbors are active, spawn phantom.
            if (grid[i] === 0 && neighbors === 2) {
              const gLeft = currentGates.get(((i - 1 + 64) % 64) + 1);
              const gRight = currentGates.get(((i + 1) % 64) + 1);
              if (gLeft && gRight) {
                const b1 = 'address' in gLeft ? gLeft.address.binary : gLeft.binary;
                const b2 = 'address' in gRight ? gRight.address.binary : gRight.binary;
                const outBin = xorBinary(b1, b2);
                stateRef.current.phantoms.push({
                  id: `p_${stateRef.current.tickCount}_${i}`,
                  gate: i + 1,
                  binary: outBin,
                  ticksLeft: 3
                });
              }
            }
          }
          
          // Calculate Channels
          const channels: ActiveChannel[] = [];
          CHANNELS.forEach(([gA, gB]) => {
            const a = currentGates.get(gA);
            const b = currentGates.get(gB);
            if (a && b) {
              const binA = 'address' in a ? a.address.binary : a.binary;
              const binB = 'address' in b ? b.address.binary : b.binary;
              const outBin = xorBinary(binA, binB);
              
              // Find existing to preserve resonance
              const existing = stateRef.current.channels.find(c => c.gateA === gA && c.gateB === gB);
              
              channels.push({
                gateA: gA,
                gateB: gB,
                planetAId: a.id,
                planetBId: b.id,
                outputBinary: outBin,
                outputGate: findGateByBinary(outBin),
                resonance: (existing ? existing.resonance : 0) + 1
              });
            }
          });
          stateRef.current.channels = channels;
          
          // Update DH based on depth
          // Depth 0 = 64, 1 = 384, 2 = 2304, etc.
          // To keep it fast, we'll build a boolean array for the current depth scale.
          const dhScale = depth === 0 ? 64 : depth === 1 ? 384 : depth === 2 ? 2304 : depth === 3 ? 13824 : 69120;
          let seq: number[] = [];
          
          if (depth === 0) {
            seq = grid;
          } else {
            // Downsample simulation for deeper levels to avoid stalling the UI thread
            const maxSeq = Math.min(dhScale, 2000); 
            seq = new Array(maxSeq).fill(0);
            const ratio = dhScale / maxSeq;
            
            // Map planets into the finer grid
            stateRef.current.planets.forEach(p => {
              let idx = 0;
              if (depth === 1) idx = (p.address.gate - 1) * 6 + (p.address.line - 1);
              if (depth === 2) idx = ((p.address.gate - 1) * 6 + (p.address.line - 1)) * 6 + (p.address.color - 1);
              if (depth >= 3) {
                // Approximate for performance
                idx = Math.floor((p.arc / 360) * maxSeq);
              }
              const mapped = Math.floor(idx / ratio);
              if (mapped >= 0 && mapped < maxSeq) seq[mapped] = 1;
            });
          }
          
          stateRef.current.dh = computeHiguchiDimension(seq);
          stateRef.current.conwayGrid = grid;
          
          // Push to UI
          setUiState({
            planets: [...stateRef.current.planets],
            phantoms: [...stateRef.current.phantoms],
            channels: [...stateRef.current.channels],
            dh: stateRef.current.dh,
            conwayGrid: [...grid]
          });
        }
      } else {
        // Still push UI state to keep in sync if paused
        setUiState({
          planets: [...stateRef.current.planets],
          phantoms: [...stateRef.current.phantoms],
          channels: [...stateRef.current.channels],
          dh: stateRef.current.dh,
          conwayGrid: [...stateRef.current.conwayGrid]
        });
      }
      
      animId = requestAnimationFrame(loop);
    };
    
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [playing, speedMult, depth]);

  return {
    ...uiState,
    tickCount,
    speedMult, setSpeedMult,
    playing, setPlaying,
    depth, setDepth,
    reset, seedPhantom
  };
}
