import { useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';

interface HudProps {
  stats: { t0: number; t1: number; t2: number; t3: number };
  speed: number;
  onSpeedChange: (speed: number) => void;
  onSeed: () => void;
}

export function Hud({ stats, speed, onSpeedChange, onSeed }: HudProps) {
  const [showLegend, setShowLegend] = useState(true);

  return (
    <>
      {/* Title */}
      <div className="fixed top-4 left-4 text-[10px] tracking-[0.3em] opacity-40 uppercase">
        SUBSTRATE
      </div>

      {/* Legend */}
      {showLegend && (
        <div className="fixed top-4 right-4 text-[9px] space-y-1 opacity-60">
          <div className="mb-2 text-[10px] tracking-wider">PROCESS TYPES</div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-0.5">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#3dd9eb]" />
              <span>Oscillator</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#5bc5d9]" />
              <span>Counter</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#42d4f5]" />
              <span>Signal</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rotate-45 bg-[#2ec4d6]" />
              <span>Gate</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#4fd1e0]" />
              <span>Memory</span>
            </div>
          </div>
          <div className="pt-2 mt-2 border-t border-border/30">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#f5a623]" />
              <span>Tier 1</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#c850c0]" />
              <span>Tier 2</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#fff8dc]" />
              <span>Tier 3 Apex</span>
            </div>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="fixed bottom-4 left-4 text-xs tracking-wider opacity-70 font-mono">
        <span className="text-[#3dd9eb]">T0: {stats.t0}</span>
        <span className="ml-4 text-[#f5a623]">T1: {stats.t1}</span>
        <span className="ml-4 text-[#c850c0]">T2: {stats.t2}</span>
        <span className="ml-4 text-[#fff8dc]">T3: {stats.t3}</span>
      </div>

      {/* Controls */}
      <div className="fixed bottom-4 right-4 flex items-center gap-4">
        <div className="flex items-center gap-3">
          <span className="text-[10px] opacity-60 tracking-wider">SPEED</span>
          <Slider
            value={[speed]}
            onValueChange={([v]) => onSpeedChange(v)}
            min={0.5}
            max={3}
            step={0.1}
            className="w-24"
            data-testid="speed-slider"
          />
          <span className="text-[10px] opacity-60 w-8 text-right">{speed.toFixed(1)}x</span>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={onSeed}
          className="text-[10px] tracking-wider h-7 px-3"
          data-testid="button-seed"
        >
          SEED
        </Button>
      </div>

      {/* Instructions hint */}
      <div className="fixed bottom-16 right-4 text-[9px] opacity-30 tracking-wide text-right">
        Click anywhere to spawn a process
      </div>
    </>
  );
}
