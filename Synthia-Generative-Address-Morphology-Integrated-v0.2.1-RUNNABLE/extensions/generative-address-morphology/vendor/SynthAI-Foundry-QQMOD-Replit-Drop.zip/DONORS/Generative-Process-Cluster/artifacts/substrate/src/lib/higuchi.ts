/**
 * Computes Higuchi Fractal Dimension (D_H) for a sequence.
 * 
 * @param sequence Array of numbers (0s and 1s) representing segment states.
 * @param kMax Maximum interval size.
 * @returns Fractal dimension DH.
 */
export function computeHiguchiDimension(sequence: number[], kMax: number = 8): number {
  const N = sequence.length;
  if (N <= kMax) return 1.0;

  const Lk: number[] = [];
  const ln_k: number[] = [];
  const ln_Lk: number[] = [];

  for (let k = 1; k <= kMax; k++) {
    let L_k_sum = 0;
    
    for (let m = 0; m < k; m++) {
      let L_m_k = 0;
      const limit = Math.floor((N - m - 1) / k);
      
      for (let i = 1; i <= limit; i++) {
        L_m_k += Math.abs(sequence[m + i * k] - sequence[m + (i - 1) * k]);
      }
      
      const normalization = (N - 1) / (limit * k);
      L_k_sum += (L_m_k * normalization) / k;
    }
    
    const L = L_k_sum / k;
    if (L > 0) {
      Lk.push(L);
      ln_k.push(Math.log(1 / k));
      ln_Lk.push(Math.log(L));
    }
  }

  if (ln_k.length < 2) return 1.0;

  // Linear regression to find the slope
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  const n = ln_k.length;
  
  for (let i = 0; i < n; i++) {
    sumX += ln_k[i];
    sumY += ln_Lk[i];
    sumXY += ln_k[i] * ln_Lk[i];
    sumX2 += ln_k[i] * ln_k[i];
  }
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  
  // D_H is the slope, bound between 1.0 (ordered) and 2.0 (fully fractal)
  return Math.min(Math.max(slope, 1.0), 2.0);
}
