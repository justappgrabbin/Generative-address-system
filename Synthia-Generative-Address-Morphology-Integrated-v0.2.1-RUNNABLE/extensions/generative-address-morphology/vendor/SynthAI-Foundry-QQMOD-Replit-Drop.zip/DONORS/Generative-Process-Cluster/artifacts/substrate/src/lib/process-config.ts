import type { ProcessType, PrimitiveType, Tier1Type, Tier2Type } from '@/types/process';

export const TIER_RADIUS = {
  0: 8,
  1: 16,
  2: 28,
  3: 45,
} as const;

export const TIER_PROXIMITY = {
  0: 80,
  1: 140,
  2: 200,
} as const;

export const TIER_COLORS = {
  0: {
    oscillator: '#3dd9eb',
    counter: '#5bc5d9',
    signal: '#42d4f5',
    gate: '#2ec4d6',
    memory: '#4fd1e0',
  },
  1: {
    'rhythm-generator': '#f5a623',
    'pattern-recognizer': '#7ed321',
    'broadcaster': '#e8c547',
    'threshold-logic': '#d4a825',
  },
  2: {
    'temporal-sequencer': '#c850c0',
    'field-emitter': '#8e44ad',
    'unknown-composite': '#9b59b6',
  },
  3: {
    'apex-entity': '#fff8dc',
  },
} as const;

export const FUSION_RULES: Array<{
  inputs: ProcessType[];
  output: ProcessType;
  tier: 1 | 2 | 3;
}> = [
  // Tier 1 from primitives
  { inputs: ['oscillator', 'gate'], output: 'rhythm-generator', tier: 1 },
  { inputs: ['counter', 'memory'], output: 'pattern-recognizer', tier: 1 },
  { inputs: ['signal', 'signal', 'oscillator'], output: 'broadcaster', tier: 1 },
  { inputs: ['gate', 'memory', 'counter'], output: 'threshold-logic', tier: 1 },
  
  // Tier 2 from tier 1
  { inputs: ['rhythm-generator', 'pattern-recognizer'], output: 'temporal-sequencer', tier: 2 },
  { inputs: ['broadcaster', 'threshold-logic'], output: 'field-emitter', tier: 2 },
  
  // Tier 3 from tier 2
  { inputs: ['temporal-sequencer', 'field-emitter'], output: 'apex-entity', tier: 3 },
  { inputs: ['field-emitter', 'temporal-sequencer'], output: 'apex-entity', tier: 3 },
];

export function getProcessColor(type: ProcessType, tier: 0 | 1 | 2 | 3): string {
  return TIER_COLORS[tier][type as keyof typeof TIER_COLORS[typeof tier]] || '#ffffff';
}

export function getProcessRadius(tier: 0 | 1 | 2 | 3): number {
  return TIER_RADIUS[tier];
}

export function getProximityThreshold(tier: 0 | 1 | 2): number {
  return TIER_PROXIMITY[tier];
}

export function checkFusionCompatibility(types: ProcessType[]): ProcessType | null {
  const sortedTypes = [...types].sort();
  
  for (const rule of FUSION_RULES) {
    const sortedRuleInputs = [...rule.inputs].sort();
    if (sortedTypes.length === sortedRuleInputs.length &&
        sortedTypes.every((t, i) => t === sortedRuleInputs[i])) {
      return rule.output;
    }
  }
  
  return null;
}

export function generateCompositeName(parentTypes: ProcessType[]): string {
  const fragments = parentTypes.map(t => {
    const parts = t.split('-');
    return parts[Math.floor(Math.random() * parts.length)];
  });
  
  return fragments.join('-');
}

export const PRIMITIVE_TYPES: PrimitiveType[] = ['oscillator', 'counter', 'signal', 'gate', 'memory'];

export function getRandomPrimitiveType(): PrimitiveType {
  return PRIMITIVE_TYPES[Math.floor(Math.random() * PRIMITIVE_TYPES.length)];
}
