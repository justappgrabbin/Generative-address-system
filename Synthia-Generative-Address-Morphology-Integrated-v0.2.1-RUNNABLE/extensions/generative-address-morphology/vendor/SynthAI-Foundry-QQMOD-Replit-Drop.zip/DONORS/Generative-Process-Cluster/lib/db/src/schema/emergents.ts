import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

// Fires when two active channels share a gate (a circuit junction).
// type: "messi" (peak flow) | "auto-novel" (autonomous generation)
export const emergentsTable = pgTable("emergents", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  type: text("type").notNull(), // "messi" | "auto-novel"
  channelAGateA: integer("channel_a_gate_a").notNull(),
  channelAGateB: integer("channel_a_gate_b").notNull(),
  channelBGateA: integer("channel_b_gate_a").notNull(),
  channelBGateB: integer("channel_b_gate_b").notNull(),
  sharedGate: integer("shared_gate").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type InsertEmergent = typeof emergentsTable.$inferInsert;
export type Emergent = typeof emergentsTable.$inferSelect;
