import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

export const winsTable = pgTable("wins", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  gateNumber: integer("gate_number").notNull(),
  description: text("description").notNull(),
  bigramValue: text("bigram_value").notNull(), // "00" | "01" | "10" | "11"
  levelBefore: integer("level_before").notNull(),
  levelAfter: integer("level_after").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type InsertWin = typeof winsTable.$inferInsert;
export type Win = typeof winsTable.$inferSelect;
