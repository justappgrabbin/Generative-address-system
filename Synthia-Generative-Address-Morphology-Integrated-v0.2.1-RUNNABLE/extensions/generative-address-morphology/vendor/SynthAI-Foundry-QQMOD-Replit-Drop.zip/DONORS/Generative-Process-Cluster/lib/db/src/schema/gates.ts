import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const gatesTable = pgTable("gates", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  gateNumber: integer("gate_number").notNull().unique(),
  level: integer("level").notNull().default(0),
  binaryState: text("binary_state").notNull(),
  upperTrigram: integer("upper_trigram").notNull(),
  lowerTrigram: integer("lower_trigram").notNull(),
  upperTrigramName: text("upper_trigram_name").notNull(),
  lowerTrigramName: text("lower_trigram_name").notNull(),
  bigramCount: integer("bigram_count").notNull().default(0),
  intention: text("intention"),
  isActive: boolean("is_active").notNull().default(false),
  channelPartner: integer("channel_partner"),
  channelActive: boolean("channel_active").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type InsertGate = typeof gatesTable.$inferInsert;
export type Gate = typeof gatesTable.$inferSelect;
