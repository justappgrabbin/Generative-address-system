/**
 * Synthia Hands Organ
 *
 * Subordinate capability layer. It never replaces the Universal Execution
 * Spine or Trainable cognition.
 */
const clone = value => {
  try { return structuredClone(value); }
  catch {
    try { return JSON.parse(JSON.stringify(value)); }
    catch { return String(value); }
  }
};

function androidBridge() {
  return globalThis.SynthiaAndroid ?? null;
}

export class SynthiaHands {
  constructor({ journal = null } = {}) {
    this.journal = journal;
    this.history = [];
    this.capabilities = new Map();
    this.registerDefaults();
  }

  registerDefaults() {
    this.register({
      id:'javascript.run',
      description:'Run local JavaScript inside Cynthia.',
      autonomous:true,
      available:() => true,
      invoke:async ({ runtime, code, input }) => runtime.runJS(code, input, { manual:false }),
    });

    this.register({
      id:'files.pick',
      description:'Ask the person to pick a file through Android.',
      autonomous:false,
      available:() => Boolean(document?.createElement),
      invoke:async () => {
        const input = document.createElement('input');
        input.type = 'file';
        return await new Promise(resolve => {
          input.onchange = () => {
            const file = input.files?.[0] ?? null;
            resolve(file ? {
              name:file.name,
              type:file.type,
              size:file.size,
              file,
            } : null);
          };
          input.click();
        });
      },
    });

    this.register({
      id:'clipboard.read',
      description:'Read clipboard text with browser permission.',
      autonomous:false,
      available:() => Boolean(globalThis.navigator?.clipboard?.readText),
      invoke:async () => navigator.clipboard.readText(),
    });

    this.register({
      id:'clipboard.write',
      description:'Write clipboard text.',
      autonomous:false,
      available:() => Boolean(globalThis.navigator?.clipboard?.writeText),
      invoke:async ({ text }) => {
        await navigator.clipboard.writeText(String(text ?? ''));
        return { ok:true };
      },
    });

    this.register({
      id:'open.url',
      description:'Open a URL through the Android host.',
      autonomous:false,
      available:() => typeof androidBridge()?.openUrl === 'function',
      invoke:async ({ url }) => androidBridge().openUrl(String(url ?? '')),
    });

    this.register({
      id:'share.text',
      description:'Open Android share sheet for text.',
      autonomous:false,
      available:() => typeof androidBridge()?.shareText === 'function',
      invoke:async ({ text }) => androidBridge().shareText(String(text ?? '')),
    });

    this.register({
      id:'notify',
      description:'Show a local Android notification/toast.',
      autonomous:true,
      available:() => typeof androidBridge()?.notify === 'function',
      invoke:async ({ text }) => androidBridge().notify(String(text ?? '')),
    });

    this.register({
      id:'workspace.write',
      description:'Write UTF-8 text into Cynthia workspace.',
      autonomous:true,
      available:() => typeof androidBridge()?.writeWorkspaceText === 'function',
      invoke:async ({ path, text }) =>
        androidBridge().writeWorkspaceText(String(path ?? ''), String(text ?? '')),
    });

    this.register({
      id:'workspace.read',
      description:'Read UTF-8 text from Cynthia workspace.',
      autonomous:true,
      available:() => typeof androidBridge()?.readWorkspaceText === 'function',
      invoke:async ({ path }) =>
        androidBridge().readWorkspaceText(String(path ?? '')),
    });

    this.register({
      id:'termux.shell',
      description:'Optional Termux shell faculty.',
      autonomous:false,
      available:() => typeof androidBridge()?.runShell === 'function',
      invoke:async ({ command }) => androidBridge().runShell(String(command ?? '')),
    });
  }

  register(capability) {
    if (!capability?.id || typeof capability.invoke !== 'function') {
      throw new Error('Hand capability requires id + invoke().');
    }
    this.capabilities.set(capability.id, Object.freeze({ ...capability }));
  }

  list() {
    return [...this.capabilities.values()].map(cap => ({
      id:cap.id,
      description:cap.description ?? '',
      autonomous:Boolean(cap.autonomous),
      available:Boolean(cap.available?.()),
    }));
  }

  async use(id, args = {}, context = {}) {
    const capability = this.capabilities.get(id);
    if (!capability) throw new Error(`Unknown hand: ${id}`);
    if (!capability.available?.()) throw new Error(`Hand unavailable: ${id}`);

    const autonomous = context.manual !== true;
    if (autonomous && !capability.autonomous) {
      throw new Error(`Hand requires person approval: ${id}`);
    }

    const startedAt = new Date().toISOString();
    try {
      const result = await capability.invoke(args, context);
      const row = {
        at:startedAt,
        id,
        ok:true,
        autonomous,
        args:clone(args),
        result:clone(result),
      };
      this.history.push(row);
      if (this.history.length > 300) this.history.splice(0, this.history.length - 300);
      return result;
    } catch (error) {
      const row = {
        at:startedAt,
        id,
        ok:false,
        autonomous,
        args:clone(args),
        error:String(error?.stack || error?.message || error),
      };
      this.history.push(row);
      throw error;
    }
  }
}
