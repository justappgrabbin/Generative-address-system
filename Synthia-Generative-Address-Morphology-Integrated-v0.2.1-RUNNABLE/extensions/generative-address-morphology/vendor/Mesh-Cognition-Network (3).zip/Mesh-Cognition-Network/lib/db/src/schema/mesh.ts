import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, pgTable, real, serial, text, timestamp } from "drizzle-orm/pg-core";

export const meshAgentsTable = pgTable("mesh_agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  glyph: text("glyph").notNull(),
  status: text("status").notNull().default("listening"),
  activation: real("activation").notNull().default(0.45),
  generation: integer("generation").notNull().default(1),
  featureVector: integer("feature_vector").array().notNull(),
  focus: text("focus").array().notNull(),
  description: text("description").notNull(),
  recognitionRules: text("recognition_rules").array().notNull().default([]),
  generationRules: text("generation_rules").array().notNull().default([]),
  ruleFrequencies: jsonb("rule_frequencies").$type<Record<string, number>>().notNull().default({}),
  interactionCount: integer("interaction_count").notNull().default(0),
  lastInteractionAt: timestamp("last_interaction_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const meshCapabilityNodesTable = pgTable("mesh_capability_nodes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  networkType: text("network_type").notNull(),
  capabilities: text("capabilities").array().notNull().default([]),
  description: text("description").notNull(),
  featureVector: integer("feature_vector").array().notNull(),
  status: text("status").notNull().default("listening"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const meshNeuralNetworksTable = pgTable("mesh_neural_networks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  networkType: text("network_type").notNull(),
  familyKeys: text("family_keys").array().notNull().default([]),
  primitiveSlots: integer("primitive_slots").array().notNull().default([]),
  sharedPrimitiveSlots: integer("shared_primitive_slots").array().notNull().default([]),
  architectureStack: text("architecture_stack").array().notNull().default([]),
  inputSize: integer("input_size").notNull(),
  hiddenLayers: integer("hidden_layers").array().notNull(),
  outputSize: integer("output_size").notNull(),
  activation: text("activation").notNull().default("tanh"),
  weights: jsonb("weights").$type<Record<string, unknown>>().notNull(),
  trainingSteps: integer("training_steps").notNull().default(0),
  loss: real("loss").notNull().default(1),
  status: text("status").notNull().default("untrained"),
  lastTrainedAt: timestamp("last_trained_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const meshConnectionFiltersTable = pgTable("mesh_connection_filters", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  allowedCapabilities: text("allowed_capabilities").array().notNull().default([]),
  contextLens: text("context_lens").array().notNull().default([]),
  preferredOutputs: text("preferred_outputs").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const meshMemoryTable = pgTable("mesh_memory", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  content: text("content").notNull(),
  source: text("source").notNull(),
  strength: real("strength").notNull().default(0.5),
  featureVector: integer("feature_vector").array().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const meshSemanticNodesTable = pgTable("mesh_semantic_nodes", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  label: text("label").notNull(),
  kind: text("kind").notNull(),
  lexicalExpressions: text("lexical_expressions").array().notNull().default([]),
  featureVector: integer("feature_vector").array().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const meshSemanticTriplesTable = pgTable("mesh_semantic_triples", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").notNull(),
  relationId: integer("relation_id").notNull(),
  objectId: integer("object_id"),
  source: text("source").notNull(),
  confidence: real("confidence").notNull().default(0.5),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  terminatedAt: timestamp("terminated_at", { withTimezone: true }),
});

export const meshSemanticRulesTable = pgTable("mesh_semantic_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  surfacePattern: text("surface_pattern").notNull(),
  semanticPattern: text("semantic_pattern").notNull(),
  positiveCount: integer("positive_count").notNull().default(0),
  negativeCount: integer("negative_count").notNull().default(0),
  confidence: real("confidence").notNull().default(0.5),
  status: text("status").notNull().default("tentative"),
  examples: text("examples").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const meshEventsTable = pgTable("mesh_events", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(),
  message: text("message").notNull(),
  agentName: text("agent_name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const meshInquiriesTable = pgTable("mesh_inquiries", {
  id: serial("id").primaryKey(),
  query: text("query").notNull(),
  response: text("response").notNull(),
  outputModes: text("output_modes").array().notNull(),
  viewerKey: text("viewer_key").notNull().default("anonymous"),
  filterKey: text("filter_key").notNull().default("generalist"),
  lattice: jsonb("lattice").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const meshArtifactsTable = pgTable("mesh_artifacts", {
  id: text("id").primaryKey(),
  inquiryId: integer("inquiry_id").notNull(),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  mimeType: text("mime_type").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertMeshAgentSchema = createInsertSchema(meshAgentsTable);
export const insertMeshCapabilityNodeSchema = createInsertSchema(meshCapabilityNodesTable);
export const insertMeshNeuralNetworkSchema = createInsertSchema(meshNeuralNetworksTable);
export const insertMeshConnectionFilterSchema = createInsertSchema(meshConnectionFiltersTable);
export const insertMeshMemorySchema = createInsertSchema(meshMemoryTable);
export const insertMeshSemanticNodeSchema = createInsertSchema(meshSemanticNodesTable);
export const insertMeshSemanticTripleSchema = createInsertSchema(meshSemanticTriplesTable);
export const insertMeshSemanticRuleSchema = createInsertSchema(meshSemanticRulesTable);
export const insertMeshEventSchema = createInsertSchema(meshEventsTable);
export const insertMeshInquirySchema = createInsertSchema(meshInquiriesTable);
export const insertMeshArtifactSchema = createInsertSchema(meshArtifactsTable);

export type MeshAgent = typeof meshAgentsTable.$inferSelect;
export type MeshCapabilityNode = typeof meshCapabilityNodesTable.$inferSelect;
export type MeshNeuralNetwork = typeof meshNeuralNetworksTable.$inferSelect;
export type MeshConnectionFilter = typeof meshConnectionFiltersTable.$inferSelect;
export type MeshMemory = typeof meshMemoryTable.$inferSelect;
export type MeshSemanticNode = typeof meshSemanticNodesTable.$inferSelect;
export type MeshSemanticTriple = typeof meshSemanticTriplesTable.$inferSelect;
export type MeshSemanticRule = typeof meshSemanticRulesTable.$inferSelect;
export type MeshEvent = typeof meshEventsTable.$inferSelect;
export type MeshInquiry = typeof meshInquiriesTable.$inferSelect;
export type MeshArtifact = typeof meshArtifactsTable.$inferSelect;