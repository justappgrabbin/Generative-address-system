import { useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import {
  getListMeshArchitectureFamiliesQueryKey,
  getListMeshNeuralNetworksQueryKey,
  useBuildMeshNeuralNetwork,
  useListMeshArchitectureFamilies,
  useListMeshNeuralNetworks,
  useTrainMeshNeuralNetwork,
} from "@workspace/api-client-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Brain, Play, Plus, RefreshCw } from "lucide-react"

const networkTypes = ["semantic", "sequence", "visual", "code", "game", "app"]

export default function Networks() {
  const queryClient = useQueryClient()
  const { data: families, isLoading: familiesLoading } = useListMeshArchitectureFamilies({
    query: { queryKey: getListMeshArchitectureFamiliesQueryKey() }
  })
  const { data: networks, isLoading } = useListMeshNeuralNetworks({
    query: { refetchInterval: 5000, queryKey: getListMeshNeuralNetworksQueryKey() }
  })
  const buildNetwork = useBuildMeshNeuralNetwork()
  const trainNetwork = useTrainMeshNeuralNetwork()
  const [name, setName] = useState("")
  const [networkType, setNetworkType] = useState("semantic")
  const [hiddenLayers, setHiddenLayers] = useState("32,16")
  const [selectedFamilyKeys, setSelectedFamilyKeys] = useState<string[]>([])

  const handleBuild = (event: React.FormEvent) => {
    event.preventDefault()
    const layers = hiddenLayers.split(",").map((value) => Number(value.trim())).filter((value) => Number.isFinite(value) && value >= 4 && value <= 128)
    if (!name.trim() || layers.length === 0) return
    buildNetwork.mutate({ data: {
      name: name.trim(),
      networkType,
      hiddenLayers: layers,
      ...(selectedFamilyKeys.length > 0 ? { familyKeys: selectedFamilyKeys } : {}),
    } }, {
      onSuccess: () => {
        setName("")
        queryClient.invalidateQueries({ queryKey: getListMeshNeuralNetworksQueryKey() })
      }
    })
  }

  const toggleFamily = (key: string) => {
    setSelectedFamilyKeys((current) => current.includes(key) ? current.filter((item) => item !== key) : [...current, key].slice(0, 8))
  }

  const handleTrain = (id: number) => {
    trainNetwork.mutate({ id, data: { epochs: 5 } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListMeshNeuralNetworksQueryKey() })
    })
  }

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6">
      <div className="flex items-end justify-between border-b border-border pb-4">
        <div>
          <h1 className="text-3xl font-mono text-primary flex items-center gap-3">
            <Brain className="h-8 w-8" />
            Neural Network Lab
          </h1>
          <p className="text-muted-foreground mt-2 text-sm font-mono">
            Build local trainable networks, then fit them against recursive lattice samples.
          </p>
        </div>
        <Badge variant="outline" className="font-mono">INPUT SPACE · 64P + 5D</Badge>
      </div>

      <Card className="border-primary/30 bg-primary/5">
        <CardHeader className="pb-3">
          <CardTitle className="font-mono text-base flex items-center gap-2"><Plus className="h-4 w-4" /> Build a network</CardTitle>
          <CardDescription className="font-mono text-xs">The mesh uses an 81-value lattice vector and a six-class capability target.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleBuild} className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Input value={name} onChange={(event) => setName(event.target.value)} placeholder="network name" className="font-mono text-xs bg-background/60" />
            <select value={networkType} onChange={(event) => setNetworkType(event.target.value)} className="h-10 border border-input bg-background/60 px-3 text-xs font-mono">
              {networkTypes.map((type) => <option key={type} value={type}>{type} capability</option>)}
            </select>
            <Input value={hiddenLayers} onChange={(event) => setHiddenLayers(event.target.value)} placeholder="hidden layers: 32,16" className="font-mono text-xs bg-background/60" />
            <Button type="submit" disabled={buildNetwork.isPending || !name.trim()}><Plus className="h-4 w-4 mr-2" /> Build</Button>
          </form>
          <div className="mt-4 border-t border-primary/20 pt-3">
            <div className="flex items-center justify-between mb-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <span>compose from overlapping families</span>
              <span className="text-primary">{selectedFamilyKeys.length}/8 selected · blank uses capability defaults</span>
            </div>
            <div className="max-h-56 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5 pr-1">
              {familiesLoading ? <div className="text-xs text-muted-foreground font-mono col-span-full py-3">loading family registry…</div> : families?.map((family) => {
                const selected = selectedFamilyKeys.includes(family.key)
                return (
                  <label key={family.key} className={`flex items-start gap-2 border px-2 py-2 cursor-pointer transition-colors ${selected ? "border-primary bg-primary/10" : "border-border/60 hover:border-primary/50"}`}>
                    <input type="checkbox" checked={selected} onChange={() => toggleFamily(family.key)} disabled={!selected && selectedFamilyKeys.length >= 8} className="mt-0.5 accent-primary" />
                    <span className="min-w-0">
                      <span className="block font-mono text-[11px] text-foreground truncate">{family.name}</span>
                      <span className="block font-mono text-[9px] text-muted-foreground uppercase">{family.category} · {family.primitiveSlots.length} primitives</span>
                    </span>
                  </label>
                )
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, index) => <Skeleton key={index} className="h-52 w-full" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {networks?.map((network) => (
            <Card key={network.id} className="flex flex-col hover:border-primary/40 transition-colors">
              <CardHeader className="pb-3 border-b border-border/50">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <CardTitle className="font-mono text-lg">{network.name}</CardTitle>
                    <CardDescription className="font-mono text-xs text-primary mt-1">{network.networkType} network</CardDescription>
                  </div>
                  <Badge variant="outline" className="font-mono text-[10px]">{network.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="flex-1 py-4 space-y-4 font-mono text-xs">
                <div className="text-muted-foreground">architecture</div>
                <div className="text-foreground">{network.inputSize} → {network.hiddenLayers.join(" → ")} → {network.outputSize}</div>
                <div className="space-y-1">
                  <div className="text-muted-foreground">family composition</div>
                  <div className="text-foreground leading-5">{network.architectureStack.join(" + ")}</div>
                  <div className="text-muted-foreground">{network.familyKeys.length} families · {network.primitiveSlots.length} unique primitives · {network.sharedPrimitiveSlots.length} shared links</div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-muted-foreground"><span>training loss</span><span className="text-secondary">{network.loss.toFixed(5)}</span></div>
                  <div className="h-1.5 bg-muted overflow-hidden"><div className="h-full bg-secondary transition-all" style={{ width: `${Math.max(3, Math.min(100, (1 - network.loss) * 100))}%` }} /></div>
                </div>
                <div className="flex justify-between text-muted-foreground"><span>steps</span><span className="text-foreground">{network.trainingSteps}</span></div>
              </CardContent>
              <CardFooter className="border-t border-border/50 pt-3">
                <Button variant="secondary" className="w-full font-mono" onClick={() => handleTrain(network.id)} disabled={trainNetwork.isPending}>
                  {trainNetwork.isPending ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Play className="h-4 w-4 mr-2" />}
                  Train 5 epochs
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}