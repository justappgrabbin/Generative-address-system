import { Router, type IRouter } from "express";
import { asc, count, desc, eq, sql, and } from "drizzle-orm";
import { db, meshAgentsTable, meshArtifactsTable, meshCapabilityNodesTable, meshConnectionFiltersTable, meshEventsTable, meshInquiriesTable, meshMemoryTable, meshNeuralNetworksTable, meshSemanticNodesTable, meshSemanticRulesTable, meshSemanticTriplesTable } from "@workspace/db";
import { BuildMeshNeuralNetworkBody, MorphMeshAgentBody, RunMeshInquiryBody, TrainMeshNeuralNetworkBody } from "@workspace/api-zod";
import { activationFor, architectureFamilySeeds, buildNetworkBlueprint, buildSemanticGraph, capabilityNodeSeeds, capabilityTarget, connectionFilterSeeds, createCapabilityArtifact, createResponse, createSvgArtifact, createTrainableNetwork, grammarForRole, generateGrammarUtterance, initialRuleFrequencies, latticeContext, latticeFeatures, latticeInput, normalizeLatticeSelection, parseWithGrammar, roleSeeds, ruleConfidence, semanticPatternFor, solveAnalogy, surfacePatternFor, tokenize, trainNeuralNetwork, vectorize, type NeuralNetworkWeights } from "../lib/mesh-engine";

const router: IRouter = Router();
let seedPromise: Promise<void> | null = null;

function ensureSeeded(): Promise<void> {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    const existing = await db.select().from(meshAgentsTable).orderBy(asc(meshAgentsTable.id));
    if (existing.length === 0) {
      await db.insert(meshAgentsTable).values(roleSeeds.map((seed) => {
        const grammar = grammarForRole(seed.role, [...seed.focus]);
        return {
          ...seed,
          focus: [...seed.focus],
          status: "listening",
          activation: 0.42,
          generation: 1,
          featureVector: [0, 0, 0, 0, 0, 0, 0, 0],
          ...grammar,
          ruleFrequencies: initialRuleFrequencies(grammar.generationRules),
        };
      }));
      await db.insert(meshMemoryTable).values([
        { label: "objects + relations", content: "Treat meaning as objects connected by explicit relations.", source: "seed grammar", strength: 0.82, featureVector: [1, 1, 0, 0, 0, 0, 0, 0] },
        { label: "analogy transfer", content: "Transfer relational structure, not surface appearance.", source: "seed grammar", strength: 0.76, featureVector: [0, 1, 0, 1, 0, 0, 0, 0] },
      ]);
      await db.insert(meshEventsTable).values({ kind: "seed", message: "Five grammars entered the mesh and began listening.", agentName: "Archivist" });
    } else {
      for (const agent of existing) {
        if (agent.generationRules.length === 0 || agent.recognitionRules.length === 0) {
          const grammar = grammarForRole(agent.role, agent.focus);
          await db.update(meshAgentsTable).set({ ...grammar, ruleFrequencies: initialRuleFrequencies(grammar.generationRules) }).where(eq(meshAgentsTable.id, agent.id));
        }
      }
    }
    const existingNodes = await db.select().from(meshCapabilityNodesTable);
    for (const seed of capabilityNodeSeeds) {
      if (!existingNodes.some((node) => node.name === seed.name)) {
        await db.insert(meshCapabilityNodesTable).values({
          ...seed,
          capabilities: [...seed.capabilities],
          featureVector: [...seed.featureVector],
        });
      }
    }
    const existingFilters = await db.select().from(meshConnectionFiltersTable);
    for (const seed of connectionFilterSeeds) {
      if (!existingFilters.some((filter) => filter.key === seed.key)) {
        await db.insert(meshConnectionFiltersTable).values({
          ...seed,
          allowedCapabilities: [...seed.allowedCapabilities],
          contextLens: [...seed.contextLens],
          preferredOutputs: [...seed.preferredOutputs],
        });
      }
    }
    const existingNetworks = await db.select().from(meshNeuralNetworksTable);
    for (const seed of capabilityNodeSeeds) {
      const name = `${seed.networkType}-network`;
      const blueprint = buildNetworkBlueprint(undefined, seed.networkType);
      if (!existingNetworks.some((network) => network.name === name)) {
        await db.insert(meshNeuralNetworksTable).values({
          name,
          networkType: seed.networkType,
          familyKeys: blueprint.selectedFamilyKeys,
          primitiveSlots: blueprint.primitiveSlots,
          sharedPrimitiveSlots: blueprint.sharedPrimitives,
          architectureStack: blueprint.architectureStack,
          inputSize: 81,
          hiddenLayers: [32, 16],
          outputSize: 6,
          activation: "tanh",
          weights: createTrainableNetwork(name),
          status: "untrained",
        });
      }
    }
    for (const network of existingNetworks) {
      if (network.familyKeys.length === 0 || network.primitiveSlots.length === 0 || network.architectureStack.length === 0 || network.sharedPrimitiveSlots.length === 0) {
        const blueprint = buildNetworkBlueprint(undefined, network.networkType);
        await db.update(meshNeuralNetworksTable).set({
          familyKeys: blueprint.selectedFamilyKeys,
          primitiveSlots: blueprint.primitiveSlots,
          sharedPrimitiveSlots: blueprint.sharedPrimitives,
          architectureStack: blueprint.architectureStack,
          updatedAt: new Date(),
        }).where(eq(meshNeuralNetworksTable.id, network.id));
      }
    }
  })();
  return seedPromise;
}

router.get("/mesh/overview", async (_req, res): Promise<void> => {
  await ensureSeeded();
  const [agents, active, memories, inquiries, artifacts, latest] = await Promise.all([
    db.select({ value: count() }).from(meshAgentsTable),
    db.select({ value: count() }).from(meshAgentsTable).where(sql`${meshAgentsTable.activation} > 0.58`),
    db.select({ value: count() }).from(meshMemoryTable),
    db.select({ value: count() }).from(meshInquiriesTable),
    db.select({ value: count() }).from(meshArtifactsTable),
    db.select({ query: meshInquiriesTable.query }).from(meshInquiriesTable).orderBy(desc(meshInquiriesTable.createdAt)).limit(1),
  ]);
  res.json({ agents: agents[0]?.value ?? 0, active: active[0]?.value ?? 0, memories: memories[0]?.value ?? 0, inquiries: inquiries[0]?.value ?? 0, artifacts: artifacts[0]?.value ?? 0, latestInquiry: latest[0]?.query ?? null });
});

router.get("/mesh/agents", async (_req, res): Promise<void> => {
  await ensureSeeded();
  res.json(await db.select().from(meshAgentsTable).orderBy(asc(meshAgentsTable.id)));
});

router.get("/mesh/capabilities", async (_req, res): Promise<void> => {
  await ensureSeeded();
  const [nodes, filters] = await Promise.all([
    db.select().from(meshCapabilityNodesTable).orderBy(asc(meshCapabilityNodesTable.id)),
    db.select().from(meshConnectionFiltersTable).orderBy(asc(meshConnectionFiltersTable.id)),
  ]);
  res.json({ nodes, filters });
});

router.get("/mesh/architecture-families", async (_req, res): Promise<void> => {
  await ensureSeeded();
  res.json(architectureFamilySeeds);
});

router.get("/mesh/neural-networks", async (_req, res): Promise<void> => {
  await ensureSeeded();
  res.json(await db.select().from(meshNeuralNetworksTable).orderBy(asc(meshNeuralNetworksTable.id)));
});

router.post("/mesh/neural-networks", async (req, res): Promise<void> => {
  await ensureSeeded();
  const parsed = BuildMeshNeuralNetworkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const inputSize = 81;
  const outputSize = 6;
  const hiddenLayers = parsed.data.hiddenLayers.map(Number);
  const blueprint = buildNetworkBlueprint(parsed.data.familyKeys, parsed.data.networkType);
  const [network] = await db.insert(meshNeuralNetworksTable).values({
    name: parsed.data.name,
    networkType: parsed.data.networkType,
    familyKeys: blueprint.selectedFamilyKeys,
    primitiveSlots: blueprint.primitiveSlots,
    sharedPrimitiveSlots: blueprint.sharedPrimitives,
    architectureStack: blueprint.architectureStack,
    inputSize,
    hiddenLayers,
    outputSize,
    activation: "tanh",
    weights: createTrainableNetwork(parsed.data.name, inputSize, hiddenLayers, outputSize),
    status: "untrained",
  }).returning();
  res.status(201).json(network);
});

router.post("/mesh/neural-networks/:id/train", async (req, res): Promise<void> => {
  await ensureSeeded();
  const id = Number(req.params.id);
  const parsed = TrainMeshNeuralNetworkBody.safeParse(req.body ?? {});
  if (!Number.isInteger(id) || !parsed.success) {
    res.status(400).json({ error: parsed.success ? "Invalid network id" : parsed.error.message });
    return;
  }
  const [network] = await db.select().from(meshNeuralNetworksTable).where(eq(meshNeuralNetworksTable.id, id)).limit(1);
  if (!network) {
    res.status(404).json({ error: "Neural network not found" });
    return;
  }
  const lattice = normalizeLatticeSelection(parsed.data.lattice);
  const epochs = parsed.data.epochs ?? 5;
  const trained = trainNeuralNetwork(network.weights as unknown as NeuralNetworkWeights, latticeInput(lattice), capabilityTarget(network.networkType), epochs);
  const [updated] = await db.update(meshNeuralNetworksTable).set({
    weights: trained.network,
    trainingSteps: network.trainingSteps + epochs,
    loss: trained.loss,
    status: "trained",
    lastTrainedAt: new Date(),
    updatedAt: new Date(),
  }).where(eq(meshNeuralNetworksTable.id, id)).returning();
  res.json(updated);
});

router.get("/mesh/memory", async (_req, res): Promise<void> => {
  await ensureSeeded();
  res.json(await db.select().from(meshMemoryTable).orderBy(desc(meshMemoryTable.strength), desc(meshMemoryTable.createdAt)).limit(20));
});

router.get("/mesh/events", async (_req, res): Promise<void> => {
  await ensureSeeded();
  res.json(await db.select().from(meshEventsTable).orderBy(desc(meshEventsTable.createdAt)).limit(24));
});

router.get("/mesh/semantic-network", async (_req, res): Promise<void> => {
  await ensureSeeded();
  const [nodes, triples, rules] = await Promise.all([
    db.select().from(meshSemanticNodesTable).orderBy(asc(meshSemanticNodesTable.id)),
    db.select().from(meshSemanticTriplesTable).orderBy(desc(meshSemanticTriplesTable.createdAt)).limit(80),
    db.select().from(meshSemanticRulesTable).orderBy(desc(meshSemanticRulesTable.confidence), desc(meshSemanticRulesTable.updatedAt)).limit(40),
  ]);
  const nodeById = new Map(nodes.map((node) => [node.id, node]));
  res.json({
    nodes,
    triples: triples.map((triple) => ({
      id: triple.id,
      subject: nodeById.get(triple.subjectId)?.label ?? `node-${triple.subjectId}`,
      relation: nodeById.get(triple.relationId)?.label ?? `relation-${triple.relationId}`,
      object: triple.objectId ? nodeById.get(triple.objectId)?.label ?? `node-${triple.objectId}` : null,
      source: triple.source,
      confidence: triple.confidence,
      createdAt: triple.createdAt,
    })),
    rules,
  });
});

router.post("/mesh/inquiries", async (req, res): Promise<void> => {
  await ensureSeeded();
  const parsed = RunMeshInquiryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { query, outputModes, viewerKey = "anonymous", filterKey = "generalist" } = parsed.data;
  const lattice = normalizeLatticeSelection(parsed.data.lattice);
  const selectedLatticeContext = latticeContext(lattice);
  const latticeTokens = latticeFeatures(lattice);
  const [allCapabilityNodes, allFilters] = await Promise.all([
    db.select().from(meshCapabilityNodesTable).orderBy(asc(meshCapabilityNodesTable.id)),
    db.select().from(meshConnectionFiltersTable).orderBy(asc(meshConnectionFiltersTable.id)),
  ]);
  const filter = allFilters.find((candidate) => candidate.key === filterKey) ?? allFilters.find((candidate) => candidate.key === "generalist");
  const allowedCapabilities = filter?.allowedCapabilities ?? [];
  const capabilityNodes = allCapabilityNodes.filter((node) => node.capabilities.some((capability) => allowedCapabilities.includes(capability)));
  const contextLens = filter?.contextLens ?? ["whole-mesh"];
  const usableOutputModes = outputModes.filter((mode) => mode === "text" || allowedCapabilities.includes(mode));
  const tokens = [...new Set([...tokenize(query), ...latticeTokens])];
  const vector = vectorize(tokens);
  const semanticDraft = buildSemanticGraph(tokens, vector);
  const agents = await db.select().from(meshAgentsTable).orderBy(asc(meshAgentsTable.id));
  const memories = await db.select().from(meshMemoryTable).orderBy(desc(meshMemoryTable.strength)).limit(12);
  const active = agents.map((agent) => ({ agent, activation: activationFor(agent.focus, tokens, memories[0]?.strength ?? 0) }))
    .filter(({ agent }) => capabilityNodes.some((node) => node.capabilities.some((capability) => agent.focus.includes(capability) || agent.role.includes(capability))))
    .sort((a, b) => b.activation - a.activation).slice(0, 4);
  const activeNames = active.map(({ agent }) => agent.name);
  const speaker = active[0]?.agent ?? agents[0];
  const generated = speaker ? generateGrammarUtterance(query, tokens, speaker.generationRules, speaker.ruleFrequencies, `${speaker.id}:${speaker.interactionCount}`) : { utterance: query, rule: "inherit-context" };
  const analogy = solveAnalogy(
    vector,
    speaker?.featureVector?.length ? speaker.featureVector : vector,
    [...vector].reverse(),
  );
  const interactionTrace = [`Speaker ${speaker?.name ?? "mesh"} generated a speech form with ${generated.rule}.`, generated.utterance];
  const updatedAuditors: Array<{ id: number; ruleFrequencies: Record<string, number>; recognitionRules: string[]; generationRules: string[]; borrowed: string | null; promoted: boolean }> = [];
  for (const { agent } of active.slice(1)) {
    const parsedSpeech = parseWithGrammar(generated.rule, agent.recognitionRules, speaker?.generationRules ?? []);
    const frequencies = { ...agent.ruleFrequencies };
    const oldFrequency = frequencies[generated.rule] ?? 0;
    const newFrequency = Math.min(1, oldFrequency + (parsedSpeech.recognized ? 0.08 : 0.22));
    frequencies[generated.rule] = newFrequency;
    const recognitionRules = [...agent.recognitionRules];
    const generationRules = [...agent.generationRules];
    const promoted = !parsedSpeech.recognized && newFrequency >= 0.72;
    if (promoted) {
      if (!recognitionRules.includes(generated.rule)) recognitionRules.push(generated.rule);
      if (!generationRules.includes(generated.rule)) generationRules.push(generated.rule);
    }
    updatedAuditors.push({ id: agent.id, ruleFrequencies: frequencies, recognitionRules, generationRules, borrowed: parsedSpeech.borrowedRule, promoted });
    interactionTrace.push(`${agent.name} ${parsedSpeech.recognized ? "parsed" : "temporarily borrowed"} ${generated.rule}${promoted ? " and promoted it into generation grammar" : ""}.`);
  }
  const response = `${createResponse(query, activeNames, tokens)} Generated speech form: “${generated.utterance}” Viewed through the ${filter?.name ?? "Generalist"} filter (${contextLens.join(" · ")}); ${capabilityNodes.map((node) => node.networkType).join(", ")} nodes were available to this connection. Recursive lattice ${selectedLatticeContext.signature} shaped the active context.`;
  const [inquiry] = await db.insert(meshInquiriesTable).values({ query, response, outputModes: usableOutputModes, viewerKey, filterKey, lattice }).returning();
  if (!inquiry) {
    res.status(500).json({ error: "Inquiry could not be recorded" });
    return;
  }
  const label = tokens.slice(0, 3).join(" + ") || "new relation";
  const [learned] = await db.insert(meshMemoryTable).values({
    label,
    content: `The mesh linked ${tokens.join(", ") || "open concepts"} through ${activeNames.join(", ")}.`,
    source: `inquiry ${inquiry.id}`,
    strength: 0.58 + Math.min(tokens.length, 5) * 0.05,
    featureVector: vector,
  }).returning();
  if (!learned) {
    res.status(500).json({ error: "Learned memory could not be recorded" });
    return;
  }
  const persistedNodes = new Map<string, typeof meshSemanticNodesTable.$inferSelect>();
  for (const draftNode of semanticDraft.nodes) {
    const [existingNode] = await db.select().from(meshSemanticNodesTable).where(eq(meshSemanticNodesTable.key, draftNode.key)).limit(1);
    const [node] = existingNode
      ? await db.update(meshSemanticNodesTable).set({
        label: draftNode.label,
        kind: draftNode.kind,
        lexicalExpressions: [...new Set([...existingNode.lexicalExpressions, ...draftNode.lexicalExpressions])],
        featureVector: draftNode.featureVector,
        updatedAt: new Date(),
      }).where(eq(meshSemanticNodesTable.id, existingNode.id)).returning()
      : await db.insert(meshSemanticNodesTable).values(draftNode).returning();
    if (node) persistedNodes.set(node.key, node);
  }
  const persistedTriples = [];
  for (const draftTriple of semanticDraft.triples) {
    const subject = persistedNodes.get(draftTriple.subjectKey);
    const relation = persistedNodes.get(draftTriple.relationKey);
    const object = draftTriple.objectKey ? persistedNodes.get(draftTriple.objectKey) : undefined;
    if (!subject || !relation) continue;
    const [triple] = await db.insert(meshSemanticTriplesTable).values({
      subjectId: subject.id,
      relationId: relation.id,
      objectId: object?.id ?? null,
      source: `inquiry ${inquiry.id}`,
      confidence: draftTriple.confidence,
    }).returning();
    if (triple) persistedTriples.push(triple);
  }
  const relationLabel = persistedNodes.get(semanticDraft.triples[0]?.relationKey ?? "")?.label ?? "relates";
  const candidateSurface = surfacePatternFor(tokens);
  const candidateSemantic = semanticPatternFor(tokens, relationLabel);
  const [matchingRule] = await db.select().from(meshSemanticRulesTable).where(and(
    eq(meshSemanticRulesTable.surfacePattern, candidateSurface),
    eq(meshSemanticRulesTable.semanticPattern, candidateSemantic),
  )).limit(1);
  const positiveCount = (matchingRule?.positiveCount ?? 0) + 1;
  const negativeCount = matchingRule?.negativeCount ?? 0;
  const semanticRule = matchingRule
    ? (await db.update(meshSemanticRulesTable).set({
      positiveCount,
      confidence: ruleConfidence(positiveCount, negativeCount),
      status: positiveCount >= 3 && negativeCount === 0 ? "accepted" : "tentative",
      examples: [...new Set([...matchingRule.examples, query])].slice(-8),
      updatedAt: new Date(),
    }).where(eq(meshSemanticRulesTable.id, matchingRule.id)).returning())[0]
    : (await db.insert(meshSemanticRulesTable).values({
      name: `S${Date.now()}`,
      surfacePattern: candidateSurface,
      semanticPattern: candidateSemantic,
      positiveCount: 1,
      negativeCount: 0,
      confidence: ruleConfidence(1, 0),
      status: "tentative",
      examples: [query],
    }).returning())[0];
  const semanticNodes = await db.select().from(meshSemanticNodesTable).orderBy(asc(meshSemanticNodesTable.id));
  const semanticTriples = await db.select().from(meshSemanticTriplesTable).orderBy(desc(meshSemanticTriplesTable.createdAt)).limit(80);
  const semanticRules = await db.select().from(meshSemanticRulesTable).orderBy(desc(meshSemanticRulesTable.confidence), desc(meshSemanticRulesTable.updatedAt)).limit(40);
  const semanticNetwork = {
    nodes: semanticNodes,
    triples: semanticTriples.map((triple) => ({
      id: triple.id,
      subject: semanticNodes.find((node) => node.id === triple.subjectId)?.label ?? `node-${triple.subjectId}`,
      relation: semanticNodes.find((node) => node.id === triple.relationId)?.label ?? `relation-${triple.relationId}`,
      object: triple.objectId ? semanticNodes.find((node) => node.id === triple.objectId)?.label ?? `node-${triple.objectId}` : null,
      source: triple.source,
      confidence: triple.confidence,
      createdAt: triple.createdAt,
    })),
    rules: semanticRules,
  };
  const networks = await db.select().from(meshNeuralNetworksTable).orderBy(asc(meshNeuralNetworksTable.id));
  const selectedNetworkTypes = new Set(capabilityNodes.map((node) => node.networkType));
  for (const network of networks.filter((candidate) => selectedNetworkTypes.has(candidate.networkType))) {
    const trained = trainNeuralNetwork(network.weights as unknown as NeuralNetworkWeights, latticeInput(lattice), capabilityTarget(network.networkType), 1);
    await db.update(meshNeuralNetworksTable).set({
      weights: trained.network,
      trainingSteps: network.trainingSteps + 1,
      loss: trained.loss,
      status: "trained",
      lastTrainedAt: new Date(),
      updatedAt: new Date(),
    }).where(eq(meshNeuralNetworksTable.id, network.id));
  }
  const trainedNetworks = await db.select().from(meshNeuralNetworksTable).where(sql`${meshNeuralNetworksTable.networkType} IN (${sql.join([...selectedNetworkTypes].map((type) => sql`${type}`), sql`, `)})`).orderBy(asc(meshNeuralNetworksTable.id));
  await db.transaction(async (tx) => {
    for (const { agent, activation } of active) {
      const auditorUpdate = updatedAuditors.find((item) => item.id === agent.id);
      await tx.update(meshAgentsTable).set({
        activation,
        status: "sharing",
        generation: agent.generation + (activation > 0.72 ? 1 : 0),
        featureVector: vector,
        interactionCount: agent.interactionCount + 1,
        lastInteractionAt: new Date(),
        ...(auditorUpdate ? {
          recognitionRules: auditorUpdate.recognitionRules,
          generationRules: auditorUpdate.generationRules,
          ruleFrequencies: auditorUpdate.ruleFrequencies,
        } : {}),
        updatedAt: new Date(),
      }).where(eq(meshAgentsTable.id, agent.id));
    }
    await tx.insert(meshEventsTable).values([
      { kind: "inquiry", message: `Inquiry ${inquiry.id} activated ${activeNames.join(", ")}.`, agentName: activeNames[0] ?? "Cartographer" },
      { kind: "conversation", message: interactionTrace.slice(0, 2).join(" "), agentName: speaker?.name ?? "Mesh" },
      { kind: "semantic", message: `Inferred ${candidateSurface} → ${candidateSemantic} as a ${semanticRule?.status ?? "tentative"} rule.`, agentName: "Grammarian" },
      { kind: "learn", message: `Shared memory strengthened: ${label}.`, agentName: "Archivist" },
    ]);
  });
  const artifacts = [];
  if (usableOutputModes.includes("text")) artifacts.push({ id: `text-${inquiry.id}`, kind: "text" as const, title: "Mesh synthesis", content: response, mimeType: "text/plain" });
  if (usableOutputModes.includes("image")) {
    const image = createSvgArtifact(query, tokens, false);
    artifacts.push({ id: image.id, kind: "image" as const, title: "Relational pixel map", content: image.content, mimeType: image.mimeType });
  }
  if (usableOutputModes.includes("video")) {
    const video = createSvgArtifact(query, tokens, true);
    artifacts.push({ id: video.id, kind: "video" as const, title: "Animated mesh trace", content: video.content, mimeType: video.mimeType });
  }
  for (const mode of ["code", "game", "app"] as const) {
    if (usableOutputModes.includes(mode)) {
      artifacts.push(createCapabilityArtifact(mode, query, tokens, contextLens));
    }
  }
  await db.insert(meshArtifactsTable).values(artifacts.map((artifact) => ({ ...artifact, inquiryId: inquiry.id })));
  const refreshedAgents = await db.select().from(meshAgentsTable).where(sql`${meshAgentsTable.id} IN (${sql.join(active.map(({ agent }) => sql`${agent.id}`), sql`, `)})`);
  res.status(201).json({ id: inquiry.id, query, response, activatedAgents: refreshedAgents, artifacts, learned, trace: [
    `Tokenized into ${tokens.length || 1} features.`,
    `Inherited ${memories.length} shared memories bidirectionally.`,
    `Connected viewer "${viewerKey}" through the ${filter?.name ?? "Generalist"} filter.`,
    `Available network types: ${capabilityNodes.map((node) => node.networkType).join(" · ") || "none"}.`,
    `Trained ${trainedNetworks.length} selected neural network${trainedNetworks.length === 1 ? "" : "s"} on this lattice sample.`,
    `Context lens: ${contextLens.join(" · ")}.`,
    `Recursive lattice: ${selectedLatticeContext.signature}.`,
    `Activated ${activeNames.join(" → ") || "no role automata"}.`,
    usableOutputModes.length !== outputModes.length ? `Filtered outputs from ${outputModes.join(", ")} to ${usableOutputModes.join(", ") || "text"}.` : `Enabled outputs: ${usableOutputModes.join(", ")}.`,
    `Built ${semanticDraft.triples.length} semantic triple${semanticDraft.triples.length === 1 ? "" : "s"} from the inquiry.`,
    `Applied ATO/XNOR analogy operator [${analogy.operator.join("")}] → [${analogy.target.join("")}].`,
    `Proposed ${candidateSurface} → ${candidateSemantic}; status: ${semanticRule?.status ?? "tentative"}.`,
    ...interactionTrace,
    `Stored "${label}" as a reusable rule.`,
  ], semanticNetwork, analogies: [analogy], perspective: {
    viewerKey,
    filterKey: filter?.key ?? "generalist",
    contextLens,
    allowedCapabilities,
  }, capabilityNodes, neuralNetworks: trainedNetworks, toolContexts: capabilityNodes.map((node) => `${node.name}: ${contextLens.join(" + ")} + ${selectedLatticeContext.filter}`), lattice, latticeContext: selectedLatticeContext, createdAt: inquiry.createdAt });
});

router.post("/mesh/agents/:id/morph", async (req, res): Promise<void> => {
  await ensureSeeded();
  const id = Number(req.params.id);
  const parsed = MorphMeshAgentBody.safeParse(req.body);
  if (!Number.isInteger(id) || !parsed.success) {
    res.status(400).json({ error: parsed.success ? "Invalid agent id" : parsed.error.message });
    return;
  }
  const [agent] = await db.update(meshAgentsTable).set({ role: parsed.data.role, status: "evolving", generation: sql`${meshAgentsTable.generation} + 1`, updatedAt: new Date() }).where(eq(meshAgentsTable.id, id)).returning();
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  await db.insert(meshEventsTable).values({ kind: "morph", message: `${agent.name} morphed into ${agent.role}.`, agentName: agent.name });
  res.json(agent);
});

router.post("/mesh/agents/:id/evolve", async (req, res): Promise<void> => {
  await ensureSeeded();
  const id = Number(req.params.id);
  const [agent] = await db.update(meshAgentsTable).set({ status: "evolving", generation: sql`${meshAgentsTable.generation} + 1`, activation: sql`LEAST(0.98, ${meshAgentsTable.activation} + 0.08)`, updatedAt: new Date() }).where(eq(meshAgentsTable.id, id)).returning();
  if (!agent) {
    res.status(404).json({ error: "Agent not found" });
    return;
  }
  await db.insert(meshEventsTable).values({ kind: "evolve", message: `${agent.name} absorbed shared memory and advanced to generation ${agent.generation}.`, agentName: agent.name });
  res.json(agent);
});

export default router;