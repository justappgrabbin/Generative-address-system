import { randomUUID } from "node:crypto";

export const roleSeeds = [
  {
    name: "Cartographer",
    role: "context mapper",
    glyph: "◌",
    focus: ["map", "context", "relation", "place", "system"],
    description: "Maps the inquiry into objects, relations, and surrounding context.",
  },
  {
    name: "Analogist",
    role: "analogy engine",
    glyph: "⟷",
    focus: ["analogy", "pattern", "compare", "story", "culture"],
    description: "Finds a useful bridge to a different domain and transfers structure.",
  },
  {
    name: "Grammarian",
    role: "meaning composer",
    glyph: "≋",
    focus: ["language", "meaning", "sequence", "explain", "name"],
    description: "Turns the active structure into a transparent response.",
  },
  {
    name: "Polymorph",
    role: "representation shifter",
    glyph: "◇",
    focus: ["image", "motion", "form", "visual", "transform"],
    description: "Re-encodes meaning as a visual or moving artifact.",
  },
  {
    name: "Archivist",
    role: "shared memory",
    glyph: "▣",
    focus: ["remember", "learn", "history", "rule", "share"],
    description: "Strengthens reusable rules and distributes them across the mesh.",
  },
] as const;

export const capabilityNodeSeeds = [
  {
    name: "Semantic Network",
    networkType: "semantic",
    capabilities: ["semantics", "language", "memory"],
    description: "Maps objects, relations, lexical forms, and shared context.",
    featureVector: [1, 1, 1, 0, 0, 0, 1, 1],
  },
  {
    name: "Sequence Network",
    networkType: "sequence",
    capabilities: ["semantics", "language", "conversation"],
    description: "Tracks order, recurrence, dialogue state, and grammar drift.",
    featureVector: [1, 1, 1, 1, 0, 0, 0, 1],
  },
  {
    name: "Visual Network",
    networkType: "visual",
    capabilities: ["visual", "image", "video"],
    description: "Transforms shared structures into visual and temporal forms.",
    featureVector: [0, 1, 0, 0, 1, 1, 0, 1],
  },
  {
    name: "Code Network",
    networkType: "code",
    capabilities: ["code", "automation", "app"],
    description: "Compiles semantic structures into readable source and tool graphs.",
    featureVector: [1, 1, 0, 1, 0, 0, 1, 1],
  },
  {
    name: "Game Network",
    networkType: "game",
    capabilities: ["game", "simulation", "interaction"],
    description: "Encodes relations as state machines, rules, and playable loops.",
    featureVector: [1, 1, 0, 1, 1, 1, 0, 1],
  },
  {
    name: "App Network",
    networkType: "app",
    capabilities: ["app", "interface", "workflow"],
    description: "Composes semantic objects into interface and workflow scaffolds.",
    featureVector: [1, 1, 1, 1, 1, 0, 1, 1],
  },
] as const;

const architectureFamilyDefinitions = [
  ["feedforward", "Feedforward / MLP", "mapping", "Maps fixed lattice inputs to fixed decisions, scores, and routes.", ["semantic", "code", "app"]],
  ["convolutional", "CNN / Convolutional", "perception", "Composes local spatial patterns into visual and structural features.", ["visual", "game", "app"]],
  ["recurrent", "RNN / Recurrent", "temporal", "Carries state through ordered events, dialogue, and behavior.", ["sequence", "semantic", "game"]],
  ["gated-recurrent", "LSTM / GRU", "temporal-memory", "Learns which historical signals to keep or forget.", ["sequence", "memory", "game"]],
  ["temporal-convolution", "Temporal Convolutional", "temporal", "Reads causal timelines with parallel local sequence windows.", ["sequence", "game"]],
  ["transformer", "Transformer", "attention", "Relates distant elements across a context or sequence.", ["semantic", "code", "app"]],
  ["encoder-transformer", "Encoder-only Transformer", "representation", "Builds representations for meaning, similarity, and routing.", ["semantic", "code", "visual"]],
  ["decoder-transformer", "Decoder-only Transformer", "generation", "Predicts the next token, action, code fragment, or narrative element.", ["semantic", "code", "app"]],
  ["encoder-decoder-transformer", "Encoder–Decoder Transformer", "translation", "Transforms one structured representation into another.", ["code", "app", "semantic"]],
  ["autoencoder", "Autoencoder", "compression", "Compresses a state and reconstructs its useful structure.", ["semantic", "visual", "app"]],
  ["sparse-autoencoder", "Sparse Autoencoder", "interpretability", "Discovers recurring concepts through selectively active latent units.", ["semantic", "memory", "code"]],
  ["denoising-autoencoder", "Denoising Autoencoder", "repair", "Restores coherent state from incomplete or corrupted signals.", ["memory", "code", "app"]],
  ["variational-autoencoder", "Variational Autoencoder", "variation", "Learns a continuous latent space for controlled variations.", ["visual", "game", "app"]],
  ["vector-quantized-vae", "VQ-VAE", "discretization", "Turns messy perception into reusable discrete primitive codes.", ["visual", "semantic", "game"]],
  ["generative-adversarial", "GAN", "synthesis", "Learns a generator and critic for realistic asset variations.", ["visual", "game", "app"]],
  ["diffusion", "Diffusion", "synthesis", "Iteratively denoises noise into structured visual or state outputs.", ["visual", "game", "app"]],
  ["graph-neural", "Graph Neural Network", "relations", "Learns over nodes, edges, addresses, tools, people, and places.", ["semantic", "code", "app"]],
  ["graph-convolution", "Graph Convolution", "relations", "Propagates state and meaning across neighboring graph nodes.", ["semantic", "game", "app"]],
  ["graph-attention", "Graph Attention", "routing", "Learns which neighbors and relationships matter most.", ["semantic", "code", "game"]],
  ["message-passing", "Message Passing", "distributed", "Lets autonomous cells exchange learned messages across edges.", ["semantic", "game", "app"]],
  ["metric-comparison", "Siamese / Triplet Metric", "similarity", "Learns relational distance, equivalence, duplicates, and morphs.", ["semantic", "visual", "code"]],
  ["associative-memory", "Hopfield Associative Memory", "memory", "Recovers complete patterns from partial or noisy fragments.", ["memory", "semantic", "sequence"]],
  ["explicit-memory", "Memory Network", "memory", "Separates learned reasoning from addressable persistent memory.", ["memory", "semantic", "code"]],
  ["energy-based", "Energy-Based Model", "coherence", "Scores whether a proposed whole-system state is compatible.", ["semantic", "game", "app"]],
  ["neural-cellular-automata", "Neural Cellular Automata", "morphology", "Learns local cell updates for growth, repair, and differentiation.", ["game", "visual", "app"]],
  ["liquid-dynamics", "Liquid / Continuous-Time", "dynamics", "Maintains adaptive internal dynamics as signals arrive over time.", ["sequence", "game", "memory"]],
  ["reservoir", "Reservoir / Echo State", "temporal", "Uses a dynamic reservoir with a lightweight trainable readout.", ["sequence", "game", "memory"]],
  ["spiking", "Spiking Neural Network", "events", "Communicates through discrete timing-sensitive events.", ["sequence", "game", "interaction"]],
  ["self-organizing-map", "Self-Organizing Map", "topology", "Arranges tools, files, states, and concepts by learned similarity.", ["semantic", "visual", "code"]],
  ["growing-neural-gas", "Growing Neural Gas", "topology", "Expands its semantic topology as new data and relationships arrive.", ["semantic", "memory", "app"]],
  ["mixture-of-experts", "Mixture of Experts", "specialization", "Routes each context to only the relevant neural specialists.", ["semantic", "code", "app", "game"]],
  ["hypernetwork", "Hypernetwork", "composition", "Generates parameters for a context-specific downstream network.", ["code", "app", "game"]],
  ["meta-learning", "Meta-Learning", "adaptation", "Learns how to adapt quickly from a small number of examples.", ["semantic", "code", "app"]],
  ["world-model", "World Model", "prediction", "Simulates likely consequences before an action changes the mesh.", ["game", "app", "code"]],
  ["action-policy", "Policy / Actor-Critic", "action", "Proposes actions and scores them before execution.", ["game", "app", "automation"]],
  ["neuro-symbolic", "Neuro-Symbolic", "reasoning", "Combines learned functions with explicit rules, grammar, and addresses.", ["semantic", "code", "app", "game"]],
] as const;

export type ArchitectureFamily = {
  index: number;
  key: string;
  name: string;
  category: string;
  description: string;
  capabilities: string[];
  primitiveSlots: number[];
  sharedPrimitive: number | null;
};

export const architectureFamilySeeds: ArchitectureFamily[] = architectureFamilyDefinitions.map(([key, name, category, description, capabilities], index) => {
  const previousShared = index === 0 ? null : ((index - 1) * 11 + 7) % 64;
  const sharedPrimitive = (index * 11 + 7) % 64;
  const anchor = (index * 7) % 64;
  return {
    index: index + 1,
    key,
    name,
    category,
    description,
    capabilities: [...capabilities],
    primitiveSlots: [
      previousShared ?? anchor,
      (anchor + 13) % 64,
      (anchor + 29) % 64,
      sharedPrimitive,
    ],
    sharedPrimitive: previousShared,
  };
});

export const architectureFamilyKeys = architectureFamilySeeds.map((family) => family.key);

const capabilityFamilyDefaults: Record<string, string[]> = {
  semantic: ["neuro-symbolic", "graph-neural", "associative-memory", "encoder-transformer"],
  sequence: ["recurrent", "gated-recurrent", "temporal-convolution", "reservoir"],
  visual: ["convolutional", "vector-quantized-vae", "diffusion", "metric-comparison"],
  code: ["neuro-symbolic", "transformer", "encoder-decoder-transformer", "mixture-of-experts"],
  game: ["world-model", "action-policy", "neural-cellular-automata", "energy-based"],
  app: ["encoder-decoder-transformer", "autoencoder", "mixture-of-experts", "hypernetwork"],
};

export function familyKeysForCapability(networkType: string): string[] {
  return [...(capabilityFamilyDefaults[networkType] ?? capabilityFamilyDefaults.semantic ?? [])];
}

export function buildNetworkBlueprint(familyKeys: string[] | undefined, networkType: string) {
  const requested = [...new Set((familyKeys ?? []).filter((key) => architectureFamilyKeys.includes(key)))].slice(0, 8);
  const selectedFamilyKeys = requested.length > 0 ? requested : familyKeysForCapability(networkType);
  const selectedFamilies = selectedFamilyKeys.map((key) => architectureFamilySeeds.find((family) => family.key === key)).filter((family): family is ArchitectureFamily => Boolean(family));
  const primitiveCounts = new Map<number, number>();
  for (const family of selectedFamilies) {
    for (const primitive of family.primitiveSlots) primitiveCounts.set(primitive, (primitiveCounts.get(primitive) ?? 0) + 1);
  }
  const primitiveSlots = [...primitiveCounts.keys()].sort((a, b) => a - b);
  const sharedPrimitives = primitiveSlots.filter((primitive) => (primitiveCounts.get(primitive) ?? 0) > 1);
  return {
    selectedFamilyKeys,
    architectureStack: selectedFamilies.map((family) => family.name),
    primitiveSlots,
    sharedPrimitives,
    familyCount: selectedFamilies.length,
  };
}

export const connectionFilterSeeds = [
  {
    key: "generalist",
    name: "Generalist",
    description: "See the full mesh and let every compatible tool contribute.",
    allowedCapabilities: ["semantics", "language", "memory", "conversation", "visual", "image", "video", "code", "automation", "app", "game", "simulation", "interaction", "interface", "workflow"],
    contextLens: ["whole-mesh", "shared-memory", "cross-domain"],
    preferredOutputs: ["text", "image", "video", "code", "game", "app"],
  },
  {
    key: "meaning",
    name: "Meaning Researcher",
    description: "Prioritize semantic structure, language, and historical context.",
    allowedCapabilities: ["semantics", "language", "memory", "conversation"],
    contextLens: ["objects-relations", "grammar", "shared-memory"],
    preferredOutputs: ["text", "code"],
  },
  {
    key: "maker",
    name: "Maker",
    description: "Prioritize code, applications, automation, and usable artifacts.",
    allowedCapabilities: ["semantics", "code", "automation", "app", "interface", "workflow"],
    contextLens: ["requirements", "components", "tool-graph"],
    preferredOutputs: ["text", "code", "app"],
  },
  {
    key: "worldbuilder",
    name: "World Builder",
    description: "Prioritize simulation, game rules, motion, and visual feedback.",
    allowedCapabilities: ["semantics", "visual", "image", "video", "game", "simulation", "interaction"],
    contextLens: ["world-state", "rules", "motion"],
    preferredOutputs: ["text", "image", "video", "game"],
  },
] as const;

export type RecursiveLatticeSelection = {
  primitive: number;
  dimensions: number[];
  filterStage: number;
  behavior: number;
  motivation: number;
  sense: number;
  base: number;
  degree: number;
  minute: number;
  second: number;
  arc: number;
  archetype: number;
  environment: number;
  recursionDepth: number;
};

const clamp = (value: unknown, min: number, max: number, fallback: number) => {
  const numeric = typeof value === "number" && Number.isFinite(value) ? Math.round(value) : fallback;
  return Math.min(max, Math.max(min, numeric));
};

export const defaultLatticeSelection: RecursiveLatticeSelection = {
  primitive: 0,
  dimensions: [0, 0, 0, 0, 0],
  filterStage: 0,
  behavior: 0,
  motivation: 0,
  sense: 0,
  base: 0,
  degree: 0,
  minute: 0,
  second: 0,
  arc: 0,
  archetype: 0,
  environment: 0,
  recursionDepth: 1,
};

export const latticeFilterSlots = Array.from({ length: 13 }, (_, index) => `F${String(index + 1).padStart(2, "0")}`);
export const latticeArchetypeSlots = Array.from({ length: 12 }, (_, index) => `A${String(index + 1).padStart(2, "0")}`);
export const latticeEnvironmentSlots = Array.from({ length: 12 }, (_, index) => `E${String(index + 1).padStart(2, "0")}`);

export function normalizeLatticeSelection(input?: Partial<RecursiveLatticeSelection> | null): RecursiveLatticeSelection {
  const source = input ?? {};
  return {
    primitive: clamp(source.primitive, 0, 63, defaultLatticeSelection.primitive),
    dimensions: Array.from({ length: 5 }, (_, index) => clamp(source.dimensions?.[index], 0, 4, 0)),
    filterStage: clamp(source.filterStage, 0, 12, defaultLatticeSelection.filterStage),
    behavior: clamp(source.behavior, 0, 5, defaultLatticeSelection.behavior),
    motivation: clamp(source.motivation, 0, 5, defaultLatticeSelection.motivation),
    sense: clamp(source.sense, 0, 5, defaultLatticeSelection.sense),
    base: clamp(source.base, 0, 4, defaultLatticeSelection.base),
    degree: clamp(source.degree, 0, 29, defaultLatticeSelection.degree),
    minute: clamp(source.minute, 0, 59, defaultLatticeSelection.minute),
    second: clamp(source.second, 0, 59, defaultLatticeSelection.second),
    arc: clamp(source.arc, 0, 99, defaultLatticeSelection.arc),
    archetype: clamp(source.archetype, 0, 11, defaultLatticeSelection.archetype),
    environment: clamp(source.environment, 0, 11, defaultLatticeSelection.environment),
    recursionDepth: clamp(source.recursionDepth, 0, 8, defaultLatticeSelection.recursionDepth),
  };
}

export function latticeContext(selection: RecursiveLatticeSelection) {
  const primitive = `P${String(selection.primitive).padStart(2, "0")}`;
  const filter = latticeFilterSlots[selection.filterStage] ?? latticeFilterSlots[0];
  const archetype = latticeArchetypeSlots[selection.archetype] ?? latticeArchetypeSlots[0];
  const environment = latticeEnvironmentSlots[selection.environment] ?? latticeEnvironmentSlots[0];
  const coordinate = `${selection.degree}° ${String(selection.minute).padStart(2, "0")}' ${String(selection.second).padStart(2, "0")}" ${String(selection.arc).padStart(2, "0")}arc`;
  const signature = `${primitive}.${selection.dimensions.join("")}.${filter}.B${selection.behavior}M${selection.motivation}S${selection.sense}B${selection.base}.${archetype}/${environment}@${coordinate}/R${selection.recursionDepth}`;
  return { primitive, filter, archetype, environment, coordinate, signature };
}

export function latticeFeatures(selection: RecursiveLatticeSelection): string[] {
  const context = latticeContext(selection);
  return [
    context.primitive.toLowerCase(),
    context.filter.toLowerCase(),
    context.archetype.toLowerCase(),
    context.environment.toLowerCase(),
    `dimension-${selection.dimensions.join("-")}`,
    `behavior-${selection.behavior}`,
    `motivation-${selection.motivation}`,
    `sense-${selection.sense}`,
    `base-${selection.base}`,
    `recursion-${selection.recursionDepth}`,
  ];
}

export type NeuralNetworkLayer = {
  weights: number[][];
  bias: number[];
};

export type NeuralNetworkWeights = {
  layers: NeuralNetworkLayer[];
};

function seededRandom(seed: string): () => number {
  let state = 2166136261;
  for (const character of seed) state = Math.imul(state ^ character.charCodeAt(0), 16777619);
  return () => {
    state = Math.imul(state ^ (state >>> 13), 1274126177);
    return ((state >>> 0) % 10000) / 10000;
  };
}

export function createTrainableNetwork(seed: string, inputSize = 81, hiddenLayers = [32, 16], outputSize = 6): NeuralNetworkWeights {
  const random = seededRandom(seed);
  const sizes = [inputSize, ...hiddenLayers, outputSize];
  const layers = sizes.slice(0, -1).map((size, layerIndex) => {
    const nextSize = sizes[layerIndex + 1] ?? outputSize;
    return {
      weights: Array.from({ length: nextSize }, () => Array.from({ length: size }, () => (random() - 0.5) * 0.18)),
      bias: Array.from({ length: nextSize }, () => 0),
    };
  });
  return { layers };
}

function tanh(value: number): number {
  return Math.tanh(value);
}

function forwardNetwork(network: NeuralNetworkWeights, input: number[]) {
  const activations = [input.slice()];
  const preActivations: number[][] = [];
  let current = input.slice();
  for (const layer of network.layers) {
    const next = layer.weights.map((row, rowIndex) => {
      const sum = row.reduce((total, weight, columnIndex) => total + weight * (current[columnIndex] ?? 0), layer.bias[rowIndex] ?? 0);
      return tanh(sum);
    });
    preActivations.push(next);
    activations.push(next);
    current = next;
  }
  return { output: current, activations, preActivations };
}

export function latticeInput(selection: RecursiveLatticeSelection): number[] {
  const primitive = Array.from({ length: 64 }, (_, index) => index === selection.primitive ? 1 : 0);
  const dimensions = selection.dimensions.map((value) => value / 4);
  return [
    ...primitive,
    ...dimensions,
    selection.filterStage / 12,
    selection.behavior / 5,
    selection.motivation / 5,
    selection.sense / 5,
    selection.base / 4,
    selection.degree / 29,
    selection.minute / 59,
    selection.second / 59,
    selection.arc / 99,
    selection.archetype / 11,
    selection.environment / 11,
    selection.recursionDepth / 8,
  ];
}

export function capabilityTarget(networkType: string): number[] {
  const types = ["semantic", "sequence", "visual", "code", "game", "app"];
  const target = Array.from({ length: types.length }, () => -1);
  const index = types.indexOf(networkType);
  if (index >= 0) target[index] = 1;
  return target;
}

export function trainNeuralNetwork(network: NeuralNetworkWeights, input: number[], target: number[], epochs = 1, learningRate = 0.04) {
  const safeEpochs = Math.max(1, Math.min(100, Math.round(epochs)));
  let loss = 1;
  for (let epoch = 0; epoch < safeEpochs; epoch += 1) {
    const pass = forwardNetwork(network, input);
    const deltas = network.layers.map(() => [] as number[]);
    const output = pass.output;
    loss = output.reduce((sum, value, index) => sum + ((value - (target[index] ?? 0)) ** 2), 0) / Math.max(1, output.length);
    const lastLayer = network.layers.length - 1;
    deltas[lastLayer] = output.map((value, index) => (value - (target[index] ?? 0)) * (1 - value * value));
    for (let layerIndex = lastLayer - 1; layerIndex >= 0; layerIndex -= 1) {
      const layer = network.layers[layerIndex];
      const nextLayer = network.layers[layerIndex + 1];
      const nextDelta = deltas[layerIndex + 1] ?? [];
      const activation = pass.activations[layerIndex + 1] ?? [];
      deltas[layerIndex] = layer.weights.map((_, rowIndex) => {
        const propagated = nextLayer.weights.reduce((sum, row, nextRowIndex) => sum + (row[rowIndex] ?? 0) * (nextDelta[nextRowIndex] ?? 0), 0);
        return propagated * (1 - (activation[rowIndex] ?? 0) ** 2);
      });
    }
    for (let layerIndex = 0; layerIndex < network.layers.length; layerIndex += 1) {
      const layer = network.layers[layerIndex];
      const previousActivation = pass.activations[layerIndex] ?? [];
      for (let rowIndex = 0; rowIndex < layer.weights.length; rowIndex += 1) {
        const delta = deltas[layerIndex]?.[rowIndex] ?? 0;
        for (let columnIndex = 0; columnIndex < layer.weights[rowIndex].length; columnIndex += 1) {
          layer.weights[rowIndex][columnIndex] -= learningRate * delta * (previousActivation[columnIndex] ?? 0);
        }
        layer.bias[rowIndex] -= learningRate * delta;
      }
    }
  }
  return { network, loss };
}

export const grammarSeeds: Record<string, { recognitionRules: string[]; generationRules: string[] }> = {
  "context mapper": {
    recognitionRules: ["identify-object", "bind-relation", "inherit-context"],
    generationRules: ["identify-object", "bind-relation"],
  },
  "analogy engine": {
    recognitionRules: ["transfer-structure", "compare-relations", "map-domain"],
    generationRules: ["transfer-structure", "compare-relations"],
  },
  "meaning composer": {
    recognitionRules: ["sequence-meaning", "name-relation", "cohere-clause"],
    generationRules: ["sequence-meaning", "cohere-clause"],
  },
  "representation shifter": {
    recognitionRules: ["encode-form", "animate-change", "inherit-context"],
    generationRules: ["encode-form", "animate-change"],
  },
  "shared memory": {
    recognitionRules: ["record-rule", "share-feature", "inherit-context"],
    generationRules: ["record-rule", "share-feature"],
  },
};

export function grammarForRole(role: string, focus: string[]) {
  return grammarSeeds[role] ?? {
    recognitionRules: [...focus.map((item) => `recognize-${item}`), "inherit-context"],
    generationRules: [...focus.slice(0, 2).map((item) => `generate-${item}`)],
  };
}

export function initialRuleFrequencies(rules: string[]): Record<string, number> {
  return Object.fromEntries(rules.map((rule) => [rule, 0.5]));
}

function stableFraction(input: string): number {
  let hash = 2166136261;
  for (const character of input) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return ((hash >>> 0) % 1000) / 1000;
}

export function weightedRulePick(rules: string[], frequencies: Record<string, number>, seed: string): string {
  if (rules.length === 0) return "inherit-context";
  const total = rules.reduce((sum, rule) => sum + Math.max(0.05, frequencies[rule] ?? 0.5), 0);
  let cursor = stableFraction(seed) * total;
  for (const rule of rules) {
    cursor -= Math.max(0.05, frequencies[rule] ?? 0.5);
    if (cursor <= 0) return rule;
  }
  return rules[rules.length - 1] ?? "inherit-context";
}

export function generateGrammarUtterance(
  query: string,
  tokens: string[],
  generationRules: string[],
  frequencies: Record<string, number>,
  seed: string,
): { utterance: string; rule: string } {
  const subject = tokens[0] ?? "the signal";
  const relation = tokens[1] ?? "changes";
  const context = tokens[2] ?? "the field";
  const rule = weightedRulePick(generationRules, frequencies, `${seed}:${query}`);
  const utteranceByRule: Record<string, string> = {
    "identify-object": `${subject} is the object under attention; ${relation} is its active relation.`,
    "bind-relation": `${subject} binds to ${relation} through ${context}.`,
    "inherit-context": `${subject} inherits context from ${context} and carries it into ${relation}.`,
    "transfer-structure": `${subject} has the same relational shape as ${relation} within ${context}.`,
    "compare-relations": `${subject} compares its relation to ${relation}; the difference becomes a signal.`,
    "map-domain": `${subject} maps from one domain into ${context} without losing its relation.`,
    "sequence-meaning": `${subject} then ${relation}; the sequence gives the signal meaning.`,
    "cohere-clause": `${subject} ${relation} in ${context}, so the thought remains coherent.`,
    "encode-form": `${subject} becomes a form whose relation is ${relation}.`,
    "animate-change": `${subject} moves through ${context} as ${relation} changes.`,
    "record-rule": `${subject} records ${relation} as a reusable rule in ${context}.`,
    "share-feature": `${subject} shares its feature with ${relation} across ${context}.`,
  };
  return { utterance: utteranceByRule[rule] ?? `${subject} relates to ${relation} through ${context}.`, rule };
}

export function parseWithGrammar(
  utteranceRule: string,
  recognitionRules: string[],
  speakerGenerationRules: string[],
): { recognized: boolean; borrowedRule: string | null; score: number } {
  if (recognitionRules.includes(utteranceRule)) {
    return { recognized: true, borrowedRule: null, score: 0.92 };
  }
  const transferable = speakerGenerationRules.find((rule) => rule === utteranceRule) ?? utteranceRule;
  return { recognized: false, borrowedRule: transferable, score: 0.38 };
}

const stopWords = new Set(["the", "and", "for", "with", "that", "this", "from", "into", "about", "what", "how", "can", "please"]);

export function tokenize(query: string): string[] {
  return [...new Set(query.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).filter((token) => token.length > 2 && !stopWords.has(token)))];
}

export function vectorize(tokens: string[]): number[] {
  const dimensions = ["context", "relation", "language", "analogy", "visual", "motion", "memory", "change"];
  return dimensions.map((dimension) => tokens.some((token) => token.includes(dimension.slice(0, 4))) ? 1 : 0);
}

export type SemanticNodeDraft = {
  key: string;
  label: string;
  kind: "object" | "relation";
  lexicalExpressions: string[];
  featureVector: number[];
};

export type SemanticTripleDraft = {
  subjectKey: string;
  relationKey: string;
  objectKey: string | null;
  confidence: number;
};

export function xnorVector(left: number[], right: number[]): number[] {
  const width = Math.max(left.length, right.length);
  return Array.from({ length: width }, (_, index) => (left[index] ?? 0) === (right[index] ?? 0) ? 1 : 0);
}

export function solveAnalogy(source: number[], sourceCounterpart: number[], target: number[]) {
  const operator = xnorVector(source, sourceCounterpart);
  const result = xnorVector(target, operator);
  return {
    source,
    target: result,
    operator,
    interpretation: "The target keeps the relational difference between the source pair while changing its feature position.",
  };
}

export function buildSemanticGraph(tokens: string[], vector: number[]) {
  const nodes: SemanticNodeDraft[] = tokens.map((token, index) => ({
    key: `object:${token}`,
    label: token,
    kind: "object" as const,
    lexicalExpressions: [token],
    featureVector: vector.map((value, dimension) => value ? 1 : (dimension === index % vector.length ? 1 : 0)),
  }));
  const relationWords = new Set(["is", "has", "learn", "learns", "change", "changes", "share", "shares", "connect", "connects", "make", "makes", "use", "uses", "become", "becomes"]);
  const relationToken = tokens.find((token) => relationWords.has(token)) ?? "relates";
  nodes.push({
    key: `relation:${relationToken}`,
    label: relationToken,
    kind: "relation",
    lexicalExpressions: [relationToken],
    featureVector: vector.map((_, index) => index === 1 ? 1 : 0),
  });
  const triples: SemanticTripleDraft[] = [];
  for (let index = 0; index < Math.min(tokens.length - 1, 5); index += 1) {
    triples.push({
      subjectKey: `object:${tokens[index]}`,
      relationKey: `relation:${relationToken}`,
      objectKey: tokens[index + 1] ? `object:${tokens[index + 1]}` : null,
      confidence: Math.max(0.52, 0.9 - index * 0.08),
    });
  }
  if (triples.length === 0) {
    triples.push({ subjectKey: "object:inquiry", relationKey: `relation:${relationToken}`, objectKey: null, confidence: 0.5 });
  }
  return { nodes, triples };
}

export function surfacePatternFor(tokens: string[]): string {
  if (tokens.length <= 1) return "O";
  return tokens.map((_, index) => index % 2 === 0 ? "O" : "R").join(" ");
}

export function semanticPatternFor(tokens: string[], relation = "relates"): string {
  const subject = tokens[0] ?? "inquiry";
  const object = tokens[1] ?? null;
  return object ? `O(${subject})-R(${relation})-O(${object})` : `O(${subject})-R(${relation})`;
}

export function ruleConfidence(positiveCount: number, negativeCount: number): number {
  const total = positiveCount + negativeCount;
  return total === 0 ? 0.5 : Math.max(0.02, Math.min(0.99, (positiveCount + 1) / (total + 2)));
}

export function activationFor(focus: string[], tokens: string[], memoryStrength = 0): number {
  const overlap = focus.filter((item) => tokens.some((token) => token.includes(item) || item.includes(token))).length;
  return Math.min(0.98, Math.max(0.26, 0.34 + overlap * 0.13 + memoryStrength * 0.16));
}

export function createResponse(query: string, activeNames: string[], tokens: string[]): string {
  const subject = tokens.slice(0, 4).join(", ") || "the inquiry";
  const path = activeNames.join(" → ");
  return `The mesh parsed “${query}” as a relation between ${subject}. ${path} activated a shared rule: represent the question as objects, transfer its structure through analogy, then return the result in more than one form. This is a local automaton response—not a black box: the active features are ${tokens.length ? tokens.join(" · ") : "open-ended"}, and the pattern is now available to the next inquiry.`;
}

export function createSvgArtifact(query: string, tokens: string[], animated: boolean): { id: string; content: string; mimeType: string } {
  const safe = query.replace(/[<>&'"]/g, "").slice(0, 52);
  const circles = tokens.slice(0, 6).map((token, index) => {
    const x = 90 + (index % 3) * 130;
    const y = 88 + Math.floor(index / 3) * 110;
    const delay = `${index * 0.35}s`;
    return `<circle cx="${x}" cy="${y}" r="${18 + (index % 3) * 6}" fill="none" stroke="#81f7d8" stroke-width="2" opacity=".8"><animate attributeName="r" values="${18 + (index % 3) * 6};${30 + (index % 3) * 8};${18 + (index % 3) * 6}" dur="2.8s" begin="${delay}" repeatCount="indefinite"/></circle><text x="${x}" y="${y + 4}" text-anchor="middle" fill="#f5fbff" font-size="11" font-family="monospace">${token.slice(0, 10)}</text>`;
  }).join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 280"><rect width="480" height="280" fill="#101926"/><path d="M40 220 C140 30 320 250 440 50" fill="none" stroke="#ffb16a" stroke-width="1" opacity=".35"/><path d="M40 50 C170 250 310 20 440 220" fill="none" stroke="#81f7d8" stroke-width="1" opacity=".35"/>${circles || `<circle cx="240" cy="140" r="36" fill="none" stroke="#81f7d8" stroke-width="2"><animate attributeName="r" values="30;46;30" dur="2.8s" repeatCount="indefinite"/></circle>`}<text x="24" y="32" fill="#f5fbff" font-size="14" font-family="monospace">AUTOMATA / ${animated ? "MOTION" : "PIXEL"}</text><text x="24" y="260" fill="#a1b1c5" font-size="10" font-family="monospace">${safe}</text></svg>`;
  return { id: randomUUID(), content: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`, mimeType: "image/svg+xml" };
}

export function createCapabilityArtifact(mode: string, query: string, tokens: string[], contextLens: string[]): { id: string; kind: string; title: string; content: string; mimeType: string } {
  const subject = tokens[0] ?? "signal";
  const relation = tokens[1] ?? "changes";
  const context = tokens[2] ?? contextLens[0] ?? "mesh";
  if (mode === "code") {
    const content = `// Generated from semantic relation: ${subject} -> ${relation} -> ${context}
type MeshSignal = { subject: string; relation: string; context: string };

export function transform(signal: MeshSignal): MeshSignal {
  return { ...signal, context: "${context}" };
}

export const signal: MeshSignal = {
  subject: "${subject}",
  relation: "${relation}",
  context: "${context}",
};`;
    return { id: randomUUID(), kind: "code", title: "Semantic source graph", content, mimeType: "text/typescript" };
  }
  if (mode === "game") {
    const html = `<!doctype html><meta charset="utf-8"><title>Mesh State Loop</title>
<style>body{margin:0;background:#101926;color:#81f7d8;font:14px monospace;display:grid;place-items:center;height:100vh}canvas{border:1px solid #81f7d8;box-shadow:0 0 24px #81f7d833}</style>
<canvas width="520" height="300"></canvas><script>
const c=document.querySelector("canvas"),x=c.getContext("2d"); let t=0;
function loop(){t+=.02;x.fillStyle="#101926";x.fillRect(0,0,c.width,c.height);x.strokeStyle="#81f7d8";x.beginPath();x.arc(260+Math.cos(t)*110,150+Math.sin(t)*70,28,0,7);x.stroke();x.fillStyle="#f5fbff";x.fillText("${subject} ${relation} ${context}",24,28);requestAnimationFrame(loop)}loop();
</script>`;
    return { id: randomUUID(), kind: "game", title: "Playable state machine", content: html, mimeType: "text/html" };
  }
  if (mode === "app") {
    const html = `<!doctype html><meta charset="utf-8"><title>Mesh Context View</title>
<style>body{margin:0;background:#101926;color:#f5fbff;font:14px monospace;padding:24px}main{border:1px solid #81f7d8;padding:20px;max-width:560px}b{color:#81f7d8}button{background:#81f7d8;border:0;padding:10px 16px;font:inherit}</style>
<main><b>CONTEXT FILTER</b><h1>${subject}</h1><p>Relation: ${relation}</p><p>Lens: ${context}</p><button>Propagate signal</button></main>`;
    return { id: randomUUID(), kind: "app", title: "Context-aware app view", content: html, mimeType: "text/html" };
  }
  return { id: randomUUID(), kind: mode, title: `${mode} capability output`, content: `${subject} ${relation} through ${context}.`, mimeType: "text/plain" };
}
