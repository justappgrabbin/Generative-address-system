import type { ArtifactClass, FiveDReport } from "@/lib/klein-engine";

export type MorphAxis = "space" | "time" | "appearance" | "behavior" | "meaning";

export const morphAxes: { id: MorphAxis; label: string; description: string }[] = [
  { id: "space", label: "Space", description: "position, layout, and structure" },
  { id: "time", label: "Time", description: "order, timing, and state changes" },
  { id: "appearance", label: "Appearance", description: "visual, audio, or surface state" },
  { id: "behavior", label: "Behavior", description: "rules, events, and responses" },
  { id: "meaning", label: "Meaning", description: "purpose, labels, and relationships" },
];

export type MorphPlan = {
  source: string;
  target: string;
  score: number;
  compatible: boolean;
  sharedCapabilities: string[];
  steps: string[];
  intermediateState: string;
  result: string;
};

const classAxes: Record<ArtifactClass, MorphAxis[]> = {
  game: ["space", "time", "behavior", "meaning"],
  app: ["space", "time", "behavior", "meaning"],
  code: ["space", "time", "behavior", "meaning"],
  document: ["space", "time", "meaning"],
  image: ["space", "appearance", "meaning"],
  video: ["space", "time", "appearance", "meaning"],
  audio: ["time", "appearance", "meaning"],
  model: ["space", "appearance", "meaning"],
  data: ["space", "time", "behavior", "meaning"],
  archive: ["space", "meaning"],
  unknown: ["meaning"],
};

function pairBonus(source: ArtifactClass, target: ArtifactClass) {
  if (source === target) return 0.35;
  if ([source, target].every((kind) => ["image", "video", "model"].includes(kind))) return 0.25;
  if ([source, target].every((kind) => ["code", "app", "game", "data"].includes(kind))) return 0.3;
  if ([source, target].includes("document") && [source, target].some((kind) => ["code", "data", "app"].includes(kind))) return 0.2;
  if ([source, target].includes("unknown")) return 0.05;
  return 0.1;
}

function unique(values: string[]) {
  return Array.from(new Set(values.filter(Boolean)));
}

function axisStep(axis: MorphAxis, source: FiveDReport, target: FiveDReport, progress: number) {
  const percent = Math.round(progress * 100);
  if (axis === "space") return `${percent}%: map ${source.artifactClass} structure toward ${target.artifactClass} structure`;
  if (axis === "time") return `${percent}%: align sequence and state changes`;
  if (axis === "appearance") return `${percent}%: interpolate available visual or audio states`;
  if (axis === "behavior") return `${percent}%: compare events, rules, and responses`;
  return `${percent}%: connect purpose and relationships`;
}

export function buildMorphPlan(source: FiveDReport, target: FiveDReport, weights: Record<MorphAxis, number>, progress = 0.5): MorphPlan {
  const sharedCapabilities = source.capabilities.filter((capability) => target.capabilities.includes(capability));
  const sharedAxes = classAxes[source.artifactClass].filter((axis) => classAxes[target.artifactClass].includes(axis));
  const score = Math.min(0.99, Math.max(0.08, 0.35 + pairBonus(source.artifactClass, target.artifactClass) + sharedCapabilities.length * 0.05 + sharedAxes.length * 0.04));
  const activeAxes = morphAxes
    .filter(({ id }) => sharedAxes.includes(id) || weights[id] > 0.45)
    .sort((a, b) => weights[b.id] - weights[a.id]);
  const steps = activeAxes.map(({ id }) => axisStep(id, source, target, progress));
  return {
    source: source.name,
    target: target.name,
    score,
    compatible: score >= 0.45,
    sharedCapabilities,
    steps: steps.length ? steps : ["No shared transformation axis detected"],
    intermediateState: `Intermediate state at ${Math.round(progress * 100)}% between ${source.name} and ${target.name}.`,
    result: activeAxes.length
      ? `A ${activeAxes.map((axis) => axis.label.toLowerCase()).join(", ")} transition can be generated.`
      : "Only a relationship link can be generated.",
  };
}

export function defaultWeights(): Record<MorphAxis, number> {
  return { space: 0.5, time: 0.5, appearance: 0.5, behavior: 0.5, meaning: 0.5 };
}

export function compatibleArtifacts(source: FiveDReport, target: FiveDReport) {
  return unique([...source.compatibility, ...target.compatibility]);
}