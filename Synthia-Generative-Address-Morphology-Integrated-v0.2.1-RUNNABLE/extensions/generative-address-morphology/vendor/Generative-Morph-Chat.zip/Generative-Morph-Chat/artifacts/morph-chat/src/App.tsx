import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Activity,
  BrainCircuit,
  BookOpen,
  ChevronDown,
  CirclePause,
  CirclePlay,
  CircleStop,
  Download,
  FileText,
  Film,
  GitBranch,
  Image as ImageIcon,
  Info,
  Layers3,
  RefreshCcw,
  Scissors,
  Send,
  Sparkles,
  Upload,
  Waypoints,
  Wand2,
  Zap,
  X,
} from "lucide-react";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { buildResponseIntent, dimensionMap, englishDataset, realizeResponse, routeQuestion, semanticRead } from "@/lib/automata";
import { KleinArtifactEngine, type FiveDReport } from "@/lib/klein-engine";
import { buildMorphPlan, compatibleArtifacts, defaultWeights, morphAxes, type MorphAxis, type MorphPlan } from "@/lib/morph-engine";
import NotFound from "@/pages/not-found";
import { Route, Switch, Router as WouterRouter, useLocation } from "wouter";

const queryClient = new QueryClient();

type NodeKind = "object" | "relation" | "feature";
type MessageRole = "system" | "user";

type MeshNode = {
  id: string;
  label: string;
  kind: NodeKind;
  x: number;
  y: number;
  size: number;
  parent?: string;
  energy: number;
};

type ChatMessage = {
  id: string;
  role: MessageRole;
  text: string;
  meta?: string;
  nodeIds?: string[];
};

type SemanticDimension = "who" | "what" | "where" | "when" | "why";
type MediaKind = "book" | "video" | "image";
type DimensionAnswers = Record<SemanticDimension, string>;

type MediaAsset = {
  id: string;
  name: string;
  kind: MediaKind;
  mime: string;
  size: number;
  url: string;
  text: string;
  analysis: DimensionAnswers;
  report: FiveDReport;
};

const dimensions: { id: SemanticDimension; label: string; hint: string }[] = [
  { id: "who", label: "who", hint: "agent / witness" },
  { id: "what", label: "what", hint: "object / action" },
  { id: "where", label: "where", hint: "place" },
  { id: "when", label: "when", hint: "time / sequence" },
  { id: "why", label: "why", hint: "reason" },
];

const initialNodes: MeshNode[] = [
  { id: "idea", label: "idea", kind: "object", x: 380, y: 290, size: 22, energy: 1 },
  { id: "shape", label: "shape", kind: "object", x: 214, y: 190, size: 15, parent: "idea", energy: .76 },
  { id: "pressure", label: "pressure", kind: "relation", x: 529, y: 171, size: 13, parent: "idea", energy: .69 },
  { id: "memory", label: "memory", kind: "object", x: 155, y: 370, size: 16, parent: "idea", energy: .72 },
  { id: "curiosity", label: "curiosity", kind: "feature", x: 566, y: 373, size: 17, parent: "idea", energy: .91 },
  { id: "becomes", label: "becomes", kind: "relation", x: 373, y: 124, size: 10, parent: "idea", energy: .54 },
  { id: "boundary", label: "boundary", kind: "feature", x: 382, y: 482, size: 14, parent: "idea", energy: .61 },
  { id: "observe", label: "observe", kind: "relation", x: 690, y: 274, size: 11, parent: "curiosity", energy: .57 },
  { id: "echo", label: "echo", kind: "feature", x: 88, y: 234, size: 10, parent: "memory", energy: .48 },
  { id: "inherit", label: "inherit", kind: "relation", x: 235, y: 493, size: 10, parent: "memory", energy: .62 },
  { id: "unknown", label: "unknown", kind: "feature", x: 625, y: 493, size: 12, parent: "curiosity", energy: .76 },
  { id: "tension", label: "tension", kind: "feature", x: 93, y: 440, size: 12, parent: "shape", energy: .64 },
  { id: "return", label: "return", kind: "relation", x: 682, y: 108, size: 10, parent: "pressure", energy: .44 },
  { id: "vector", label: "vector", kind: "feature", x: 510, y: 548, size: 11, parent: "boundary", energy: .52 },
  { id: "seed", label: "seed", kind: "object", x: 72, y: 114, size: 9, parent: "shape", energy: .36 },
];

const initialMessages: ChatMessage[] = [
  {
    id: "m-1",
    role: "system",
    text: "Ready.",
    meta: "status · 00:00",
  },
  {
    id: "m-2",
    role: "user",
    text: "I want to understand how an idea becomes a shape.",
    meta: "instruction · 00:12",
  },
  {
    id: "m-3",
    role: "system",
    text: "I connected idea and shape.",
    meta: "updated · 00:12",
    nodeIds: ["idea", "shape", "pressure"],
  },
  {
    id: "m-4",
    role: "user",
    text: "Keep curiosity and uncertainty visible.",
    meta: "instruction · 00:28",
  },
  {
    id: "m-5",
    role: "system",
    text: "I connected curiosity, uncertainty, and boundary.",
    meta: "updated · 00:28",
    nodeIds: ["curiosity", "unknown", "boundary"],
  },
];

const examplePrompts = [
  "Connect memory to possibility",
  "What is connected to the current shape?",
  "Add doubt",
];

const ruleDescriptions = [
  ["WORDS", "Learns which English words appear together"],
  ["CATEGORIES", "Sorts messages by who, what, where, when, and why"],
  ["CONNECTIONS", "Keeps related items linked"],
];

function hashText(text: string) {
  return text.split("").reduce((value, char) => ((value * 31) + char.charCodeAt(0)) % 997, 7);
}

function kindColor(kind: NodeKind) {
  if (kind === "object") return "#d5ff63";
  if (kind === "relation") return "#79dce6";
  return "#ff917c";
}

function classifyWord(word: string): NodeKind {
  const relationWords = ["connect", "become", "resist", "make", "hold", "move", "link", "turn", "return", "grow", "understand"];
  const featureWords = ["curious", "curiosity", "unknown", "doubt", "soft", "strange", "possible", "quiet", "wild", "open", "tension"];
  if (relationWords.some((item) => word.includes(item))) return "relation";
  if (featureWords.some((item) => word.includes(item))) return "feature";
  return "object";
}

function cleanWords(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, "").split(/\s+/).filter((word) => word.length > 3);
}

function mediaKind(file: File): MediaKind {
  if (file.type.startsWith("video/")) return "video";
  if (file.type.startsWith("image/")) return "image";
  return "book";
}

function readableBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function readBookText(file: File) {
  const isText = file.type.startsWith("text/") || /\.(txt|md|csv|json|xml|html?|ts|tsx|js|jsx|py|rb|go|rs|java|css|glsl|sh|yaml|yml|toml)$/i.test(file.name);
  if (!isText) return "";
  try {
    return (await file.text()).slice(0, 16000);
  } catch {
    return "";
  }
}

function Mesh({
  nodes,
  selectedId,
  onSelect,
}: {
  nodes: MeshNode[];
  selectedId: string;
  onSelect: (id: string) => void;
}) {
  const byId = useMemo(() => new Map(nodes.map((node) => [node.id, node])), [nodes]);
  return (
    <svg className="h-full w-full" viewBox="0 0 760 620" role="img" aria-label="Live semantic mesh">
      <defs>
        <radialGradient id="mesh-orb" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#d5ff63" stopOpacity=".2" />
          <stop offset="48%" stopColor="#79dce6" stopOpacity=".07" />
          <stop offset="100%" stopColor="#79dce6" stopOpacity="0" />
        </radialGradient>
        <filter id="soft-glow">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <circle cx="380" cy="300" r="184" fill="url(#mesh-orb)" className="drift-slow" />
      <g opacity=".5">
        {Array.from({ length: 10 }).map((_, index) => (
          <circle key={`orbit-${index}`} cx="380" cy="300" r={86 + index * 26} fill="none" stroke="#91a0d8" strokeOpacity={index % 2 ? ".06" : ".1"} strokeDasharray={index % 2 ? "2 12" : "1 0"} />
        ))}
      </g>
      <g>
        {nodes.filter((node) => node.parent && byId.has(node.parent)).map((node, index) => {
          const parent = byId.get(node.parent as string) as MeshNode;
          const active = node.id === selectedId || node.parent === selectedId;
          return (
            <g key={`edge-${node.id}`} className="drift" style={{ animationDelay: `${(index % 7) * 180}ms` }}>
              <line x1={parent.x} y1={parent.y} x2={node.x} y2={node.y} stroke={active ? "#d5ff63" : "#8793c4"} strokeOpacity={active ? ".68" : ".22"} strokeWidth={active ? "1.6" : "1"} />
              <circle cx={(parent.x + node.x) / 2} cy={(parent.y + node.y) / 2} r="2" fill={active ? "#ff917c" : "#8793c4"} opacity={active ? ".95" : ".4"} />
            </g>
          );
        })}
      </g>
      <g>
        {nodes.map((node, index) => {
          const active = node.id === selectedId;
          const color = kindColor(node.kind);
          return (
            <g
              key={node.id}
              className="node-enter"
              style={{ animationDelay: `${Math.min(index * 35, 500)}ms` }}
              transform={`translate(${node.x} ${node.y})`}
              onClick={() => onSelect(node.id)}
              onKeyDown={(event: KeyboardEvent<SVGGElement>) => { if (event.key === "Enter" || event.key === " ") onSelect(node.id); }}
              role="button"
              tabIndex={0}
              data-testid={`mesh-node-${node.id}`}
              aria-label={`Inspect ${node.label} node`}
            >
              {active && <circle r={node.size + 16} fill="none" stroke={color} strokeOpacity=".48" strokeWidth="1" className="pulse-ring" />}
              <circle r={node.size + 8} fill={color} fillOpacity={active ? ".18" : ".06"} filter={active ? "url(#soft-glow)" : undefined} />
              <circle r={node.size} fill="#1b2146" stroke={color} strokeOpacity={active ? "1" : ".72"} strokeWidth={active ? "2" : "1.2"} />
              <circle cx={-node.size * .3} cy={-node.size * .3} r={Math.max(2, node.size * .16)} fill={color} opacity={node.energy} />
              <text y={node.size + 17} textAnchor="middle" fill={active ? "#f5f4e9" : "#9ca7d0"} fontSize={active ? "12" : "10"} fontFamily="var(--app-font-mono)" letterSpacing=".06em">{node.label}</text>
            </g>
          );
        })}
      </g>
    </svg>
  );
}

function ChatMessageView({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  return (
    <article className={`message-enter flex gap-3 ${isUser ? "flex-row-reverse" : ""}`} data-testid={`message-${message.id}`}>
      <div className={`mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border ${isUser ? "border-[#ff917c]/40 bg-[#ff917c]/10 text-[#ff917c]" : "border-[#79dce6]/40 bg-[#79dce6]/10 text-[#79dce6]"}`}>
        {isUser ? <span className="mono-font text-[10px]">you</span> : <Sparkles size={13} />}
      </div>
      <div className={`max-w-[86%] ${isUser ? "text-right" : ""}`}>
        <div className={`inline-block rounded-2xl border px-4 py-3 text-[13px] leading-relaxed ${isUser ? "rounded-tr-sm border-[#ff917c]/20 bg-[#ff917c]/[.09] text-[#f4d9d0]" : "rounded-tl-sm border-[#79dce6]/15 bg-[#20264c]/75 text-[#d8d9e8]"}`}>
          {message.text}
        </div>
        {message.meta && <div className="mono-font mt-1.5 text-[9px] uppercase tracking-[.12em] text-[#727da9]">{message.meta}</div>}
      </div>
    </article>
  );
}

function Home() {
  const [nodes, setNodes] = useState<MeshNode[]>(initialNodes);
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [editInstruction, setEditInstruction] = useState("");
  const [clipUrl, setClipUrl] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [input, setInput] = useState("");
  const [paused, setPaused] = useState(false);
  const [cycle, setCycle] = useState(14);
  const [selectedId, setSelectedId] = useState("idea");
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [morphSourceId, setMorphSourceId] = useState<string | null>(null);
  const [morphTargetId, setMorphTargetId] = useState<string | null>(null);
  const [morphProgress, setMorphProgress] = useState(0.5);
  const [morphWeights, setMorphWeights] = useState<Record<MorphAxis, number>>(defaultWeights);
  const scrollRef = useRef<HTMLDivElement>(null);
  const mediaInputRef = useRef<HTMLInputElement>(null);
  const kleinEngineRef = useRef(new KleinArtifactEngine());

  const selectedNode = nodes.find((node) => node.id === selectedId) ?? nodes[0];
  const objectCount = nodes.filter((node) => node.kind === "object").length;
  const relationCount = nodes.filter((node) => node.kind === "relation").length;
  const featureCount = nodes.filter((node) => node.kind === "feature").length;
  const selectedAsset = assets.find((asset) => asset.id === selectedAssetId) ?? assets[0];
  const morphSource = assets.find((asset) => asset.id === morphSourceId) ?? assets[0];
  const morphTarget = assets.find((asset) => asset.id === morphTargetId) ?? assets[1];
  const morphPlan = useMemo<MorphPlan | null>(() => {
    if (!morphSource || !morphTarget || morphSource.id === morphTarget.id) return null;
    return buildMorphPlan(morphSource.report, morphTarget.report, morphWeights, morphProgress);
  }, [morphProgress, morphSource, morphTarget, morphWeights]);

  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(() => {
      setNodes((current) => {
        if (current.length > 29) return current;
        const index = current.length;
        const parent = current[(index * 5 + 2) % current.length];
        const angle = index * 2.399;
        const radius = 150 + (index % 4) * 28;
        const node: MeshNode = {
          id: `ambient-${index}`,
          label: `phase ${String(index - 14).padStart(2, "0")}`,
          kind: index % 3 === 0 ? "relation" : "feature",
          x: 380 + Math.cos(angle) * radius,
          y: 300 + Math.sin(angle) * radius * .7,
          size: 5 + (index % 3),
          parent: parent.id,
          energy: .28 + (index % 6) * .08,
        };
        return [...current, node];
      });
      setCycle((current) => current + 1);
    }, 4200);
    return () => window.clearInterval(timer);
  }, [paused]);

  useEffect(() => {
    const scrollElement = scrollRef.current;
    if (scrollElement) scrollElement.scrollTop = scrollElement.scrollHeight;
  }, [messages]);

  function appendForPrompt(text: string) {
    const words = cleanWords(text);
    const uniqueWords = Array.from(new Set(words)).slice(0, 3);
    const baseHash = hashText(text);
    const added: MeshNode[] = [];
    const current = nodes;
    if (paused) return added;
    const parent = current.find((node) => node.id === selectedId) ?? current[0];
    uniqueWords.forEach((word, wordIndex) => {
      const angle = ((baseHash + wordIndex * 113) % 360) * (Math.PI / 180);
      const distance = 92 + ((baseHash + wordIndex * 29) % 54);
      const id = `${word}-${baseHash}-${wordIndex}`;
      if (current.some((node) => node.label === word)) return;
      added.push({
        id,
        label: word,
        kind: classifyWord(word),
        x: Math.max(48, Math.min(712, parent.x + Math.cos(angle) * distance)),
        y: Math.max(58, Math.min(555, parent.y + Math.sin(angle) * distance)),
        size: 9 + ((baseHash + wordIndex) % 8),
        parent: parent.id,
        energy: .64 + (wordIndex * .11),
      });
    });
    setNodes([...current, ...added]);
    return added;
  }

  async function handleMediaUpload(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []);
    if (!files.length) return;
    const nextAssets = await Promise.all(files.map(async (file, index) => {
      const kind = mediaKind(file);
      const text = kind === "book" ? await readBookText(file) : "";
      const report = kleinEngineRef.current.ingest({
        name: file.name,
        mimeType: file.type,
        size: file.size,
        text,
      });
      return {
        id: `asset-${Date.now()}-${index}`,
        name: file.name,
        kind,
        mime: file.type || "application/octet-stream",
        size: file.size,
        url: URL.createObjectURL(file),
        text,
        analysis: report.dimensions,
        report,
      };
    }));
    setAssets((current) => [...current, ...nextAssets]);
    setSelectedAssetId(nextAssets[0].id);
    const sourceId = morphSourceId ?? nextAssets[0].id;
    setMorphSourceId(sourceId);
    if (!morphTargetId) {
      const nextTarget = nextAssets.find((asset) => asset.id !== sourceId)?.id
        ?? assets.find((asset) => asset.id !== sourceId)?.id
        ?? null;
      setMorphTargetId(nextTarget);
    }
    const first = nextAssets[0];
    const sourceRead = semanticRead(`${first.name} ${first.text}`);
    const sourceWords = [...sourceRead.tokens.slice(0, 3), ...sourceRead.neighbors.slice(0, 2).map((neighbor) => neighbor.word)].join(" ");
    const reportFacts = [...first.report.dependencies.slice(0, 2), ...first.report.capabilities.slice(0, 2)].join(" ");
    const addedNodes = appendForPrompt(`${first.name} ${sourceWords} ${reportFacts}`);
    const artifactLabel = first.report.artifactClass.charAt(0).toUpperCase() + first.report.artifactClass.slice(1);
    setMessages((current) => [...current, {
      id: `m-${Date.now()}-asset`,
      role: "system",
      text: `${artifactLabel} added. ${sourceRead.neighbors.length ? `The closest related word is ${sourceRead.neighbors[0].word}.` : "I didn’t find a related word."}`,
      meta: `added · ${readableBytes(first.size)} · ${dimensionMap[sourceRead.route].name}`,
      nodeIds: addedNodes.map((node) => node.id),
    }]);
    setCycle((current) => current + Math.max(1, addedNodes.length));
    if (addedNodes[0]) setSelectedId(addedNodes[0].id);
    event.target.value = "";
  }

  function updateAssetAnswer(dimension: SemanticDimension, value: string) {
    if (!selectedAsset) return;
    setAssets((current) => current.map((asset) => asset.id === selectedAsset.id
      ? { ...asset, analysis: { ...asset.analysis, [dimension]: value } }
      : asset));
  }

  function routeEdit(event?: FormEvent) {
    event?.preventDefault();
    if (!selectedAsset) {
      mediaInputRef.current?.click();
      return;
    }
    const instruction = editInstruction.trim() || "make a visual study";
    const dimension = routeQuestion(instruction);
    const addedNodes = appendForPrompt(`${selectedAsset.name} ${instruction} ${dimension}`);
    setMessages((current) => [...current,
      {
        id: `m-${Date.now()}-edit`,
        role: "user",
        text: instruction,
        meta: `edit directive · routed to ${dimension}`,
      },
      {
        id: `m-${Date.now()}-edit-system`,
        role: "system",
        text: `${addedNodes.length ? `${addedNodes.length} ${addedNodes.length === 1 ? "item" : "items"} added.` : "The existing item was updated."} Category: ${dimensionMap[dimension].name}.`,
        meta: `route · ${dimension} / ${dimensionMap[dimension].sense}`,
        nodeIds: addedNodes.map((node) => node.id),
      },
    ]);
    setCycle((current) => current + Math.max(1, addedNodes.length));
    if (addedNodes[0]) setSelectedId(addedNodes[0].id);
    setEditInstruction("");
  }

  function removeAsset(assetId: string) {
    const asset = assets.find((item) => item.id === assetId);
    if (asset) URL.revokeObjectURL(asset.url);
    setAssets((current) => current.filter((item) => item.id !== assetId));
    if (selectedAssetId === assetId) {
      const remaining = assets.filter((item) => item.id !== assetId);
      setSelectedAssetId(remaining[0]?.id ?? null);
    }
    if (morphSourceId === assetId) setMorphSourceId(null);
    if (morphTargetId === assetId) setMorphTargetId(null);
  }

  function applyMorphPlan() {
    if (!morphPlan || !morphSource || !morphTarget) return;
    const addedNodes = appendForPrompt(`${morphSource.name} ${morphTarget.name} ${morphPlan.result}`);
    setMessages((current) => [...current, {
      id: `m-${Date.now()}-morph`,
      role: "system",
      text: `${morphPlan.result} ${addedNodes.length ? `${addedNodes.length} items added to the mesh.` : "The existing items were kept."}`,
      meta: `morph plan · ${Math.round(morphPlan.score * 100)}% compatible`,
      nodeIds: addedNodes.map((node) => node.id),
    }]);
    setCycle((current) => current + Math.max(1, addedNodes.length));
    if (addedNodes[0]) setSelectedId(addedNodes[0].id);
  }

  function recordMorphClip() {
    if (isRecording || typeof MediaRecorder === "undefined") return;
    const canvas = document.createElement("canvas");
    canvas.width = 960;
    canvas.height = 540;
    const context = canvas.getContext("2d");
    if (!context) return;
    const snapshot = nodes.slice();
    const startedAt = performance.now();
    const duration = 6500;
    const chunks: Blob[] = [];
    const stream = canvas.captureStream(30);
    const recorder = new MediaRecorder(stream, { mimeType: "video/webm;codecs=vp9" });
    setIsRecording(true);
    if (clipUrl) URL.revokeObjectURL(clipUrl);
    setClipUrl(null);
    recorder.ondataavailable = (event) => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onstop = () => {
      setClipUrl(URL.createObjectURL(new Blob(chunks, { type: "video/webm" })));
      setIsRecording(false);
    };
    recorder.start();
    const drawFrame = (now: number) => {
      const progress = Math.min(1, (now - startedAt) / duration);
      context.fillStyle = "#0d1230";
      context.fillRect(0, 0, canvas.width, canvas.height);
      const glow = context.createRadialGradient(480, 270, 10, 480, 270, 290);
      glow.addColorStop(0, "rgba(213,255,99,.18)");
      glow.addColorStop(0.45, "rgba(121,220,230,.08)");
      glow.addColorStop(1, "rgba(13,18,48,0)");
      context.fillStyle = glow;
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.strokeStyle = "rgba(164,176,222,.08)";
      context.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 32) {
        context.beginPath(); context.moveTo(x, 0); context.lineTo(x, canvas.height); context.stroke();
      }
      for (let y = 0; y < canvas.height; y += 32) {
        context.beginPath(); context.moveTo(0, y); context.lineTo(canvas.width, y); context.stroke();
      }
      const byId = new Map(snapshot.map((node) => [node.id, node]));
      snapshot.forEach((node) => {
        if (!node.parent) return;
        const parent = byId.get(node.parent);
        if (!parent) return;
        context.strokeStyle = node.kind === "relation" ? "rgba(121,220,230,.45)" : "rgba(213,255,99,.28)";
        context.beginPath();
        context.moveTo(parent.x * 1.15, parent.y * .82 + 18);
        context.lineTo(node.x * 1.15, node.y * .82 + 18);
        context.stroke();
      });
      snapshot.forEach((node, index) => {
        const wobble = Math.sin(now / 800 + index) * (2 + node.energy * 3);
        const x = node.x * 1.15 + wobble;
        const y = node.y * .82 + 18 + Math.cos(now / 950 + index) * 2;
        const color = kindColor(node.kind);
        context.beginPath(); context.arc(x, y, node.size * 1.15, 0, Math.PI * 2);
        context.fillStyle = "rgba(27,33,70,.95)"; context.fill();
        context.strokeStyle = color; context.globalAlpha = .45 + node.energy * .55; context.stroke(); context.globalAlpha = 1;
      });
      context.fillStyle = "#f4f2e5";
      context.font = "600 17px monospace";
      context.fillText("GENERATIVE MORPH / SCENE STUDY", 34, 42);
      context.fillStyle = "#79dce6";
      context.font = "12px monospace";
      context.fillText(selectedAsset ? selectedAsset.name.toUpperCase().slice(0, 54) : "UNTITLED FIELD", 34, 64);
      context.fillStyle = "#d5ff63";
      context.fillText(`AUTOMATA CYCLE ${String(cycle + Math.floor(progress * 12)).padStart(2, "0")}`, 760, 42);
      if (progress < 1) {
        requestAnimationFrame(drawFrame);
      } else {
        recorder.stop();
        stream.getTracks().forEach((track) => track.stop());
      }
    };
    requestAnimationFrame(drawFrame);
  }

  function submitMessage(event?: FormEvent) {
    event?.preventDefault();
    const text = input.trim();
    if (!text) return;
    const messageId = `m-${Date.now()}`;
    setMessages((current) => [...current, { id: messageId, role: "user", text, meta: "instruction · now" }]);
    const addedNodes = appendForPrompt(text);
    const responseIntent = buildResponseIntent(text, addedNodes.length, paused);
    const response = realizeResponse(responseIntent);
    window.setTimeout(() => {
      setMessages((current) => [...current, {
        id: `m-${Date.now()}-system`,
        role: "system",
        text: response,
        meta: paused ? "status · now" : `updated · ${responseIntent.dimension}`,
        nodeIds: addedNodes.map((node) => node.id),
      }]);
    }, 360);
    setCycle((current) => current + (paused ? 0 : Math.max(1, addedNodes.length)));
    if (addedNodes[0]) setSelectedId(addedNodes[0].id);
    setInput("");
  }

  function handleInputKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submitMessage();
    }
  }

  function resetMesh() {
    assets.forEach((asset) => URL.revokeObjectURL(asset.url));
    if (clipUrl) URL.revokeObjectURL(clipUrl);
    setNodes(initialNodes);
    setMessages(initialMessages);
    setAssets([]);
    setSelectedAssetId(null);
    setMorphSourceId(null);
    setMorphTargetId(null);
    setMorphProgress(0.5);
    setMorphWeights(defaultWeights());
    setEditInstruction("");
    setClipUrl(null);
    setIsRecording(false);
    setCycle(14);
    setSelectedId("idea");
    setInput("");
  }

  return (
    <main className="morph-app">
      <div className="page-shell mx-auto flex min-h-[100dvh] max-w-[1640px] flex-col px-4 py-4 sm:px-6 lg:px-8">
        <header className="flex shrink-0 items-center justify-between border-b hairline pb-4">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-[12px] border border-[#d5ff63]/40 bg-[#d5ff63]/10 text-[#d5ff63]">
              <BrainCircuit size={19} strokeWidth={1.5} />
              <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-[#ff917c] shadow-[0_0_12px_#ff917c]" />
            </div>
            <div>
              <div className="display-font text-[20px] leading-none tracking-[-.02em] text-[#f4f2e5]">Generative <i className="text-[#d5ff63]">Morph</i></div>
              <div className="mono-font mt-1 text-[9px] uppercase tracking-[.24em] text-[#727da9]">local text and image tool</div>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-5">
            <div className="hidden items-center gap-2 sm:flex">
              <span className={`h-1.5 w-1.5 rounded-full ${paused ? "bg-[#ff917c]" : "bg-[#d5ff63] shadow-[0_0_10px_#d5ff63]"}`} />
              <span className="mono-font text-[10px] uppercase tracking-[.16em] text-[#9da7cd]">{paused ? "paused" : "ready"}</span>
            </div>
            <button type="button" onClick={() => setIsRulesOpen((value) => !value)} className="flex items-center gap-2 rounded-full border border-[#aab4df]/20 px-3 py-2 text-[11px] text-[#b8bfdb] transition hover:border-[#d5ff63]/50 hover:text-[#d5ff63]" data-testid="button-toggle-rules">
              <Info size={13} />
              <span className="hidden sm:inline">How it thinks</span>
              <ChevronDown size={13} className={`transition-transform ${isRulesOpen ? "rotate-180" : ""}`} />
            </button>
          </div>
        </header>

        {isRulesOpen && (
          <section className="message-enter mt-4 rounded-2xl border border-[#d5ff63]/20 bg-[#d5ff63]/[.05] p-4" data-testid="panel-rules">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              {ruleDescriptions.map(([label, detail]) => (
                <div key={label} className="flex items-start gap-3">
                  <span className="mono-font mt-0.5 text-[10px] text-[#d5ff63]">{label}</span>
                  <span className="text-[12px] leading-relaxed text-[#a9b0ce]">{detail}</span>
                </div>
              ))}
            </div>
            <div className="mono-font mt-3 border-t border-[#d5ff63]/10 pt-3 text-[9px] uppercase tracking-[.12em] text-[#7280a9]">
              Uses {englishDataset.length} short English examples to find related words · categories: who, what, where, when, why
            </div>
          </section>
        )}

        <div className="grid min-h-0 flex-1 grid-cols-1 gap-5 py-5 lg:grid-cols-[minmax(320px,.78fr)_minmax(560px,1.42fr)]">
          <section className="order-2 flex min-h-0 min-w-0 flex-col border-r-0 hairline lg:order-1 lg:min-h-[620px] lg:border-r lg:pr-5" aria-label="Conversation">
            <div className="mb-4 flex items-end justify-between">
              <div>
                <div className="eyebrow">Conversation / 01</div>
                <h1 className="display-font mt-1 text-[27px] leading-tight text-[#f4f2e5]">Enter a message.</h1>
              </div>
              <span className="mono-font text-[10px] text-[#727da9]">{messages.length} traces</span>
            </div>
            <div ref={scrollRef} className="scrollbar-thin flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto pb-5 pr-2" data-testid="conversation-list">
              {messages.map((message) => <ChatMessageView key={message.id} message={message} />)}
              <div className="mt-auto flex items-center gap-2 pt-2 text-[10px] uppercase tracking-[.13em] text-[#626d99]">
                <span className="h-px flex-1 bg-[#aab4df]/10" />
                 <span>{paused ? "paused" : "ready"}</span>
                <span className="h-px flex-1 bg-[#aab4df]/10" />
              </div>
            </div>
            <form onSubmit={submitMessage} className="mt-1">
              <div className="relative overflow-hidden rounded-2xl border border-[#8793c4]/30 bg-[#171c3c]/90 shadow-[0_12px_35px_rgba(0,0,0,.18)] transition focus-within:border-[#d5ff63]/60">
                <textarea
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={handleInputKeyDown}
                  placeholder="Type a message..."
                  rows={3}
                  className="w-full resize-none bg-transparent px-4 pb-12 pt-4 text-[13px] leading-relaxed text-[#ebeada] outline-none placeholder:text-[#66719c]"
                  data-testid="input-prompt"
                   aria-label="Type a message"
                />
                <div className="absolute bottom-3 left-4 right-3 flex items-center justify-between">
                   <span className="mono-font text-[9px] uppercase tracking-[.13em] text-[#56618d]">shift + enter for a new line</span>
                  <button type="submit" disabled={!input.trim()} className="button-shine flex h-8 items-center gap-2 rounded-lg bg-[#d5ff63] px-3 text-[11px] font-bold text-[#1a203e] transition hover:bg-[#e5ff9b] disabled:cursor-not-allowed disabled:opacity-35" data-testid="button-submit-prompt">
                    <span>Send</span><Send size={13} />
                  </button>
                </div>
              </div>
              <div className="scrollbar-thin mt-3 flex gap-2 overflow-x-auto pb-1">
                {examplePrompts.map((prompt) => (
                  <button key={prompt} type="button" onClick={() => setInput(prompt)} className="shrink-0 rounded-full border border-[#8793c4]/20 px-3 py-1.5 text-[10px] text-[#8f99bf] transition hover:border-[#79dce6]/50 hover:text-[#79dce6]" data-testid={`button-example-${prompt.slice(0, 8).replace(/\s/g, "-")}`}>
                    {prompt}
                  </button>
                ))}
              </div>
            </form>
            <section className="mt-5 rounded-2xl border border-[#8793c4]/20 bg-[#151a38]/70 p-4" aria-label="Source automaton">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="eyebrow">Source analysis</div>
                  <h2 className="mt-1 text-[15px] font-medium text-[#f1f0e2]">Add a source.</h2>
                  <p className="mt-1 max-w-[360px] text-[11px] leading-relaxed text-[#7f8ab3]">Add a file to create connected items from its name or text.</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {assets.length > 0 && (
                    <button type="button" onClick={recordMorphClip} disabled={isRecording} className="flex items-center gap-2 rounded-lg border border-[#79dce6]/35 bg-[#79dce6]/[.08] px-3 py-2 text-[11px] font-bold text-[#79dce6] transition hover:bg-[#79dce6]/[.15] disabled:cursor-wait disabled:opacity-70" data-testid="button-make-clip">
                      {isRecording ? <CircleStop size={13} /> : <Film size={13} />}
                      <span>{isRecording ? "Recording..." : "Make clip"}</span>
                    </button>
                  )}
                  <button type="button" onClick={() => mediaInputRef.current?.click()} className="button-shine flex items-center gap-2 rounded-lg border border-[#d5ff63]/35 bg-[#d5ff63]/[.09] px-3 py-2 text-[11px] font-bold text-[#d5ff63] transition hover:bg-[#d5ff63]/[.16]" data-testid="button-upload-source">
                    <Upload size={13} />
                    <span>Ingest source</span>
                  </button>
                </div>
                <input ref={mediaInputRef} type="file" accept="*/*" multiple onChange={handleMediaUpload} className="sr-only" aria-label="Upload a file" />
              </div>
              {assets.length > 0 ? (
                <div className="mt-4 space-y-3">
                  <div className="scrollbar-thin flex gap-2 overflow-x-auto pb-1">
                    {assets.map((asset) => (
                      <div key={asset.id} className={`group relative flex min-w-[132px] items-center gap-2 rounded-xl border px-2.5 py-2 text-left transition ${selectedAsset?.id === asset.id ? "border-[#79dce6]/55 bg-[#79dce6]/[.09]" : "border-[#8793c4]/15 bg-[#1c2244]/50 hover:border-[#8793c4]/35"}`}>
                        <button type="button" onClick={() => setSelectedAssetId(asset.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left" aria-label={`Select ${asset.name}`}>
                          {asset.kind === "book" ? <BookOpen size={14} className="shrink-0 text-[#d5ff63]" /> : asset.kind === "video" ? <Film size={14} className="shrink-0 text-[#79dce6]" /> : <ImageIcon size={14} className="shrink-0 text-[#ff917c]" />}
                          <span className="truncate text-[10px] text-[#c8cbe0]">{asset.name}</span>
                        </button>
                        <button type="button" onClick={() => removeAsset(asset.id)} className="rounded p-0.5 text-[#65709b] opacity-0 transition hover:text-[#ff917c] group-hover:opacity-100" aria-label={`Remove ${asset.name}`}><X size={12} /></button>
                      </div>
                    ))}
                  </div>
                  {selectedAsset && (
                    <div className="grid gap-3 xl:grid-cols-[120px_1fr]">
                      <div className="source-preview relative overflow-hidden rounded-xl border border-[#8793c4]/15 bg-[#0e1230]">
                         {selectedAsset.report.artifactClass === "audio" ? (
                           <audio src={selectedAsset.url} controls className="w-full p-2" />
                         ) : selectedAsset.kind === "video" ? (
                          <video src={selectedAsset.url} controls className="h-full min-h-[90px] w-full object-cover" />
                        ) : selectedAsset.kind === "image" ? (
                          <img src={selectedAsset.url} alt={selectedAsset.name} className="h-full min-h-[90px] w-full object-cover" />
                        ) : (
                          <div className="flex min-h-[90px] flex-col items-center justify-center gap-2 p-3 text-center">
                            <BookOpen size={25} className="text-[#d5ff63]" />
                            <span className="line-clamp-2 text-[10px] leading-relaxed text-[#a9b0ce]">{selectedAsset.name}</span>
                          </div>
                        )}
                        <span className="absolute bottom-2 left-2 rounded-full bg-[#0e1230]/85 px-2 py-1 mono-font text-[8px] uppercase tracking-[.12em] text-[#9da7cd]">{readableBytes(selectedAsset.size)}</span>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Sparkles size={13} className="text-[#ff917c]" />
                             <span className="mono-font text-[9px] uppercase tracking-[.16em] text-[#ff917c]">Local file analysis</span>
                          </div>
                          <span className="mono-font text-[9px] text-[#65709b]">5 dimensions</span>
                        </div>
                        <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                          {dimensions.map((dimension) => (
                            <label key={dimension.id} className="block">
                              <span className="mono-font text-[8px] uppercase tracking-[.14em] text-[#7d88b1]">{dimension.label} <span className="text-[#525d88]">· {dimension.hint}</span></span>
                              <input value={selectedAsset.analysis[dimension.id]} onChange={(event) => updateAssetAnswer(dimension.id, event.target.value)} className="mt-1 w-full rounded-lg border border-[#8793c4]/15 bg-[#1b2043]/70 px-2.5 py-2 text-[10px] text-[#d8d9e8] outline-none transition focus:border-[#79dce6]/60" aria-label={`${dimension.label} dimension`} />
                            </label>
                          ))}
                        </div>
                         <div className="mt-3 rounded-xl border border-[#8793c4]/15 bg-[#111633]/55 p-3">
                           <div className="flex items-center justify-between gap-2">
                             <span className="mono-font text-[9px] uppercase tracking-[.14em] text-[#79dce6]">Detected from file</span>
                             <span className="mono-font text-[9px] text-[#65709b]">{Math.round(selectedAsset.report.confidence * 100)}% confidence</span>
                           </div>
                           <div className="mt-2 grid grid-cols-1 gap-1.5 text-[10px] leading-relaxed text-[#a9b0ce] sm:grid-cols-2">
                             <div><span className="text-[#65709b]">Type:</span> {selectedAsset.report.artifactClass}</div>
                             <div><span className="text-[#65709b]">Words scanned:</span> {selectedAsset.report.tokens}</div>
                             {selectedAsset.report.structure.slice(0, 2).map((item) => <div key={item}><span className="text-[#65709b]">Structure:</span> {item}</div>)}
                             {selectedAsset.report.behavior.slice(0, 2).map((item) => <div key={item}><span className="text-[#65709b]">Behavior:</span> {item}</div>)}
                           </div>
                           <div className="mt-2 border-t border-[#8793c4]/10 pt-2 text-[10px] leading-relaxed text-[#a9b0ce]">
                             <span className="text-[#65709b]">Connections:</span> {selectedAsset.report.relationships.slice(0, 3).join(" · ")}
                           </div>
                         </div>
                      </div>
                    </div>
                  )}
                  <form onSubmit={routeEdit} className="flex gap-2 border-t border-[#8793c4]/10 pt-3">
                    <div className="relative flex min-w-0 flex-1 items-center">
                      <Scissors size={13} className="absolute left-3 text-[#79dce6]" />
                       <input value={editInstruction} onChange={(event) => setEditInstruction(event.target.value)} placeholder="Describe an edit..." className="w-full rounded-lg border border-[#8793c4]/20 bg-[#111633]/80 py-2.5 pl-9 pr-3 text-[11px] text-[#e8e7dc] outline-none placeholder:text-[#5f6a95] focus:border-[#79dce6]/60" aria-label="Describe an edit" />
                    </div>
                   <button type="submit" className="flex shrink-0 items-center gap-2 rounded-lg bg-[#79dce6] px-3 py-2 text-[10px] font-bold text-[#111633] transition hover:bg-[#a1edf2]" data-testid="button-route-edit"><Wand2 size={13} /><span className="hidden sm:inline">Apply edit</span></button>
                  </form>
                  {clipUrl && (
                    <a href={clipUrl} download="generative-morph-scene.webm" className="flex items-center justify-center gap-2 rounded-lg border border-[#ff917c]/30 bg-[#ff917c]/[.08] px-3 py-2 text-[10px] font-bold text-[#ffb0a0] transition hover:bg-[#ff917c]/[.14]" data-testid="link-download-clip">
                      <Download size={13} />
                      Download generated scene clip
                    </a>
                  )}
                </div>
              ) : (
                <button type="button" onClick={() => mediaInputRef.current?.click()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[#8793c4]/25 px-3 py-4 text-[11px] text-[#7f8ab3] transition hover:border-[#79dce6]/50 hover:text-[#79dce6]" data-testid="button-empty-source">
                  <Upload size={14} />
                   Add a file
                </button>
              )}
            </section>
          </section>

          <section className="order-1 flex min-h-[500px] min-w-0 flex-col lg:order-2 lg:min-h-[620px]" aria-label="Semantic mesh">
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="eyebrow">Live structure / <span className="text-[#d5ff63]">g{String(cycle).padStart(2, "0")}</span></div>
                <div className="mt-1 flex items-center gap-2">
                   <h2 className="display-font text-[27px] leading-tight text-[#f4f2e5]">Semantic mesh</h2>
                  <Activity size={17} className="text-[#79dce6]" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setPaused((value) => !value)} className="flex items-center gap-2 rounded-lg border border-[#8793c4]/25 px-3 py-2 text-[11px] text-[#b8bfdb] transition hover:border-[#d5ff63]/50 hover:text-[#d5ff63]" data-testid="button-toggle-growth">
                  {paused ? <CirclePlay size={14} /> : <CirclePause size={14} />}
                  <span>{paused ? "Resume updates" : "Pause updates"}</span>
                </button>
                <button type="button" onClick={resetMesh} className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#8793c4]/25 text-[#8e98bf] transition hover:border-[#ff917c]/60 hover:text-[#ff917c]" aria-label="Reset mesh" data-testid="button-reset-mesh">
                  <RefreshCcw size={14} />
                </button>
              </div>
            </div>
            <div className="mesh-panel mesh-grid relative min-h-0 flex-1 overflow-hidden rounded-[26px]">
              <div className="absolute left-5 top-5 z-[1] flex items-center gap-2 rounded-full border border-[#aab4df]/15 bg-[#111633]/65 px-3 py-1.5 backdrop-blur">
                <Waypoints size={12} className="text-[#d5ff63]" />
                   <span className="mono-font text-[9px] uppercase tracking-[.16em] text-[#aab4df]">connected items</span>
              </div>
              <div className="absolute right-5 top-5 z-[1] text-right">
                <div className="mono-font text-[10px] text-[#d5ff63]">{nodes.length} nodes</div>
                <div className="mono-font mt-1 text-[9px] text-[#65709b]">{relationCount} connections</div>
              </div>
              <div className="absolute inset-0 p-3 pt-10 sm:p-6 sm:pt-12">
                <Mesh nodes={nodes} selectedId={selectedId} onSelect={setSelectedId} />
              </div>
              <div className="absolute bottom-4 left-5 z-[1] flex flex-wrap gap-3 rounded-xl border border-[#aab4df]/15 bg-[#111633]/70 px-3 py-2 backdrop-blur sm:bottom-5 sm:left-6" data-testid="mesh-legend">
                {([["object", "objects"], ["relation", "relations"], ["feature", "features"]] as [NodeKind, string][]).map(([kind, label]) => (
                  <div key={kind} className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: kindColor(kind) }} />
                    <span className="mono-font text-[9px] uppercase tracking-[.1em] text-[#8993b9]">{label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-[#aab4df]/15 bg-[#1b2043]/60 p-3">
                <div className="eyebrow">Selected node</div>
                <div className="mt-2 flex items-center gap-2 truncate text-[13px] text-[#f1f0e2]"><span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: kindColor(selectedNode.kind) }} />{selectedNode.label}</div>
              </div>
              <div className="rounded-xl border border-[#aab4df]/15 bg-[#1b2043]/60 p-3">
                <div className="eyebrow">Objects</div>
                <div className="mono-font mt-2 text-[16px] text-[#d5ff63]" data-testid="text-object-count">{String(objectCount).padStart(2, "0")}</div>
              </div>
              <div className="rounded-xl border border-[#aab4df]/15 bg-[#1b2043]/60 p-3">
                <div className="eyebrow">Relations</div>
                <div className="mono-font mt-2 text-[16px] text-[#79dce6]" data-testid="text-relation-count">{String(relationCount).padStart(2, "0")}</div>
              </div>
              <div className="rounded-xl border border-[#aab4df]/15 bg-[#1b2043]/60 p-3">
                <div className="eyebrow">Features</div>
                <div className="mono-font mt-2 text-[16px] text-[#ff917c]" data-testid="text-feature-count">{String(featureCount).padStart(2, "0")}</div>
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between px-1">
              <div className="flex items-center gap-2 text-[11px] text-[#7f8ab3]">
                <GitBranch size={13} className="text-[#79dce6]" />
                 <span>Selected relations link in both directions.</span>
              </div>
              <div className="hidden items-center gap-1.5 text-[10px] text-[#65709b] sm:flex"><Zap size={12} /> deterministic / local</div>
            </div>
             <section className="mt-5 rounded-2xl border border-[#8793c4]/20 bg-[#151a38]/70 p-4" aria-label="Five dimensional morphing">
               <div className="flex items-start justify-between gap-3">
                 <div>
                   <div className="eyebrow">Morph two artifacts</div>
                   <h2 className="mt-1 text-[15px] font-medium text-[#f1f0e2]">Create an intermediate state.</h2>
                   <p className="mt-1 max-w-[420px] text-[11px] leading-relaxed text-[#7f8ab3]">Choose two uploaded files. The engine compares their structure, timing, appearance, behavior, and meaning before creating a plan.</p>
                 </div>
                 <GitBranch size={16} className="mt-1 shrink-0 text-[#79dce6]" />
               </div>
               {assets.length < 2 ? (
                 <div className="mt-4 rounded-xl border border-dashed border-[#8793c4]/25 px-3 py-4 text-center text-[11px] text-[#7f8ab3]">
                   Add one more file to compare artifacts.
                 </div>
               ) : (
                 <div className="mt-4 space-y-4">
                   <div className="grid gap-3 sm:grid-cols-2">
                     <label className="block">
                       <span className="eyebrow">From</span>
                       <select value={morphSource?.id ?? ""} onChange={(event) => setMorphSourceId(event.target.value)} className="mt-1 w-full rounded-lg border border-[#8793c4]/20 bg-[#111633] px-3 py-2 text-[11px] text-[#d8d9e8] outline-none focus:border-[#79dce6]/60">
                         {assets.map((asset) => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
                       </select>
                     </label>
                     <label className="block">
                       <span className="eyebrow">To</span>
                       <select value={morphTarget?.id ?? ""} onChange={(event) => setMorphTargetId(event.target.value)} className="mt-1 w-full rounded-lg border border-[#8793c4]/20 bg-[#111633] px-3 py-2 text-[11px] text-[#d8d9e8] outline-none focus:border-[#79dce6]/60">
                         {assets.map((asset) => <option key={asset.id} value={asset.id}>{asset.name}</option>)}
                       </select>
                     </label>
                   </div>
                   <div className="space-y-3">
                     {morphAxes.map((axis) => (
                       <label key={axis.id} className="block">
                         <div className="flex items-center justify-between gap-2 text-[10px]">
                           <span className="text-[#d8d9e8]">{axis.label} <span className="text-[#65709b]">· {axis.description}</span></span>
                           <span className="mono-font text-[#79dce6]">{Math.round(morphWeights[axis.id] * 100)}%</span>
                         </div>
                         <input type="range" min="0" max="100" value={Math.round(morphWeights[axis.id] * 100)} onChange={(event) => setMorphWeights((current) => ({ ...current, [axis.id]: Number(event.target.value) / 100 }))} className="mt-1 w-full accent-[#79dce6]" aria-label={`${axis.label} morph weight`} />
                       </label>
                     ))}
                   </div>
                   {morphPlan && morphSource && morphTarget && (
                     <div className="rounded-xl border border-[#79dce6]/20 bg-[#79dce6]/[.05] p-3">
                       <div className="flex items-center justify-between gap-2">
                         <span className="mono-font text-[9px] uppercase tracking-[.14em] text-[#79dce6]">Compatibility</span>
                         <span className={`mono-font text-[10px] ${morphPlan.compatible ? "text-[#d5ff63]" : "text-[#ff917c]"}`}>{Math.round(morphPlan.score * 100)}%</span>
                       </div>
                       <p className="mt-2 text-[11px] leading-relaxed text-[#c5c9df]">{morphPlan.result}</p>
                       <div className="mt-2 text-[10px] leading-relaxed text-[#8f99bf]">{morphPlan.intermediateState}</div>
                       <ol className="mt-3 space-y-1.5 text-[10px] leading-relaxed text-[#a9b0ce]">
                         {morphPlan.steps.map((step, index) => <li key={step}><span className="mono-font mr-2 text-[#79dce6]">{String(index + 1).padStart(2, "0")}</span>{step}</li>)}
                       </ol>
                       <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                         <span className="text-[10px] text-[#65709b]">{compatibleArtifacts(morphSource.report, morphTarget.report).slice(0, 2).join(" · ") || "No shared capabilities"}</span>
                         <button type="button" onClick={applyMorphPlan} className="flex items-center gap-2 rounded-lg bg-[#79dce6] px-3 py-2 text-[10px] font-bold text-[#111633] transition hover:bg-[#a1edf2]" data-testid="button-apply-morph">
                           <GitBranch size={13} /> Generate intermediate
                         </button>
                       </div>
                     </div>
                   )}
                 </div>
               )}
             </section>
          </section>
        </div>
        <footer className="flex shrink-0 items-center justify-between border-t hairline pt-3 text-[10px] text-[#626d99]">
           <span className="mono-font uppercase tracking-[.15em]">Local rules only</span>
           <span className="hidden sm:inline">Relations remain inspectable.</span>
          <span className="flex items-center gap-1.5"><Layers3 size={12} /> browser memory only</span>
        </footer>
      </div>
    </main>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <RoutedErrorBoundary><Router /></RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;