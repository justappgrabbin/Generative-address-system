export type ArtifactClass =
  | "game"
  | "app"
  | "code"
  | "document"
  | "image"
  | "video"
  | "audio"
  | "model"
  | "data"
  | "archive"
  | "unknown";

export type FiveD = "who" | "what" | "where" | "when" | "why";

export type FiveDReport = {
  id: string;
  name: string;
  artifactClass: ArtifactClass;
  mimeType: string;
  size: number;
  confidence: number;
  dimensions: Record<FiveD, string>;
  structure: string[];
  behavior: string[];
  relationships: string[];
  dependencies: string[];
  capabilities: string[];
  inputs: string[];
  outputs: string[];
  stateTransitions: string[];
  internalComponents: string[];
  externalRequirements: string[];
  constraints: string[];
  intendedPurpose: string;
  possibleTransformations: string[];
  compatibility: string[];
  tokens: number;
};

type IngestInput = {
  name: string;
  mimeType: string;
  size: number;
  text?: string;
};

const extensionClasses: Record<string, ArtifactClass> = {
  apk: "app", exe: "app", wasm: "app",
  ts: "code", tsx: "code", js: "code", jsx: "code", py: "code", rb: "code",
  go: "code", rs: "code", java: "code", c: "code", cpp: "code", h: "code",
  css: "code", html: "code", glsl: "code", sh: "code",
  md: "document", txt: "document", rtf: "document", pdf: "document", epub: "document",
  json: "data", csv: "data", xml: "data", yaml: "data", yml: "data", toml: "data",
  png: "image", jpg: "image", jpeg: "image", gif: "image", webp: "image", svg: "image",
  mp4: "video", webm: "video", mov: "video", avi: "video", mkv: "video",
  mp3: "audio", wav: "audio", ogg: "audio", m4a: "audio",
  glb: "model", gltf: "model", obj: "model", fbx: "model", blend: "model",
  zip: "archive", tar: "archive", gz: "archive", rar: "archive",
};

const dimensionLabels: Record<FiveD, string> = {
  who: "Who is involved",
  what: "What it is",
  where: "Where it exists",
  when: "When it acts",
  why: "Why it exists",
};

const transformations: Record<ArtifactClass, string[]> = {
  game: ["re-map space", "reorder states", "blend rules", "connect entities"],
  app: ["re-map components", "trace events", "reorder states", "connect data flow"],
  code: ["re-map modules", "reorder execution", "connect functions", "extract interfaces"],
  document: ["reorder sections", "extract structure", "connect concepts", "change purpose"],
  image: ["change space", "interpolate visual state", "segment objects", "connect to motion"],
  video: ["re-time sequence", "reorder scenes", "interpolate frames", "connect motion"],
  audio: ["re-time sequence", "reorder segments", "connect to visual states"],
  model: ["change space", "interpolate shape", "connect parts", "re-map materials"],
  data: ["reorder records", "map fields", "connect schemas", "interpolate values"],
  archive: ["inspect contents", "connect contained files", "extract structure"],
  unknown: ["inspect metadata", "connect to compatible artifacts"],
};

function extension(name: string) {
  return name.split(".").pop()?.toLowerCase() ?? "";
}

function words(text: string) {
  return text.toLowerCase().match(/[a-z][a-z0-9_-]{2,}/g) ?? [];
}

function unique(values: string[], limit = 6) {
  return Array.from(new Set(values.filter(Boolean))).slice(0, limit);
}

function detectClass(name: string, mimeType: string, text: string): ArtifactClass {
  const ext = extension(name);
  const byExtension = extensionClasses[ext];
  if (byExtension) {
    if (/(game|unity|godot|level|scene|sprite|shader|physics)/i.test(`${name} ${text}`)) return "game";
    if (byExtension === "code" && /(react|vite|next|express|component|interface|app)/i.test(`${name} ${text}`)) return "app";
    return byExtension;
  }
  if (mimeType.startsWith("image/")) return "image";
  if (mimeType.startsWith("video/")) return "video";
  if (mimeType.startsWith("audio/")) return "audio";
  if (mimeType.startsWith("text/")) return "document";
  return "unknown";
}

function typeName(artifactClass: ArtifactClass) {
  return artifactClass === "unknown" ? "unknown file" : artifactClass;
}

function reportFor(input: IngestInput, id: string): FiveDReport {
  const text = input.text ?? "";
  const ext = extension(input.name);
  const tokens = words(text);
  const artifactClass = detectClass(input.name, input.mimeType, text);
  const imports = unique(Array.from(text.matchAll(/(?:import|require)\s*(?:\([^)]*?['"]|[^'"]*from\s*['"])([^'"]+)/g)).map((match) => match[1]));
  const exports = unique(Array.from(text.matchAll(/export\s+(?:default\s+)?(?:class|function|const|let|var|interface|type)\s+([A-Za-z0-9_]+)/g)).map((match) => match[1]));
  const functions = unique(Array.from(text.matchAll(/(?:function|async\s+function)\s+([A-Za-z0-9_]+)/g)).map((match) => match[1]));
  const states = unique(Array.from(text.matchAll(/(?:useState|status|state|phase|mode|lifecycle)\W{0,12}([A-Za-z0-9_-]+)/gi)).map((match) => match[1]));
  const domains = unique([
    /canvas|webgl|render|pixel|sprite|shader/i.test(text) ? "graphics" : "",
    /audio|sound|music|waveform/i.test(text) ? "audio" : "",
    /physics|collision|gravity|velocity/i.test(text) ? "physics" : "",
    /button|input|component|modal|css|tailwind|react/i.test(text) ? "interface" : "",
    /fetch|websocket|http|api|server|express/i.test(text) ? "network" : "",
  ]);
  const structure = artifactClass === "code"
    ? [
        `${tokens.length} words scanned`,
        exports.length ? `${exports.length} exported symbol${exports.length === 1 ? "" : "s"}` : "No exports detected",
        functions.length ? `${functions.length} function${functions.length === 1 ? "" : "s"} detected` : "No functions detected",
      ]
    : artifactClass === "document"
      ? [`${tokens.length} words available`, `.${ext || "file"} document`, "Text structure available when readable"]
      : [`${typeName(artifactClass)} metadata`, input.mimeType || "MIME type unavailable", `${Math.max(1, Math.round(input.size / 1024))} KB`];
  const behavior = artifactClass === "code" || artifactClass === "app" || artifactClass === "game"
    ? [
        states.length ? `State signals: ${states.slice(0, 3).join(", ")}` : "No explicit state signals detected",
        domains.length ? `Functional areas: ${domains.join(", ")}` : "No functional area detected",
        /if\s*\(|switch\s*\(|while\s*\(|for\s*\(/.test(text) ? "Conditional or repeated execution detected" : "No control-flow markers detected",
      ]
    : artifactClass === "video"
      ? ["Frame sequence available to the browser", "Timing and motion require frame analysis", "Playback is available locally"]
      : artifactClass === "image"
        ? ["Single visual state available", "Pixels can be previewed locally", "Object detection is not assumed"]
        : ["Behavior not inferred from metadata alone"];
  const relationships = unique([
    ...imports.map((item) => `imports ${item}`),
    ...domains.map((domain) => `uses ${domain}`),
    artifactClass === "game" ? "contains scenes, entities, or rules" : "",
    artifactClass === "app" ? "contains interface or runtime components" : "",
  ]);
  const dependencies = imports.length ? imports : artifactClass === "code" ? ["No import dependency found"] : ["No dependency data available"];
  const capabilities = unique([
    artifactClass === "code" ? "inspect source" : "",
    artifactClass === "document" ? "read text when supported" : "",
    artifactClass === "image" ? "preview and connect" : "",
    artifactClass === "video" ? "preview and record a scene" : "",
    artifactClass === "game" ? "inspect gameplay structure" : "",
    artifactClass === "app" ? "inspect interface and state signals" : "",
    "connect to other artifacts",
  ]);
  const purpose = domains.length ? `Likely related to ${domains.join(", ")}.` : `Purpose inferred from its ${typeName(artifactClass)} classification.`;
  const inputs = artifactClass === "code" || artifactClass === "app" || artifactClass === "game"
    ? unique([
        /event|onClick|onChange|listener|input|command/i.test(text) ? "events or user input" : "",
        /fetch|request|api|socket|file/i.test(text) ? "file or network data" : "",
      ])
    : artifactClass === "video" || artifactClass === "audio" ? ["frames or samples"] : ["file bytes and metadata"];
  const outputs = artifactClass === "code" || artifactClass === "app" || artifactClass === "game"
    ? unique([
        /return|export|render|response|output/i.test(text) ? "returned or rendered values" : "",
        /download|write|save|emit/i.test(text) ? "saved or emitted data" : "",
      ])
    : artifactClass === "image" || artifactClass === "video" || artifactClass === "audio" ? ["visual or audio states"] : ["an analyzed report"];
  const stateTransitions = unique([
    ...states.map((state) => `state: ${state}`),
    /if\s*\(|switch\s*\(/.test(text) ? "conditional transitions" : "",
    /onClick|onChange|addEventListener|emit/.test(text) ? "event-triggered transitions" : "",
  ]);
  const internalComponents = unique([
    ...exports.map((item) => `export ${item}`),
    ...functions.map((item) => `function ${item}`),
    ...domains.map((domain) => `${domain} area`),
  ]);
  const externalRequirements = imports.length ? imports : artifactClass === "code" ? ["No external imports detected"] : [input.mimeType || "browser file access"];
  const constraints = unique([
    artifactClass === "unknown" ? "Type is not confirmed" : "",
    !text && ["code", "document", "data"].includes(artifactClass) ? "Text content was not readable" : "",
    ["image", "video", "audio", "model"].includes(artifactClass) ? "Deep pixel, frame, sample, or geometry analysis is not enabled" : "",
    "Changes remain in browser memory",
  ]);
  const compatibility = unique([
    "Can connect to other analyzed artifacts",
    artifactClass === "video" ? "Best with images, audio, and other videos" : "",
    artifactClass === "code" || artifactClass === "app" || artifactClass === "game" ? "Best with related code, data, or interface files" : "",
    artifactClass === "document" ? "Best with text, code, and structured data" : "",
  ]);

  return {
    id,
    name: input.name,
    artifactClass,
    mimeType: input.mimeType || "unknown",
    size: input.size,
    confidence: artifactClass === "unknown" ? 0.35 : text ? 0.9 : 0.7,
    dimensions: {
      who: artifactClass === "code" || artifactClass === "app" || artifactClass === "game" ? "Developers, users, and connected components." : "Creator, source, or subject.",
      what: `A ${typeName(artifactClass)}${ext ? ` (.${ext})` : ""}.`,
      where: `In the local browser as ${input.name}.`,
      when: states.length ? `State changes may involve ${states.slice(0, 3).join(", ")}.` : artifactClass === "video" ? "Ordered by frames and playback time." : "Timing was not available from this file.",
      why: purpose,
    },
    structure,
    behavior,
    relationships: relationships.length ? relationships : ["No relationships detected yet"],
    dependencies,
    capabilities,
    inputs: inputs.length ? inputs : ["No inputs detected"],
    outputs: outputs.length ? outputs : ["No outputs detected"],
    stateTransitions: stateTransitions.length ? stateTransitions : ["No state transitions detected"],
    internalComponents: internalComponents.length ? internalComponents : ["No internal components detected"],
    externalRequirements,
    constraints,
    intendedPurpose: purpose,
    possibleTransformations: transformations[artifactClass],
    compatibility,
    tokens: tokens.length,
  };
}

export class KleinArtifactEngine {
  private reports = new Map<string, FiveDReport>();
  private counter = 0;

  ingest(input: IngestInput) {
    this.counter += 1;
    const id = `artifact-${this.counter}-${input.name}`;
    const report = reportFor(input, id);
    this.reports.set(id, report);
    return report;
  }

  getReport(id: string) {
    return this.reports.get(id);
  }

  getReports() {
    return Array.from(this.reports.values());
  }
}

export { dimensionLabels };