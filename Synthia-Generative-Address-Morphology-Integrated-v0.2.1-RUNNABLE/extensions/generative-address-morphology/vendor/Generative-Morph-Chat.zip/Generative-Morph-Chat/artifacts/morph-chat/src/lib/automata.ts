export type Dimension = "who" | "what" | "where" | "when" | "why";
export type ChatPhase = "IDLE" | "RECEIVE" | "PARSE" | "ACTIVATE_MESH" | "RESOLVE_MEANING" | "FORM_RESPONSE_INTENT" | "REALIZE_LANGUAGE" | "EMIT" | "LEARN";

export const dimensionMap: Record<Dimension, { name: string; base: number; sense: string }> = {
  where: { name: "Movement", base: 1, sense: "seeing" },
  what: { name: "Evolution", base: 2, sense: "taste" },
  when: { name: "Being", base: 3, sense: "touch" },
  why: { name: "Design", base: 4, sense: "smell" },
  who: { name: "Space", base: 5, sense: "hearing" },
};

export const englishDataset = [
  "A person moves through a place and remembers what happened there.",
  "An object changes when pressure creates a new relation.",
  "A scene has a beginning, a middle, and a reason to continue.",
  "A voice gives shape to an idea, and a shape can carry meaning.",
  "The witness observes the world, then the world changes the witness.",
  "Every edit is a choice about time, attention, and purpose.",
];

const stopWords = new Set([
  "about", "after", "again", "also", "been", "being", "from", "have", "into",
  "more", "that", "their", "there", "these", "they", "this", "with", "your",
]);

export function tokenize(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).filter((word) => word.length > 2 && !stopWords.has(word));
}

function buildCooccurrence(text: string, windowSize = 2) {
  const tokens = tokenize(text);
  const vectors = new Map<string, Map<string, number>>();
  tokens.forEach((token, index) => {
    if (!vectors.has(token)) vectors.set(token, new Map());
    const vector = vectors.get(token)!;
    for (let cursor = Math.max(0, index - windowSize); cursor <= Math.min(tokens.length - 1, index + windowSize); cursor += 1) {
      if (cursor === index) continue;
      const context = tokens[cursor];
      vector.set(context, (vector.get(context) ?? 0) + 1);
    }
  });
  return { tokens, vectors };
}

function cosine(a: Map<string, number>, b: Map<string, number>) {
  const keys = new Set([...a.keys(), ...b.keys()]);
  let dot = 0;
  let magnitudeA = 0;
  let magnitudeB = 0;
  keys.forEach((key) => {
    const valueA = a.get(key) ?? 0;
    const valueB = b.get(key) ?? 0;
    dot += valueA * valueB;
    magnitudeA += valueA * valueA;
    magnitudeB += valueB * valueB;
  });
  return magnitudeA && magnitudeB ? dot / (Math.sqrt(magnitudeA) * Math.sqrt(magnitudeB)) : 0;
}

export function diseminer(text: string, seed?: string, topN = 4) {
  const { tokens, vectors } = buildCooccurrence(`${englishDataset.join(" ")} ${text}`);
  const target = (seed && vectors.get(seed.toLowerCase())) ?? vectors.get(tokens[0]);
  if (!target) return { tokenCount: 0, vocabulary: 0, seed: "", neighbors: [] as { word: string; similarity: number }[] };
  const targetWord = seed && vectors.has(seed.toLowerCase()) ? seed.toLowerCase() : tokens[0];
  const neighbors = Array.from(vectors.entries())
    .filter(([word]) => word !== targetWord)
    .map(([word, vector]) => ({ word, similarity: cosine(target, vector) }))
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, topN);
  return { tokenCount: tokens.length, vocabulary: vectors.size, seed: targetWord, neighbors };
}

const routeWords: Record<Dimension, string[]> = {
  who: ["who", "person", "people", "character", "author", "speaker", "maker", "voice"],
  what: ["what", "thing", "object", "action", "make", "edit", "cut", "rewrite", "source"],
  where: ["where", "place", "location", "scene", "room", "world", "field"],
  when: ["when", "time", "before", "after", "sequence", "moment", "pace", "first"],
  why: ["why", "because", "motive", "meaning", "purpose", "tension", "pressure"],
};

export function routeQuestion(text: string): Dimension {
  const lower = text.toLowerCase();
  const scored = (Object.entries(routeWords) as [Dimension, string[]][])
    .map(([dimension, words]) => [dimension, words.reduce((score, word) => score + (lower.includes(word) ? 1 : 0), 0)] as const)
    .sort((a, b) => b[1] - a[1]);
  return scored[0]?.[1] ? scored[0][0] : "what";
}

export function semanticRead(text: string) {
  const words = tokenize(text);
  const seed = words[0] ?? "signal";
  return {
    seed,
    route: routeQuestion(text),
    tokens: words.slice(0, 8),
    neighbors: diseminer(text, seed).neighbors,
  };
}

export type ResponseIntent = {
  status: "held" | "grew" | "updated";
  focus: string;
  dimension: Dimension;
  dimensionName: string;
  nodeCount: number;
};

export function buildResponseIntent(text: string, nodeCount: number, paused: boolean): ResponseIntent {
  const semantic = semanticRead(text);
  return {
    status: paused ? "held" : nodeCount > 0 ? "grew" : "updated",
    focus: semantic.seed,
    dimension: semantic.route,
    dimensionName: dimensionMap[semantic.route].name,
    nodeCount,
  };
}

export function realizeResponse(intent: ResponseIntent) {
  if (intent.status === "held") {
    return "Paused. I’ll process this when you resume.";
  }
  if (intent.status === "grew") {
    return `${intent.nodeCount} ${intent.nodeCount === 1 ? "item" : "items"} added. Category: ${intent.dimensionName}.`;
  }
  return `"${intent.focus}" is already connected. I updated the existing item.`;
}

export function chatPhases(): ChatPhase[] {
  return ["IDLE", "RECEIVE", "PARSE", "ACTIVATE_MESH", "RESOLVE_MEANING", "FORM_RESPONSE_INTENT", "REALIZE_LANGUAGE", "EMIT", "LEARN", "IDLE"];
}