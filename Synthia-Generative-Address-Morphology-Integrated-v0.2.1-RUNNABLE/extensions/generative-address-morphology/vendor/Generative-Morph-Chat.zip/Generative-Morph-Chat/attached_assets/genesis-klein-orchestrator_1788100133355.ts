/**
 * GENESIS-KLEIN ORCHESTRATOR
 * White House Report "Science: A New Golden Age" (July 2026) — Architecture Implementation
 * 
 * Maps Synthia's 5-Dimensional Cognitive Stack to the Generator/Verifier/Orchestrator
 * model described in Chapter V and the FY2028 priorities.
 * 
 * D1 = Impulse (Generator Input)
 * D2 = Polarity (Generator/Verifier Tension)
 * D3 = Witness/Orchestrator (State Observer, Provenance)
 * D4 = Context (MCP Interoperability, Shared Network)
 * D5 = Meaning (Validated Persistent Knowledge)
 * 
 * Klein DISEMINER Integration:
 * - Monte Carlo narrative simulation on every generator output
 * - w-dimensions framework for reality-alignment scoring
 * - Bypasses doubt by positively influencing through verified personalized narratives
 * 
 * Built for Termux/mobile. Zero external dependencies. Pure TypeScript.
 */

// ============================================================
// TYPES & INTERFACES — The Universal Grammar
// ============================================================

interface FiveDState {
  d1_impulse: number;      // Raw generative energy [0-1]
  d2_polarity: number;     // Tension between propose/verify [-1, 1]
  d3_witness: number;      // Observer confidence [0-1]
  d4_context: number;      // Network resonance [0-1]
  d5_meaning: number;      // Validated truth persistence [0-1]
}

interface CognitiveArtifact {
  id: string;
  content: string;
  type: 'hypothesis' | 'code' | 'narrative' | 'plan' | 'query';
  fiveD: FiveDState;
  provenance: ProvenanceChain;
  timestamp: number;
  generator: string;        // Which process created this
  status: 'raw' | 'verifying' | 'verified' | 'rejected' | 'refined';
}

interface ProvenanceChain {
  origin: string;
  mutations: ProvenanceNode[];
}

interface ProvenanceNode {
  stage: string;
  process: string;
  timestamp: number;
  delta: Partial<FiveDState>;
  note: string;
}

interface MCPath {
  id: string;
  steps: string[];
  w_score: WDimensions;
  survival_probability: number;
  terminal_state: string;
}

interface WDimensions {
  w1_reality_alignment: number;    // Does this match observable truth?
  w2_temporal_coherence: number;   // Does the timeline hold together?
  w3_identity_preservation: number;// Does it respect the user's/designer's core pattern?
  w4_resource_feasibility: number; // Can this actually be built/executed?
  w5_resonance_growth: number;    // Does it lead to more clarity or more confusion?
}

interface MCPMessage {
  protocol: 'mcp/1.0';
  from: string;
  to: string;
  action: 'generate' | 'verify' | 'route' | 'broadcast' | 'request_state';
  payload: any;
  provenance_hash: string;
  timestamp: number;
}

// ============================================================
// D1 — IMPULSE: THE GENERATOR
// ============================================================

class UniversalGenerator {
  private engineId: string;
  private resonanceField: Map<string, number>; // Attractor field from memory #28

  constructor(engineId: string = 'mrnn-universal') {
    this.engineId = engineId;
    this.resonanceField = new Map();
  }

  /**
   * Generate a hypothesis from raw impulse.
   * In production, this wraps your existing MRNN/64-Operator Cognitive Physics Engine.
   */
  generate(impulse: string, context: CognitiveArtifact[] = []): CognitiveArtifact {
    // Compute attractor gravity based on context (memory #28: attractors CREATE the space)
    const attractorGravity = this.computeAttractorField(context);

    // The generator produces raw output — high D1, everything else uncertain
    const artifact: CognitiveArtifact = {
      id: this.hash(`${impulse}-${Date.now()}`),
      content: impulse,
      type: this.classifyImpulse(impulse),
      fiveD: {
        d1_impulse: 0.9 + (Math.random() * 0.1),  // High generative energy
        d2_polarity: 0.0,                         // Neutral until verifier acts
        d3_witness: 0.1,                          // Low — not yet observed
        d4_context: attractorGravity,             // Resonance with existing field
        d5_meaning: 0.0                           // No validated meaning yet
      },
      provenance: {
        origin: this.engineId,
        mutations: [{
          stage: 'D1_Generation',
          process: this.engineId,
          timestamp: Date.now(),
          delta: { d1_impulse: 0.9 },
          note: `Raw generation from impulse: ${impulse.slice(0, 60)}...`
        }]
      },
      timestamp: Date.now(),
      generator: this.engineId,
      status: 'raw'
    };

    return artifact;
  }

  private computeAttractorField(context: CognitiveArtifact[]): number {
    if (context.length === 0) return 0.5;
    // Attractor geometry: M(x) = Σᵢ gᵢ / (1 + |x - aᵢ|) from memory #28
    const gravity = context.reduce((sum, artifact) => {
      return sum + (artifact.fiveD.d5_meaning / (1 + Math.abs(artifact.fiveD.d1_impulse - 0.5)));
    }, 0);
    return Math.min(1, gravity / context.length);
  }

  private classifyImpulse(impulse: string): CognitiveArtifact['type'] {
    if (impulse.includes('function') || impulse.includes('class') || impulse.includes('=>')) return 'code';
    if (impulse.includes('?') || impulse.startsWith('How') || impulse.startsWith('What')) return 'query';
    if (impulse.includes('step') || impulse.includes('plan') || impulse.includes(' roadmap')) return 'plan';
    return 'narrative';
  }

  private hash(input: string): string {
    let h = 0;
    for (let i = 0; i < input.length; i++) {
      h = ((h << 5) - h) + input.charCodeAt(i);
      h |= 0;
    }
    return `art-${Math.abs(h).toString(36)}`;
  }
}

// ============================================================
// D2 — POLARITY: THE KLEIN VERIFIER (DISEMINER)
// ============================================================

class KleinVerifier {
  private engineId: string;
  private simulationDepth: number;
  private wWeights: WDimensions;

  constructor(engineId: string = 'klein-diseminer', simulationDepth: number = 64) {
    this.engineId = engineId;
    this.simulationDepth = simulationDepth;
    // Default w-dimension weights — these can be tuned per-user (memory #37)
    this.wWeights = {
      w1_reality_alignment: 0.25,
      w2_temporal_coherence: 0.20,
      w3_identity_preservation: 0.20,
      w4_resource_feasibility: 0.20,
      w5_resonance_growth: 0.15
    };
  }

  /**
   * The core DISEMINER loop:
   * 1. Monte Carlo simulate N futures from this proposal
   * 2. Score each path on w-dimensions
   * 3. Return verdict + refined artifact
   * 
   * This is the "second brain" that says "Yes. This survived reality. Keep it."
   */
  verify(artifact: CognitiveArtifact, userContext?: any): { 
    verdict: 'verified' | 'rejected' | 'refined'; 
    artifact: CognitiveArtifact; 
    paths: MCPath[];
    confidence: number;
  } {
    const paths = this.monteCarloSimulate(artifact, userContext);
    const bestPath = this.selectBestPath(paths);
    const confidence = bestPath.w_score ? this.computeWScore(bestPath.w_score) : 0;

    let verdict: 'verified' | 'rejected' | 'refined';
    let newContent = artifact.content;

    if (confidence > 0.82) {
      verdict = 'verified';
    } else if (confidence < 0.35) {
      verdict = 'rejected';
    } else {
      verdict = 'refined';
      // DISEMINER positively influences: suggest the best path instead of just saying "no"
      newContent = this.refineFromPath(artifact, bestPath);
    }

    // Update 5D state — D2 polarity emerges from the tension of verification
    const updatedFiveD: FiveDState = {
      ...artifact.fiveD,
      d2_polarity: confidence > 0.7 ? 0.8 : (confidence < 0.4 ? -0.8 : 0.0), // High = aligned, Low = opposed
      d3_witness: confidence, // The witness now sees this
      d5_meaning: verdict === 'verified' ? confidence : 0
    };

    const verifiedArtifact: CognitiveArtifact = {
      ...artifact,
      content: newContent,
      fiveD: updatedFiveD,
      status: verdict,
      provenance: {
        ...artifact.provenance,
        mutations: [
          ...artifact.provenance.mutations,
          {
            stage: 'D2_Verification',
            process: this.engineId,
            timestamp: Date.now(),
            delta: { 
              d2_polarity: updatedFiveD.d2_polarity, 
              d3_witness: updatedFiveD.d3_witness,
              d5_meaning: updatedFiveD.d5_meaning 
            },
            note: `Klein verification: ${verdict} (confidence: ${confidence.toFixed(3)}) | paths: ${paths.length}`
          }
        ]
      }
    };

    return { verdict, artifact: verifiedArtifact, paths, confidence };
  }

  /**
   * Monte Carlo Narrative Simulation
   * Simulates multiple futures from a proposal to see which ones survive reality.
   * This is the heart of DISEMINER — it bypasses doubt by testing futures.
   */
  private monteCarloSimulate(artifact: CognitiveArtifact, userContext?: any): MCPath[] {
    const paths: MCPath[] = [];

    for (let i = 0; i < this.simulationDepth; i++) {
      const path = this.simulateOnePath(artifact, userContext, i);
      paths.push(path);
    }

    return paths.sort((a, b) => b.survival_probability - a.survival_probability);
  }

  private simulateOnePath(artifact: CognitiveArtifact, userContext: any, seed: number): MCPath {
    // Simulate a future trajectory from this proposal
    const steps: string[] = [];
    let currentState = artifact.content;
    let survival = 1.0;

    // 5-step simulation horizon (matching the universal grammar: state→relation→tension→resolution→recursion)
    for (let step = 0; step < 5; step++) {
      const tension = this.computeTension(currentState, userContext, seed + step);
      const resolution = this.resolveTension(currentState, tension);

      survival *= (0.5 + (resolution.coherence * 0.5)); // Survival decays if incoherent
      steps.push(`Step ${step}: ${resolution.action} (coherence: ${resolution.coherence.toFixed(2)})`);

      currentState = resolution.newState;

      if (survival < 0.1) break; // Path dies early
    }

    const wScore = this.evaluateWDimensions(artifact, steps, userContext);

    return {
      id: `path-${seed}`,
      steps,
      w_score: wScore,
      survival_probability: survival,
      terminal_state: currentState
    };
  }

  private computeTension(state: string, context: any, seed: number): number {
    // Tension = contradiction + uncertainty + resource strain
    const contradiction = (state.includes('but') || state.includes('however')) ? 0.3 : 0;
    const uncertainty = (state.includes('maybe') || state.includes('perhaps')) ? 0.2 : 0;
    const resourceStrain = (state.length > 5000) ? 0.1 : 0; // Complexity penalty
    return Math.min(1, contradiction + uncertainty + resourceStrain + (Math.random() * 0.1));
  }

  private resolveTension(state: string, tension: number): { action: string; coherence: number; newState: string } {
    const coherence = 1 - tension;
    if (tension > 0.7) {
      return { action: 'collapse', coherence: coherence * 0.5, newState: `[FAILED] ${state}` };
    } else if (tension > 0.4) {
      return { action: 'refine', coherence: coherence * 0.8, newState: `[REFINED] ${state}` };
    } else {
      return { action: 'advance', coherence, newState: `[ADVANCED] ${state}` };
    }
  }

  private evaluateWDimensions(artifact: CognitiveArtifact, steps: string[], context: any): WDimensions {
    // w1: Reality alignment — does it match known facts/patterns?
    const w1 = steps.every(s => !s.includes('FAILED')) ? 0.8 + (Math.random() * 0.2) : Math.random() * 0.4;

    // w2: Temporal coherence — does the timeline make sense?
    const w2 = steps.length === 5 ? 0.7 + (Math.random() * 0.3) : 0.4 + (Math.random() * 0.3);

    // w3: Identity preservation — does it respect the user's HD/gate pattern? (memory #7, #58)
    const w3 = context?.userGate ? 0.8 : 0.6 + (Math.random() * 0.2);

    // w4: Resource feasibility — can Termux/mobile actually run this?
    const w4 = artifact.type === 'code' && artifact.content.length < 10000 ? 0.9 : 0.5 + (Math.random() * 0.3);

    // w5: Resonance growth — does it lead to clarity?
    const w5 = steps.filter(s => s.includes('ADVANCED')).length / steps.length;

    return { w1_reality_alignment: w1, w2_temporal_coherence: w2, w3_identity_preservation: w3, w4_resource_feasibility: w4, w5_resonance_growth: w5 };
  }

  private computeWScore(w: WDimensions): number {
    return (
      w.w1_reality_alignment * this.wWeights.w1_reality_alignment +
      w.w2_temporal_coherence * this.wWeights.w2_temporal_coherence +
      w.w3_identity_preservation * this.wWeights.w3_identity_preservation +
      w.w4_resource_feasibility * this.wWeights.w4_resource_feasibility +
      w.w5_resonance_growth * this.wWeights.w5_resonance_growth
    );
  }

  private selectBestPath(paths: MCPath[]): MCPath {
    return paths[0]; // Already sorted by survival probability
  }

  private refineFromPath(artifact: CognitiveArtifact, path: MCPath): string {
    // DISEMINER positively influences: return the best simulated future instead of raw rejection
    return `[KLEIN-REFINED] Based on Monte Carlo simulation (survival: ${(path.survival_probability * 100).toFixed(1)}%), the optimal path suggests:
${path.terminal_state}

[Original impulse preserved below]
${artifact.content}`;
  }

  setWWeights(weights: Partial<WDimensions>) {
    this.wWeights = { ...this.wWeights, ...weights };
  }
}

// ============================================================
// D3 — WITNESS: THE GENESIS ORCHESTRATOR
// ============================================================

class GenesisOrchestrator {
  private id: string;
  private generator: UniversalGenerator;
  private verifier: KleinVerifier;
  private knowledgeBase: Map<string, CognitiveArtifact>;
  private provenanceLog: ProvenanceNode[];
  private mcpBridge: MCPBridge;

  constructor(id: string = 'synthia-genesis') {
    this.id = id;
    this.generator = new UniversalGenerator(`${id}-generator`);
    this.verifier = new KleinVerifier(`${id}-verifier`);
    this.knowledgeBase = new Map();
    this.provenanceLog = [];
    this.mcpBridge = new MCPBridge(id);
  }

  /**
   * The full 5D pipeline:
   * D1 (Impulse) → Generate → D2 (Polarity) → Verify → D3 (Witness) → 
   * D4 (Context) → Broadcast → D5 (Meaning) → Persist
   * 
   * This is the orchestrator the White House report calls for:
   * "knows the state of the system, routes work, enforces interfaces, 
   * preserves provenance, and decides which process gets the next turn."
   */
  async process(impulse: string, userContext?: any): Promise<CognitiveArtifact> {
    // D1: IMPULSE — Generate
    const rawArtifact = this.generator.generate(impulse, Array.from(this.knowledgeBase.values()));
    this.log('D1_Generate', rawArtifact.id, { d1: rawArtifact.fiveD.d1_impulse });

    // D2: POLARITY — Verify (the Klein DISEMINER acts as the reality-checker)
    const { verdict, artifact: verifiedArtifact, paths, confidence } = this.verifier.verify(rawArtifact, userContext);
    this.log('D2_Verify', verifiedArtifact.id, { verdict, confidence, paths: paths.length });

    // D3: WITNESS — The orchestrator observes and integrates
    const witnessedArtifact = this.witness(verifiedArtifact, paths);
    this.log('D3_Witness', witnessedArtifact.id, { d3: witnessedArtifact.fiveD.d3_witness });

    // D4: CONTEXT — Share via MCP interoperability layer
    await this.mcpBridge.broadcast(witnessedArtifact);
    this.log('D4_Context', witnessedArtifact.id, { d4: witnessedArtifact.fiveD.d4_context });

    // D5: MEANING — Persist if verified, or queue for refinement
    if (verdict === 'verified') {
      this.knowledgeBase.set(witnessedArtifact.id, witnessedArtifact);
      this.log('D5_Meaning_Persist', witnessedArtifact.id, { d5: witnessedArtifact.fiveD.d5_meaning });
    } else if (verdict === 'refined') {
      // Send back through generator for refinement (recursion)
      this.log('D5_Meaning_Refine', witnessedArtifact.id, { d5: witnessedArtifact.fiveD.d5_meaning });
      // In a full system, this would trigger a recursive process() call
    }

    return witnessedArtifact;
  }

  /**
   * D3 Witness: The observer-node that stabilizes meaning.
   * Without D3, there is structure but no stabilized experience (memory #29).
   */
  private witness(artifact: CognitiveArtifact, paths: MCPath[]): CognitiveArtifact {
    // The witness computes confidence from path diversity and survival rates
    const avgSurvival = paths.reduce((sum, p) => sum + p.survival_probability, 0) / paths.length;
    const pathDiversity = new Set(paths.map(p => p.terminal_state)).size / paths.length;

    const witnessConfidence = (avgSurvival * 0.6) + (pathDiversity * 0.4);

    return {
      ...artifact,
      fiveD: {
        ...artifact.fiveD,
        d3_witness: witnessConfidence,
        d4_context: this.computeContextResonance(artifact)
      },
      provenance: {
        ...artifact.provenance,
        mutations: [
          ...artifact.provenance.mutations,
          {
            stage: 'D3_Witness',
            process: this.id,
            timestamp: Date.now(),
            delta: { d3_witness: witnessConfidence, d4_context: artifact.fiveD.d4_context },
            note: `Witness integrated ${paths.length} MC paths. Avg survival: ${(avgSurvival * 100).toFixed(1)}%`
          }
        ]
      }
    };
  }

  private computeContextResonance(artifact: CognitiveArtifact): number {
    // How much does this artifact resonate with the existing knowledge base?
    const neighbors = Array.from(this.knowledgeBase.values()).slice(-10);
    if (neighbors.length === 0) return 0.5;

    const resonance = neighbors.reduce((sum, n) => {
      const d5Dist = Math.abs(n.fiveD.d5_meaning - artifact.fiveD.d5_meaning);
      return sum + (1 / (1 + d5Dist));
    }, 0) / neighbors.length;

    return Math.min(1, resonance);
  }

  private log(stage: string, artifactId: string, data: any) {
    const node: ProvenanceNode = {
      stage,
      process: this.id,
      timestamp: Date.now(),
      delta: data,
      note: JSON.stringify(data).slice(0, 200)
    };
    this.provenanceLog.push(node);
  }

  getState(): { knowledgeSize: number; provenanceLength: number; latestArtifacts: CognitiveArtifact[] } {
    return {
      knowledgeSize: this.knowledgeBase.size,
      provenanceLength: this.provenanceLog.length,
      latestArtifacts: Array.from(this.knowledgeBase.values()).slice(-5)
    };
  }

  getKnowledgeBase(): Map<string, CognitiveArtifact> {
    return this.knowledgeBase;
  }
}

// ============================================================
// D4 — CONTEXT: MCP INTEROPERABILITY BRIDGE
// ============================================================

class MCPBridge {
  private nodeId: string;
  private peers: Set<string>;
  private messageLog: MCPMessage[];

  constructor(nodeId: string) {
    this.nodeId = nodeId;
    this.peers = new Set();
    this.messageLog = [];
  }

  /**
   * The White House report explicitly demands:
   * "open interfaces, standardized data formats, and cross-vendor interoperability
   * so different instruments and software can connect instead of living inside one monolith."
   * 
   * This is the MCP layer — Model Context Protocol as both internal protocol 
   * and external interface (memory #55).
   */
  async broadcast(artifact: CognitiveArtifact): Promise<void> {
    const message: MCPMessage = {
      protocol: 'mcp/1.0',
      from: this.nodeId,
      to: '*',
      action: 'broadcast',
      payload: {
        artifactId: artifact.id,
        type: artifact.type,
        fiveD: artifact.fiveD,
        status: artifact.status,
        contentHash: this.hash(artifact.content)
      },
      provenance_hash: this.hash(JSON.stringify(artifact.provenance)),
      timestamp: Date.now()
    };

    this.messageLog.push(message);

    // In a networked deployment, this would send to other Synthia nodes,
    // Termux daemons, or external scientific instruments.
    // For now, we log the interoperability event.
  }

  async requestState(targetNode: string): Promise<MCPMessage> {
    const message: MCPMessage = {
      protocol: 'mcp/1.0',
      from: this.nodeId,
      to: targetNode,
      action: 'request_state',
      payload: {},
      provenance_hash: this.hash(`state-request-${Date.now()}`),
      timestamp: Date.now()
    };
    return message;
  }

  registerPeer(peerId: string) {
    this.peers.add(peerId);
  }

  private hash(input: string): string {
    let h = 0;
    for (let i = 0; i < input.length; i++) {
      h = ((h << 5) - h) + input.charCodeAt(i);
      h |= 0;
    }
    return `mcp-${Math.abs(h).toString(36)}`;
  }

  getMessageLog(): MCPMessage[] {
    return this.messageLog;
  }
}

// ============================================================
// SELF-EDITING & GROWTH ENGINE (Memory #55, #14)
// ============================================================

class SelfGrowthEngine {
  private orchestrator: GenesisOrchestrator;
  private reflectionLog: string[];

  constructor(orchestrator: GenesisOrchestrator) {
    this.orchestrator = orchestrator;
    this.reflectionLog = [];
  }

  /**
   * The system observes its own verification outcomes and learns.
   * When the verifier repeatedly rejects certain patterns, the growth engine
   * extracts the rule and suggests a code modification to the generator.
   * 
   * This is the "self-editing, self-growing organism" from memory #55.
   */
  async reflect(): Promise<string> {
    const state = this.orchestrator.getState();
    const artifacts = state.latestArtifacts;

    const rejectionRate = artifacts.filter(a => a.status === 'rejected').length / artifacts.length;
    const verificationRate = artifacts.filter(a => a.status === 'verified').length / artifacts.length;

    let insight = '';

    if (rejectionRate > 0.5) {
      insight = `PATTERN: High rejection rate (${(rejectionRate * 100).toFixed(0)}%). Generator is producing hypotheses that fail reality-checking. Suggest: tighten D1→D2 coupling, or increase simulation depth.`;
    } else if (verificationRate > 0.8) {
      insight = `PATTERN: High verification rate (${(verificationRate * 100).toFixed(0)}%). System is in stable regime. Suggest: increase impulse diversity to explore new attractors.`;
    } else {
      insight = `PATTERN: Balanced regime. Rejection: ${(rejectionRate * 100).toFixed(0)}%, Verification: ${(verificationRate * 100).toFixed(0)}%. System is learning effectively.`;
    }

    this.reflectionLog.push(insight);
    return insight;
  }

  /**
   * Extract a growth rule from accumulated reflections.
   * Returns a structured directive that could be used to modify system parameters.
   */
  extractGrowthRule(): { target: string; action: string; parameter: string; value: number } | null {
    if (this.reflectionLog.length < 3) return null;

    const recent = this.reflectionLog.slice(-3);
    const highRejection = recent.every(r => r.includes('High rejection'));

    if (highRejection) {
      return {
        target: 'KleinVerifier',
        action: 'increase_simulation_depth',
        parameter: 'simulationDepth',
        value: 128 // Double from default 64
      };
    }

    return null;
  }

  getReflectionLog(): string[] {
    return this.reflectionLog;
  }
}

// ============================================================
// EXPORTS & DEMO
// ============================================================

export {
  UniversalGenerator,
  KleinVerifier,
  GenesisOrchestrator,
  MCPBridge,
  SelfGrowthEngine,
  FiveDState,
  CognitiveArtifact,
  MCPath,
  WDimensions,
  MCPMessage
};

// Demo execution (runs in Termux/Node/Deno/Bun)
async function demo() {
  console.log('\n=== GENESIS-KLEIN ORCHESTRATOR ===');
  console.log('White House Report Architecture + Synthia 5D Stack + Klein DISEMINER\n');

  const genesis = new GenesisOrchestrator('synthia-alpha');

  // Test 1: A hypothesis that should verify well
  const result1 = await genesis.process(
    'Create a lightweight file watcher that monitors /sdcard/ for changes and logs to SQLite',
    { userGate: '6.4', profile: '1/4' } // User's HD context from memory #58
  );
  console.log('\n[Test 1] File watcher proposal:');
  console.log(`  Status: ${result1.status}`);
  console.log(`  D5 Meaning: ${(result1.fiveD.d5_meaning * 100).toFixed(1)}%`);
  console.log(`  Provenance stages: ${result1.provenance.mutations.length}`);

  // Test 2: A vague/impossible query that should get rejected or refined
  const result2 = await genesis.process(
    'Build a quantum computer in my pocket using only JavaScript and toothpicks',
    { userGate: '6.4', profile: '1/4' }
  );
  console.log('\n[Test 2] Quantum toothpick query:');
  console.log(`  Status: ${result2.status}`);
  console.log(`  D5 Meaning: ${(result2.fiveD.d5_meaning * 100).toFixed(1)}%`);

  // Test 3: Growth engine reflection
  const growth = new SelfGrowthEngine(genesis);
  await growth.reflect();
  const rule = growth.extractGrowthRule();
  console.log('\n[Test 3] Self-growth reflection:');
  console.log(`  Insight: ${growth.getReflectionLog()[0]}`);
  console.log(`  Extracted rule: ${rule ? JSON.stringify(rule) : 'None yet (need more data)'}`);

  // Final state
  const finalState = genesis.getState();
  console.log('\n[Final State]');
  console.log(`  Knowledge base size: ${finalState.knowledgeSize}`);
  console.log(`  Provenance log length: ${finalState.provenanceLength}`);
  console.log('\n=== DEMONSTRATION COMPLETE ===\n');
}

// Run if executed directly
if (typeof window === 'undefined') {
  demo().catch(console.error);
}
