# Generative Morph Chat

A local semantic automaton where prompts and uploaded sources grow an inspectable neural mesh and can be rendered into short motion-study clips.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/morph-chat/src/App.tsx` — local automaton state, source ingestion, five-question routing, 5D report UI, mesh rendering, and clip capture.
- `artifacts/morph-chat/src/lib/klein-engine.ts` — browser-safe deterministic ingestion/classification/report engine adapted from the uploaded Klein toolkit.
- `artifacts/morph-chat/src/lib/automata.ts` — English co-occurrence dataset, DISEMINER-style neighbor search, question routing, and chat response realization.
- `artifacts/morph-chat/src/index.css` — visual language for the semantic field, motion, and responsive layout.
- `lib/api-spec/openapi.yaml` — shared API contract (unchanged for this frontend-only experience).

## Architecture decisions

- The first version is intentionally local and deterministic: no LLM, external AI provider, or API key is required.
- Meaning is routed through who, what, where, when, and why dimensions; each route becomes an inspectable branch in the mesh.
- Uploaded objects remain in browser memory. Text/code files are read locally; binary media uses local metadata and reports what can and cannot be inferred without a parser.
- The uploaded Klein toolkit is represented by a compact browser-safe vertical slice: universal artifact classification, deterministic structure/behavior/dependency checks, and a five-dimension report. Heavy gameNgen/Node/demo modules are not bundled into the client.
- Generated scene clips are recorded in-browser from the mesh using `MediaRecorder`.

## Product

Users can prompt a local semantic mesh, pause or reset updates, inspect nodes, ingest broad file types, review a deterministic 5D artifact report, edit the five dimensions, route edit directives, and download short generated WebM scene studies.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
