# Alphabet Genealogy Lab

A small offline browser prototype for tracking a symbolic alphabet genealogy.

## What it models

Each transformation event keeps:

- source token
- operation
- subject letter / symbol
- target token
- role before
- role after
- provenance class
- note

Provenance is deliberately separated into:

1. Synthia system rule
2. Personal symbolic analogy
3. Engineering interpretation
4. Source says

That lets the project preserve imaginative symbolic relationships without silently treating them as linguistic, physical, or scientific facts.

## Run

1. Extract the ZIP.
2. Open `index.html` in a browser.

No server, package manager, or internet connection is required.

## Seeded example

The included seed follows the conversation's current symbolic genealogy:

WHO -> witness
H extracted from WHO
W -> F
P -> prosecutor
P + H -> PH
PH -> PHO / PHE
branches to phonology / photon / photography and phenology / phenomenon
neutrino/W "people-door" idea preserved as personal analogy

All entries are editable by clearing/reloading or importing/exporting JSON.
