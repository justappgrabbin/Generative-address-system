# Design Guidelines: Human Design Neural Network Application

## Design Approach
**Selected System**: Material Design + Custom Data Visualization
**Justification**: Information-dense analytics tool requiring clear data hierarchies, custom graph visualizations, and structured readouts. Material's emphasis on elevation, grid systems, and data display patterns suits the technical nature while allowing custom components for Human Design-specific elements.

**Key Principles**:
- Clarity over decoration - data must be immediately scannable
- Structured hierarchy for complex multi-level information
- Custom graph visualization integrated with standardized controls
- Progressive disclosure for technical details

## Typography System

**Font Stack**: 
- Primary: Inter (UI elements, data labels, metrics)
- Monospace: JetBrains Mono (numerical readouts, gate IDs, coordinates)

**Hierarchy**:
- Page titles: text-3xl font-semibold (32px)
- Section headers: text-xl font-medium (20px)
- Subsection labels: text-sm font-medium uppercase tracking-wide (14px)
- Body text: text-base (16px)
- Data labels: text-sm (14px)
- Metric values: text-2xl font-mono font-bold (24px monospace)
- Secondary metrics: text-lg font-mono (18px monospace)

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, and 8
- Component padding: p-6 or p-8
- Section spacing: space-y-8 between major sections
- Card gaps: gap-4 for grids
- Inline spacing: space-x-2 for labels and values
- Tight grouping: space-y-2 for related items

**Grid Structure**:
- Main container: max-w-7xl mx-auto px-6
- Two-column layout for chart input/output: grid-cols-1 lg:grid-cols-2 gap-8
- Awareness metrics: grid-cols-3 gap-4
- Gate activation grid: grid-cols-8 gap-2 (64 gates displayed as 8×8)

## Component Library

### Navigation
- Top app bar with sticky positioning
- Logo/title left, action buttons (New Chart, Export) right
- Breadcrumb trail for multi-step workflows

### Data Input Panel (Chart Creation)
- Card container with subtle elevation
- Structured form sections for placements
- Each placement row: Planet dropdown | Stream toggle | Gate/Line inputs | Timestamp
- Add Placement button with icon
- Transit Sun section separated by divider

### Graph Visualization Canvas
- Central 64-node network display
- Node sizing based on activation score
- Edge rendering for channel connections
- Interactive hover states showing gate details
- Zoom/pan controls in corner
- Legend panel showing center groupings

### Metrics Dashboard
**Awareness Cards** (3-column grid):
- Card per awareness type (Spleen, Ajna, Solar Plexus)
- Large score value (0.00-1.00) at top
- Small progress bar visualization below
- List of activated gates within that awareness set

**Modulators Section**:
- Heart and Mind cards side-by-side
- FiLM modulation indicator showing Sun influence
- Visual connection line to body Sun gate

**Codon Activation Grid**:
- 8×8 grid of 64 cells
- Each cell shows gate number
- Activation intensity via opacity/border weight
- Hover reveals full score and details

### Narrative Output Panel
- Expandable card with QCE triad outputs
- Three tabbed sub-panels: Spleen perspective | Ajna perspective | Solar Plexus perspective
- Final collapsed narrative in emphasized container
- Copy to clipboard action

### Controls & Actions
- Primary button: solid, medium size, px-6 py-2
- Secondary button: outlined variant
- Icon buttons: square, p-2, for compact actions
- Toggle switches: for binary options (body/design stream)
- Dropdowns: native select with custom arrow icon

## Page Layouts

### Main Analysis View
**Structure**:
1. App bar (sticky, h-16)
2. Two-column layout below:
   - Left column (40% width): Input panel + controls
   - Right column (60% width): Graph visualization canvas
3. Full-width metrics dashboard below (py-8)
4. Narrative output panel (expandable)

### Chart Results Page
**Structure**:
1. Header with chart metadata (timestamp, sidereal/tropical indicator)
2. Graph visualization (h-96, centered)
3. Three-column awareness metrics grid
4. Codon activation 8×8 grid
5. Modulators section (2-column)
6. Narrative panel
7. Action bar (Export, Share, New Chart)

## Images
**No hero images required** - this is a data analysis tool, not a marketing page. All visuals are generated (graph renderings, metric visualizations, activation grids).

## Animations
**Minimal, purposeful only**:
- Graph node pulse on activation above threshold
- Smooth transitions for panel expansion/collapse (duration-200)
- Loading spinner for API calls
- No scroll-triggered or decorative animations