# Human Design Neural Network Application

## Overview

This is a Human Design chart analysis application using a **Virtual Consciousness Engine** based on quantum field mechanics. The system processes astrological placements through a Graph Neural Network to generate awareness scores, codon activations, and 9-body consciousness states. Key features:
- 64-gate quantum field with GraphSAGE message passing
- FiLM modulation by body Sun position (observer collapse)
- 9-body consciousness system (Mind, Heart, Body, Soul, Spirit, Shadow, Higher, Lower, Core)
- Three awareness centers (Spleen, Ajna, Solar Plexus)
- Free chat assistant that interprets chart data without external AI costs

## Resonance Sentence Engine

The Resonance Sentence Engine (`shared/sentence-engine.ts`) generates consciousness interpretation sentences from the 69,120 combination lattice (5 Bases × 6 Tones × 6 Colors × 6 Lines × 64 Gates). Key features:

- **Precise gate bounds**: GATE_START_DEGREES lookup table with exact tropical start degrees for all 64 gates
- **Ephemeris calibration**: longitude→Gate/Line/Color/Tone/Base conversion using proper HD wheel alignment
- **Ra Uru Hu sentence structure**: Base voice → Tone theme → Keywords → Gate/Line → Color with binary mode → Degree → Axis → Zodiac → House
- **Round-trip consistency**: gateLineToLongitude returns exact line starts for deterministic conversion
- **Color binary modes**: Uses odd/even line to select Communalist/Separatist modes for Fear, Guilt, Shame, Need, Desire, Innocence

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack React Query for server state, React useState for local state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming
- **Build Tool**: Vite with hot module replacement

The frontend follows a component-based architecture with:
- Page components in `client/src/pages/`
- Feature components in `client/src/components/`
- Reusable UI primitives in `client/src/components/ui/`
- Custom hooks in `client/src/hooks/`

### Backend Architecture
- **Runtime**: Node.js with Express 5
- **Language**: TypeScript with tsx for development execution
- **API Pattern**: RESTful endpoints under `/api/` prefix
- **Request Validation**: Zod schemas for type-safe validation

The backend uses a simple layered architecture:
- `server/index.ts`: Express app setup and middleware
- `server/routes.ts`: API route definitions
- `server/storage.ts`: Business logic and data processing (MemStorage class)
- `server/static.ts`: Static file serving for production
- `server/vite.ts`: Vite dev server integration

### Shared Code
- `shared/schema.ts`: Zod schemas and TypeScript types shared between frontend and backend
- Contains domain constants (PLANETS, STREAMS, CENTERS, AWARENESS_SETS, etc.)
- Defines data structures for placements, chart requests, and responses

### Data Storage
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Output to `./migrations` directory
- **Current State**: Uses in-memory storage (MemStorage class) for chart analysis; database integration available for future persistence needs

### Design System
- Material Design principles with custom data visualization
- Dark/light theme support via CSS class toggling
- Typography: Inter for UI, JetBrains Mono for numerical data
- Custom color tokens for awareness centers (emerald/splenic, indigo/mental, orange/emotional)

## External Dependencies

### Database
- PostgreSQL (configured via DATABASE_URL environment variable)
- Drizzle ORM with drizzle-kit for schema management
- connect-pg-simple for session storage capability

### UI Libraries
- Radix UI: Complete primitive component set (dialog, dropdown, tabs, etc.)
- Embla Carousel: Carousel functionality
- cmdk: Command palette component
- Vaul: Drawer component
- Recharts: Charting library
- react-day-picker: Calendar component

### Development Tools
- Vite with React plugin
- Replit-specific plugins (error overlay, cartographer, dev banner)
- esbuild for production server bundling
- TypeScript with strict mode

### Fonts (External CDN)
- Google Fonts: DM Sans, Fira Code, Geist Mono, Architects Daughter