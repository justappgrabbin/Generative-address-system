
// resonance_engine.js
// Minimal, stateless-ish engine for MVP. Replace with real HD/astrology later.
export const ResonanceEngine = {
  // Inputs:
  // - profile: { birthday: 'YYYY-MM-DD', time?: 'HH:MM', place?: 'City, Country' }
  // - activity: { watchMinutes:number, posts:number, quests:number, streak:number }
  // - boosters: { codons:string[], gates:number[] }
  // Output:
  // - { score:0-100, socialUnlock:boolean, payoutUnlock:boolean, reasons:string[] }
  evaluate({ profile, activity, boosters, createdAtISO }) {
    const reasons = [];
    const createdAt = createdAtISO ? new Date(createdAtISO) : new Date();
    const daysSince = Math.floor((Date.now() - createdAt.getTime()) / (1000*60*60*24));

    // 1) Base score from birthday digits (stable pseudo-personalization)
    const seed = (profile?.birthday||"2000-01-01").replace(/[^0-9]/g, "");
    let base = 0;
    for (let i=0;i<seed.length;i++) base = (base*31 + Number(seed[i])) % 9973;
    let score = (base % 41) + 30; // 30..70 baseline
    reasons.push(`Baseline from profile: +${score-30}`);

    // 2) Activity weighting
    const watch = Math.min(activity?.watchMinutes||0, 240); // cap 4h/day for sanity
    score += Math.round(Math.sqrt(watch)); // gentle boost
    if (watch > 0) reasons.push(`Watch time boost: +${Math.round(Math.sqrt(watch))}`);

    const posts = activity?.posts||0;
    score += Math.min(posts*3, 18);
    if (posts>0) reasons.push(`Posting activity: +${Math.min(posts*3,18)}`);

    const quests = activity?.quests||0;
    score += Math.min(quests*5, 25);
    if (quests>0) reasons.push(`Quest completions: +${Math.min(quests*5,25)}`);

    const streak = Math.min(activity?.streak||0, 30);
    score += Math.floor(streak/3)*2; // +2 per 3-day chunk
    if (streak>0) reasons.push(`Streak bonus: +${Math.floor(streak/3)*2}`);

    // 3) Boosters (codons/gates)
    const boosterCount = (boosters?.codons?.length||0) + (boosters?.gates?.length||0);
    score += Math.min(boosterCount, 10);
    if (boosterCount>0) reasons.push(`Field boosters: +${Math.min(boosterCount,10)}`);

    // Clamp 0..100
    score = Math.max(0, Math.min(100, score));

    // Unlock logic
    const socialUnlock = (score >= 60) && ((posts + quests) >= 3);
    const payoutEligible = daysSince >= 14 && socialUnlock;

    reasons.push(socialUnlock ? "Social unlocked: YES" : "Social unlocked: NO (need score>=60 and 3+ actions)");
    reasons.push(daysSince >= 14 ? "2-week calibration: COMPLETE" : `Calibration lock: ${14-daysSince} days remaining`);

    return { score, socialUnlock, payoutUnlock: payoutEligible, daysSince, reasons };
  },

  // Simple resonance sentence generator (placeholder for HD/astrology integration)
  sentence({ hexagram=51, trigram="Thunder", tone="Arousal", line=1 }){
    const lineTxt = ["root","path","turn","bridge","crest","crown"][Math.max(1,Math.min(6,line))-1];
    return `H${hexagram}.${line} — ${trigram} ${tone}: “Stabilize the ${lineTxt}, then move.”`;
  }
};
