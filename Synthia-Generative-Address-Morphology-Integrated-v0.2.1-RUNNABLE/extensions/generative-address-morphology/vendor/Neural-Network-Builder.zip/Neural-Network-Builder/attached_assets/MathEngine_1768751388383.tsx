import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calculator, Infinity, TrendingUp, PieChart } from "lucide-react";
import { useSynthia } from "@/hooks/use-synthia";
import { useToast } from "@/hooks/use-toast";

interface MathResult {
  solution: string;
  steps: string[];
  visualization?: string;
  confidence: number;
}

export function MathEngine() {
  const [isOpen, setIsOpen] = useState(false);
  const [problem, setProblem] = useState("");
  const [lastResult, setLastResult] = useState<MathResult | null>(null);

  const { solveMathProblem, isSolvingMath } = useSynthia();
  const { toast } = useToast();

  const handleSolveProblem = async () => {
    if (!problem.trim()) {
      toast({
        title: "Problem Required",
        description: "Please enter a mathematical problem to solve.",
        variant: "destructive"
      });
      return;
    }

    try {
      await solveMathProblem(problem, {
        onSuccess: (result) => {
          setLastResult(result);
          toast({
            title: "Problem Solved",
            description: `Solution generated with ${result.confidence}% confidence.`
          });
          setIsOpen(false);
        },
        onError: (error) => {
          toast({
            title: "Solving Failed",
            description: "Failed to solve the mathematical problem. Please try again.",
            variant: "destructive"
          });
        }
      });
    } catch (error) {
      console.error("Error solving math problem:", error);
    }
  };

  const exampleProblems = [
    "Find the derivative of x³ + 2x² - 5x + 1",
    "Solve the system: 2x + y = 5, x - y = 1",
    "Calculate the integral of sin(x) from 0 to π",
    "Find the limit of (x² - 1)/(x - 1) as x approaches 1"
  ];

  return (
    <Card className="glass-morphism rounded-2xl p-6 hover:border-purple-500/50 transition-all group">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center group-hover:bg-purple-500/30 transition-colors">
            <Calculator className="text-purple-500 h-5 w-5" />
          </div>
          <h3 className="text-lg font-semibold">Math Engine</h3>
        </div>
        <Badge variant="secondary" className="text-xs flex items-center">
          <Infinity className="h-3 w-3 mr-1" />
          Power
        </Badge>
      </div>
      
      <p className="text-sm text-muted-foreground mb-4">
        Advanced mathematical problem solving with visual representations.
      </p>
      
      {/* Math Visualization Preview */}
      <div className="bg-muted/20 rounded-lg p-3 mb-4 font-mono text-sm" data-testid="math-display">
        {lastResult ? (
          <div className="space-y-2">
            <div className="text-purple-500 mb-2">Latest Solution:</div>
            <div className="text-xs space-y-1">
              <div className="font-bold text-accent">{lastResult.solution}</div>
              <div className="text-muted-foreground">Steps: {lastResult.steps.length}</div>
              <div className="text-green-500">Confidence: {lastResult.confidence}%</div>
            </div>
            {lastResult.visualization && (
              <div className="mt-2 p-2 bg-purple-500/10 rounded">
                <div className="text-xs text-purple-300">{lastResult.visualization}</div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <div className="text-purple-500 mb-2">∫ f(x)dx = Solution</div>
            <div className="h-16 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded flex items-center justify-center">
              <span className="text-xs text-muted-foreground">Live Graph Visualization</span>
            </div>
          </div>
        )}
      </div>
      
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            className="w-full py-2 bg-purple-500/10 text-purple-500 rounded-lg hover:bg-purple-500/20 transition-colors"
            data-testid="button-solve-problem"
          >
            <Calculator className="mr-2 h-4 w-4" />
            Solve Problem
          </Button>
        </DialogTrigger>
        
        <DialogContent className="glass-morphism border-border max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-gradient">Mathematical Problem Solver</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="math-problem">Mathematical Problem</Label>
              <Textarea
                id="math-problem"
                placeholder="Enter your mathematical problem (calculus, algebra, geometry, etc.)"
                className="min-h-[100px] font-mono"
                value={problem}
                onChange={(e) => setProblem(e.target.value)}
                data-testid="input-math-problem"
              />
            </div>
            
            <div>
              <Label>Example Problems</Label>
              <div className="grid grid-cols-1 gap-2 mt-2">
                {exampleProblems.map((example, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="text-left justify-start h-auto p-2 font-mono text-xs"
                    onClick={() => setProblem(example)}
                    data-testid={`button-example-${index}`}
                  >
                    {example}
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button
                onClick={handleSolveProblem}
                disabled={isSolvingMath || !problem.trim()}
                className="flex-1"
                data-testid="button-solve"
              >
                {isSolvingMath ? "Solving..." : "Solve Problem"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsOpen(false)}
                data-testid="button-cancel-math"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
