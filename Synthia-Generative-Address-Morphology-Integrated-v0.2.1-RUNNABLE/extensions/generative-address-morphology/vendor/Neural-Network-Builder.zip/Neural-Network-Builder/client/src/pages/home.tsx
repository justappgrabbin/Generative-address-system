import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ThemeToggle } from "@/components/theme-toggle";
import { PlacementForm } from "@/components/placement-form";
import { GraphVisualization } from "@/components/graph-visualization";
import { AwarenessCard } from "@/components/awareness-card";
import { CodonGrid } from "@/components/codon-grid";
import { ModulatorsSection } from "@/components/modulators-section";
import { AlchemySection } from "@/components/alchemy-section";
import { NarrativePanel } from "@/components/narrative-panel";
import { ChatPanel } from "@/components/chat-panel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Network, FileDown, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Placement, TransitSun, ChartResponse } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [chartData, setChartData] = useState<ChartResponse | null>(null);

  const analyzeChartMutation = useMutation({
    mutationFn: async (data: { placements: Placement[]; transitSun?: TransitSun }) => {
      const response = await apiRequest("POST", "/api/chart", data);
      return await response.json() as ChartResponse;
    },
    onSuccess: (data) => {
      setChartData(data);
      toast({
        title: "Chart Analyzed",
        description: `Processed ${data.codons.filter(c => c.isActivated).length} activated gates`,
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (placements: Placement[], transitSun?: TransitSun) => {
    analyzeChartMutation.mutate({ placements, transitSun });
  };

  const handleNewChart = () => {
    setChartData(null);
  };

  const handleExport = () => {
    if (!chartData) return;
    const dataStr = JSON.stringify(chartData, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hd-chart-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Export Complete",
      description: "Chart data has been downloaded as JSON",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Network className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">HD Neural Network</h1>
              <p className="text-xs text-muted-foreground">Human Design Chart Analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {chartData && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNewChart}
                  className="gap-2"
                  data-testid="button-new-chart"
                >
                  <RefreshCw className="h-4 w-4" />
                  New Chart
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExport}
                  className="gap-2"
                  data-testid="button-export"
                >
                  <FileDown className="h-4 w-4" />
                  Export
                </Button>
              </>
            )}
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!chartData ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <PlacementForm 
                onSubmit={handleSubmit} 
                isLoading={analyzeChartMutation.isPending} 
              />
              <div className="p-4 rounded-lg bg-muted/30 border border-border">
                <h3 className="text-sm font-medium mb-2">Quick Start</h3>
                <p className="text-sm text-muted-foreground">
                  Enter planetary placements from your Human Design chart. Each placement includes 
                  the planet, stream (body or design), gate (1-64), and line (1-6). The default 
                  values provide a sample chart for exploration.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-center p-8 rounded-lg border border-dashed border-border bg-muted/20 min-h-[400px]">
              <div className="text-center space-y-4">
                <div className="p-4 rounded-full bg-muted/50 mx-auto w-fit">
                  <Network className="h-12 w-12 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-1">No Chart Data</h3>
                  <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                    Enter placements and click "Analyze Chart" to visualize the 64-gate network
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-semibold">Chart Analysis</h2>
                  <Badge variant="secondary" className="font-mono">
                    {chartData.codons.filter(c => c.isActivated).length} gates
                  </Badge>
                  <Badge variant="outline" className="font-mono">
                    {chartData.definedChannels.length} channels
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Body Sun: Gate {chartData.heart.filmParams.sunGate}.{chartData.heart.filmParams.sunLine}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <PlacementForm 
                onSubmit={handleSubmit} 
                isLoading={analyzeChartMutation.isPending} 
              />
              <GraphVisualization 
                codons={chartData.codons} 
                definedChannels={chartData.definedChannels} 
              />
            </div>

            <Separator />

            <section>
              <h3 className="text-xl font-medium mb-4">Awareness Metrics</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <AwarenessCard awareness={chartData.awareness.spleen} />
                <AwarenessCard awareness={chartData.awareness.ajna} />
                <AwarenessCard awareness={chartData.awareness.solar_plexus} />
              </div>
            </section>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <CodonGrid codons={chartData.codons} />
              <ModulatorsSection heart={chartData.heart} mind={chartData.mind} />
            </div>

            <AlchemySection alchemy={chartData.alchemy} />

            <NarrativePanel awareness={chartData.awareness} />
          </div>
        )}
      </main>

      <ChatPanel chartData={chartData} />
    </div>
  );
}
