import express from "express";
import { createServer } from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { parseGroundedModelContent } from "./grounding";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const forgeUrl = (process.env.BUILT_IN_FORGE_API_URL || "").replace(/\/+$/, "");
const forgeKey = process.env.BUILT_IN_FORGE_API_KEY;

const understandingSchema = {
  type: "object",
  properties: {
    answer: { type: "string" },
    purpose: { type: "string" },
    observedFacts: { type: "array", items: { type: "string" } },
    inferredRelationships: { type: "array", items: { type: "string" } },
    behaviors: { type: "array", items: { type: "string" } },
    dependencies: { type: "array", items: { type: "string" } },
    unknowns: { type: "array", items: { type: "string" } },
    confidence: { type: "string", enum: ["low", "medium", "high"] },
    evidenceRefs: { type: "array", items: { type: "object", properties: { artifactId: { type: "string" }, claim: { type: "string" } }, required: ["artifactId", "claim"], additionalProperties: false } },
  },
  required: ["answer", "purpose", "observedFacts", "inferredRelationships", "behaviors", "dependencies", "unknowns", "confidence", "evidenceRefs"],
  additionalProperties: false,
};

async function chooseModel() {
  if (!forgeUrl || !forgeKey) throw new Error("Built-in model service is not configured");
  const response = await fetch(`${forgeUrl}/v1/models`, { headers: { Authorization: `Bearer ${forgeKey}` } });
  if (!response.ok) throw new Error(`Model catalog unavailable (${response.status})`);
  const body = await response.json() as { data?: Array<{ id: string }> };
  return body.data?.find((model) => /gpt-5|claude|gemini/i.test(model.id))?.id || body.data?.[0]?.id;
}

async function understand(packet: unknown, question?: string) {
  const model = await chooseModel();
  if (!model) throw new Error("No built-in model is available");
  const response = await fetch(`${forgeUrl}/v1/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${forgeKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.1,
      messages: [
        { role: "system", content: "You are the Meaning Mesh evidence analyst. Use only the supplied evidence packet. Never invent file contents, runtime behavior, dependencies, purpose, or certainty. Separate observed facts from inferences. If evidence is insufficient, put the gap in unknowns. Every material claim must cite an artifactId from the evidence packet in evidenceRefs. Return only JSON matching the schema." },
        { role: "user", content: JSON.stringify({ question: question || "Explain this artifact set: its purpose, observed behaviors, dependencies, relationships, and unknowns.", evidencePacket: packet }) },
      ],
      response_format: { type: "json_schema", json_schema: { name: "meaning_mesh_understanding", strict: true, schema: understandingSchema } },
    }),
  });
  if (!response.ok) throw new Error(`Grounded analysis failed (${response.status})`);
  const body = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
  const content = body.choices?.[0]?.message?.content;
  if (!content) throw new Error("The model returned no grounded analysis");
  return parseGroundedModelContent(content);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "8mb" }));
  app.post("/api/understand", async (req, res) => {
    try {
      const result = await understand(req.body?.evidencePacket, req.body?.question);
      res.json(result);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : "Grounded analysis unavailable" });
    }
  });

  if (process.env.NODE_ENV === "production") {
    const staticPath = path.resolve(__dirname, "public");
    app.use(express.static(staticPath));
    app.get("*", (_req, res) => res.sendFile(path.join(staticPath, "index.html")));
  } else {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      try {
        const template = fs.readFileSync(path.resolve(__dirname, "..", "client", "index.html"), "utf-8");
        const html = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(html);
      } catch (error) {
        vite.ssrFixStacktrace(error as Error);
        next(error);
      }
    });
  }
  const port = process.env.PORT || 3000;
  server.listen(port, () => console.log(`Server running on http://localhost:${port}/`));
}

startServer().catch(console.error);
