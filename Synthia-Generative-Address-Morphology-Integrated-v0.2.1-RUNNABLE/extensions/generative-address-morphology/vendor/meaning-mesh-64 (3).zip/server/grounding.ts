export type GroundedUnderstanding = {
  answer: string;
  purpose: string;
  observedFacts: string[];
  inferredRelationships: string[];
  behaviors: string[];
  dependencies: string[];
  unknowns: string[];
  confidence: "low" | "medium" | "high";
  evidenceRefs: Array<{ artifactId: string; claim: string }>;
};

export function parseGroundedModelContent(content: string): GroundedUnderstanding {
  const value = JSON.parse(content) as Partial<GroundedUnderstanding>;
  const arrays = ["observedFacts", "inferredRelationships", "behaviors", "dependencies", "unknowns"] as const;
  if (typeof value.answer !== "string" || typeof value.purpose !== "string" || !value.confidence || !["low", "medium", "high"].includes(value.confidence) || arrays.some((key) => !Array.isArray(value[key]) || value[key]?.some((item) => typeof item !== "string")) || !Array.isArray(value.evidenceRefs) || value.evidenceRefs.some((item) => !item || typeof item.artifactId !== "string" || typeof item.claim !== "string")) {
    throw new Error("The model returned an incomplete or uncited understanding record");
  }
  return value as GroundedUnderstanding;
}
