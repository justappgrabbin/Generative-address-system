# Meaning Mesh 64 — Design Directions

## Three approaches

| Theme Name | Very Brief Intro | Probability |
| --- | --- | --- |
| Field Manual | A warm, typographic workbench that feels like a technical notebook, emphasizing careful inspection over spectacle. | 0.07 |
| Quiet Instrument | A compact desktop utility with a dark graphite work surface, dense but breathable information hierarchy, and deliberately restrained interaction. | 0.04 |
| Technical Atelier | A light, editorial environment where every result is treated as an annotated artifact. | 0.09 |

## Chosen approach — Quiet Instrument

### Design Movement

**Quiet Instrument** draws from high-end desktop developer tools, calibrated industrial design, and contemporary Swiss information systems. It must feel purpose-built and serious, not like a dashboard template, a sci-fi control room, or a data visualization toy.

### Core Principles

1. **Function declares form.** Controls, reports, and states are visible because they do work; decoration is removed.
2. **Text is the interface.** Monospaced metadata and precise hierarchy make relationships legible without a graph.
3. **Calm density.** Persistent context, compact panels, and whitespace give complex material a stable reading surface.
4. **Honest boundaries.** Local processing and sandbox constraints are stated plainly; no universal-execution claims or implied capabilities.

### Color Philosophy

Near-black graphite provides a quiet, low-glare reading field; fog-white text and cool gray strata establish depth without visual noise. A sharply limited mineral green serves only as a confirmation and active-state signal—an ownable indication that the system has found a meaningful connection. It must not become an all-purpose accent or gradient.

### Layout Paradigm

Use an **instrument panel**, not a centered dashboard. A narrow left rail persists for inputs and workspace selection. The main surface is a vertical reading column split into active records and interrogations. A right-side inspector presents current facts, relationships, and 64 structural slots. On small screens, inspector panels become stacked drawers while the command bar remains reachable.

### Signature Elements

1. **Index coordinates:** subtle `01–64` references mark background structural slots and replace visual-network decoration.
2. **Rule lines:** ultra-fine horizontal separators organize evidence, output, and transitions.
3. **Status lozenges:** squared, modest state labels such as `LOCAL`, `READY`, and `SANDBOX` communicate scope at a glance.

### Interaction Philosophy

Interactions should be direct, reversible, and legible. Import opens the native file picker; analysis results appear in context; command submissions update an event log. Controls should favor labelled actions over icon-only mystery. The interface should preserve the imported file and never make hidden network requests.

### Animation

Motion is quiet and purposeful. Panels fade and rise by 4px over 160–220ms using a strong ease-out. Only transient output rows may stagger by 40ms. Buttons compress to 0.98 on activation. There are no looping ornaments, glowing pulses, physics simulations, animated meshes, or large entrance choreography. Honor reduced-motion preferences.

### Typography System

Use **IBM Plex Sans** for navigational labels, instructions, and report prose. Use **IBM Plex Mono** for source previews, quantities, node IDs, command output, and parsed primitives. Headings use Plex Sans at restrained weights and letter spacing; monospaced text never impersonates display type.

### Brand Essence

**Meaning Mesh 64 is a local analysis instrument for people who need to reduce complex files into inspectable relationships, constraints, and next actions.**

Personality: **measured, exacting, unflashy**.

### Brand Voice

Headlines should name the active operation rather than promise transformation. CTAs should describe their immediate result; microcopy should clearly distinguish observation from inference.

> “Load a file. Keep the facts close.”

> “Trace what depends on this.”

### Wordmark & Logo

The logo is a compact **segmented coordinate mark**: four offset rectangular strokes suggest four quadrants of a 64-slot index without forming a visible mesh or a human symbol. The wordmark is set in restrained uppercase Plex Mono, never a default rounded sans.

### Signature Brand Color

**Trace Green — `#74D99F`**. It is reserved for active confirmation, focus, and validated relationships.

## Style Decisions

Empty states are operational record states, not marketing heroes: headings must name the current instrument condition and sit within metadata, rule lines, and local-processing context. The `01–64` coordinate system appears as persistent textual structure across the primary record, inspector, and session context; it replaces decorative network visuals. Trace Green is reserved for confirmed active states, validated relationships, focus, and the single immediate import command; neutral graphite treatments handle all other controls.
