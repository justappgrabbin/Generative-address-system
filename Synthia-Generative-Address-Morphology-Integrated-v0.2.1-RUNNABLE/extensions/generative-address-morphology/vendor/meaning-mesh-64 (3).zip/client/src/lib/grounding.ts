import type { UnderstandingRecord } from "./analysis";

export function normalizeGroundedResponse(value: unknown): UnderstandingRecord | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Record<string, unknown>;
  const list = (key: string) => Array.isArray(candidate[key]) && candidate[key].every((item) => typeof item === "string") ? candidate[key] as string[] : null;
  const observedFacts = list("observedFacts");
  const inferredRelationships = list("inferredRelationships");
  const behaviors = list("behaviors");
  const dependencies = list("dependencies");
  const unknowns = list("unknowns");
  const evidenceRefs = Array.isArray(candidate.evidenceRefs) && candidate.evidenceRefs.every((item) => item && typeof item === "object" && typeof (item as Record<string, unknown>).artifactId === "string" && typeof (item as Record<string, unknown>).claim === "string") ? candidate.evidenceRefs as Array<{ artifactId: string; claim: string }> : null;
  if (typeof candidate.purpose !== "string" || !observedFacts || !inferredRelationships || !behaviors || !dependencies || !unknowns || !evidenceRefs || !["low", "medium", "high"].includes(candidate.confidence as string)) return null;
  return { answer: typeof candidate.answer === "string" ? candidate.answer : undefined, purpose: candidate.purpose, observedFacts, inferredRelationships, behaviors, dependencies, unknowns, confidence: candidate.confidence as UnderstandingRecord["confidence"], evidenceRefs };
}
