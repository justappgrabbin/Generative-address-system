import { unzipSync } from "fflate";
export type RuleTone = "green" | "amber" | "neutral";

export type AnalysisRule = {
  id: string;
  name: string;
  pattern: string;
  detail: string;
  tone: RuleTone;
  enabled: boolean;
};

export type ArtifactMetadata = { pages?: number; headings?: string[] };

export type ImportedArtifact = {
  id: string;
  name: string;
  type: string;
  size: number;
  text: string;
  opaque: boolean;
  source: "local" | "archive";
  parent?: string;
  kind: "text" | "json" | "csv" | "pdf" | "archive" | "binary";
  metadata?: ArtifactMetadata;
};

export type Behavior = { label: string; detail: string; tone: RuleTone };

export type DataShape = {
  kind: "json" | "csv";
  rows: number;
  columns: number;
  keys: string[];
  preview: string;
};

export type UnderstandingRecord = {
  purpose: string;
  observedFacts: string[];
  inferredRelationships: string[];
  behaviors: string[];
  dependencies: string[];
  unknowns: string[];
  confidence: "low" | "medium" | "high";
  answer?: string;
  evidenceRefs: Array<{ artifactId: string; claim: string }>;
};

export type GateMode = "mirror" | "complement";

export type GateBlueprint = {
  gate: number;
  name: string;
  allowedQualities: string[];
  constraint: string;
  signalTerms: string[];
};

export type GateAssignment = GateBlueprint & { score: number; evidence: string[]; artifactIds: string[] };

export function validateGateRules(payload: unknown): GateBlueprint[] {
  const gates = payload && typeof payload === "object" && "gates" in payload ? (payload as { gates?: unknown }).gates : payload;
  if (!Array.isArray(gates) || gates.length !== 64) throw new Error("Expected exactly 64 gate rules.");
  const valid = gates.every((gate) => {
    if (!gate || typeof gate !== "object") return false;
    const item = gate as Partial<GateBlueprint>;
    return Number.isInteger(item.gate) && (item.gate ?? 0) >= 1 && (item.gate ?? 0) <= 64 && typeof item.name === "string" && item.name.trim().length > 0 && Array.isArray(item.allowedQualities) && item.allowedQualities.length > 0 && item.allowedQualities.every((value) => typeof value === "string" && value.trim().length > 0) && typeof item.constraint === "string" && item.constraint.trim().length > 0 && Array.isArray(item.signalTerms) && item.signalTerms.length > 0 && item.signalTerms.every((value) => typeof value === "string" && value.trim().length > 0);
  });
  if (!valid) throw new Error("Gate rules must include gate, name, allowed qualities, constraint, and signal terms.");
  return gates as GateBlueprint[];
}

export type GateSystemState = {
  mode: GateMode;
  activeGate: number;
  allowedQualities: string[];
  constraint: string;
  focus: string;
  adjustment: string;
};

const GATE_NAMES = [
  "Initiate", "Measure", "Respond", "Shape", "Sustain", "Clarify", "Wait", "Connect",
  "Refine", "Express", "Direct", "Gather", "Commit", "Order", "Test", "Translate",
  "Adapt", "Focus", "Protect", "Exchange", "Return", "Reframe", "Open", "Contain",
  "Repeat", "Name", "Compare", "Sequence", "Balance", "Repair", "Observe", "Resolve",
  "Seed", "Build", "Filter", "Coordinate", "Remember", "Release", "Choose", "Integrate",
  "Pattern", "Signal", "Boundary", "Resource", "Tempo", "Context", "Threshold", "Craft",
  "Question", "Model", "Practice", "Agency", "Witness", "Bridge", "Archive", "Distill",
  "Scope", "Detail", "Variation", "Rule", "Play", "Rest", "Return", "Meaning",
];

const GATE_QUALITIES = ["initiative", "precision", "patience", "connection", "expression", "adaptation", "containment", "integration"];

export const GATE_BLUEPRINTS: GateBlueprint[] = GATE_NAMES.map((name, index) => {
  const first = GATE_QUALITIES[index % GATE_QUALITIES.length];
  const second = GATE_QUALITIES[(index * 3 + 1) % GATE_QUALITIES.length];
  return {
    gate: index + 1,
    name,
    allowedQualities: [first, second],
    constraint: `Favor ${first} and ${second}; reject actions that contradict the active blueprint.`,
    signalTerms: [name.toLowerCase(), first, second, index % 2 ? "rule" : "system"],
  };
});

export function filterGateBlueprints(gates: GateBlueprint[], query: string) {
  const normalized = query.trim().toLowerCase();
  return gates.filter((gate) => !normalized || `${gate.gate} ${gate.name} ${gate.allowedQualities.join(" ")} ${gate.signalTerms.join(" ")}`.toLowerCase().includes(normalized));
}

export type Analysis = {
  lines: number;
  words: number;
  tokens: number;
  characters: number;
  symbols: string[];
  imports: string[];
  behaviors: Behavior[];
  concepts: Array<{ term: string; count: number }>;
  slots: number[];
  dataShape?: DataShape;
};

export const TEXT_EXTENSIONS = [
  "txt", "md", "markdown", "json", "csv", "tsv", "js", "mjs", "cjs", "ts", "tsx", "jsx",
  "html", "css", "scss", "xml", "yml", "yaml", "py", "java", "c", "cpp", "h", "hpp", "rs",
  "go", "rb", "php", "sh", "sql", "ini", "toml", "svg", "glsl", "wgsl",
];

export const ARCHIVE_EXTENSIONS = ["zip"];
export const PDF_EXTENSIONS = ["pdf"];

const STOP_WORDS = new Set([
  "this", "that", "with", "from", "then", "else", "true", "false", "null", "undefined", "return",
  "const", "function", "class", "import", "export", "default", "public", "private", "static", "void",
  "string", "number", "boolean", "object", "array", "into", "about", "your", "have", "will", "were",
]);

export const DEFAULT_RULES: AnalysisRule[] = [
  { id: "network", name: "Network surface", pattern: "fetch|XMLHttpRequest|WebSocket|EventSource", detail: "Makes or prepares external requests.", tone: "amber", enabled: true },
  { id: "state", name: "Persistent state", pattern: "localStorage|sessionStorage|indexedDB|document\\.cookie", detail: "Reads or writes browser-resident state.", tone: "neutral", enabled: true },
  { id: "timed", name: "Timed work", pattern: "setTimeout|setInterval|requestAnimationFrame|queueMicrotask", detail: "Schedules work outside the immediate call path.", tone: "neutral", enabled: true },
  { id: "events", name: "Event response", pattern: "addEventListener|onclick|onchange|keydown|pointerdown", detail: "Responds to user or system events.", tone: "green", enabled: true },
  { id: "graphics", name: "Graphics capability", pattern: "canvas|getContext\\s*\\(|WebGL|WebGPU|navigator\\.gpu", detail: "Touches a drawing or GPU-facing browser API.", tone: "green", enabled: true },
  { id: "media", name: "Media capability", pattern: "AudioContext|new Audio\\s*\\(|getUserMedia", detail: "Touches browser audio or capture APIs.", tone: "amber", enabled: true },
  { id: "todo", name: "Open work marker", pattern: "TODO|FIXME|HACK", detail: "Contains an explicit unfinished-work marker.", tone: "amber", enabled: true },
];

export function hash(value: string) {
  let current = 5381;
  for (let index = 0; index < value.length; index += 1) current = (current * 33) ^ value.charCodeAt(index);
  return Math.abs(current >>> 0);
}

export function extension(name: string) {
  return name.includes(".") ? name.split(".").pop()?.toLowerCase() ?? "file" : "file";
}

export function isReadable(name: string, type = "") {
  return type.startsWith("text/") || TEXT_EXTENSIONS.includes(extension(name));
}

export function formatSize(bytes: number) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const power = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** power).toFixed(power === 0 ? 0 : 1)} ${units[power]}`;
}

export function number(value: number) {
  return new Intl.NumberFormat("en-US").format(value);
}

function parseJsonShape(text: string): DataShape | undefined {
  try {
    const parsed = JSON.parse(text) as unknown;
    const rows = Array.isArray(parsed) ? parsed : [parsed];
    const objects = rows.filter((row): row is Record<string, unknown> => Boolean(row && typeof row === "object" && !Array.isArray(row)));
    const keys = Array.from(new Set(objects.flatMap((row) => Object.keys(row)))).slice(0, 10);
    return { kind: "json", rows: rows.length, columns: keys.length, keys, preview: JSON.stringify(rows.slice(0, 2), null, 2).slice(0, 600) };
  } catch {
    return undefined;
  }
}

function parseCsvShape(text: string): DataShape | undefined {
  const rows = text.trim() ? text.trim().split(/\r?\n/) : [];
  if (rows.length < 1) return undefined;
  const delimiter = rows[0].includes("\t") ? "\t" : rows[0].includes(";") ? ";" : ",";
  const keys = rows[0].split(delimiter).map((key) => key.trim().replace(/^['"]|['"]$/g, "")).filter(Boolean);
  return { kind: "csv", rows: Math.max(rows.length - 1, 0), columns: keys.length, keys: keys.slice(0, 10), preview: rows.slice(0, 3).join("\n").slice(0, 600) };
}

export function parseDataShape(text: string, name: string): DataShape | undefined {
  const ext = extension(name);
  if (ext === "json") return parseJsonShape(text);
  if (ext === "csv" || ext === "tsv") return parseCsvShape(text);
  return undefined;
}

export function analyzeArtifact(file: Pick<ImportedArtifact, "text" | "name" | "opaque">, rules: AnalysisRule[] = DEFAULT_RULES): Analysis {
  const text = file.text ?? "";
  const lines = text ? text.split(/\r?\n/).length : 0;
  const words = text.match(/[A-Za-z0-9_$-]+/g) ?? [];
  const symbolMatches = [
    ...Array.from(text.matchAll(/\b(?:function|class|const|let|var|def|fn|interface|type)\s+([A-Za-z_$][\w$]*)/g)),
    ...Array.from(text.matchAll(/\b([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*(?:=>|\{)/g)),
  ];
  const imports = [
    ...Array.from(text.matchAll(/(?:from\s+|import\s*\(?\s*|require\s*\(\s*)["']([^"']+)["']/g)),
    ...Array.from(text.matchAll(/#include\s*[<"]([^>"]+)[>"]/g)),
  ].map((match) => match[1]);
  const frequency = new Map<string, number>();
  words.forEach((term) => {
    const normalized = term.toLowerCase();
    if (normalized.length >= 3 && !STOP_WORDS.has(normalized)) frequency.set(normalized, (frequency.get(normalized) ?? 0) + 1);
  });
  const behaviors: Behavior[] = [];
  rules.filter((rule) => rule.enabled).forEach((rule) => {
    try {
      if (new RegExp(rule.pattern, "i").test(text)) behaviors.push({ label: rule.name, detail: rule.detail, tone: rule.tone });
    } catch {
      // Invalid custom rules are ignored rather than crashing analysis.
    }
  });
  const slots = Array.from(new Set(words.map((term) => (hash(term.toLowerCase()) % 64) + 1))).sort((a, b) => a - b);
  return {
    lines,
    words: words.length,
    tokens: new Set(words.map((word) => word.toLowerCase())).size,
    characters: text.length,
    symbols: Array.from(new Set(symbolMatches.map((match) => match[1]))).slice(0, 10),
    imports: Array.from(new Set(imports)).slice(0, 12),
    behaviors,
    concepts: Array.from(frequency.entries()).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([term, count]) => ({ term, count })),
    slots,
    dataShape: parseDataShape(text, file.name),
  };
}

export type DependencyEvidence = { source: string; resolvedTo?: string };

export function dependencyEvidence(imports: string[], artifacts: ImportedArtifact[]): DependencyEvidence[] {
  const available = artifacts.map((artifact) => artifact.name.replace(/\\\\/g, "/"));
  return imports.map((source) => {
    const normalized = source.replace(/^\.\/?/, "").replace(/\\/g, "/");
    const target = normalized.split("/").pop() ?? normalized;
    const resolvedTo = available.find((name) => {
      const cleanName = name.replace(/\\\\/g, "/");
      return cleanName === normalized || cleanName.endsWith(`/${normalized}`) || cleanName.endsWith(`/${target}`) || cleanName === target;
    });
    return { source, resolvedTo };
  });
}

export function resolveLocalDependencies(imports: string[], artifacts: ImportedArtifact[]) {
  return dependencyEvidence(imports, artifacts).map((item) => item.resolvedTo).filter((value): value is string => Boolean(value));
}

export function normalizeDocumentText(value: string) {
  return value.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim().slice(0, 2_000_000);
}

export function deriveDocumentMetadata(pages: string[]): ArtifactMetadata {
  const headings: string[] = [];
  pages.forEach((pageText) => pageText.split(/\s{2,}/).map((item) => item.trim()).filter((item) => item.length >= 3 && item.length <= 120 && !/[.!?]$/.test(item) && (/^[A-Z0-9 _-]+$/.test(item) || /^[A-Z][A-Za-z0-9 _-]{2,80}$/.test(item))).slice(0, 4).forEach((item) => headings.push(item)));
  return { pages: pages.length, headings: Array.from(new Set(headings)).slice(0, 12) };
}

export async function extractPdfDocument(file: File, onPage?: (page: number, total: number) => void): Promise<{ text: string; metadata: ArtifactMetadata }> {
  const [{ getDocument, GlobalWorkerOptions }, workerModule] = await Promise.all([
    import("pdfjs-dist"),
    import("pdfjs-dist/build/pdf.worker.min.mjs?url"),
  ]);
  GlobalWorkerOptions.workerSrc = workerModule.default;
  const document = await getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const pages: string[] = [];
  const headings: string[] = [];
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent();
    const pageText = content.items.map((item) => ("str" in item ? item.str : "")).join(" ");
    pages.push(pageText);
    pageText.split(/\\s{2,}/).map((item) => item.trim()).filter((item) => item.length >= 3 && item.length <= 120 && !/[.!?]$/.test(item) && (/^[A-Z0-9 _-]+$/.test(item) || /^[A-Z][A-Za-z0-9 _-]{2,80}$/.test(item))).slice(0, 4).forEach((item) => headings.push(item));
    onPage?.(pageNumber, document.numPages);
  }
  return { text: normalizeDocumentText(pages.join("\n\n")), metadata: deriveDocumentMetadata(pages) };
}

export async function extractPdfText(file: File, onPage?: (page: number, total: number) => void): Promise<string> {
  return (await extractPdfDocument(file, onPage)).text;
}

export async function unpackZip(file: File, options: { onProgress?: (progress: number) => void; signal?: AbortSignal } = {}): Promise<ImportedArtifact[]> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const entries = unzipSync(bytes);
  const artifacts: ImportedArtifact[] = [];
  const fileEntries = Object.entries(entries).filter(([name, content]) => !name.endsWith("/") && Boolean(content)).slice(0, 80);
  fileEntries.forEach(([name, content], index) => {
    if (options.signal?.aborted) return;
    options.onProgress?.(Math.round(((index + 1) / fileEntries.length) * 100));
    const readable = isReadable(name);
    let text = "";
    if (readable) text = new TextDecoder().decode(content).slice(0, 2_000_000);
    artifacts.push({ id: crypto.randomUUID(), name, type: readable ? "text/plain" : "application/octet-stream", size: content.byteLength, text, opaque: !readable, source: "archive", parent: file.name, kind: readable ? (extension(name) === "json" ? "json" : extension(name) === "csv" ? "csv" : "text") : "binary" });
  });
  return artifacts;
}

export const SKETCH_CAPABILITIES = {
  scripts: "allow",
  sameOrigin: "deny",
  network: "deny",
  storage: "deny",
  deviceApis: "deny",
} as const;

export function canRunSketch(acknowledged: boolean) {
  return acknowledged === true;
}

export function evaluateSafeExpression(expression: string): number {
  const normalized = expression.trim();
  const words = normalized.match(/[A-Za-z_]+/g) ?? [];
  const allowed = new Set(["sum", "mean", "min", "max", "count", "abs", "round", "sqrt", "pi"]);
  if (!normalized || !/^[0-9A-Za-z_\s()+\-*/%,.]+$/.test(normalized) || words.some((word) => !allowed.has(word))) throw new Error("Expression rejected");
  const sum = (...values: number[]) => values.reduce((total, value) => total + value, 0);
  const mean = (...values: number[]) => (values.length ? sum(...values) / values.length : 0);
  const count = (...values: number[]) => values.length;
  const output = Function("sum", "mean", "min", "max", "count", "abs", "round", "sqrt", "pi", `"use strict"; return (${normalized});`)(sum, mean, Math.min, Math.max, count, Math.abs, Math.round, Math.sqrt, Math.PI);
  if (typeof output !== "number" || !Number.isFinite(output)) throw new Error("Result is not finite");
  return output;
}

export function scoreGateBlueprints(artifacts: ImportedArtifact[], analysis: Analysis | null, mode: GateMode = "mirror", catalog: GateBlueprint[] = GATE_BLUEPRINTS): GateAssignment[] {
  if (!analysis) return [];
  const corpus = `${artifacts.map((artifact) => `${artifact.name} ${artifact.text}`).join(" ")} ${analysis.behaviors.map((behavior) => behavior.label).join(" ")} ${analysis.concepts.map((concept) => concept.term).join(" ")}`.toLowerCase();
  return catalog.map((gate) => {
    const evidence = gate.signalTerms.filter((term) => corpus.includes(term));
    const artifactIds = artifacts.filter((artifact) => gate.signalTerms.some((term) => `${artifact.name} ${artifact.text}`.toLowerCase().includes(term))).map((artifact) => artifact.id);
    const signalScore = evidence.length + (analysis.slots.includes(gate.gate) ? 2 : 0);
    const score = mode === "mirror" ? signalScore : Math.max(0, gate.signalTerms.length + 2 - signalScore);
    return { ...gate, score, evidence, artifactIds };
  }).sort((left, right) => right.score - left.score || left.gate - right.gate).slice(0, 8);
}

export function applyGateConstraints(assignments: GateAssignment[], mode: GateMode): GateSystemState | null {
  const active = assignments[0];
  if (!active) return null;
  const allowedQualities = Array.from(new Set(assignments.slice(0, 3).flatMap((assignment) => assignment.allowedQualities)));
  const focus = mode === "mirror" ? `Amplify ${active.name.toLowerCase()} signals already present in the evidence.` : `Introduce ${active.name.toLowerCase()} as a balancing constraint against the dominant evidence.`;
  return { mode, activeGate: active.gate, allowedQualities, constraint: active.constraint, focus, adjustment: `System state adjusted toward ${allowedQualities.join(" + ")}.` };
}

export function gateConstrainInterrogation(result: string, state?: GateSystemState | null) {
  if (!state) return result;
  const evidenceRequired = state.allowedQualities.includes("precision") || state.allowedQualities.includes("containment");
  return evidenceRequired ? `${result} Gate decision: retain only evidence-bounded claims under ${state.allowedQualities.join(" + ")}.` : `${result} Gate decision: exploratory interpretation is permitted under ${state.allowedQualities.join(" + ")}.`;
}

export function gateAllowsExecution(state: GateSystemState | null) {
  if (!state) return { allowed: true, reason: "No gate constraint applied." };
  if (state.mode === "complement" && !state.allowedQualities.includes("containment")) return { allowed: false, reason: `Gate ${String(state.activeGate).padStart(2, "0")} blocks execution until containment is an allowed quality.` };
  return { allowed: true, reason: `Gate ${String(state.activeGate).padStart(2, "0")} permits the safe primitive path under ${state.allowedQualities.join(" + ")}.` };
}

export function evaluateWithGate(expression: string, state: GateSystemState | null) {
  const decision = gateAllowsExecution(state);
  if (!decision.allowed) throw new Error(decision.reason);
  return { value: evaluateSafeExpression(expression), reason: decision.reason };
}

export function buildGateExperience(state: GateSystemState, assignments: GateAssignment[]) {
  const active = assignments.find((assignment) => assignment.gate === state.activeGate);
  return `${state.mode === "mirror" ? "Mirrored" : "Complemented"} gate ${String(state.activeGate).padStart(2, "0")} · ${active?.name ?? "Unknown"}. ${state.adjustment} Evidence: ${active?.evidence.join(", ") || "no direct signal; constraint remains exploratory"}.`;
}

export function buildEvidencePacket(artifacts: ImportedArtifact[], selectedId?: string) {
  return artifacts.map((artifact) => {
    const localAnalysis = artifact.opaque ? null : analyzeArtifact(artifact);
    return {
      id: artifact.id,
      name: artifact.name,
      type: artifact.type,
      kind: artifact.kind,
      source: artifact.source,
      parent: artifact.parent,
      size: artifact.size,
      opaque: artifact.opaque,
      selected: artifact.id === selectedId,
      text: artifact.opaque ? "[opaque binary; no text extracted]" : artifact.text.slice(0, 12000),
      relationshipEvidence: localAnalysis ? dependencyEvidence(localAnalysis.imports, artifacts).map((edge) => ({ source: edge.source, resolvedTo: edge.resolvedTo ?? null })) : [],
      structuralFacts: localAnalysis ? {
        lines: localAnalysis.lines,
        words: localAnalysis.words,
        symbols: localAnalysis.symbols,
        imports: localAnalysis.imports,
        behaviors: localAnalysis.behaviors.map((behavior) => behavior.label),
        concepts: localAnalysis.concepts,
        dataShape: localAnalysis.dataShape,
        metadata: artifact.metadata,
      } : null,
    };
  });
}

export function queryRecord(prompt: string, artifacts: ImportedArtifact[], analysis: Analysis | null, gateState?: GateSystemState | null) {
  if (!analysis) return "Load a readable local artifact first; there is no analysis record yet.";
  const normalized = prompt.trim().toLowerCase();
  if (!normalized) return "Try: “What depends on this?”, “What behaviors are present?”, or “Reduce this to primitives.”";
  const constraintNote = gateState ? ` Gate ${String(gateState.activeGate).padStart(2, "0")} constraint applied: ${gateState.allowedQualities.join(" + ")}.` : "";
  if (/depend|import|relation/.test(normalized)) {
    const available = artifacts.map((artifact) => artifact.name);
    const evidence = dependencyEvidence(analysis.imports, artifacts);
    const matches = evidence.flatMap((item) => item.resolvedTo ? [item.resolvedTo] : []);
    const unresolved = evidence.filter((item) => !item.resolvedTo).map((item) => item.source);
    return gateConstrainInterrogation(analysis.imports.length ? `Dependency trace: ${analysis.imports.join(", ")}. ${matches.length ? `Resolved locally: ${matches.join(", ")}.` : "No local references resolved."} ${unresolved.length ? `Unresolved references: ${unresolved.join(", ")}.` : "No unresolved references."}${constraintNote}` : `No explicit import, require, or include references were found in this readable artifact.${constraintNote}`, gateState);
  }
  if (/behav|do|network|event|state|rule/.test(normalized)) return gateConstrainInterrogation(analysis.behaviors.length ? `Behavior ledger: ${analysis.behaviors.map((behavior) => behavior.label.toLowerCase()).join("; ")}. These are lexical signals, not a runtime verdict.` : "No enabled relationship rules matched. This is a lexical result, not a proof of absence.", gateState);
  if (/primitive|reduce|smallest|math/.test(normalized)) return gateConstrainInterrogation(`Primitive reduction: ${analysis.characters} characters → ${analysis.words} lexical units → ${analysis.tokens} unique tokens → ${analysis.slots.length} active structural slots. The runner accepts only whitelisted math expressions.`, gateState);
  if (/meaning|concept|about/.test(normalized)) return analysis.concepts.length ? `Most repeated concepts: ${analysis.concepts.map((concept) => `${concept.term} (${concept.count})`).join(", ")}. Repetition is an index, not an interpretation.` : "There are not enough repeated terms for a compact concept index.";
  return "I can trace explicit references, local matches, lexical rule signals, repeated concepts, and primitive counts. Phrase the question around one of those scopes.";
}

export type StoredProject = { id: string; name: string; updatedAt: number; artifacts: ImportedArtifact[]; rules: AnalysisRule[]; history: string[]; gateRules: GateBlueprint[] };

const DB_NAME = "meaning-mesh-64";
const STORE_NAME = "projects";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("IndexedDB is not available in this browser"));
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open local project store"));
  });
}

export async function saveProject(project: StoredProject) {
  try {
    const database = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const request = database.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).put(project);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error("Could not save project"));
    });
    database.close();
  } catch {
    // The app remains usable in-memory in browsers with storage disabled.
  }
}

export async function loadLatestProject(): Promise<StoredProject | null> {
  try {
    const database = await openDatabase();
    const projects = await new Promise<StoredProject[]>((resolve, reject) => {
      const request = database.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
      request.onsuccess = () => resolve(request.result as StoredProject[]);
      request.onerror = () => reject(request.error ?? new Error("Could not read local projects"));
    });
    database.close();
    return projects.sort((a, b) => b.updatedAt - a.updatedAt)[0] ?? null;
  } catch {
    return null;
  }
}

export async function deleteAllProjects() {
  try {
    const database = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const request = database.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error("Could not clear local projects"));
    });
    database.close();
  } catch {
    // Clearing the in-memory state still works if storage is unavailable.
  }
}

