import { zipSync } from "fflate";
import { normalizeGroundedResponse } from "./grounding";
import { parseGroundedModelContent } from "../../../server/grounding";
import { describe, expect, it } from "vitest";
import { DEFAULT_RULES, GATE_BLUEPRINTS, analyzeArtifact, applyGateConstraints, buildEvidencePacket, canRunSketch, dependencyEvidence, deriveDocumentMetadata, evaluateSafeExpression, evaluateWithGate, filterGateBlueprints, gateAllowsExecution, gateConstrainInterrogation, normalizeDocumentText, parseDataShape, queryRecord, scoreGateBlueprints, unpackZip, validateGateRules } from "./analysis";

describe("Meaning Mesh analysis primitives", () => {
  it("indexes imports, enabled behavior rules, concepts, and 64 slots", () => {
    const artifact = {
      name: "main.ts",
      opaque: false,
      text: `import { run } from "./engine";\nconst run = () => fetch("/data");\n// TODO: wire button\nrun();`,
    };
    const result = analyzeArtifact(artifact, DEFAULT_RULES);
    expect(result.imports).toContain("./engine");
    expect(result.behaviors.map((behavior) => behavior.label)).toEqual(expect.arrayContaining(["Network surface", "Open work marker"]));
    expect(result.slots.every((slot) => slot >= 1 && slot <= 64)).toBe(true);
    expect(result.concepts.some((concept) => concept.term === "run")).toBe(true);
  });

  it("understands JSON and CSV structure without inventing rows", () => {
    expect(parseDataShape('[{"id":1,"name":"A"},{"id":2,"name":"B"}]', "items.json")).toMatchObject({ kind: "json", rows: 2, columns: 2 });
    expect(parseDataShape("id,name\n1,A\n2,B", "items.csv")).toMatchObject({ kind: "csv", rows: 2, columns: 2, keys: ["id", "name"] });
  });

  it("normalizes extracted document text without inventing content", () => {
    expect(normalizeDocumentText(`  Page   one  



 Page two `)).toBe(`Page one 

 Page two`);
  });

  it("scores the 64-gate blueprint and applies mode-specific constraints", () => {
    const artifact = { name: "system.js", text: "export function system(){ return rule + precision; }", opaque: false };
    const localAnalysis = analyzeArtifact(artifact);
    const mirror = scoreGateBlueprints([{ id: "a", name: "system.js", type: "text/javascript", size: 44, text: artifact.text, opaque: false, source: "local", kind: "text" }], localAnalysis, "mirror");
    const complement = scoreGateBlueprints([{ id: "a", name: "system.js", type: "text/javascript", size: 44, text: artifact.text, opaque: false, source: "local", kind: "text" }], localAnalysis, "complement");
    expect(mirror).toHaveLength(8);
    expect(mirror[0]?.evidence.length).toBeGreaterThan(0);
    expect(mirror.some((assignment) => assignment.artifactIds.includes("a"))).toBe(true);
    expect(applyGateConstraints(mirror, "mirror")?.mode).toBe("mirror");
    expect(applyGateConstraints(complement, "complement")?.mode).toBe("complement");
  });

  it("lets gate qualities alter interrogation and execution decisions", () => {
    const state = { mode: "complement" as const, activeGate: 7, allowedQualities: ["precision"], constraint: "test", focus: "test", adjustment: "test" };
    expect(gateConstrainInterrogation("Trace", state)).toContain("evidence-bounded");
    expect(gateAllowsExecution(state).allowed).toBe(false);
    expect(gateAllowsExecution({ ...state, allowedQualities: ["containment"] }).allowed).toBe(true);
    expect(() => evaluateWithGate("2 + 2", state)).toThrow(/blocks execution/);
    expect(evaluateWithGate("2 + 2", { ...state, allowedQualities: ["containment"] }).value).toBe(4);
  });

  it("validates full gate-rule JSON and filters the editor catalog", () => {
    expect(validateGateRules({ gates: GATE_BLUEPRINTS })).toHaveLength(64);
    expect(filterGateBlueprints(GATE_BLUEPRINTS, "precision").length).toBeGreaterThan(0);
    expect(() => validateGateRules({ gates: GATE_BLUEPRINTS.slice(0, 63) })).toThrow(/exactly 64/);
    expect(() => validateGateRules({ gates: GATE_BLUEPRINTS.map((gate, index) => index === 0 ? { ...gate, signalTerms: [] } : gate) })).toThrow(/signal terms/);
  });

  it("validates grounded server responses and rejects uncited output", () => {
    const valid = JSON.stringify({ answer: "A", purpose: "P", observedFacts: ["F"], inferredRelationships: [], behaviors: [], dependencies: [], unknowns: ["U"], confidence: "medium", evidenceRefs: [{ artifactId: "a", claim: "F" }] });
    expect(parseGroundedModelContent(valid).evidenceRefs[0]?.artifactId).toBe("a");
    expect(() => parseGroundedModelContent(JSON.stringify({ answer: "A", purpose: "P", observedFacts: [], inferredRelationships: [], behaviors: [], dependencies: [], unknowns: [], confidence: "high" }))).toThrow();
  });

  it("accepts grounded responses only when confidence and evidence references are present", () => {
    expect(normalizeGroundedResponse({ purpose: "x", observedFacts: [], inferredRelationships: [], behaviors: [], dependencies: [], unknowns: [], confidence: "high", evidenceRefs: [{ artifactId: "a", claim: "observed" }] })).not.toBeNull();
    expect(normalizeGroundedResponse({ purpose: "x", observedFacts: [], inferredRelationships: [], behaviors: [], dependencies: [], unknowns: [], confidence: "high" })).toBeNull();
  });

  it("builds a bounded evidence packet with structural facts and selection state", () => {
    const packet = buildEvidencePacket([{ id: "a", name: "main.js", type: "text/javascript", size: 24, text: "export const run = () => 1", opaque: false, source: "local", kind: "text" }], "a");
    expect(packet[0]).toMatchObject({ name: "main.js", selected: true, text: "export const run = () => 1", structuralFacts: { symbols: ["run"] } });
  });

  it("captures page count and likely headings without changing page text", () => {
    expect(deriveDocumentMetadata(["TITLE  Introductory text.", "SECOND PAGE  More text."])).toEqual({ pages: 2, headings: ["TITLE", "SECOND PAGE"] });
  });

  it("reports archive progress and honors cancellation", async () => {
    const file = new File([zipSync({ "src/main.ts": new TextEncoder().encode("export const main = 1"), "README.md": new TextEncoder().encode("Notes") })], "bundle.zip");
    const progress: number[] = [];
    const artifacts = await unpackZip(file, { onProgress: (value) => progress.push(value) });
    expect(artifacts).toHaveLength(2);
    expect(progress.at(-1)).toBe(100);
    const controller = new AbortController();
    controller.abort();
    expect(await unpackZip(file, { signal: controller.signal })).toEqual([]);
  });

  it("reports unresolved imports separately from resolved local references", () => {
    const artifacts = [{ id: "a", name: "engine.ts", type: "text/plain", size: 10, text: "", opaque: false, source: "local" as const, kind: "text" as const }];
    expect(dependencyEvidence(["./engine.ts", "missing"], artifacts)).toEqual([{ source: "./engine.ts", resolvedTo: "engine.ts" }, { source: "missing" }]);
  });

  it("requires explicit acknowledgment before a sketch can run", () => {
    expect(canRunSketch(false)).toBe(false);
    expect(canRunSketch(true)).toBe(true);
  });

  it("evaluates only the documented primitive math vocabulary", () => {
    expect(evaluateSafeExpression("mean(4, 12, 20) + sqrt(81)")).toBe(21);
    expect(() => evaluateSafeExpression("document.cookie")).toThrow();
    expect(() => evaluateSafeExpression("fetch('https://example.com')")).toThrow();
  });

  it("resolves a dependency to another local artifact when names match", () => {
    const artifacts = [
      { id: "a", name: "main.ts", type: "text/plain", size: 10, text: 'import "./engine.ts"', opaque: false, source: "local" as const, kind: "text" as const },
      { id: "b", name: "engine.ts", type: "text/plain", size: 10, text: "export const run = 1", opaque: false, source: "local" as const, kind: "text" as const },
    ];
    const result = queryRecord("what depends on this?", artifacts, analyzeArtifact(artifacts[0]));
    expect(result).toContain("Resolved locally: engine.ts");
  });
});
