/**
 * Quiet Instrument design: a graphite, text-first analysis workstation. The new project layer keeps
 * the visual language restrained while making persistence, archive inspection, relationship rules,
 * and isolated browser sketches concrete and inspectable.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Archive,
  ArrowUpRight,
  Braces,
  ChevronRight,
  CircleDot,
  Code2,
  Database,
  Download,
  FileCode2,
  FileSearch,
  FolderOpen,
  Gauge,
  HardDrive,
  Inbox,
  Play,
  Plus,
  Save,
  ScanSearch,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Table2,
  TerminalSquare,
  Trash2,
  X,
} from "lucide-react";
import {
  AnalysisRule,
  DEFAULT_RULES,
  GATE_BLUEPRINTS,
  ImportedArtifact,
  StoredProject,
  UnderstandingRecord,
  analyzeArtifact,
  applyGateConstraints,
  buildGateExperience,
  buildEvidencePacket,
  canRunSketch,
  deleteAllProjects,
  dependencyEvidence,
  extractPdfDocument,
  evaluateSafeExpression,
  filterGateBlueprints,
  evaluateWithGate,
  extension,
  formatSize,
  isReadable,
  loadLatestProject,
  number,
  queryRecord,
  scoreGateBlueprints,
  saveProject,
  validateGateRules,
  unpackZip,
} from "@/lib/analysis";
import { normalizeGroundedResponse } from "@/lib/grounding";

type View = "Ingest" | "Investigate" | "Reduce";

type StatusTone = "green" | "amber" | "muted";

function Status({ children, tone = "muted" }: { children: React.ReactNode; tone?: StatusTone }) {
  return <span className={`status status--${tone}`}>{children}</span>;
}

function freshProject(): StoredProject {
  return {
    id: crypto.randomUUID(),
    name: "Untitled local project",
    updatedAt: Date.now(),
    artifacts: [],
    rules: DEFAULT_RULES.map((rule) => ({ ...rule })),
    history: [],
    gateRules: GATE_BLUEPRINTS.map((gate) => ({ ...gate, allowedQualities: [...gate.allowedQualities], signalTerms: [...gate.signalTerms] })),
  };
}

function kindLabel(artifact: ImportedArtifact) {
  if (artifact.kind === "archive") return "ZIP";
  if (artifact.kind === "json") return "JSON";
  if (artifact.kind === "csv") return "CSV";
  if (artifact.kind === "pdf") return "PDF";
  if (artifact.opaque) return "BINARY";
  return extension(artifact.name).toUpperCase();
}

function sketchStarter() {
  return `<!doctype html>
<html>
  <head><meta charset="utf-8"><style>
    :root { color-scheme: dark; font-family: system-ui, sans-serif; }
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #101313; color: #e5ebe7; }
    button { border: 1px solid #74d99f; background: #74d99f; color: #092616; padding: 10px 14px; cursor: pointer; }
    small { display: block; margin-top: 12px; color: #a0aaa5; text-align: center; }
  </style></head>
  <body><div><button id="action">Run local sketch</button><small id="result">No host access · no network</small></div>
    <script>document.querySelector('#action').onclick = () => document.querySelector('#result').textContent = 'Sketch event handled locally';</script>
  </body>
</html>`;
}

export default function Home() {
  const [project, setProject] = useState<StoredProject>(() => freshProject());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<View>("Ingest");
  const [dragging, setDragging] = useState(false);
  const [query, setQuery] = useState("");
  const [queryResult, setQueryResult] = useState("Ask about dependencies, behaviors, concepts, or primitives.");
  const [expression, setExpression] = useState("mean(4, 12, 20) + sqrt(81)");
  const [execution, setExecution] = useState("Ready for a primitive-only expression.");
  const [grammar, setGrammar] = useState("A factual account will appear here after an artifact is inspected.");
  const [understanding, setUnderstanding] = useState<UnderstandingRecord | null>(null);
  const [understandingBusy, setUnderstandingBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [ready, setReady] = useState(false);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [ruleName, setRuleName] = useState("");
  const [rulePattern, setRulePattern] = useState("");
  const [ruleDetail, setRuleDetail] = useState("");
  const [ruleTone, setRuleTone] = useState<AnalysisRule["tone"]>("neutral");
  const [runnerOpen, setRunnerOpen] = useState(false);
  const [runnerHtml, setRunnerHtml] = useState(sketchStarter);
  const [runnerAcknowledged, setRunnerAcknowledged] = useState(false);
  const [runnerVersion, setRunnerVersion] = useState(0);
  const [gateMode, setGateMode] = useState<"mirror" | "complement">("mirror");
  const [gateEditorNumber, setGateEditorNumber] = useState(1);
  const [gateSearch, setGateSearch] = useState("");
  const [gateState, setGateState] = useState<ReturnType<typeof applyGateConstraints>>(null);
  const [gateExperience, setGateExperience] = useState("No gate constraint applied.");
  const [gateQualitiesInput, setGateQualitiesInput] = useState("");
  const [gateConstraintInput, setGateConstraintInput] = useState("");
  const [gateSignalsInput, setGateSignalsInput] = useState("");
  const [importProgress, setImportProgress] = useState<number | null>(null);
  const importControllerRef = useRef<AbortController | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const gateInputRef = useRef<HTMLInputElement>(null);
  const gateTransitionRef = useRef<number | null>(null);

  useEffect(() => {
    loadLatestProject().then((saved) => {
      if (saved) {
        setProject({ ...saved, gateRules: saved.gateRules?.length ? saved.gateRules : GATE_BLUEPRINTS });
        setActiveId(saved.artifacts.find((artifact) => !artifact.opaque)?.id ?? saved.artifacts[0]?.id ?? null);
      }
      setReady(true);
    });
  }, []);

  useEffect(() => {
    if (ready) void saveProject(project);
  }, [project, ready]);

  const currentFile = project.artifacts.find((artifact) => artifact.id === activeId) ?? null;
  const analysis = useMemo(() => currentFile && !currentFile.opaque ? analyzeArtifact(currentFile, project.rules) : null, [currentFile, project.rules]);
  const slotsText = analysis?.slots.length ? analysis.slots.map((slot) => String(slot).padStart(2, "0")).join(" · ") : "No active slots";
  const dependencyRows = useMemo(() => analysis ? dependencyEvidence(analysis.imports, project.artifacts) : [], [analysis, project.artifacts]);
  const gateAssignments = useMemo(() => scoreGateBlueprints(project.artifacts, analysis, gateMode, project.gateRules), [project.artifacts, analysis, gateMode, project.gateRules]);
  const gateEditorRule = project.gateRules.find((gate) => gate.gate === gateEditorNumber) ?? project.gateRules[0];
  const filteredGateRules = useMemo(() => filterGateBlueprints(project.gateRules, gateSearch), [project.gateRules, gateSearch]);

  useEffect(() => {
    const activeDefinition = gateAssignments[0];
    if (activeDefinition) {
      setGateQualitiesInput(activeDefinition.allowedQualities.join(", "));
      setGateConstraintInput(activeDefinition.constraint);
    }
    const nextState = applyGateConstraints(gateAssignments, gateMode);
    if (nextState && gateTransitionRef.current !== nextState.activeGate) {
      gateTransitionRef.current = nextState.activeGate;
      updateProject((value) => ({ ...value, history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · Active gate ${String(nextState.activeGate).padStart(2, "0")} · artifacts ${gateAssignments[0]?.artifactIds.join(", ") || "none"}`] }));
    }
    setGateState(nextState);
    setGateExperience(nextState ? buildGateExperience(nextState, gateAssignments) : "No gate constraint applied.");
  }, [gateAssignments, gateMode]);

  useEffect(() => {
    if (gateEditorRule) {
      setGateQualitiesInput(gateEditorRule.allowedQualities.join(", "));
      setGateConstraintInput(gateEditorRule.constraint);
      setGateSignalsInput(gateEditorRule.signalTerms.join(", "));
    }
  }, [gateEditorRule]);

  function saveGateRule() {
    const activeGate = gateEditorRule;
    if (!activeGate) return;
    const allowedQualities = gateQualitiesInput.split(",").map((quality) => quality.trim().toLowerCase()).filter(Boolean).slice(0, 6);
    const signalTerms = gateSignalsInput.split(",").map((term) => term.trim().toLowerCase()).filter(Boolean).slice(0, 8);
    if (!allowedQualities.length || !gateConstraintInput.trim() || !signalTerms.length) {
      setNotice("A gate needs at least one allowed quality and a constraint statement.");
      return;
    }
    updateProject((value) => ({ ...value, gateRules: value.gateRules.map((gate) => gate.gate === activeGate.gate ? { ...gate, allowedQualities, constraint: gateConstraintInput.trim(), signalTerms } : gate), history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · Edited gate ${String(activeGate.gate).padStart(2, "0")} blueprint`] }));
    setNotice(`Saved gate ${String(activeGate.gate).padStart(2, "0")} blueprint rule.`);
  }

  function exportGateRules() {
    const blob = new Blob([JSON.stringify({ format: "meaning-mesh-64-gates", version: 1, gates: project.gateRules }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "meaning-mesh-64-gates.json";
    link.click();
    URL.revokeObjectURL(url);
    setNotice("Gate rules exported as portable JSON.");
  }

  async function importGateRules(file?: File) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as { gates?: unknown };
      const gateRules = validateGateRules(parsed.gates);
      updateProject((value) => ({ ...value, gateRules, history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · Imported 64 gate rules`] }));
      setNotice("Imported and persisted 64 gate rules.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Gate rule import rejected.");
    }
  }

  function applyGateMode(mode: "mirror" | "complement") {
    setGateMode(mode);
    const assignments = scoreGateBlueprints(project.artifacts, analysis, mode, project.gateRules);
    const nextState = applyGateConstraints(assignments, mode);
    setGateState(nextState);
    setGateExperience(nextState ? buildGateExperience(nextState, assignments) : "Load a readable artifact before applying a gate constraint.");
    updateProject((value) => ({ ...value, history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · Gate mode ${mode} · ${nextState ? `gate ${String(nextState.activeGate).padStart(2, "0")} · ${nextState.allowedQualities.join(" + ")}` : "no active gate"}`] }));
  }

  function updateProject(next: (value: StoredProject) => StoredProject) {
    setProject((value) => next({ ...value, updatedAt: Date.now() }));
  }

  function logAction(message: string) {
    updateProject((value) => ({ ...value, history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · ${message}`] }));
  }

  async function importFiles(fileList?: FileList | File[]) {
    if (!fileList) return;
    const candidates = Array.from(fileList);
    const imported: ImportedArtifact[] = [];
    const skipped: string[] = [];
    importControllerRef.current?.abort();
    const controller = new AbortController();
    importControllerRef.current = controller;
    setImportProgress(0);
    for (let index = 0; index < candidates.length; index += 1) {
      const candidate = candidates[index];
      if (!candidate) continue;
      if (controller.signal.aborted) {
        setNotice("Import cancelled. Files already indexed remain local.");
        setImportProgress(null);
        return;
      }
      setImportProgress(Math.round((index / candidates.length) * 100));
      if (candidate.size > 8 * 1024 * 1024) {
        skipped.push(`${candidate.name} exceeds 8 MB`);
        continue;
      }
      if (extension(candidate.name) === "pdf") {
        try {
          const extracted = await extractPdfDocument(candidate, (page, total) => setImportProgress(Math.round(((index + page / total) / candidates.length) * 100)));
          imported.push({ id: crypto.randomUUID(), name: candidate.name, type: "application/pdf", size: candidate.size, text: extracted.text, metadata: extracted.metadata, opaque: false, source: "local", kind: "pdf" });
        } catch {
          skipped.push(`${candidate.name} could not be extracted as PDF`);
        }
        continue;
      }
      if (extension(candidate.name) === "zip") {
        try {
          const children = await unpackZip(candidate, { signal: controller.signal, onProgress: (progress) => setImportProgress(Math.round(((index + progress / 100) / candidates.length) * 100)) });
          imported.push({ id: crypto.randomUUID(), name: candidate.name, type: "application/zip", size: candidate.size, text: "", opaque: false, source: "local", kind: "archive" }, ...children);
        } catch {
          skipped.push(`${candidate.name} could not be read as ZIP`);
        }
        continue;
      }
      if (!isReadable(candidate.name, candidate.type)) {
        imported.push({ id: crypto.randomUUID(), name: candidate.name, type: candidate.type || "application/octet-stream", size: candidate.size, text: "", opaque: true, source: "local", kind: "binary" });
        continue;
      }
      try {
        const text = (await candidate.text()).slice(0, 2_000_000);
        const ext = extension(candidate.name);
        imported.push({ id: crypto.randomUUID(), name: candidate.name, type: candidate.type || "text/plain", size: candidate.size, text, opaque: false, source: "local", kind: ext === "json" ? "json" : ext === "csv" || ext === "tsv" ? "csv" : "text" });
      } catch {
        skipped.push(`${candidate.name} could not be read as text`);
      }
    }
    setImportProgress(null);
    importControllerRef.current = null;
    if (!imported.length) {
      setNotice(skipped.length ? skipped.join(" · ") : "No files were selected.");
      return;
    }
    updateProject((value) => ({ ...value, artifacts: [...value.artifacts, ...imported], history: [...value.history.slice(-19), `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · Imported ${imported.length} local artifact${imported.length === 1 ? "" : "s"}`] }));
    const firstReadable = imported.find((artifact) => !artifact.opaque);
    setActiveId(firstReadable?.id ?? imported[0].id);
    setNotice(`Indexed ${imported.length} local artifact${imported.length === 1 ? "" : "s"}. Nothing was uploaded.${skipped.length ? ` Skipped: ${skipped.join(" · ")}` : ""}`);
    setQueryResult("Ask about dependencies, behaviors, concepts, or primitives.");
    setUnderstanding(null);
    setGrammar("A factual account will appear here after an artifact is inspected.");
  }

  async function askQuestion() {
    const localResult = queryRecord(query, project.artifacts, analysis, gateState);
    setQueryResult(localResult);
    if (!analysis) return;
    await runUnderstanding(query);
    logAction(`Interrogated ${currentFile?.name ?? "record"}`);
  }

  async function runUnderstanding(question?: string) {
    if (!project.artifacts.length) {
      setNotice("Load an artifact before asking the evidence analyst.");
      return;
    }
    setUnderstandingBusy(true);
    try {
      const response = await fetch("/api/understand", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question, evidencePacket: buildEvidencePacket(project.artifacts, currentFile?.id) }) });
      const rawBody = await response.json() as UnderstandingRecord & { error?: string };
      if (!response.ok) throw new Error(rawBody.error || "Grounded analysis unavailable");
      const body = normalizeGroundedResponse(rawBody);
      if (!body) throw new Error("The analyst returned an incomplete or uncited understanding record");
      setUnderstanding(body);
      if (body.answer) setQueryResult(body.answer);
      setGrammar(body.purpose);
      logAction(question ? "Received grounded interrogation" : "Built grounded understanding record");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Grounded analysis unavailable");
    } finally {
      setUnderstandingBusy(false);
    }
  }

  function runExpression() {
    try {
      const result = evaluateWithGate(expression, gateState);
      setExecution(`Output · ${result.value} · ${result.reason}`);
      logAction("Ran safe primitive expression");
    } catch (error) {
      setExecution(error instanceof Error ? `Rejected · ${error.message}` : "Rejected. Use numbers, parentheses, arithmetic, and only: sum, mean, min, max, count, abs, round, sqrt, pi.");
    }
  }

  function generateAccount() {
    if (!analysis || !currentFile) {
      setGrammar("Load a readable artifact first. The grammar only summarizes facts already in the local record.");
      return;
    }
    const dependencyClause = analysis.imports.length ? `It explicitly references ${analysis.imports.slice(0, 3).join(", ")}.` : "It exposes no explicit import, require, or include reference in the inspected text.";
    const behaviorClause = analysis.behaviors.length ? `Its enabled rules point to ${analysis.behaviors.map((behavior) => behavior.label.toLowerCase()).join(" and ")}.` : "No enabled lexical rule matched.";
    setGrammar(`${currentFile.name} resolves to ${analysis.tokens} distinct terms across ${analysis.lines} lines. ${dependencyClause} ${behaviorClause} Its structural footprint occupies ${analysis.slots.length} of 64 background slots.`);
    logAction(`Generated account for ${currentFile.name}`);
  }

  function exportProject() {
    const blob = new Blob([JSON.stringify(project, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${project.name.toLowerCase().replace(/[^a-z0-9]+/g, "-") || "meaning-mesh-project"}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setNotice("Portable local project export created.");
    logAction("Exported project JSON");
  }

  async function clearStorage() {
    await deleteAllProjects();
    const next = freshProject();
    setProject(next);
    setActiveId(null);
    setNotice("Local projects cleared from this browser.");
  }

  function addRule() {
    if (!ruleName.trim() || !rulePattern.trim()) {
      setNotice("A rule needs a name and a regular-expression pattern.");
      return;
    }
    try {
      new RegExp(rulePattern, "i");
    } catch {
      setNotice("The rule pattern is not a valid regular expression.");
      return;
    }
    const rule: AnalysisRule = { id: `custom-${crypto.randomUUID()}`, name: ruleName.trim(), pattern: rulePattern.trim(), detail: ruleDetail.trim() || "Custom lexical relationship rule.", tone: ruleTone, enabled: true };
    updateProject((value) => ({ ...value, rules: [...value.rules, rule] }));
    setRuleName(""); setRulePattern(""); setRuleDetail(""); setNotice(`Added rule “${rule.name}”.`);
  }

  function toggleRule(ruleId: string) {
    updateProject((value) => ({ ...value, rules: value.rules.map((rule) => rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule) }));
  }

  function removeRule(ruleId: string) {
    updateProject((value) => ({ ...value, rules: value.rules.filter((rule) => rule.id !== ruleId) }));
  }

  function runSketch() {
    if (!canRunSketch(runnerAcknowledged)) {
      setNotice("Acknowledge the sketch capability boundary before running it.");
      return;
    }
    setRunnerVersion((version) => version + 1);
    logAction("Ran isolated browser sketch");
  }

  return (
    <main className="instrument-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <img className="brand-mark" src="/manus-storage/meaning-mesh-mark_13a7f148.png" alt="Meaning Mesh 64 coordinate mark" />
          <div><p className="brand-name">MEANING MESH <span>64</span></p><p className="brand-caption">local analysis instrument</p></div>
        </div>
        <div className="project-header">
          <input aria-label="Project name" value={project.name} onChange={(event) => updateProject((value) => ({ ...value, name: event.target.value }))} />
          <button className="quiet-icon-button" onClick={exportProject} title="Export local project"><Download size={15} /></button>
          <Status tone="green"><ShieldCheck size={12} /> LOCAL ONLY</Status>
        </div>
      </header>

      <section className="workspace">
        <aside className="left-rail" aria-label="Workspace navigation">
          <div className="rail-section">
            <p className="eyebrow">WORKSPACE</p>
            {([{ icon: Inbox, label: "Ingest" }, { icon: ScanSearch, label: "Investigate" }, { icon: Braces, label: "Reduce" }] as const).map(({ icon: Icon, label }) => (
              <button key={label} className={`rail-button ${activeView === label ? "is-active" : ""}`} onClick={() => setActiveView(label)}><Icon size={16} /><span>{label}</span><ChevronRight size={14} /></button>
            ))}
          </div>
          <div className="artifact-rail">
            <div className="artifact-rail-heading"><p className="eyebrow">PROJECT FILES</p><span>{project.artifacts.length.toString().padStart(2, "0")}</span></div>
            {project.artifacts.length ? project.artifacts.map((artifact) => <button className={`artifact-rail-item ${artifact.id === activeId ? "is-active" : ""}`} key={artifact.id} onClick={() => { setActiveId(artifact.id); setActiveView("Investigate"); }}><FileCode2 size={14} /><span>{artifact.name}</span><small>{kindLabel(artifact)}</small></button>) : <p className="rail-empty">No local files yet.</p>}
          </div>
          <div className="rail-section rail-section--bottom">
            <p className="eyebrow">SESSION</p>
            <div className="session-stat"><span>Artifacts</span><strong>{project.artifacts.length.toString().padStart(2, "0")}</strong></div>
            <div className="session-stat"><span>Network</span><strong>OFF</strong></div>
            <div className="session-stat"><span>Storage</span><strong>INDEXED</strong></div>
          </div>
        </aside>

        <section className="primary-pane">
          <div className="pane-heading"><div><p className="eyebrow">01 / {activeView.toUpperCase()} / {currentFile ? "ACTIVE RECORD" : "NO RECORD"}</p><h1>{currentFile ? currentFile.name : "Input rail clear"}</h1></div>{currentFile && <button className="text-button" onClick={() => setActiveId(null)}><X size={15} /> Deselect</button>}</div>

          {importProgress !== null && <div className="import-progress" role="status"><span>INGEST / {importProgress}%</span><progress value={importProgress} max={100} /><button className="text-button" onClick={() => { importControllerRef.current?.abort(); setImportProgress(null); setNotice("Import cancellation requested."); }}>Cancel</button></div>}

          {!currentFile ? (
            <div className={`drop-zone ${dragging ? "is-dragging" : ""}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); void importFiles(event.dataTransfer.files); }}>
              <div className="artifact-thumbnail"><img src="/manus-storage/meaning-file-specimen_4255d15c.png" alt="Abstract unclassified artifact specimen" /><span>00 / UNRESOLVED</span></div>
              <div className="index-ruler" aria-label="64-slot structural index"><span>01</span><span>08</span><span>16</span><span>24</span><span>32</span><span>40</span><span>48</span><span>56</span><span>64</span></div>
              <p className="drop-zone__kicker">NO RECORD / SLOT RANGE 01—64</p><h2>Awaiting a local artifact.</h2><p>Import text, JSON, CSV, or a ZIP archive. Everything stays in this browser; unsupported binaries remain opaque.</p>
              <button className="action-button" onClick={() => inputRef.current?.click()}><FolderOpen size={17} /> Choose files</button><p className="picker-fact">NATIVE PICKER · MULTI-FILE · MEMORY + INDEXEDDB</p>
            </div>
          ) : currentFile.opaque ? (
            <div className="opaque-record"><Archive size={28} /><p className="drop-zone__kicker">OPAQUE ARTIFACT / NO DECODER</p><h2>{currentFile.name}</h2><p>This binary file was not decoded or run. Its local metadata is retained: {formatSize(currentFile.size)}, {currentFile.type}.</p><button className="action-button" onClick={() => inputRef.current?.click()}><Plus size={17} /> Add another file</button></div>
          ) : (
            <>
              <section className="metric-strip" aria-label="Artifact metrics">{[{ label: "LINES", value: analysis?.lines ?? 0 }, { label: "WORDS", value: analysis?.words ?? 0 }, { label: "TOKENS", value: analysis?.tokens ?? 0 }, { label: "CHARS", value: analysis?.characters ?? 0 }].map((metric) => <div className="metric" key={metric.label}><span>{metric.label}</span><strong>{number(metric.value)}</strong></div>)}</section>
              <div className="record-index"><span>STRUCTURAL INDEX / 01—64</span><i /><strong>{analysis?.slots.length ?? 0} ACTIVE</strong><p>{slotsText}</p></div>

              {analysis?.dataShape && <section className="data-shape-section"><div className="section-title"><div><p className="eyebrow">00 / STRUCTURED DATA</p><h2>{analysis.dataShape.kind.toUpperCase()} shape</h2></div><Status tone="green"><Table2 size={12} /> {analysis.dataShape.rows} ROWS</Status></div><div className="data-shape-grid"><div><span>Columns</span><strong>{analysis.dataShape.columns}</strong></div><div><span>Keys</span><strong>{analysis.dataShape.keys.join(" · ") || "—"}</strong></div><pre>{analysis.dataShape.preview}</pre></div></section>}

              <section className="report-section"><div className="section-title"><div><p className="eyebrow">01 / EXPLICIT REFERENCES</p><h2>Dependency trace</h2></div><Status tone={analysis?.imports.length ? "green" : "muted"}>{analysis?.imports.length ?? 0} FOUND</Status></div><div className="trace-block"><figure className="evidence-figure"><img src="/manus-storage/meaning-trace-specimen_a287e7c5.png" alt="Abstract dependency trace specimen" /><figcaption>EDGE REGISTER / LOCAL</figcaption></figure><div className="trace-list">{analysis?.imports.length ? analysis.imports.map((item, index) => <div className="trace-row" key={item}><span>{String(index + 1).padStart(2, "0")}</span><code>{item}</code><ArrowUpRight size={14} /></div>) : <p className="empty-copy">No explicit <code>import</code>, <code>require</code>, or <code>include</code> form was found.</p>}</div></div><div className="dependency-evidence"><div className="evidence-table-heading"><span>LOCAL RESOLUTION EVIDENCE</span><span>{dependencyRows.filter((row) => row.resolvedTo).length}/{dependencyRows.length} RESOLVED</span></div>{dependencyRows.length ? dependencyRows.map((row) => <div className="evidence-table-row" key={row.source}><code>{row.source}</code><span className="evidence-arrow">→</span><code>{row.resolvedTo ?? "unresolved"}</code><Status tone={row.resolvedTo ? "green" : "amber"}>{row.resolvedTo ? "LOCAL" : "OPEN"}</Status></div>) : <p className="empty-copy">No dependency references to resolve.</p>}</div></section>

              <section className="report-section report-section--split"><div><div className="section-title"><div><p className="eyebrow">02 / ENABLED RULES</p><h2>Behavior ledger</h2></div></div><div className="behavior-list">{analysis?.behaviors.length ? analysis.behaviors.map((behavior) => <div className="behavior-row" key={behavior.label}><CircleDot size={14} className={`tone-${behavior.tone}`} /><div><strong>{behavior.label}</strong><p>{behavior.detail}</p></div></div>) : <p className="empty-copy">No enabled relationship rules matched this artifact.</p>}</div></div><div><div className="section-title"><div><p className="eyebrow">03 / BOUND SYMBOLS</p><h2>Named structures</h2></div></div><div className="token-cloud">{analysis?.symbols.length ? analysis.symbols.map((symbol) => <code key={symbol}>{symbol}</code>) : <p className="empty-copy">No named declaration pattern was found.</p>}</div></div></section>

              <section className="source-preview"><div className="section-title"><div><p className="eyebrow">04 / SOURCE PREVIEW</p><h2>Read-only local text</h2></div><Status>{kindLabel(currentFile)}</Status></div>{currentFile.metadata && <div className="document-meta"><span>{currentFile.metadata.pages ?? 0} PDF PAGES</span><span>{currentFile.metadata.headings?.length ?? 0} HEADINGS INDEXED</span></div>}<pre>{currentFile.text.slice(0, 1800) || "—"}</pre></section>
            </>
          )}
        </section>

        <aside className="inspector" aria-label="Record inspector">
          <section className="inspector-block"><div className="inspector-title"><Gauge size={16} /><span>Project state</span><Status tone={ready ? "green" : "muted"}>{ready ? "READY" : "LOADING"}</Status></div><div className="state-file"><Database size={18} /><div><strong>{project.name}</strong><span>{project.artifacts.length} artifact{project.artifacts.length === 1 ? "" : "s"} · local project</span></div></div><p className="privacy-note"><ShieldCheck size={14} /> IndexedDB persistence. No remote processing.</p><div className="inspector-actions"><button className="quiet-button" onClick={() => { setProject(freshProject()); setActiveId(null); setNotice("New local project created."); }}><Plus size={14} /> New project</button><button className="quiet-button" onClick={() => void clearStorage()}><Trash2 size={14} /> Clear storage</button></div></section>

          <section className="inspector-block"><div className="inspector-title"><span className="coordinate">01—64</span><span>Structural slots</span><Status tone={analysis?.slots.length ? "green" : "muted"}>{analysis?.slots.length ?? 0} ACTIVE</Status></div><p className="slot-intro">Terms hash into persistent background coordinates. This is an index, not a visual mesh.</p><p className="slot-values">{slotsText}</p></section>

          <section className="inspector-block blueprint-block"><div className="inspector-title"><span className="coordinate">64 GATE</span><span>User-authored blueprint</span><Status tone={gateState ? "green" : "muted"}>{gateState ? `GATE ${String(gateState.activeGate).padStart(2, "0")}` : "IDLE"}</Status></div><p className="slot-intro">Your simulation rule: a gate permits qualities, then the system adjusts toward them. This is an experimental model, not an external diagnosis.</p><div className="gate-toolbar"><label>Search / gate editor<input value={gateSearch} onChange={(event) => setGateSearch(event.target.value)} placeholder="gate, name, quality" /><select value={gateEditorNumber} onChange={(event) => setGateEditorNumber(Number(event.target.value))}>{filteredGateRules.map((gate) => <option key={gate.gate} value={gate.gate}>{String(gate.gate).padStart(2, "0")} · {gate.name}</option>)}</select></label><button className="quiet-button" onClick={exportGateRules}>Export rules</button><button className="quiet-button" onClick={() => gateInputRef.current?.click()}>Import rules</button><input ref={gateInputRef} type="file" accept="application/json" hidden onChange={(event) => { void importGateRules(event.target.files?.[0]); event.target.value = ""; }} /></div><div className="gate-mode"><button className={gateMode === "mirror" ? "mode-button is-active" : "mode-button"} onClick={() => applyGateMode("mirror")}>Mirror</button><button className={gateMode === "complement" ? "mode-button is-active" : "mode-button"} onClick={() => applyGateMode("complement")}>Complement</button></div><div className="gate-editor"><label>Allowed qualities<input value={gateQualitiesInput} onChange={(event) => setGateQualitiesInput(event.target.value)} placeholder="precision, patience" /></label><label>Signal terms<input value={gateSignalsInput} onChange={(event) => setGateSignalsInput(event.target.value)} placeholder="system, rule" /></label><label>Constraint<textarea value={gateConstraintInput} onChange={(event) => setGateConstraintInput(event.target.value)} rows={2} /></label><button className="quiet-button" onClick={saveGateRule}>Save gate rule</button></div>{gateAssignments.slice(0, 3).map((assignment) => <div className="gate-row" key={assignment.gate}><span className="gate-id">{String(assignment.gate).padStart(2, "0")}</span><div><strong>{assignment.name}</strong><p>{assignment.allowedQualities.join(" · ")}</p><small>{assignment.evidence.length ? `evidence: ${assignment.evidence.join(", ")}` : "exploratory connection"}{assignment.artifactIds.length ? ` · artifacts: ${assignment.artifactIds.join(", ")}` : ""}</small></div><span className="gate-score">{assignment.score}</span></div>)}<p className="gate-experience">{gateExperience}</p><p className="slot-intro">Allowed qualities: {gateState?.allowedQualities.join(" · ") || "none applied"}</p><div className="gate-history"><span>Transition history</span>{project.history.filter((item) => item.includes("Gate") || item.includes("gate")).slice(-5).reverse().map((item) => <small key={item}>{item}</small>)}{!project.history.some((item) => item.includes("Gate") || item.includes("gate")) && <small>No gate transitions recorded.</small>}</div></section>

          <section className="inspector-block query-block"><div className="inspector-title"><TerminalSquare size={16} /><span>Interrogate record</span></div><textarea value={query} onChange={(event) => setQuery(event.target.value)} placeholder="What depends on this?" rows={3} /><button className="compact-action" onClick={askQuestion}><ScanSearch size={15} /> Trace meaning</button><p className="console-output">{queryResult}</p></section>

          <section className="inspector-block grammar-block"><div className="inspector-title"><Sparkles size={16} /><span>Evidence understanding</span><Status tone={understanding ? "green" : "muted"}>{understanding ? understanding.confidence.toUpperCase() : "NOT RUN"}</Status></div><p>{grammar}</p><button className="text-button" onClick={() => void runUnderstanding()} disabled={understandingBusy}>{understandingBusy ? "Analyzing evidence…" : "Understand from evidence"} <ArrowUpRight size={14} /></button>{understanding && <div className="understanding-card"><div><span>Observed</span><p>{understanding.observedFacts.join(" · ") || "None returned"}</p></div><div><span>Inferred</span><p>{understanding.inferredRelationships.join(" · ") || "None returned"}</p></div><div><span>Unknowns</span><p>{understanding.unknowns.join(" · ") || "None returned"}</p></div><div><span>Evidence refs</span><p>{understanding.evidenceRefs?.map((ref) => `${ref.artifactId}: ${ref.claim}`).join(" · ") || "No claim references returned"}</p></div></div>}</section>

          <section className="inspector-block rules-block"><button className="inspector-title inspector-title-button" onClick={() => setRulesOpen((open) => !open)}><SlidersHorizontal size={16} /><span>Relationship rules</span><span className="rule-count">{project.rules.filter((rule) => rule.enabled).length}/{project.rules.length}</span><ChevronRight size={14} className={rulesOpen ? "rotate-90" : ""} /></button>{rulesOpen && <div className="rules-editor"><p className="slot-intro">Lexical rules are editable signals. They never prove runtime behavior.</p>{project.rules.map((rule) => <div className="rule-row" key={rule.id}><button className={`rule-toggle ${rule.enabled ? "is-on" : ""}`} onClick={() => toggleRule(rule.id)} aria-label={`Toggle ${rule.name}`}><span /></button><div><strong>{rule.name}</strong><code>{rule.pattern}</code></div>{rule.id.startsWith("custom-") && <button className="rule-remove" onClick={() => removeRule(rule.id)} aria-label={`Remove ${rule.name}`}><Trash2 size={13} /></button>}</div>)}<div className="rule-form"><input value={ruleName} onChange={(event) => setRuleName(event.target.value)} placeholder="Rule name" /><input value={rulePattern} onChange={(event) => setRulePattern(event.target.value)} placeholder="Regex pattern" /><input value={ruleDetail} onChange={(event) => setRuleDetail(event.target.value)} placeholder="Meaning of a match" /><select value={ruleTone} onChange={(event) => setRuleTone(event.target.value as AnalysisRule["tone"])}><option value="neutral">Neutral signal</option><option value="green">Validated signal</option><option value="amber">Review signal</option></select><button className="quiet-button" onClick={addRule}><Plus size={14} /> Add rule</button></div></div>}</section>
        </aside>
      </section>

      <section className="bottom-dock"><div className="dock-intro"><div className="boundary-figure"><img src="/manus-storage/meaning-sandbox-specimen_e9741aea.png" alt="Abstract sealed sandbox boundary specimen" /><span>BOUNDARY / LOCAL</span></div><div><p className="eyebrow">64 / PRIMITIVE RUNNER</p><h2>Do the smallest safe math.</h2><p>Local numeric expressions only. It is not an arbitrary-code executor.</p></div></div><div className="runner-form"><label htmlFor="expression">Expression</label><div className="runner-input"><input id="expression" value={expression} onChange={(event) => setExpression(event.target.value)} spellCheck={false} /><button onClick={runExpression}><Play size={15} /> Run</button></div><p>{execution}</p><button className="sketch-open" onClick={() => setRunnerOpen(true)}><Code2 size={14} /> Open isolated browser sketch runner</button></div></section>

      {runnerOpen && <div className="runner-overlay" role="dialog" aria-modal="true" aria-labelledby="runner-title"><div className="runner-dialog"><div className="runner-dialog-heading"><div><p className="eyebrow">SANDBOX / ALLOW-SCRIPTS ONLY</p><h2 id="runner-title">Browser sketch runner</h2></div><button className="quiet-icon-button" onClick={() => setRunnerOpen(false)} aria-label="Close sketch runner"><X size={17} /></button></div><p className="runner-boundary"><HardDrive size={14} /> Isolated iframe · no same-origin access · no network permission · no host storage</p><div className="capability-checklist"><p className="eyebrow">RUN GATE / CAPABILITIES</p><label className="ack-row"><input type="checkbox" checked={runnerAcknowledged} onChange={(event) => setRunnerAcknowledged(event.target.checked)} /><span>I understand this sketch runs only inside the isolated frame below.</span></label><div className="capability-list"><div><span>JavaScript execution</span><Status tone="green">ALLOW</Status></div><div><span>Same-origin host access</span><Status>DENY</Status></div><div><span>Network requests</span><Status>DENY</Status></div><div><span>Host storage / device APIs</span><Status>DENY</Status></div></div></div><div className="runner-grid"><textarea value={runnerHtml} onChange={(event) => setRunnerHtml(event.target.value)} spellCheck={false} aria-label="Sketch HTML editor" /><iframe key={runnerVersion} title="Isolated browser sketch preview" sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={runnerHtml} /><div className="runner-dialog-actions"><button className="quiet-button" onClick={runSketch} disabled={!runnerAcknowledged}><Play size={14} /> {runnerAcknowledged ? "Run sketch" : "Acknowledge to run"}</button><span>Only the sandboxed document is reloaded.</span></div></div></div></div>}
      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss notification"><X size={15} /></button></div>}
      <input ref={inputRef} className="sr-only" type="file" multiple accept=".txt,.md,.json,.csv,.tsv,.pdf,.js,.mjs,.cjs,.ts,.tsx,.jsx,.html,.css,.scss,.xml,.yml,.yaml,.py,.java,.c,.cpp,.h,.hpp,.rs,.go,.rb,.php,.sh,.sql,.ini,.toml,.svg,.glsl,.wgsl,.zip" onChange={(event) => { void importFiles(event.target.files ?? undefined); event.currentTarget.value = ""; }} />
    </main>
  );
}
