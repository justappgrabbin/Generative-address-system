import { Phase1Gate as Phase1GateV1 } from "../pure-synthia-compatible/phase1/tests/phase1-gate.js";
import { Phase1Gate as Phase1GateV2 } from "../pure-synthia-compatible/phase2/tests/phase1-gate.js";
import { verifyStep41 } from "../pure-synthia-compatible/pass4-step41/tests/pass4-step41-verify.js";

const phase1 = await new Phase1GateV1().run();
const phase2 = await new Phase1GateV2().run();
const pass41 = await verifyStep41();
const report = {
  phase1: { passed: phase1.passed, failed: phase1.failed, failures: phase1.results.filter(item => !item.ok).map(item => item.name) },
  phase2: { passed: phase2.passed, failed: phase2.failed, failures: phase2.results.filter(item => !item.ok).map(item => item.name) },
  pass41: { passed: pass41.passed, failed: pass41.failed, failures: pass41.results.filter(item => !item.ok).map(item => item.name) },
};

console.log(JSON.stringify(report, null, 2));
if (report.phase1.failed > 0 || report.phase2.failed > 0 || report.pass41.failed > 0) process.exitCode = 1;
