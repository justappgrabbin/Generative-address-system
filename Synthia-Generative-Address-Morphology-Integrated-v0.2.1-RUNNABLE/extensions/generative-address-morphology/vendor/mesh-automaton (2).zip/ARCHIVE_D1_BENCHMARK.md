# Archive-Backed D1 Benchmark Protocol

## Scope

The supplied `pure-synthia-phase1` archive defines a complete **D1 feature-to-phoneme** benchmark, not a D2 morpheme dataset. The browser-local laboratory must represent D1 accurately and must not relabel its phoneme corpus as D2. The full D2 workflow stays available as a validated empty manifest gate until a declared morpheme dataset exists.

## Supplied Data and Acceptance Criteria

| Item | Archive instruction | Laboratory representation |
|---|---|---|
| Dataset | Fixed ten-phoneme English consonant subset built from eight feature records, fixed arity three | Immutable source corpus and feature registry |
| Split | Discovery: `p b t d k m n f`; held-out test: `g v` | Explicit split preserved in the D1 experiment record |
| Operator | `o_bundle3`: order-insensitive, constituent-preserving feature bundling | Registered `o_bundle` implementation with canonical child order |
| Reconstruction | Both held-out phonemes must reconstruct from their declared feature bundles | Exact component equality, measured locally |
| Novelty | No held-out derivation may collide with a stored discovery derivation | Explicit local discovery-output comparison |
| Compression | `L_direct=40`; `L(G)+L(X|G)=64`; `CG=-0.6` | Immutable source compression record, shown as a negative D1 result |
| Ablation | Remove operator, each feature, and canonicalization; record impact | Source entries retained and replayed/checked locally where the control is defined |
| Replay | Equivalent input and grammar must reproduce output | Stable output hashes are compared across local replays |

## Interpretive Boundary

The archive labels D1 as a small, hand-built test. Its recorded `generationAccuracy=1.0` and `novelCompositionRate=1.0` support only the limited held-out feature-bundle reconstruction claim. The recorded `compressionGain=-0.6` is a loss at this scale, not evidence of compression. Neither result establishes higher-scale linguistic, behavioral, dimensional, or Human Design claims.

## D2 Separation

The source archive contains no declared morpheme observation list, no D2 gold decomposition, and no D2 discovery/holdout split. The application must continue to reject any underspecified D2 execution and cannot synthesize the missing observations from the D1 corpus.
