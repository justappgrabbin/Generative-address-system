# Pure Synthia D2.0 — Laboratory Design

## Experimental Frame

D2.0 is a browser-local, deterministic experiment. It asks whether the already defined operators `o_bundle` and `o_sequence` can construct ordered morpheme-level objects from phoneme-level composites without adding scale-specific transformation logic. It does **not** establish a dimensional, Human Design, gate, canonical-address, medical, or psychological claim.

## Core Records

| Record | Required contents | Mutability |
|---|---|---|
| Primitive | identity, contrast, position, permitted operators, dependencies, native scale, evidence | Immutable after registration; changes create a new version |
| Operator | identity, exact arity, admissible-input predicate, positional semantics, invariants, observed scales | Versioned definition |
| Composite | scale, ordered or unordered child IDs, operator ID, context, derivation ID | Immutable generated output |
| Derivation | source input, decomposition, resolved primitives, operator applications, active topology, output, evaluation | Immutable and replayable |
| Evidence | kind, source, supports, contradicts, timestamp | Append-only |
| Hypothesis | claim, null, metric, threshold, evidence IDs, state | State advances only through explicit review actions |
| Experiment | frozen grammar/operator version, data split, controls, metrics, results | Configuration locks when a run begins |

## Dynamic Mesh

The laboratory models one state registry through five independent projections. A relation belongs to exactly one projection and is never reinterpreted as a relation in another projection without a separate record. Runtime activation is continuous within the unit interval and activation history is append-only.

| Projection | Permitted relation examples | Purpose |
|---|---|---|
| Knowledge | contrasts, categorizes, represents | Stores structural observations |
| Causal | produces, blocks, transforms | Records directed generation dependencies |
| Phase | ready, active, dormant, completed | Tracks lifecycle state without deleting topology |
| Temporal | precedes, co-occurs, follows | Preserves order and timing context |
| Dependency | requires, derives-from, supports | Enables derivation reconstruction |

An incoming experiment action activates primitive states, selects only operators whose contracts accept the active operands, emits a composite, and propagates only those projection-specific relations that have explicit supporting records. The mesh remains dynamic because activation, legal operator availability, and current graph neighborhood determine the next permitted transition; no generic static score determines an outcome.

## Operator Contracts

`o_bundle` accepts two or more compatible primitives or composites at the same working scale and yields an **order-insensitive** composite containing its full constituent set. `o_sequence` accepts two or more operands and yields an **order-sensitive** composite with explicit positions. In both cases, output IDs derive deterministically from the operator version, operand IDs, order mode, and normalized context.

## D2.0 Dataset Contract

The UI will require an imported or manually entered dataset manifest before execution. A valid D2.0 manifest must declare at least ten D1-tier phoneme records, at least twelve morpheme observations, an explicit discovery and holdout split with at least two holdout items, and gold ordered phoneme sequences. The system will not generate or seed these records from an assumed corpus.

## Run Path and Controls

1. Validate the frozen manifest and confirm the target item is a holdout composition.
2. Resolve its supplied component primitives without reading its expected output during composition.
3. Construct lower-level phoneme composites with `o_bundle` where supplied by the manifest.
4. Construct the morpheme candidate with `o_sequence`.
5. Produce a derivation, complexity ledger, output hash, and exact-match evaluation.
6. Re-run with a removed operator, removed primitive, or removed position signal to obtain ablation results.
7. Replay the original run from its frozen manifest and compare output hashes.

## Measurements

The first laboratory exposes exact reconstruction accuracy, novel-composition rate, operator reuse, special-case burden, a fixed description-length comparison, derivation integrity, execution time, recursion depth, activation count, state count, edge traversals, operation count, and transition count. These are measurements, not proof of the proposal’s broader claims.

## Explicit Deferrals

Candidate dimension records and canonical-address fields may be stored as inert annotated reference material but must not influence primitive extraction, operator selection, graph activation, D2.0 scoring, or the control baseline. A separate preregistered experiment would be required before they become a tested condition.
