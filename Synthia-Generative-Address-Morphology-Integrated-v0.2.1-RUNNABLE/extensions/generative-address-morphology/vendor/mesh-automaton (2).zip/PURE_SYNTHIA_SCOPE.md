# Pure Synthia — Bounded Initial Milestone

## Objective

The next Mesh Automaton milestone is a **deterministic Pure Synthia laboratory**, not a participant study site. It investigates whether explicit primitives and a finite operator vocabulary can form higher-order objects across a sequence of scales. It preserves the project's experimental boundary: no language model, remote inference, external embeddings, or hidden source of domain knowledge participates in the experiment.

## Selected Initial Increment: D2.0

The supplied proposal identifies D2.0 as the next preregistered increment. D2.0 tests whether two fixed operators already used at the feature-to-phoneme level can be applied without modification at the phoneme-to-morpheme level. The laboratory will treat the **derivation** as the primary result: every output must include its input, primitive decomposition, selected operators, topology, intermediate transformations, output, and evaluation data.

| Component | D2.0 behavior | Boundary |
|---|---|---|
| Primitive | Immutable, versioned record with identity, contrast, position, scale, operations, dependencies, and evidence | Candidate dimensional/address fields are nullable and inert |
| `o_bundle` | Simultaneously composes compatible lower-order primitives while preserving all children | Order-insensitive by design |
| `o_sequence` | Composes an ordered sequence and records positional indexes | Order-sensitive: reversing operands changes the composite |
| Composite | Becomes a whole relative to its children and a valid operand at a subsequent scale | Always retains a derivation reference |
| Activation mesh | Tracks state activation and projection-specific edges | Knowledge, causal, phase, temporal, and dependency relations remain separate |
| Experiment | Uses frozen discovery/holdout splits, controls, metrics, and deterministic replay | The test split cannot alter the grammar being evaluated |

## D2.0 Evidence Discipline

The implementation will record complexity-ledger values, exact reconstruction, novel-composition status, operator reuse, special-case burden, compression comparison, and ablation results. A control can remove an operator, primitive, positional information, or projection. A negative result remains a valid recorded outcome; no control failure is overwritten with an interpretive claim.

## Required Source Data

The supplied text refers to a sealed D1 artifact and its `goldPhonemes` inventory, but the artifact itself was not included with the supplied materials. The application will therefore provide an empty, editable laboratory rather than fabricate the D1 primitive inventory or D2 morpheme data. To execute the declared D2.0 benchmark, the user must supply the sealed D1 artifact or an equivalent machine-readable list of D1 phonemes and the preregistered discovery/holdout morpheme split.

## Deferred References

Candidate dimensions, canonical addresses, gates, Human Design, and I Ching references remain stored, if later added, as **unassigned hypotheses**. They are excluded from primitive extraction, operator selection, D2.0 experiment execution, controls, and scoring unless a separately specified test introduces them as a measured experimental condition.
