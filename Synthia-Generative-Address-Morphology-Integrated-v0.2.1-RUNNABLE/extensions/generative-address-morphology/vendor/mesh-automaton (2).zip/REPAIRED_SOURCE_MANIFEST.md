# Complete Repaired Pure Synthia Source Manifest

## Preservation Rule

All supplied repaired source bundles are preserved **unaltered** as separate browser-accessible snapshots in `client/public/pure-synthia-archive/`. The unified application routes to each snapshot; it does not merge duplicate files, silently select a later revision as a replacement for an earlier one, or discard provisional files. A separate shell provides navigation only.

| Snapshot | Preserved files | Primary scope | Browser entry point |
|---|---:|---|---|
| Phase 1 repaired | 24 | Primitive calculus, D1 core, derivations, controls, replay, experiments, IndexedDB | `/pure-synthia-archive/phase1/index.html` |
| Phase 2 repaired | 35 | Five graph projections, topology, meshes, address/dimensional evaluation, cross-scale experiments, added operators | `/pure-synthia-archive/phase2/index.html` |
| Pass 3 repaired | 40 | Discourse parsing, dependency graphing, finite-state automata, automata composition, eight-tab laboratory | `/pure-synthia-archive/pass3/index.html` |
| Pass 4 Step 4.1 repaired | 49 | All Pass 3 components plus emergence, multi-automata, intent, self-editor, Pass 4 engine, and Pass 4 laboratory | `/pure-synthia-archive/pass4-step41/pass4.html` |

The four snapshots total **148 source, specification, user-interface, and verification files**. Their complete original file trees also remain in `pure-synthia-source/` at the project root for source review and download.

## Repair Log Compatibility Record

The source bundles carry three mechanical repairs: `o_bundle` uses its documented minimum arity rather than exact two-item arity, replay hashes exclude generated identifiers/timestamps, and the Phase 2 address evaluator returns zero for an empty retrieval test set. The unified application retains those repaired files as supplied.

The Phase 1 and Phase 2 repair logs also identify a source-data gap: bare string decomposition for examples containing vowels lacks an archive-supplied grapheme-to-phoneme/vowel inventory. The unified shell does not modify the original snapshots to silently invent an inventory. The archive-backed sealed D1 baseline is retained in the application source and uses only the supplied D1 feature records; the Phase 1 archive surface remains directly available through the unified selector.

### Versioned Compatibility Patch — CP-01

The runnable compatibility layer contains one additional, explicit compatibility patch in `src/engine/synthia.js` for each snapshot. CP-01 adds lookup of the existing slash-wrapped phonemic identities (for example, bare `p` resolves to the already registered `/p/`) and corrects the lookup scale from the nonexistent `phoneme` spelling to the supplied `phonemic` spelling. It does not add a primitive, vowel, grapheme-to-phoneme mapping, operator, corpus entry, or inference rule. Unregistered characters remain unregistered.

This patch is deliberately **not** applied to the preserved original source tree. It exists only in `pure-synthia-compatible/` and its browser mirror, and allows the source’s documented `pat`/`bat` examples to activate their existing consonant primitives rather than return an empty ledger. The compatibility audit verifies that every compatibility snapshot contains every original file and differs only at this one documented path. The repaired Phase 1 and Phase 2 gates pass `12/12`, and the repaired Pass 4 Step 4.1 suite passes `23/23` through that layer.

## Pass 4 Scope

The Pass 4 Step 4.1 source includes every provisional module supplied by the user. Its own specification classifies `emergence/detector.js` and `emergence/multi-automata.js` as derivable measurement extensions, and retains `intent.js` and `self-editor.js` as separately testable experimental mechanisms. The static supplied Pass 4 laboratory is exposed intact; the unified shell neither omits nor automatically enables an unsupported external service or language model.

## Unified Access

The canonical active route is `/laboratory`. It exposes all four laboratory entry points in a persistent selector, defaults to the separately versioned compatibility layer, and lets the user switch to each frozen original surface. The prior `/pure-synthia-complete` route redirects to `/laboratory` without dropping access. The existing Mesh Automaton workspace remains available at `/`.
