import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export type RepairedSourceStage = "phase1" | "phase2" | "pass3" | "pass4-step41";

type StageConfig = {
  id: RepairedSourceStage;
  label: string;
  entryPoint: string;
};

const STAGES: StageConfig[] = [
  { id: "phase1", label: "Phase 1 repaired", entryPoint: "/pure-synthia-archive/phase1/index.html" },
  { id: "phase2", label: "Phase 2 repaired", entryPoint: "/pure-synthia-archive/phase2/index.html" },
  { id: "pass3", label: "Pass 3 repaired", entryPoint: "/pure-synthia-archive/pass3/index.html" },
  { id: "pass4-step41", label: "Pass 4 Step 4.1 repaired", entryPoint: "/pure-synthia-archive/pass4-step41/pass4.html" },
];

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const canonicalSnapshotsRoot = path.join(projectRoot, "pure-synthia-source");
const publicSnapshotRoot = path.join(projectRoot, "client", "public", "pure-synthia-archive");
const compatibilitySnapshotsRoot = path.join(projectRoot, "pure-synthia-compatible");
const publicCompatibilityRoot = path.join(projectRoot, "client", "public", "pure-synthia-compatible");

function filesAt(root: string, current = ""): string[] {
  const directory = path.join(root, current);
  if (!existsSync(directory)) return [];
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const relative = path.join(current, entry.name);
    return entry.isDirectory() ? filesAt(root, relative) : [relative.split(path.sep).join("/")];
  });
}

function checksum(filePath: string): string {
  return createHash("sha256").update(readFileSync(filePath)).digest("hex");
}

export function getRepairedSourceManifest() {
  const stages = STAGES.map(stage => {
    const canonicalRoot = path.join(canonicalSnapshotsRoot, stage.id);
    const publicRoot = path.join(publicSnapshotRoot, stage.id);
    const files = filesAt(canonicalRoot).sort((a, b) => a.localeCompare(b)).map(relativePath => {
      const canonicalPath = path.join(canonicalRoot, relativePath);
      const publicPath = path.join(publicRoot, relativePath);
      const mirrored = existsSync(publicPath) && checksum(canonicalPath) === checksum(publicPath);
      return {
        relativePath,
        sha256: checksum(canonicalPath),
        bytes: statSync(canonicalPath).size,
        browserPath: `/pure-synthia-archive/${stage.id}/${relativePath}`,
        mirrored,
      };
    });
    const extraPublicFiles = filesAt(publicRoot).filter(relativePath => !files.some(file => file.relativePath === relativePath)).sort((a, b) => a.localeCompare(b));
    return { ...stage, files, extraPublicFiles, complete: files.length > 0 && files.every(file => file.mirrored) && extraPublicFiles.length === 0 };
  });
  return { stages, totalFiles: stages.reduce((total, stage) => total + stage.files.length, 0), complete: stages.every(stage => stage.complete) };
}

export function getCompatibilityAudit() {
  const permittedChangedPath = "src/engine/synthia.js";
  const stages = STAGES.map(stage => {
    const sourceRoot = path.join(canonicalSnapshotsRoot, stage.id);
    const compatibleRoot = path.join(compatibilitySnapshotsRoot, stage.id);
    const publicRoot = path.join(publicCompatibilityRoot, stage.id);
    const sourceFiles = filesAt(sourceRoot).sort((a, b) => a.localeCompare(b));
    const compatibilityFiles = filesAt(compatibleRoot).sort((a, b) => a.localeCompare(b));
    const changedFiles = sourceFiles.filter(relativePath => checksum(path.join(sourceRoot, relativePath)) !== checksum(path.join(compatibleRoot, relativePath)));
    const missingFiles = sourceFiles.filter(relativePath => !compatibilityFiles.includes(relativePath));
    const extraFiles = compatibilityFiles.filter(relativePath => !sourceFiles.includes(relativePath));
    const publicMirrorFailures = compatibilityFiles.filter(relativePath => {
      const compatiblePath = path.join(compatibleRoot, relativePath);
      const publicPath = path.join(publicRoot, relativePath);
      return !existsSync(publicPath) || checksum(compatiblePath) !== checksum(publicPath);
    });
    const onlyPermittedChanges = changedFiles.length === 1 && changedFiles[0] === permittedChangedPath;
    return { id: stage.id, sourceFileCount: sourceFiles.length, compatibilityFileCount: compatibilityFiles.length, changedFiles, missingFiles, extraFiles, publicMirrorFailures, onlyPermittedChanges, complete: missingFiles.length === 0 && extraFiles.length === 0 && publicMirrorFailures.length === 0 && onlyPermittedChanges };
  });
  return { stages, complete: stages.every(stage => stage.complete) };
}
