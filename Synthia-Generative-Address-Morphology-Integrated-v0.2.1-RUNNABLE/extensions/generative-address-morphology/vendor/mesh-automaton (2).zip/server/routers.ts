import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as meshDb from "./mesh-db";
import { getRepairedSourceManifest } from "./repaired-source-manifest";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  archive: router({
    manifest: publicProcedure.query(() => getRepairedSourceManifest()),
  }),
  mesh: router({
    bootstrap: publicProcedure.query(() => meshDb.ensureInitialMeshSession()),
    list: publicProcedure.query(() => meshDb.listMeshSessions()),
    get: publicProcedure.input(z.object({ sessionId: z.string().min(1) })).query(({ input }) => meshDb.getMeshSession(input.sessionId)),
    createSession: publicProcedure.input(z.object({
      name: z.string().min(1).max(120),
      description: z.string().max(2000).optional(),
      seed: z.string().max(64).optional(),
      defaultInput: z.string().max(4000).optional(),
    })).mutation(({ input }) => meshDb.createMeshSession(input)),
    addNode: publicProcedure.input(z.object({
      sessionId: z.string().min(1),
      label: z.string().min(1).max(120),
      kind: z.string().min(1).max(40),
      capabilities: z.array(z.string().max(80)).optional(),
      configuration: z.record(z.string(), z.unknown()).optional(),
      positionX: z.number().int().min(0).max(1600).optional(),
      positionY: z.number().int().min(0).max(1000).optional(),
    })).mutation(({ input }) => meshDb.addMeshNode(input)),
    updateNode: publicProcedure.input(z.object({
      sessionId: z.string().min(1), nodeId: z.string().min(1), label: z.string().min(1).max(120).optional(), kind: z.string().min(1).max(40).optional(),
      capabilities: z.array(z.string().max(80)).optional(), configuration: z.record(z.string(), z.unknown()).optional(),
      positionX: z.number().int().min(0).max(1600).optional(), positionY: z.number().int().min(0).max(1000).optional(),
    })).mutation(({ input }) => meshDb.updateMeshNode(input)),
    removeNode: publicProcedure.input(z.object({ sessionId: z.string().min(1), nodeId: z.string().min(1) })).mutation(({ input }) => meshDb.removeMeshNode(input)),
    addEdge: publicProcedure.input(z.object({
      sessionId: z.string().min(1),
      sourceNodeId: z.string().min(1),
      targetNodeId: z.string().min(1),
      label: z.string().max(120).optional(),
      priority: z.number().int().min(0).max(99).optional(),
      maxHops: z.number().int().min(1).max(32).optional(),
    })).mutation(({ input }) => meshDb.addMeshEdge(input)),
    updateEdge: publicProcedure.input(z.object({
      sessionId: z.string().min(1), edgeId: z.string().min(1), label: z.string().min(1).max(120).optional(),
      priority: z.number().int().min(0).max(99).optional(), maxHops: z.number().int().min(1).max(32).optional(), enabled: z.boolean().optional(),
    })).mutation(({ input }) => meshDb.updateMeshEdge(input)),
    removeEdge: publicProcedure.input(z.object({ sessionId: z.string().min(1), edgeId: z.string().min(1) })).mutation(({ input }) => meshDb.removeMeshEdge(input)),
    addRule: publicProcedure.input(z.object({
      sessionId: z.string().min(1),
      name: z.string().min(1).max(120),
      symbol: z.string().min(1).max(80),
      priority: z.number().int().min(0).max(99).optional(),
      production: z.string().min(2).max(16000),
    })).mutation(({ input }) => meshDb.addGrammarRule(input)),
    updateRule: publicProcedure.input(z.object({
      sessionId: z.string().min(1), ruleId: z.string().min(1), name: z.string().min(1).max(120).optional(), symbol: z.string().min(1).max(80).optional(),
      priority: z.number().int().min(0).max(99).optional(), production: z.string().min(2).max(16000).optional(), enabled: z.boolean().optional(),
    })).mutation(({ input }) => meshDb.updateGrammarRule(input)),
    removeRule: publicProcedure.input(z.object({ sessionId: z.string().min(1), ruleId: z.string().min(1) })).mutation(({ input }) => meshDb.removeGrammarRule(input)),
    createTool: publicProcedure.input(z.object({
      sessionId: z.string().min(1),
      name: z.string().min(1).max(120),
      profile: z.enum(["envelope", "project", "merge", "annotate", "pipeline"]),
      capabilities: z.array(z.string().max(80)).optional(),
      configuration: z.record(z.string(), z.unknown()).optional(),
      composition: z.array(z.string().min(1)).optional(),
    })).mutation(({ input }) => meshDb.addToolDefinition(input)),
    updateTool: publicProcedure.input(z.object({
      sessionId: z.string().min(1), toolId: z.string().min(1), name: z.string().min(1).max(120).optional(),
      profile: z.enum(["envelope", "project", "merge", "annotate", "pipeline"]).optional(), capabilities: z.array(z.string().max(80)).optional(),
      configuration: z.record(z.string(), z.unknown()).optional(), composition: z.array(z.string().min(1)).optional(),
    })).mutation(({ input }) => meshDb.updateToolDefinition(input)),
    removeTool: publicProcedure.input(z.object({ sessionId: z.string().min(1), toolId: z.string().min(1) })).mutation(({ input }) => meshDb.removeToolDefinition(input)),
    runCycle: publicProcedure.input(z.object({ sessionId: z.string().min(1), input: z.string().max(4000) })).mutation(({ input }) => meshDb.runMeshCycle(input.sessionId, input.input)),
    runEvents: publicProcedure.input(z.object({ runId: z.string().min(1) })).query(({ input }) => meshDb.getRunEvents(input.runId)),
  }),
});

export type AppRouter = typeof appRouter;
