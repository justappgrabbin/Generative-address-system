import { beforeEach, describe, expect, it, vi } from "vitest";

const fixture = vi.hoisted(() => ({
  sessions: [] as Array<Record<string, unknown>>,
  nodes: [] as Array<Record<string, unknown>>,
  edges: [] as Array<Record<string, unknown>>,
  rules: [] as Array<Record<string, unknown>>,
  tools: [] as Array<Record<string, unknown>>,
  runs: [] as Array<Record<string, unknown>>,
  events: [] as Array<Record<string, unknown>>,
}));

const engineControl = vi.hoisted(() => ({ shouldFail: false }));

function tableKey(table: Record<string, unknown>) {
  if ("sessionSeed" in table) return "sessions" as const;
  if ("sourceNodeId" in table) return "edges" as const;
  if ("nodeState" in table) return "nodes" as const;
  if ("production" in table) return "rules" as const;
  if ("factoryGenerated" in table) return "tools" as const;
  if ("runSeed" in table) return "runs" as const;
  return "events" as const;
}

function queryFor(table: Record<string, unknown>) {
  const key = tableKey(table);
  const result = {
    where: () => result,
    orderBy: () => result,
    limit: (count: number) => Promise.resolve(fixture[key].slice(0, count)),
    then: (resolve: (value: unknown) => unknown, reject: (reason: unknown) => unknown) => Promise.resolve(fixture[key]).then(resolve, reject),
  };
  return result;
}

const fakeDb = {
  select: () => ({ from: (table: Record<string, unknown>) => queryFor(table) }),
  insert: (table: Record<string, unknown>) => ({
    values: (value: Record<string, unknown> | Array<Record<string, unknown>>) => {
      const key = tableKey(table);
      fixture[key].push(...(Array.isArray(value) ? value : [value]));
      return Promise.resolve();
    },
  }),
  update: (table: Record<string, unknown>) => ({
    set: (values: Record<string, unknown>) => ({
      where: () => {
        const key = tableKey(table);
        fixture[key].forEach(row => Object.assign(row, values));
        return Promise.resolve();
      },
    }),
  }),
  delete: () => ({ where: () => Promise.resolve() }),
};

vi.mock("./db", () => ({ getDb: vi.fn(async () => fakeDb) }));

vi.mock("./mesh-engine", async importOriginal => {
  const actual = await importOriginal<typeof import("./mesh-engine")>();
  return {
    ...actual,
    executeMeshCycle: (...args: Parameters<typeof actual.executeMeshCycle>) => {
      if (engineControl.shouldFail) throw new Error("forced execution failure");
      return actual.executeMeshCycle(...args);
    },
  };
});

import { getRunEvents, runMeshCycle } from "./mesh-db";

const sessionId = "mesh-persisted";

beforeEach(() => {
  engineControl.shouldFail = false;
  fixture.sessions = [{ id: sessionId, name: "Persisted mesh", description: "fixture", sessionSeed: "42", defaultInput: "default", status: "idle", createdAt: new Date(), updatedAt: new Date() }];
  fixture.nodes = [
    { id: "source", sessionId, label: "Source", kind: "ingress", capabilities: "[]", configuration: "{}", nodeState: '{"phase":"ready"}', positionX: 0, positionY: 0, createdAt: new Date(), updatedAt: new Date() },
    { id: "target", sessionId, label: "Target", kind: "observer", capabilities: "[]", configuration: "{}", nodeState: '{"phase":"ready"}', positionX: 200, positionY: 0, createdAt: new Date(), updatedAt: new Date() },
  ];
  fixture.edges = [{ id: "edge", sessionId, sourceNodeId: "source", targetNodeId: "target", label: "route", priority: 1, maxHops: 8, enabled: true, createdAt: new Date() }];
  fixture.rules = [{ id: "rule", sessionId, name: "Cycle", symbol: "CYCLE", priority: 1, enabled: true, production: JSON.stringify({ actions: [{ type: "emit", source: "source", target: "target", intent: "persisted", payload: { input: "{{input}}" } }, { type: "patch", nodeId: "target", patch: { state: "complete" } }] }), createdAt: new Date(), updatedAt: new Date() }];
  fixture.tools = [];
  fixture.runs = [];
  fixture.events = [];
});

describe("persisted mesh run lifecycle", () => {
  it("writes a completed run, event ledger, session state, and propagated node state", async () => {
    const outcome = await runMeshCycle(sessionId, "durable signal");
    const persistedEvents = await getRunEvents(outcome.runId);

    expect(fixture.runs).toHaveLength(1);
    expect(fixture.runs[0]).toMatchObject({ status: "complete", input: "durable signal" });
    expect(fixture.sessions[0]).toMatchObject({ status: "complete" });
    expect(fixture.events.length).toBeGreaterThan(3);
    expect(persistedEvents.map(event => event.eventType)).toContain("message.delivered");
    expect(JSON.parse(String(fixture.nodes[1]?.nodeState))).toMatchObject({ lastIntent: "persisted", messageCount: 1 });
  });

  it("records failed run and session statuses with a durable error summary", async () => {
    engineControl.shouldFail = true;

    await expect(runMeshCycle(sessionId, "fail safely")).rejects.toThrow("forced execution failure");

    expect(fixture.runs[0]).toMatchObject({ status: "failed" });
    expect(JSON.parse(String(fixture.runs[0]?.summary))).toMatchObject({ status: "failed", error: "forced execution failure" });
    expect(fixture.sessions[0]).toMatchObject({ status: "failed" });
  });
});
