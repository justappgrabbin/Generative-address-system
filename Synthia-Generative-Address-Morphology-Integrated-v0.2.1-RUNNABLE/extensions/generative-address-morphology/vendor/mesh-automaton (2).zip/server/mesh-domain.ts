export type JsonRecord = Record<string, unknown>;

export type ToolProfile = "envelope" | "project" | "merge" | "annotate" | "pipeline";

export interface MeshNodeSnapshot {
  id: string;
  sessionId: string;
  label: string;
  kind: string;
  capabilities: string[];
  configuration: JsonRecord;
  nodeState: JsonRecord;
  positionX: number;
  positionY: number;
}

export interface MeshEdgeSnapshot {
  id: string;
  sessionId: string;
  sourceNodeId: string;
  targetNodeId: string;
  label: string;
  priority: number;
  maxHops: number;
  enabled: boolean;
}

export interface GrammarRuleSnapshot {
  id: string;
  sessionId: string;
  name: string;
  symbol: string;
  priority: number;
  production: string;
  enabled: boolean;
}

export interface ToolDefinitionSnapshot {
  id: string;
  sessionId: string;
  name: string;
  profile: ToolProfile;
  capabilities: string[];
  configuration: JsonRecord;
  composition: string[];
  factoryGenerated: boolean;
}

export interface MeshSessionSnapshot {
  id: string;
  name: string;
  description: string;
  sessionSeed: string;
  defaultInput: string;
  status: "idle" | "running" | "complete" | "failed";
  nodes: MeshNodeSnapshot[];
  edges: MeshEdgeSnapshot[];
  rules: GrammarRuleSnapshot[];
  tools: ToolDefinitionSnapshot[];
  runs: MeshRunSummary[];
}

export interface MeshRunSummary {
  id: string;
  sessionId: string;
  runSeed: string;
  input: string;
  status: "running" | "complete" | "failed";
  summary: JsonRecord;
  startedAt: Date;
  completedAt: Date | null;
}

export type GrammarAction =
  | { type: "expand"; symbol: string }
  | { type: "emit"; source: string; target: string; intent: string; payload?: JsonRecord }
  | { type: "invoke"; source: string; target: string; toolId: string; payload?: JsonRecord }
  | { type: "patch"; nodeId: string; patch: JsonRecord };

export interface GrammarProduction {
  actions: GrammarAction[];
}

export interface GrammarPlan {
  startSymbol: string;
  selectedRules: string[];
  actions: GrammarAction[];
}

export interface MeshEvent {
  sequence: number;
  eventType: string;
  nodeId?: string;
  messageId?: string;
  payload: JsonRecord;
}

export interface MeshCycleResult {
  plan: GrammarPlan;
  events: MeshEvent[];
  nodeStates: Array<{ nodeId: string; nodeState: JsonRecord }>;
  summary: JsonRecord;
}
