import { describe, expect, it } from "vitest";
import { getCompatibilityAudit, getRepairedSourceManifest } from "./repaired-source-manifest";

describe("repaired source manifest", () => {
  it("enumerates every canonical archive file and verifies its unmodified public mirror", () => {
    const manifest = getRepairedSourceManifest();
    expect(manifest.totalFiles).toBe(148);
    expect(manifest.complete).toBe(true);
    expect(manifest.stages.map(stage => [stage.id, stage.files.length])).toEqual([
      ["phase1", 24], ["phase2", 35], ["pass3", 40], ["pass4-step41", 49],
    ]);
    for (const stage of manifest.stages) {
      expect(stage.complete).toBe(true);
      expect(stage.extraPublicFiles).toEqual([]);
      expect(stage.files.every(file => file.mirrored && file.sha256.length === 64 && file.browserPath.startsWith("/pure-synthia-archive/"))).toBe(true);
    }
  });

  it("preserves every source file in each runnable compatibility snapshot and restricts changes to the documented normalization fix", () => {
    const audit = getCompatibilityAudit();
    expect(audit.complete).toBe(true);
    for (const stage of audit.stages) {
      expect(stage.sourceFileCount).toBe(stage.compatibilityFileCount);
      expect(stage.changedFiles).toEqual(["src/engine/synthia.js"]);
      expect(stage.missingFiles).toEqual([]);
      expect(stage.extraFiles).toEqual([]);
      expect(stage.publicMirrorFailures).toEqual([]);
    }
  });
});
