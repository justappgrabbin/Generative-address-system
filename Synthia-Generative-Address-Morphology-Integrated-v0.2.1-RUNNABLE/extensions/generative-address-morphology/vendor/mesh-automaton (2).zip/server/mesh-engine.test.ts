import { describe, expect, it } from "vitest";
import { createToolDefinition, executeMeshCycle, expandGrammar, findRoute, invokeTool } from "./mesh-engine";
import type { MeshSessionSnapshot, ToolDefinitionSnapshot } from "./mesh-domain";

const sessionId = "mesh-test";
const nodes = [
  { id: "source", sessionId, label: "Source", kind: "ingress", capabilities: [], configuration: {}, nodeState: { phase: "ready" }, positionX: 0, positionY: 0 },
  { id: "middle", sessionId, label: "Middle", kind: "transform", capabilities: [], configuration: {}, nodeState: { phase: "ready" }, positionX: 240, positionY: 0 },
  { id: "target", sessionId, label: "Target", kind: "observer", capabilities: [], configuration: {}, nodeState: { phase: "ready" }, positionX: 480, positionY: 0 },
];

const baseSnapshot = (tools: ToolDefinitionSnapshot[] = []): MeshSessionSnapshot => ({
  id: sessionId,
  name: "Test mesh",
  description: "Deterministic unit-test fixture",
  sessionSeed: "12",
  defaultInput: "fixture",
  status: "idle",
  nodes,
  edges: [
    { id: "edge-b", sessionId, sourceNodeId: "source", targetNodeId: "middle", label: "admit", priority: 2, maxHops: 8, enabled: true },
    { id: "edge-a", sessionId, sourceNodeId: "source", targetNodeId: "target", label: "direct", priority: 1, maxHops: 8, enabled: true },
    { id: "edge-c", sessionId, sourceNodeId: "middle", targetNodeId: "target", label: "commit", priority: 1, maxHops: 8, enabled: true },
  ],
  rules: [],
  tools,
  runs: [],
});

describe("deterministic grammar", () => {
  it("chooses the lowest-priority-number rule and interpolates scoped cycle variables", () => {
    const snapshot = baseSnapshot();
    snapshot.rules = [
      { id: "rule-z", sessionId, name: "Later", symbol: "CYCLE", priority: 3, production: JSON.stringify({ actions: [{ type: "patch", nodeId: "target", patch: { order: "later" } }] }), enabled: true },
      { id: "rule-a", sessionId, name: "First", symbol: "CYCLE", priority: 1, production: JSON.stringify({ actions: [{ type: "patch", nodeId: "target", patch: { input: "{{input}}", run: "{{runId}}" } }] }), enabled: true },
    ];

    const plan = expandGrammar(snapshot.rules, "CYCLE", { input: "signal", runId: "run-1" });

    expect(plan.selectedRules).toEqual(["rule-a"]);
    expect(plan.actions).toEqual([{ type: "patch", nodeId: "target", patch: { input: "signal", run: "run-1" } }]);
  });
});

describe("deterministic Tool Factory", () => {
  it("creates a fixed-profile pipeline and invokes its stages in stored order", () => {
    const merge = createToolDefinition({ id: "merge", sessionId, name: "Merge", profile: "merge", configuration: { defaults: { family: "mesh" } } });
    const annotate = createToolDefinition({ id: "annotate", sessionId, name: "Annotate", profile: "annotate", configuration: { labels: ["deterministic", "verified"] } });
    const pipeline = createToolDefinition({ id: "pipeline", sessionId, name: "Compose", profile: "pipeline", composition: ["merge", "annotate"] });

    const result = invokeTool(pipeline, [merge, annotate, pipeline], { signal: "ready" });

    expect(result.success).toBe(true);
    expect(result.output).toEqual({ family: "mesh", signal: "ready", annotations: ["deterministic", "verified"] });
    expect(result.stages.map(stage => stage.toolId)).toEqual(["pipeline", "merge", "annotate"]);
  });

  it("rejects a composition on a non-pipeline profile", () => {
    expect(() => createToolDefinition({ id: "invalid", sessionId, name: "Invalid", profile: "merge", composition: ["another-tool"] })).toThrow("Only pipeline tools");
  });
});

describe("mesh routing and cycle execution", () => {
  it("uses stable edge priority to select the direct route", () => {
    const route = findRoute(baseSnapshot().edges, "source", "target");
    expect(route?.map(edge => edge.id)).toEqual(["edge-a"]);
  });

  it("records grammar, tool, routing, and state events during a bounded cycle", () => {
    const tool = createToolDefinition({ id: "annotate", sessionId, name: "Annotate", profile: "annotate", configuration: { labels: ["tested"] } });
    const snapshot = baseSnapshot([tool]);
    snapshot.rules = [{
      id: "cycle", sessionId, name: "Cycle", symbol: "CYCLE", priority: 1, enabled: true,
      production: JSON.stringify({ actions: [
        { type: "emit", source: "source", target: "target", intent: "signal", payload: { input: "{{input}}" } },
        { type: "invoke", source: "source", target: "target", toolId: "annotate", payload: { input: "{{input}}" } },
        { type: "patch", nodeId: "target", patch: { phase: "complete", input: "{{input}}" } },
      ] }),
    }];

    const result = executeMeshCycle(snapshot, "run-1", "verified signal");
    const target = result.nodeStates.find(state => state.nodeId === "target")?.nodeState;

    expect(result.summary).toMatchObject({ messages: 2, toolInvocations: 1, status: "complete" });
    expect(target).toMatchObject({ phase: "complete", input: "verified signal", messageCount: 2, lastIntent: "tool.output" });
    expect(result.events.map(event => event.eventType)).toContain("tool.executed");
    expect(result.events.map(event => event.eventType)).toContain("message.delivered");
  });
});
