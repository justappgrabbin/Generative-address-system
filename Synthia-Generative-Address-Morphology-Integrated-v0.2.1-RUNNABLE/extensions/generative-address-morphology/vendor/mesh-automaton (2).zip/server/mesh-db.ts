import { and, asc, desc, eq } from "drizzle-orm";
import { nanoid } from "nanoid";
import {
  grammarRules,
  meshEdges,
  meshNodes,
  meshRunEvents,
  meshRuns,
  meshSessions,
  toolDefinitions,
} from "../drizzle/schema";
import { getDb } from "./db";
import { createToolDefinition, executeMeshCycle, parseJson } from "./mesh-engine";
import type {
  JsonRecord,
  MeshCycleResult,
  MeshEdgeSnapshot,
  MeshNodeSnapshot,
  MeshRunSummary,
  MeshSessionSnapshot,
  ToolDefinitionSnapshot,
  ToolProfile,
} from "./mesh-domain";

const stringify = (value: unknown) => JSON.stringify(value ?? {});
const asRecord = (value: string): JsonRecord => parseJson<JsonRecord>(value, {});
const asStrings = (value: string): string[] => parseJson<string[]>(value, []);

function assertProduction(raw: string) {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error("Grammar production must be valid JSON");
  }
  if (!parsed || typeof parsed !== "object" || !Array.isArray((parsed as { actions?: unknown }).actions)) {
    throw new Error("Grammar production must contain an actions array");
  }
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Persistent storage is unavailable");
  return db;
}

function makeDefaultGraph(sessionId: string) {
  const inputNodeId = `node-input-${sessionId}`;
  const grammarNodeId = `node-grammar-${sessionId}`;
  const factoryNodeId = `node-factory-${sessionId}`;
  const stateNodeId = `node-state-${sessionId}`;
  const ledgerNodeId = `node-ledger-${sessionId}`;
  const annotateToolId = `tool-annotate-${sessionId}`;

  const nodes = [
    { id: inputNodeId, sessionId, label: "Input relay", kind: "ingress", capabilities: stringify(["message.receive"]), configuration: stringify({ role: "cycle-entry" }), nodeState: stringify({ phase: "ready", messageCount: 0 }), positionX: 92, positionY: 262 },
    { id: grammarNodeId, sessionId, label: "Grammar kernel", kind: "grammar", capabilities: stringify(["grammar.expand"]), configuration: stringify({ symbol: "CYCLE" }), nodeState: stringify({ phase: "ready", messageCount: 0 }), positionX: 300, positionY: 150 },
    { id: factoryNodeId, sessionId, label: "Tool factory", kind: "factory", capabilities: stringify(["tool.create", "tool.invoke"]), configuration: stringify({ profiles: ["envelope", "project", "merge", "annotate", "pipeline"] }), nodeState: stringify({ phase: "ready", messageCount: 0 }), positionX: 532, positionY: 262 },
    { id: stateNodeId, sessionId, label: "State weaver", kind: "transform", capabilities: stringify(["state.propagate"]), configuration: stringify({ behavior: "merge-patches" }), nodeState: stringify({ phase: "ready", messageCount: 0 }), positionX: 746, positionY: 150 },
    { id: ledgerNodeId, sessionId, label: "Trace ledger", kind: "observer", capabilities: stringify(["trace.record"]), configuration: stringify({ retain: "all" }), nodeState: stringify({ phase: "ready", messageCount: 0 }), positionX: 954, positionY: 262 },
  ];
  const edges = [
    { id: `edge-01-${sessionId}`, sessionId, sourceNodeId: inputNodeId, targetNodeId: grammarNodeId, label: "admit", priority: 1, maxHops: 8, enabled: true },
    { id: `edge-02-${sessionId}`, sessionId, sourceNodeId: grammarNodeId, targetNodeId: factoryNodeId, label: "expand", priority: 1, maxHops: 8, enabled: true },
    { id: `edge-03-${sessionId}`, sessionId, sourceNodeId: factoryNodeId, targetNodeId: stateNodeId, label: "compose", priority: 1, maxHops: 8, enabled: true },
    { id: `edge-04-${sessionId}`, sessionId, sourceNodeId: stateNodeId, targetNodeId: ledgerNodeId, label: "commit", priority: 1, maxHops: 8, enabled: true },
  ];
  const ruleProduction = {
    actions: [
      { type: "emit", source: inputNodeId, target: grammarNodeId, intent: "cycle.open", payload: { input: "{{input}}", seed: "{{seed}}" } },
      { type: "emit", source: grammarNodeId, target: factoryNodeId, intent: "grammar.plan", payload: { composition: "envelope > annotate", input: "{{input}}" } },
      { type: "invoke", source: factoryNodeId, target: stateNodeId, toolId: annotateToolId, payload: { input: "{{input}}", origin: "grammar" } },
      { type: "patch", nodeId: stateNodeId, patch: { phase: "propagated", lastInput: "{{input}}", lastRun: "{{runId}}" } },
      { type: "emit", source: stateNodeId, target: ledgerNodeId, intent: "cycle.complete", payload: { input: "{{input}}", status: "complete" } },
    ],
  };
  const rules = [{ id: `rule-cycle-${sessionId}`, sessionId, name: "Canonical cycle", symbol: "CYCLE", priority: 1, production: stringify(ruleProduction), enabled: true }];
  const tools = [{
    id: annotateToolId,
    sessionId,
    name: "Annotate context",
    profile: "annotate",
    capabilities: stringify(["context.annotate", "message.transform"]),
    configuration: stringify({ labels: ["deterministic", "grammar-driven", "mesh-routed"] }),
    composition: stringify([]),
    factoryGenerated: true,
  }];
  return { nodes, edges, rules, tools };
}

function toNodeSnapshot(node: typeof meshNodes.$inferSelect): MeshNodeSnapshot {
  return { ...node, capabilities: asStrings(node.capabilities), configuration: asRecord(node.configuration), nodeState: asRecord(node.nodeState) };
}

function toEdgeSnapshot(edge: typeof meshEdges.$inferSelect): MeshEdgeSnapshot {
  return { ...edge };
}

function toToolSnapshot(tool: typeof toolDefinitions.$inferSelect): ToolDefinitionSnapshot {
  return {
    ...tool,
    profile: tool.profile as ToolProfile,
    capabilities: asStrings(tool.capabilities),
    configuration: asRecord(tool.configuration),
    composition: asStrings(tool.composition),
  };
}

function toRunSummary(run: typeof meshRuns.$inferSelect): MeshRunSummary {
  return { ...run, status: run.status as MeshRunSummary["status"], summary: asRecord(run.summary) };
}

export async function listMeshSessions() {
  const db = await requireDb();
  return db.select().from(meshSessions).orderBy(desc(meshSessions.updatedAt));
}

export async function getMeshSession(sessionId: string): Promise<MeshSessionSnapshot | null> {
  const db = await requireDb();
  const [session] = await db.select().from(meshSessions).where(eq(meshSessions.id, sessionId)).limit(1);
  if (!session) return null;
  const [nodes, edges, rules, tools, runs] = await Promise.all([
    db.select().from(meshNodes).where(eq(meshNodes.sessionId, sessionId)),
    db.select().from(meshEdges).where(eq(meshEdges.sessionId, sessionId)),
    db.select().from(grammarRules).where(eq(grammarRules.sessionId, sessionId)),
    db.select().from(toolDefinitions).where(eq(toolDefinitions.sessionId, sessionId)),
    db.select().from(meshRuns).where(eq(meshRuns.sessionId, sessionId)).orderBy(desc(meshRuns.startedAt)).limit(12),
  ]);
  return {
    ...session,
    status: session.status as MeshSessionSnapshot["status"],
    nodes: nodes.map(toNodeSnapshot),
    edges: edges.map(toEdgeSnapshot),
    rules: rules.map(rule => ({ ...rule })),
    tools: tools.map(toToolSnapshot),
    runs: runs.map(toRunSummary),
  };
}

export async function createMeshSession(input: { name: string; description?: string; seed?: string; defaultInput?: string }) {
  const db = await requireDb();
  const id = `mesh-${nanoid(12)}`;
  await db.insert(meshSessions).values({
    id,
    name: input.name.trim() || "Untitled mesh",
    description: input.description?.trim() || "A deterministic graph-mesh orchestration session.",
    sessionSeed: input.seed?.trim() || "314159",
    defaultInput: input.defaultInput?.trim() || "Route a structured signal through the mesh.",
    status: "idle",
  });
  const graph = makeDefaultGraph(id);
  await db.insert(meshNodes).values(graph.nodes);
  await db.insert(meshEdges).values(graph.edges);
  await db.insert(grammarRules).values(graph.rules);
  await db.insert(toolDefinitions).values(graph.tools);
  return getMeshSession(id);
}

export async function ensureInitialMeshSession() {
  const existing = await listMeshSessions();
  if (existing.length > 0) return getMeshSession(existing[0]!.id);
  return createMeshSession({ name: "Signal Loom", description: "A deterministic grammar-to-tool mesh with explicit routing and traceability." });
}

export async function addMeshNode(input: { sessionId: string; label: string; kind: string; capabilities?: string[]; configuration?: JsonRecord; positionX?: number; positionY?: number }) {
  const db = await requireDb();
  const id = `node-${nanoid(12)}`;
  await db.insert(meshNodes).values({
    id,
    sessionId: input.sessionId,
    label: input.label.trim() || "Untitled node",
    kind: input.kind.trim() || "transform",
    capabilities: stringify(input.capabilities ?? []),
    configuration: stringify(input.configuration ?? {}),
    nodeState: stringify({ phase: "ready", messageCount: 0 }),
    positionX: input.positionX ?? 500,
    positionY: input.positionY ?? 360,
  });
  return getMeshSession(input.sessionId);
}

export async function updateMeshNode(input: { sessionId: string; nodeId: string; label?: string; kind?: string; capabilities?: string[]; configuration?: JsonRecord; positionX?: number; positionY?: number }) {
  const db = await requireDb();
  const values: Partial<typeof meshNodes.$inferInsert> = {};
  if (input.label !== undefined) values.label = input.label.trim() || "Untitled node";
  if (input.kind !== undefined) values.kind = input.kind.trim() || "transform";
  if (input.capabilities !== undefined) values.capabilities = stringify(input.capabilities);
  if (input.configuration !== undefined) values.configuration = stringify(input.configuration);
  if (input.positionX !== undefined) values.positionX = input.positionX;
  if (input.positionY !== undefined) values.positionY = input.positionY;
  if (Object.keys(values).length > 0) await db.update(meshNodes).set(values).where(and(eq(meshNodes.id, input.nodeId), eq(meshNodes.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function removeMeshNode(input: { sessionId: string; nodeId: string }) {
  const db = await requireDb();
  await db.delete(meshNodes).where(and(eq(meshNodes.id, input.nodeId), eq(meshNodes.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function addMeshEdge(input: { sessionId: string; sourceNodeId: string; targetNodeId: string; label?: string; priority?: number; maxHops?: number }) {
  const db = await requireDb();
  await db.insert(meshEdges).values({
    id: `edge-${nanoid(12)}`,
    sessionId: input.sessionId,
    sourceNodeId: input.sourceNodeId,
    targetNodeId: input.targetNodeId,
    label: input.label?.trim() || "route",
    priority: input.priority ?? 1,
    maxHops: input.maxHops ?? 8,
    enabled: true,
  });
  return getMeshSession(input.sessionId);
}

export async function updateMeshEdge(input: { sessionId: string; edgeId: string; label?: string; priority?: number; maxHops?: number; enabled?: boolean }) {
  const db = await requireDb();
  const values: Partial<typeof meshEdges.$inferInsert> = {};
  if (input.label !== undefined) values.label = input.label.trim() || "route";
  if (input.priority !== undefined) values.priority = input.priority;
  if (input.maxHops !== undefined) values.maxHops = input.maxHops;
  if (input.enabled !== undefined) values.enabled = input.enabled;
  if (Object.keys(values).length > 0) await db.update(meshEdges).set(values).where(and(eq(meshEdges.id, input.edgeId), eq(meshEdges.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function removeMeshEdge(input: { sessionId: string; edgeId: string }) {
  const db = await requireDb();
  await db.delete(meshEdges).where(and(eq(meshEdges.id, input.edgeId), eq(meshEdges.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function addGrammarRule(input: { sessionId: string; name: string; symbol: string; priority?: number; production: string }) {
  const db = await requireDb();
  assertProduction(input.production);
  await db.insert(grammarRules).values({
    id: `rule-${nanoid(12)}`,
    sessionId: input.sessionId,
    name: input.name.trim() || "Untitled rule",
    symbol: input.symbol.trim() || "CYCLE",
    priority: input.priority ?? 5,
    production: input.production,
    enabled: true,
  });
  return getMeshSession(input.sessionId);
}

export async function updateGrammarRule(input: { sessionId: string; ruleId: string; name?: string; symbol?: string; priority?: number; production?: string; enabled?: boolean }) {
  const db = await requireDb();
  const values: Partial<typeof grammarRules.$inferInsert> = {};
  if (input.name !== undefined) values.name = input.name.trim() || "Untitled rule";
  if (input.symbol !== undefined) values.symbol = input.symbol.trim() || "CYCLE";
  if (input.priority !== undefined) values.priority = input.priority;
  if (input.production !== undefined) {
    assertProduction(input.production);
    values.production = input.production;
  }
  if (input.enabled !== undefined) values.enabled = input.enabled;
  if (Object.keys(values).length > 0) await db.update(grammarRules).set(values).where(and(eq(grammarRules.id, input.ruleId), eq(grammarRules.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function removeGrammarRule(input: { sessionId: string; ruleId: string }) {
  const db = await requireDb();
  await db.delete(grammarRules).where(and(eq(grammarRules.id, input.ruleId), eq(grammarRules.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

async function assertCompositionReferences(sessionId: string, tool: ToolDefinitionSnapshot) {
  if (tool.profile !== "pipeline" || tool.composition.length === 0) return;
  const db = await requireDb();
  const available = await db.select({ id: toolDefinitions.id }).from(toolDefinitions).where(eq(toolDefinitions.sessionId, sessionId));
  const ids = new Set(available.map(item => item.id));
  const missing = tool.composition.filter(id => !ids.has(id));
  if (missing.length > 0) throw new Error(`Pipeline composition references unavailable tools: ${missing.join(", ")}`);
}

export async function addToolDefinition(input: { sessionId: string; name: string; profile: ToolProfile; capabilities?: string[]; configuration?: JsonRecord; composition?: string[] }) {
  const db = await requireDb();
  const tool = createToolDefinition({
    id: `tool-${nanoid(12)}`,
    sessionId: input.sessionId,
    name: input.name,
    profile: input.profile,
    capabilities: input.capabilities,
    configuration: input.configuration,
    composition: input.composition,
  });
  await assertCompositionReferences(input.sessionId, tool);
  await db.insert(toolDefinitions).values({
    ...tool,
    capabilities: stringify(tool.capabilities),
    configuration: stringify(tool.configuration),
    composition: stringify(tool.composition),
  });
  return getMeshSession(input.sessionId);
}

export async function updateToolDefinition(input: { sessionId: string; toolId: string; name?: string; profile?: ToolProfile; capabilities?: string[]; configuration?: JsonRecord; composition?: string[] }) {
  const db = await requireDb();
  const [existing] = await db.select().from(toolDefinitions).where(and(eq(toolDefinitions.id, input.toolId), eq(toolDefinitions.sessionId, input.sessionId))).limit(1);
  if (!existing) throw new Error("Tool definition not found");
  const tool = createToolDefinition({
    id: existing.id,
    sessionId: existing.sessionId,
    name: input.name ?? existing.name,
    profile: input.profile ?? (existing.profile as ToolProfile),
    capabilities: input.capabilities ?? asStrings(existing.capabilities),
    configuration: input.configuration ?? asRecord(existing.configuration),
    composition: input.composition ?? asStrings(existing.composition),
  });
  const otherTools = await db.select({ id: toolDefinitions.id }).from(toolDefinitions).where(eq(toolDefinitions.sessionId, input.sessionId));
  const invalid = tool.composition.filter(id => id === tool.id || !otherTools.some(candidate => candidate.id === id));
  if (invalid.length > 0) throw new Error(`Pipeline composition references unavailable or recursive tools: ${invalid.join(", ")}`);
  await db.update(toolDefinitions).set({
    name: tool.name,
    profile: tool.profile,
    capabilities: stringify(tool.capabilities),
    configuration: stringify(tool.configuration),
    composition: stringify(tool.composition),
  }).where(eq(toolDefinitions.id, tool.id));
  return getMeshSession(input.sessionId);
}

export async function removeToolDefinition(input: { sessionId: string; toolId: string }) {
  const db = await requireDb();
  await db.delete(toolDefinitions).where(and(eq(toolDefinitions.id, input.toolId), eq(toolDefinitions.sessionId, input.sessionId)));
  return getMeshSession(input.sessionId);
}

export async function getRunEvents(runId: string) {
  const db = await requireDb();
  const events = await db.select().from(meshRunEvents).where(eq(meshRunEvents.runId, runId)).orderBy(asc(meshRunEvents.sequence));
  return events.map(event => ({ ...event, payload: asRecord(event.payload) }));
}

export async function runMeshCycle(sessionId: string, input: string): Promise<{ snapshot: MeshSessionSnapshot; result: MeshCycleResult; runId: string }> {
  const db = await requireDb();
  const snapshot = await getMeshSession(sessionId);
  if (!snapshot) throw new Error("Mesh session not found");
  const runId = `run-${nanoid(12)}`;
  const effectiveInput = input.trim() || snapshot.defaultInput;
  await db.insert(meshRuns).values({ id: runId, sessionId, runSeed: snapshot.sessionSeed, input: effectiveInput, status: "running", summary: stringify({}) });
  await db.update(meshSessions).set({ status: "running" }).where(eq(meshSessions.id, sessionId));

  try {
    const result = executeMeshCycle(snapshot, runId, effectiveInput);
    for (const state of result.nodeStates) {
      await db.update(meshNodes).set({ nodeState: stringify(state.nodeState) }).where(eq(meshNodes.id, state.nodeId));
    }
    if (result.events.length > 0) {
      await db.insert(meshRunEvents).values(result.events.map(event => ({
        id: `event-${nanoid(12)}`,
        runId,
        sessionId,
        sequence: event.sequence,
        eventType: event.eventType,
        nodeId: event.nodeId ?? null,
        messageId: event.messageId ?? null,
        payload: stringify(event.payload),
      })));
    }
    await db.update(meshRuns).set({ status: "complete", summary: stringify(result.summary), completedAt: new Date() }).where(eq(meshRuns.id, runId));
    await db.update(meshSessions).set({ status: "complete" }).where(eq(meshSessions.id, sessionId));
    const updated = await getMeshSession(sessionId);
    if (!updated) throw new Error("Mesh session disappeared after execution");
    return { snapshot: updated, result, runId };
  } catch (error) {
    const summary = { status: "failed", error: error instanceof Error ? error.message : "Unknown execution error" };
    await db.update(meshRuns).set({ status: "failed", summary: stringify(summary), completedAt: new Date() }).where(eq(meshRuns.id, runId));
    await db.update(meshSessions).set({ status: "failed" }).where(eq(meshSessions.id, sessionId));
    throw error;
  }
}
