import type {
  GrammarAction,
  GrammarPlan,
  GrammarProduction,
  JsonRecord,
  MeshCycleResult,
  MeshEdgeSnapshot,
  MeshEvent,
  MeshNodeSnapshot,
  MeshSessionSnapshot,
  ToolDefinitionSnapshot,
  ToolProfile,
} from "./mesh-domain";

const MAX_GRAMMAR_DEPTH = 4;
const MAX_GRAMMAR_ACTIONS = 32;

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function parseJson<T>(raw: string, fallback: T): T {
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function stableSortByPriority<T extends { id: string; priority: number }>(items: T[]): T[] {
  return [...items].sort((a, b) => a.priority - b.priority || a.id.localeCompare(b.id));
}

function interpolateValue(value: unknown, context: JsonRecord): unknown {
  if (typeof value === "string") {
    const exact = value.match(/^{{([a-zA-Z0-9_]+)}}$/);
    if (exact) return context[exact[1]] ?? value;
    return value.replace(/{{([a-zA-Z0-9_]+)}}/g, (_, key: string) => String(context[key] ?? `{{${key}}}`));
  }
  if (Array.isArray(value)) return value.map(item => interpolateValue(item, context));
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, interpolateValue(item, context)]));
  }
  return value;
}

function interpolateAction(action: GrammarAction, context: JsonRecord): GrammarAction {
  return interpolateValue(action, context) as GrammarAction;
}

function productionFor(rule: { production: string }): GrammarProduction {
  const parsed = parseJson<unknown>(rule.production, { actions: [] });
  if (!isRecord(parsed) || !Array.isArray(parsed.actions)) return { actions: [] };
  return { actions: parsed.actions as GrammarAction[] };
}

/**
 * Expand declarative grammar rules into an ordered, bounded action plan.
 * Rule selection is stable: priority first, then persistent rule identifier.
 */
export function expandGrammar(
  rules: MeshSessionSnapshot["rules"],
  startSymbol: string,
  context: JsonRecord,
): GrammarPlan {
  const selectedRules: string[] = [];
  const actions: GrammarAction[] = [];
  const queue: Array<{ symbol: string; depth: number }> = [{ symbol: startSymbol, depth: 0 }];

  while (queue.length > 0 && actions.length < MAX_GRAMMAR_ACTIONS) {
    const current = queue.shift()!;
    if (current.depth > MAX_GRAMMAR_DEPTH) continue;
    const rule = stableSortByPriority(rules.filter(candidate => candidate.enabled && candidate.symbol === current.symbol))[0];
    if (!rule) continue;

    selectedRules.push(rule.id);
    for (const rawAction of productionFor(rule).actions) {
      const action = interpolateAction(rawAction, { ...context, ruleId: rule.id, symbol: current.symbol });
      if (action.type === "expand") {
        queue.push({ symbol: action.symbol, depth: current.depth + 1 });
      } else if (actions.length < MAX_GRAMMAR_ACTIONS) {
        actions.push(action);
      }
    }
  }

  return { startSymbol, selectedRules, actions };
}

export interface ToolInvocationResult {
  success: boolean;
  output: JsonRecord;
  stages: Array<{ toolId: string; profile: ToolProfile; success: boolean }>;
}

function asRecord(value: unknown): JsonRecord {
  return isRecord(value) ? value : { value };
}

function uniqueStrings(value: unknown): string[] {
  return Array.isArray(value) ? Array.from(new Set(value.filter((item): item is string => typeof item === "string"))) : [];
}

/**
 * Invoke a fixed, inspectable profile vocabulary. The factory never evaluates
 * generated source, calls a network service, or delegates decisions to an LLM.
 */
export function invokeTool(
  tool: ToolDefinitionSnapshot,
  allTools: ToolDefinitionSnapshot[],
  payload: JsonRecord,
  seen: Set<string> = new Set(),
): ToolInvocationResult {
  if (seen.has(tool.id)) {
    return { success: false, output: { error: "Pipeline cycle rejected", toolId: tool.id }, stages: [] };
  }
  const nextSeen = new Set(Array.from(seen));
  nextSeen.add(tool.id);

  switch (tool.profile) {
    case "envelope": {
      return {
        success: true,
        output: { payload, envelope: { toolId: tool.id, name: tool.name, capabilities: tool.capabilities } },
        stages: [{ toolId: tool.id, profile: tool.profile, success: true }],
      };
    }
    case "project": {
      const fields = uniqueStrings(tool.configuration.fields);
      const output = fields.reduce<JsonRecord>((result, field) => {
        if (field in payload) result[field] = payload[field];
        return result;
      }, {});
      return { success: true, output, stages: [{ toolId: tool.id, profile: tool.profile, success: true }] };
    }
    case "merge": {
      const defaults = asRecord(tool.configuration.defaults);
      return {
        success: true,
        output: { ...defaults, ...payload },
        stages: [{ toolId: tool.id, profile: tool.profile, success: true }],
      };
    }
    case "annotate": {
      const labels = uniqueStrings(tool.configuration.labels).sort((a, b) => a.localeCompare(b));
      const prior = uniqueStrings(payload.annotations);
      return {
        success: true,
        output: { ...payload, annotations: Array.from(new Set([...prior, ...labels])) },
        stages: [{ toolId: tool.id, profile: tool.profile, success: true }],
      };
    }
    case "pipeline": {
      let current = payload;
      const stages: ToolInvocationResult["stages"] = [];
      for (const toolId of tool.composition) {
        const child = allTools.find(candidate => candidate.id === toolId);
        if (!child) {
          return { success: false, output: { error: "Pipeline stage unavailable", toolId }, stages };
        }
        const result = invokeTool(child, allTools, current, nextSeen);
        stages.push(...result.stages);
        if (!result.success) return { success: false, output: result.output, stages };
        current = result.output;
      }
      return {
        success: true,
        output: current,
        stages: [{ toolId: tool.id, profile: tool.profile, success: true }, ...stages],
      };
    }
  }
}

export interface FactoryRequest {
  id: string;
  sessionId: string;
  name: string;
  profile: ToolProfile;
  capabilities?: string[];
  configuration?: JsonRecord;
  composition?: string[];
}

/** Create a serializable tool definition from a constrained profile specification. */
export function createToolDefinition(request: FactoryRequest): ToolDefinitionSnapshot {
  const configuration = request.configuration ?? {};
  const composition = request.composition ?? [];
  if (request.profile !== "pipeline" && composition.length > 0) {
    throw new Error("Only pipeline tools may declare a composition");
  }
  return {
    id: request.id,
    sessionId: request.sessionId,
    name: request.name.trim() || "Untitled tool",
    profile: request.profile,
    capabilities: Array.from(new Set(request.capabilities ?? [])).sort((a, b) => a.localeCompare(b)),
    configuration,
    composition: Array.from(new Set(composition)),
    factoryGenerated: true,
  };
}

export function findRoute(edges: MeshEdgeSnapshot[], sourceNodeId: string, targetNodeId: string): MeshEdgeSnapshot[] | null {
  if (sourceNodeId === targetNodeId) return [];
  const adjacency = new Map<string, MeshEdgeSnapshot[]>();
  for (const edge of stableSortByPriority(edges.filter(edge => edge.enabled))) {
    adjacency.set(edge.sourceNodeId, [...(adjacency.get(edge.sourceNodeId) ?? []), edge]);
  }

  const queue: Array<{ nodeId: string; path: MeshEdgeSnapshot[] }> = [{ nodeId: sourceNodeId, path: [] }];
  const visited = new Set<string>([sourceNodeId]);
  while (queue.length > 0) {
    const current = queue.shift()!;
    for (const edge of adjacency.get(current.nodeId) ?? []) {
      if (current.path.length >= edge.maxHops) continue;
      const path = [...current.path, edge];
      if (edge.targetNodeId === targetNodeId) return path;
      if (!visited.has(edge.targetNodeId)) {
        visited.add(edge.targetNodeId);
        queue.push({ nodeId: edge.targetNodeId, path });
      }
    }
  }
  return null;
}

/** Execute one bounded, deterministic mesh cycle and return the state deltas and trace ledger. */
export function executeMeshCycle(snapshot: MeshSessionSnapshot, runId: string, input: string): MeshCycleResult {
  const nodeStates = new Map(snapshot.nodes.map(node => [node.id, { ...node.nodeState }]));
  const events: MeshEvent[] = [];
  let sequence = 0;
  let messageCount = 0;
  let toolInvocations = 0;

  const record = (eventType: string, payload: JsonRecord, nodeId?: string, messageId?: string) => {
    events.push({ sequence: ++sequence, eventType, payload, nodeId, messageId });
  };
  const patchNode = (nodeId: string, patch: JsonRecord) => {
    const prior = nodeStates.get(nodeId) ?? {};
    const next = { ...prior, ...patch };
    nodeStates.set(nodeId, next);
    record("state.patched", { patch }, nodeId);
  };
  const emit = (source: string, target: string, intent: string, payload: JsonRecord) => {
    const messageId = `message-${String(messageCount + 1).padStart(3, "0")}`;
    messageCount++;
    const route = findRoute(snapshot.edges, source, target);
    record("message.emitted", { source, target, intent, payload }, source, messageId);
    if (!route) {
      record("message.unroutable", { source, target, intent }, source, messageId);
      return;
    }
    let currentNode = source;
    for (const edge of route) {
      currentNode = edge.targetNodeId;
      record("message.routed", { edgeId: edge.id, from: edge.sourceNodeId, to: edge.targetNodeId, intent }, currentNode, messageId);
      const existing = nodeStates.get(currentNode) ?? {};
      nodeStates.set(currentNode, {
        ...existing,
        messageCount: (typeof existing.messageCount === "number" ? existing.messageCount : 0) + 1,
        lastIntent: intent,
        lastMessageId: messageId,
        lastOrigin: source,
      });
    }
    record("message.delivered", { source, target, intent, hops: route.length, payload }, target, messageId);
  };

  const plan = expandGrammar(snapshot.rules, "CYCLE", { input, runId, seed: snapshot.sessionSeed });
  record("grammar.expanded", { startSymbol: plan.startSymbol, selectedRules: plan.selectedRules, actionCount: plan.actions.length });

  for (const action of plan.actions) {
    if (action.type === "emit") {
      emit(action.source, action.target, action.intent, action.payload ?? {});
      continue;
    }
    if (action.type === "patch") {
      patchNode(action.nodeId, action.patch);
      continue;
    }
    if (action.type === "invoke") {
      const tool = snapshot.tools.find(candidate => candidate.id === action.toolId);
      if (!tool) {
        record("tool.unsatisfied", { toolId: action.toolId, source: action.source, target: action.target }, action.source);
        continue;
      }
      const result = invokeTool(tool, snapshot.tools, action.payload ?? {});
      toolInvocations++;
      record("tool.executed", { toolId: tool.id, name: tool.name, profile: tool.profile, success: result.success, output: result.output, stages: result.stages }, action.source);
      if (result.success) emit(action.source, action.target, "tool.output", result.output);
      continue;
    }
  }

  const summary = {
    grammarRulesApplied: plan.selectedRules.length,
    actionsExpanded: plan.actions.length,
    messages: messageCount,
    toolInvocations,
    events: events.length,
    status: "complete",
  };
  record("run.completed", summary);
  return {
    plan,
    events,
    nodeStates: snapshot.nodes.map(node => ({ nodeId: node.id, nodeState: nodeStates.get(node.id) ?? {} })),
    summary,
  };
}
