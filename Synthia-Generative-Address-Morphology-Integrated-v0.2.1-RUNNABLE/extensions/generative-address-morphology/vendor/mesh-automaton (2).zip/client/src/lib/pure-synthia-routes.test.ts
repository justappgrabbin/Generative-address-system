import { describe, expect, it } from "vitest";
import { PURE_SYNTHIA_CANONICAL_ROUTE, PURE_SYNTHIA_LEGACY_ROUTE, resolvePureSynthiaRoute } from "./pure-synthia-routes";

describe("Pure Synthia routes", () => {
  it("preserves one canonical laboratory route and a distinct legacy redirect route", () => {
    expect(PURE_SYNTHIA_CANONICAL_ROUTE).toBe("/laboratory");
    expect(PURE_SYNTHIA_LEGACY_ROUTE).toBe("/pure-synthia-complete");
    expect(PURE_SYNTHIA_CANONICAL_ROUTE).not.toBe(PURE_SYNTHIA_LEGACY_ROUTE);
  });

  it("resolves the legacy complete-laboratory URL into the canonical unified laboratory route", () => {
    expect(resolvePureSynthiaRoute(PURE_SYNTHIA_LEGACY_ROUTE)).toBe(PURE_SYNTHIA_CANONICAL_ROUTE);
    expect(resolvePureSynthiaRoute(PURE_SYNTHIA_CANONICAL_ROUTE)).toBe(PURE_SYNTHIA_CANONICAL_ROUTE);
    expect(resolvePureSynthiaRoute("/")).toBe("/");
  });
});
