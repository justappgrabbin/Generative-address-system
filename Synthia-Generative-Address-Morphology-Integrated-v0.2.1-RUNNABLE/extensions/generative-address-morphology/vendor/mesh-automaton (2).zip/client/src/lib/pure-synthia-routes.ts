export const PURE_SYNTHIA_CANONICAL_ROUTE = "/laboratory";
export const PURE_SYNTHIA_LEGACY_ROUTE = "/pure-synthia-complete";

export function resolvePureSynthiaRoute(pathname: string): string {
  return pathname === PURE_SYNTHIA_LEGACY_ROUTE ? PURE_SYNTHIA_CANONICAL_ROUTE : pathname;
}
