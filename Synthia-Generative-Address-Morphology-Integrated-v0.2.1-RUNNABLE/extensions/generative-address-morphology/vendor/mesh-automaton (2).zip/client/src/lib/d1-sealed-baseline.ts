import { createPrimitive, derive, type Derivation, type Primitive } from "./pure-synthia";

function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object") {
    Object.values(value as Record<string, unknown>).forEach(item => deepFreeze(item));
    Object.freeze(value);
  }
  return value;
}

export const D1_SEAL = deepFreeze({
  tier: "D1",
  sealedAt: "phase1-increment3",
  datasetHash: "e8812abae97c016e2719f75692a871dfa674a026b76f141995812a63bba7e126",
  grammarHash: "c34a335882449443cb142a9cf3e610a12e5d56f0e4cb6cfd0146424c672c5d59",
  manifestHash: "7714d633d691145e239e37e7dbbcde0da165b73e90552405e5a459c77f3bafcf",
  assumptionsManifestHash: "bf78eac404838806f451a2cd3fb3ff1f7b36d762ede048192c03a65855b8fc7d",
  discoverySplit: ["p", "b", "t", "d", "k", "m", "n", "f"],
  testSplit: ["g", "v"],
  recordedMetrics: { generationAccuracy: 1, novelCompositionRate: 1 },
  compressionGain: -0.6000000000000001,
  compression: { directBits: 40, grammarBits: 64, grammarCostBits: 4, residualBits: 60, encodingScheme: "supplied D1 fixed-arity bundle comparison" },
  ablations: [
    { component: "operator:o_bundle3", performanceAblated: 0, impact: 1, metric: "generationAccuracy" },
    { component: "primitive:f.place.lab", performanceAblated: 0.5, impact: 0.5, metric: "generationAccuracy" },
    { component: "primitive:f.place.alv", performanceAblated: 1, impact: 0, metric: "generationAccuracy" },
    { component: "primitive:f.place.vel", performanceAblated: 0.5, impact: 0.5, metric: "generationAccuracy" },
    { component: "primitive:f.manner.stop", performanceAblated: 0.5, impact: 0.5, metric: "generationAccuracy" },
    { component: "primitive:f.manner.nas", performanceAblated: 1, impact: 0, metric: "generationAccuracy" },
    { component: "primitive:f.manner.fric", performanceAblated: 0.5, impact: 0.5, metric: "generationAccuracy" },
    { component: "primitive:f.voice", performanceAblated: 0, impact: 1, metric: "generationAccuracy" },
    { component: "primitive:f.voiceless", performanceAblated: 1, impact: 0, metric: "generationAccuracy" },
    { component: "mechanism:o_bundle-canonicalization", performanceAblated: 0, impact: 1, metric: "orderInvariance" },
  ],
  source: "Supplied pure-synthia-phase1/D1-SEALED.json and src/datasets/d1-phonemes.js",
} as const);

const featureDefinitions = [
  ["f.place.lab", "labial place"], ["f.place.alv", "alveolar place"], ["f.place.vel", "velar place"], ["f.manner.stop", "stop/plosive manner"],
  ["f.manner.nas", "nasal manner"], ["f.manner.fric", "fricative manner"], ["f.voice", "voiced"], ["f.voiceless", "voiceless"],
] as const;

export const D1_GOLD_PHONEMES: Readonly<Record<string, readonly string[]>> = deepFreeze({
  p: ["f.place.lab", "f.manner.stop", "f.voiceless"], b: ["f.place.lab", "f.manner.stop", "f.voice"], t: ["f.place.alv", "f.manner.stop", "f.voiceless"], d: ["f.place.alv", "f.manner.stop", "f.voice"], k: ["f.place.vel", "f.manner.stop", "f.voiceless"], g: ["f.place.vel", "f.manner.stop", "f.voice"], m: ["f.place.lab", "f.manner.nas", "f.voice"], n: ["f.place.alv", "f.manner.nas", "f.voice"], f: ["f.place.lab", "f.manner.fric", "f.voiceless"], v: ["f.place.lab", "f.manner.fric", "f.voice"],
});

export function buildD1FeaturePrimitives(): Primitive[] {
  return featureDefinitions.map(([id, identity]) => createPrimitive({
    id, identity, contrast: "as-defined in supplied D1 feature corpus", position: "D1 consonant feature slot", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: [`sealed-d1:${D1_SEAL.datasetHash}`], version: D1_SEAL.sealedAt,
  }));
}

export type D1BaselineRun = {
  derivations: Derivation[];
  generationAccuracy: number;
  novelCompositionRate: number;
  ablations: Array<{ component: string; performanceAblated: number; impact: number; metric: string; matchesSeal: boolean }>;
  sourceSeal: typeof D1_SEAL;
};

function reconstructHeldOut(removedComponent?: string): number {
  if (removedComponent === "operator:o_bundle3") return 0;
  const removedPrimitive = removedComponent?.replace("primitive:", "");
  const correct = D1_SEAL.testSplit.filter(id => !removedPrimitive || !D1_GOLD_PHONEMES[id]!.includes(removedPrimitive)).length;
  return correct / D1_SEAL.testSplit.length;
}

function recomputeD1Ablations() {
  return D1_SEAL.ablations.map(source => {
    const performanceAblated = source.component === "mechanism:o_bundle-canonicalization"
      ? Number([...D1_GOLD_PHONEMES.g].join("|") === [...D1_GOLD_PHONEMES.g].reverse().join("|"))
      : reconstructHeldOut(source.component);
    return { ...source, performanceAblated, impact: 1 - performanceAblated, matchesSeal: performanceAblated === source.performanceAblated };
  });
}

export function runD1SealedBaseline(): D1BaselineRun {
  const features = buildD1FeaturePrimitives();
  const allPhonemes = [...D1_SEAL.discoverySplit, ...D1_SEAL.testSplit];
  const testIds = new Set<string>(D1_SEAL.testSplit);
  const derivations = allPhonemes.map(id => derive("o_bundle", D1_GOLD_PHONEMES[id]!.map(featureId => features.find(item => item.id === featureId)!), features, `D1 /${id}/`, { experiment: "D1 sealed replay", split: testIds.has(id) ? "test" : "discovery", sealedManifestHash: D1_SEAL.manifestHash }));
  const heldOut = derivations.filter(derivation => derivation.input.context.split === "test");
  const generationAccuracy = heldOut.every(derivation => derivation.output.children.join("|") === [...D1_GOLD_PHONEMES[derivation.output.label.replace("D1 /", "").replace("/", "")]!].sort((a, b) => a.localeCompare(b)).join("|")) ? 1 : 0;
  const discoveryOutputIds = new Set(derivations.filter(derivation => derivation.input.context.split === "discovery").map(derivation => derivation.output.id));
  const novelCompositionRate = heldOut.filter(derivation => !discoveryOutputIds.has(derivation.output.id)).length / heldOut.length;
  return { derivations, generationAccuracy, novelCompositionRate, ablations: recomputeD1Ablations(), sourceSeal: D1_SEAL };
}
