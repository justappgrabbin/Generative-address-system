import { describe, expect, it } from "vitest";
import { derive, evaluateDerivation, executeD2Holdout, measureD2Run, OPERATOR_REGISTRY, PRELIMINARY_PRIMITIVES, replay, runControl, type D2Manifest, validateD2Manifest } from "./pure-synthia";

const testManifest: D2Manifest = {
  name: "test-only sealed fixture",
  grammarVersion: "d2.0-test",
  primitives: Array.from({ length: 10 }, (_, index) => ({ id: `ph:${index}`, identity: `phoneme ${index}`, contrast: `contrast ${index}`, position: "slot", scale: "phoneme" as const })),
  observations: Array.from({ length: 12 }, (_, index) => ({ id: `m:${index}`, phonemes: [`ph:${index % 10}`, `ph:${(index + 1) % 10}`], split: index > 9 ? "holdout" as const : "discovery" as const })),
};

describe("Pure Synthia deterministic operators", () => {
  it("makes o_bundle order-insensitive while preserving complete child provenance", () => {
    const left = derive("o_bundle", [PRELIMINARY_PRIMITIVES[0]!, PRELIMINARY_PRIMITIVES[2]!, PRELIMINARY_PRIMITIVES[5]!], PRELIMINARY_PRIMITIVES, "p");
    const right = derive("o_bundle", [PRELIMINARY_PRIMITIVES[5]!, PRELIMINARY_PRIMITIVES[0]!, PRELIMINARY_PRIMITIVES[2]!], PRELIMINARY_PRIMITIVES, "p");
    expect(left.output.children).toEqual(["f.manner.stop", "f.place.lab", "f.voice.off"]);
    expect(left.outputHash).toBe(right.outputHash);
    expect(left.topology.filter(item => item.projection === "dependency")).toHaveLength(3);
    expect(new Set(left.topology.map(item => item.projection))).toEqual(new Set(["knowledge", "causal", "phase", "temporal", "dependency"]));
    expect(left.activation.at(-1)).toMatchObject({ stateId: left.output.id, activation: 1, phase: "generated" });
    expect(evaluateDerivation(left)).toMatchObject({ derivationIntegrity: 1, novelty: "not-stored" });
  });

  it("makes o_sequence position-sensitive and deterministically replayable", () => {
    const p = derive("o_bundle", [PRELIMINARY_PRIMITIVES[0]!, PRELIMINARY_PRIMITIVES[2]!, PRELIMINARY_PRIMITIVES[5]!], PRELIMINARY_PRIMITIVES, "p");
    const b = derive("o_bundle", [PRELIMINARY_PRIMITIVES[0]!, PRELIMINARY_PRIMITIVES[2]!, PRELIMINARY_PRIMITIVES[4]!], PRELIMINARY_PRIMITIVES, "b");
    const registry = [...PRELIMINARY_PRIMITIVES, p.output, b.output];
    const forward = derive("o_sequence", [p.output, b.output], registry, "pb");
    const reverse = derive("o_sequence", [b.output, p.output], registry, "bp");
    expect(forward.outputHash).not.toBe(reverse.outputHash);
    expect(replay(forward, registry)).toMatchObject({ matches: true });
  });

  it("records an expected ablation failure when a required primitive is removed", () => {
    const derivation = derive("o_bundle", [PRELIMINARY_PRIMITIVES[0]!, PRELIMINARY_PRIMITIVES[2]!], PRELIMINARY_PRIMITIVES, "specimen");
    expect(runControl("remove-primitive", derivation, PRELIMINARY_PRIMITIVES)).toMatchObject({ passed: true });
    expect(runControl("remove-operator", derivation, PRELIMINARY_PRIMITIVES)).toMatchObject({ passed: true });
  });
});

describe("D2.0 experiment gate", () => {
  it("rejects an underspecified manifest instead of manufacturing a benchmark", () => {
    const result = validateD2Manifest({ name: "partial", grammarVersion: "d2.0", primitives: [], observations: [] });
    expect(result.valid).toBe(false);
    expect(result.errors).toContain("D2.0 requires at least 10 D1-tier phoneme records.");
  });

  it("executes only a declared holdout with its frozen phoneme inventory", () => {
    expect(validateD2Manifest(testManifest)).toMatchObject({ valid: true });
    const run = executeD2Holdout(testManifest, "m:10");
    expect(run).toMatchObject({ observationId: "m:10", exactOrderedReconstruction: true, novelCompositionRate: 1 });
    expect(run.derivation.output.operatorId).toBe("o_sequence");
    expect(OPERATOR_REGISTRY.o_sequence).toMatchObject({ version: "phase1.0", positionalSemantics: "ordered-index" });
    expect(Object.isFrozen(OPERATOR_REGISTRY.o_sequence)).toBe(true);
    expect(measureD2Run(testManifest, run.derivation)).toMatchObject({ reconstructionAccuracy: 1, novelCompositionRate: 1, derivationIntegrity: 1, operatorReuse: 3, specialCaseBurden: 0 });
    expect(measureD2Run(testManifest, run.derivation, [run.derivation.output.id]).novelCompositionRate).toBe(0);
    expect(() => executeD2Holdout(testManifest, "m:0")).toThrow("restricted to declared holdout");
  });
});
