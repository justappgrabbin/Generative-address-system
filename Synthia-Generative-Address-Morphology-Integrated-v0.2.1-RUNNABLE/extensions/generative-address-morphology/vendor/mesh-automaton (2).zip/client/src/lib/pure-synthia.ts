export type Scale = "feature" | "phoneme" | "morpheme" | "word";
export type OperatorId = "o_bundle" | "o_sequence";
export type ProjectionId = "knowledge" | "causal" | "phase" | "temporal" | "dependency";

export type OperatorDefinition = {
  id: OperatorId;
  version: string;
  arity: { min: number; max: number | null };
  accepts: "same-scale-min-2";
  positionalSemantics: "set-canonical" | "ordered-index";
  invariants: string[];
  observedScales: Scale[];
  provenance: string;
};

export type Primitive = {
  id: string;
  identity: string;
  contrast: string;
  position: string;
  operations: OperatorId[];
  dependencies: string[];
  scale: Scale;
  evidence: string[];
  version: string;
};

export type EvidenceKind = "observed" | "inferred" | "control" | "contradiction";
export type EvidenceRecord = {
  id: string;
  kind: EvidenceKind;
  source: string;
  supports: string[];
  contradicts: string[];
  experimentId?: string;
  timestamp: number;
};

export type HypothesisStatus = "unobserved" | "observed" | "inferred" | "hypothesized" | "tested" | "supported" | "rejected" | "inconclusive";
export type Hypothesis = {
  id: string;
  claim: string;
  nullClaim: string;
  metric: string;
  threshold: string;
  status: HypothesisStatus;
  evidenceIds: string[];
};

export type ExperimentRecord = {
  id: string;
  manifestName: string;
  grammarVersion: string;
  controls: ControlResult["control"][];
  metrics: string[];
  measurements?: ExperimentMeasurements;
  derivationIds: string[];
  startedAt: number;
  status: "configured" | "running" | "complete" | "failed";
};

export type Composite = {
  id: string;
  label: string;
  scale: Scale;
  children: string[];
  operatorId: OperatorId;
  context: Record<string, unknown>;
  derivationId: string;
};

export type Operand = Primitive | Composite;

export type Relation = {
  id: string;
  projection: ProjectionId;
  from: string;
  to: string;
  relation: string;
};

export type ComplexityLedger = {
  primitivesActivated: number;
  statesGenerated: number;
  edgesTraversed: number;
  operationsExecuted: number;
  recursionDepth: number;
  activeAutomata: number;
  transitionCount: number;
};

export type ActivatedState = {
  stateId: string;
  activation: number;
  phase: "dormant" | "weakening" | "active" | "generated";
};

export type Derivation = {
  id: string;
  input: { operatorId: OperatorId; operandIds: string[]; label: string; context: Record<string, unknown> };
  decomposition: string[];
  resolvedPrimitives: string[];
  activeStateIds: string[];
  activation: ActivatedState[];
  operations: Array<{ operatorId: OperatorId; operands: string[]; result: string }>;
  topology: Relation[];
  output: Composite;
  ledger: ComplexityLedger;
  measurements?: ExperimentMeasurements;
  outputHash: string;
  engineVersion: string;
  grammarVersion: string;
  createdAt: number;
};

export type DerivationEvaluation = {
  derivationIntegrity: number;
  directBits: number;
  grammarBits: number;
  compressionGain: number;
  novelty: "not-stored";
};

export type ExperimentMeasurements = {
  reconstructionAccuracy: number;
  novelCompositionRate: number;
  operatorReuse: number;
  specialCaseBurden: number;
  derivationIntegrity: number;
  directBits: number;
  grammarBits: number;
  compressionGain: number;
};

export type ControlResult = {
  control: "remove-operator" | "remove-primitive" | "remove-position";
  passed: boolean;
  message: string;
  resultHash?: string;
};

export type D2Observation = { id: string; phonemes: string[]; split: "discovery" | "holdout" };
export type D2Manifest = {
  name: string;
  grammarVersion: string;
  primitives: Array<Pick<Primitive, "id" | "identity" | "contrast" | "position" | "scale">>;
  observations: D2Observation[];
};

export type D2RunResult = {
  observationId: string;
  derivation: Derivation;
  exactOrderedReconstruction: boolean;
  novelCompositionRate: number;
};

export const ENGINE_VERSION = "pure-synthia-0.1.0";
export const GRAMMAR_VERSION = "d2.0-preregistered";

export const OPERATOR_REGISTRY: Record<OperatorId, OperatorDefinition> = {
  o_bundle: Object.freeze({
    id: "o_bundle", version: "phase1.0", arity: { min: 2, max: null }, accepts: "same-scale-min-2", positionalSemantics: "set-canonical",
    invariants: Object.freeze(["constituent identity", "shared working scale", "order insensitivity"]) as unknown as string[], observedScales: Object.freeze(["feature", "phoneme"]) as unknown as Scale[], provenance: "Appendix A.2 / D2.0 preregistered contract",
  }) as OperatorDefinition,
  o_sequence: Object.freeze({
    id: "o_sequence", version: "phase1.0", arity: { min: 2, max: null }, accepts: "same-scale-min-2", positionalSemantics: "ordered-index",
    invariants: Object.freeze(["constituent identity", "shared working scale", "explicit positional index"]) as unknown as string[], observedScales: Object.freeze(["feature", "phoneme", "morpheme"]) as unknown as Scale[], provenance: "Appendix A.4 / D2.0 preregistered contract",
  }) as OperatorDefinition,
};

export function createPrimitive(input: Primitive): Primitive {
  return Object.freeze({
    ...input,
    operations: Object.freeze([...input.operations]) as unknown as OperatorId[],
    dependencies: Object.freeze([...input.dependencies]) as unknown as string[],
    evidence: Object.freeze([...input.evidence]) as unknown as string[],
  }) as Primitive;
}

function createComposite(input: Composite): Composite {
  return Object.freeze({
    ...input,
    children: Object.freeze([...input.children]) as unknown as string[],
    context: Object.freeze({ ...input.context }) as Record<string, unknown>,
  }) as Composite;
}

/** These specimens are directly derived from the supplied Appendix A preliminary pass. */
export const PRELIMINARY_PRIMITIVES: Primitive[] = [
  { id: "f.place.lab", identity: "labial place", contrast: "[place=labial]", position: "articulation point", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["minimal-pairs: pat/tat/cat"], version: "appendix-a.1" },
  { id: "f.place.alv", identity: "alveolar place", contrast: "[place=alveolar]", position: "articulation point", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["minimal-pairs: tin/pin/kin"], version: "appendix-a.1" },
  { id: "f.manner.stop", identity: "stop/plosive", contrast: "[manner=stop]", position: "manner", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["contrast: pat/fat"], version: "appendix-a.1" },
  { id: "f.manner.nas", identity: "nasal", contrast: "[manner=nasal]", position: "manner", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["contrast: mat/bat"], version: "appendix-a.1" },
  { id: "f.voice.on", identity: "voiced", contrast: "[+voice]", position: "manner-independent", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["contrast: bat/pat"], version: "appendix-a.1" },
  { id: "f.voice.off", identity: "voiceless", contrast: "[-voice]", position: "manner-independent", operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["contrast: pat/bat"], version: "appendix-a.1" },
].map(item => createPrimitive(item as Primitive));

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${stableJson(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function hash(value: string): string {
  let state = 0x811c9dc5;
  for (let index = 0; index < value.length; index += 1) {
    state ^= value.charCodeAt(index);
    state = Math.imul(state, 0x01000193);
  }
  return (state >>> 0).toString(16).padStart(8, "0");
}

function nextScale(scale: Scale): Scale {
  const order: Scale[] = ["feature", "phoneme", "morpheme", "word"];
  return order[Math.min(order.indexOf(scale) + 1, order.length - 1)]!;
}

function leafPrimitiveIds(operand: Operand, all: Map<string, Operand>): string[] {
  if ("operations" in operand) return [operand.id];
  return operand.children.flatMap(childId => {
    const child = all.get(childId);
    return child ? leafPrimitiveIds(child, all) : [];
  });
}

function lineageDepth(operand: Operand, all: Map<string, Operand>): number {
  if ("operations" in operand) return 0;
  return 1 + Math.max(0, ...operand.children.map(childId => {
    const child = all.get(childId);
    return child ? lineageDepth(child, all) : 0;
  }));
}

function ensureOperands(operatorId: OperatorId, operands: Operand[]) {
  const operator = OPERATOR_REGISTRY[operatorId];
  if (operands.length < operator.arity.min || (operator.arity.max !== null && operands.length > operator.arity.max)) {
    throw new Error(`${operatorId} requires ${operator.arity.min}${operator.arity.max === null ? "+" : `–${operator.arity.max}`} operands.`);
  }
  const scales = new Set(operands.map(operand => operand.scale));
  if (scales.size !== 1) throw new Error("All operands must share one working scale.");
  for (const operand of operands) {
    if ("operations" in operand && !operand.operations.includes(operatorId)) {
      throw new Error(`${operand.id} does not admit ${operatorId}.`);
    }
  }
}

function makeTopology(operatorId: OperatorId, children: string[], outputId: string) {
  const topology: Relation[] = [];
  children.forEach((child, index) => {
    topology.push({ id: `knowledge:${child}:${outputId}`, projection: "knowledge", from: child, to: outputId, relation: "constituent" });
    topology.push({ id: `dependency:${child}:${outputId}`, projection: "dependency", from: child, to: outputId, relation: "derives" });
    topology.push({ id: `causal:${child}:${outputId}`, projection: "causal", from: child, to: outputId, relation: "composes" });
    topology.push({ id: `phase:${child}:${outputId}`, projection: "phase", from: child, to: outputId, relation: "activates" });
    topology.push({ id: `temporal:${child}:${outputId}`, projection: "temporal", from: child, to: outputId, relation: operatorId === "o_sequence" ? `position:${index}` : "coactive" });
  });
  return topology;
}

function activate(children: string[], outputId: string): ActivatedState[] {
  return [
    ...children.map((stateId, index) => ({ stateId, activation: Math.max(0.35, 0.82 - index * 0.08), phase: "active" as const })),
    { stateId: outputId, activation: 1, phase: "generated" as const },
  ];
}

export function derive(operatorId: OperatorId, operands: Operand[], registry: Operand[], label: string, context: Record<string, unknown> = {}): Derivation {
  ensureOperands(operatorId, operands);
  const all = new Map(registry.map(item => [item.id, item]));
  const operandIds = operands.map(operand => operand.id);
  const children = operatorId === "o_bundle" ? [...operandIds].sort((a, b) => a.localeCompare(b)) : operandIds;
  const scale = nextScale(operands[0]!.scale);
  const normalizedContext = { ...context, ordering: operatorId === "o_sequence" ? "positional" : "set" };
  const resultId = `state:${hash(stableJson({ operatorId, children, scale, context: normalizedContext }))}`;
  const derivationId = `derivation:${hash(stableJson({ operatorId, children, label, context: normalizedContext, engine: ENGINE_VERSION }))}`;
  const output = createComposite({ id: resultId, label: label.trim() || resultId, scale, children, operatorId, context: normalizedContext, derivationId });
  const resolvedPrimitives = Array.from(new Set(operands.flatMap(operand => leafPrimitiveIds(operand, all)))).sort((a, b) => a.localeCompare(b));
  const topology = makeTopology(operatorId, children, resultId);
  const ledger: ComplexityLedger = {
    primitivesActivated: resolvedPrimitives.length,
    statesGenerated: 1,
    edgesTraversed: topology.length,
    operationsExecuted: 1,
    recursionDepth: 1 + Math.max(...operands.map(operand => lineageDepth(operand, all))),
    activeAutomata: 1,
    transitionCount: children.length + 1,
  };
  const outputHash = hash(stableJson({ output, resolvedPrimitives, topology, ledger, engineVersion: ENGINE_VERSION, grammarVersion: GRAMMAR_VERSION }));
  return {
    id: derivationId,
    input: { operatorId, operandIds, label: output.label, context },
    decomposition: children,
    resolvedPrimitives,
    activeStateIds: [...children, resultId],
    activation: activate(children, resultId),
    operations: [{ operatorId, operands: children, result: resultId }],
    topology,
    output,
    ledger,
    outputHash,
    engineVersion: ENGINE_VERSION,
    grammarVersion: GRAMMAR_VERSION,
    createdAt: Date.now(),
  };
}

export function replay(derivation: Derivation, registry: Operand[]) {
  const operands = derivation.input.operandIds.map(id => registry.find(item => item.id === id)).filter((item): item is Operand => Boolean(item));
  if (operands.length !== derivation.input.operandIds.length) return { matches: false, reason: "Replay registry is missing one or more recorded operands." };
  const replayed = derive(derivation.input.operatorId, operands, registry, derivation.input.label, derivation.input.context);
  return { matches: replayed.outputHash === derivation.outputHash, reason: replayed.outputHash === derivation.outputHash ? "Output hash matches the frozen derivation." : "Output hash differs from the frozen derivation.", replayed };
}

export function runControl(control: ControlResult["control"], derivation: Derivation, registry: Operand[]): ControlResult {
  if (control === "remove-operator") return { control, passed: true, message: "Expected failure: the registered operator was removed before composition." };
  if (control === "remove-primitive") {
    const removed = derivation.input.operandIds[0];
    const operands = derivation.input.operandIds.filter(id => id !== removed).map(id => registry.find(item => item.id === id)).filter((item): item is Operand => Boolean(item));
    try {
      derive(derivation.input.operatorId, operands, registry, derivation.input.label, derivation.input.context);
      return { control, passed: false, message: "Control unexpectedly generated an output after removing a required operand." };
    } catch {
      return { control, passed: true, message: `Expected failure after removing ${removed}.` };
    }
  }
  if (derivation.input.operatorId !== "o_sequence") return { control, passed: true, message: "Position control is not applicable to order-insensitive bundling." };
  const operandIds = [...derivation.input.operandIds].sort((a, b) => a.localeCompare(b));
  const operands = operandIds.map(id => registry.find(item => item.id === id)).filter((item): item is Operand => Boolean(item));
  const controlled = derive("o_sequence", operands, registry, derivation.input.label, { ...derivation.input.context, positionAblated: true });
  return { control, passed: controlled.outputHash !== derivation.outputHash, message: "Position ablation produces a distinct derivation rather than preserving ordered identity.", resultHash: controlled.outputHash };
}

export function validateD2Manifest(value: unknown): { valid: boolean; errors: string[]; manifest?: D2Manifest } {
  const errors: string[] = [];
  if (!value || typeof value !== "object" || Array.isArray(value)) return { valid: false, errors: ["Manifest must be a JSON object."] };
  const candidate = value as Partial<D2Manifest>;
  const primitives = Array.isArray(candidate.primitives) ? candidate.primitives : [];
  const observations = Array.isArray(candidate.observations) ? candidate.observations : [];
  if (!candidate.name?.trim()) errors.push("Manifest requires a name.");
  if (!candidate.grammarVersion?.trim()) errors.push("Manifest requires a frozen grammarVersion.");
  if (primitives.length < 10) errors.push("D2.0 requires at least 10 D1-tier phoneme records.");
  if (primitives.some(item => !item || typeof item !== "object" || (item as { scale?: unknown }).scale !== "phoneme")) errors.push("D2.0 primitives must be declared at the phoneme scale.");
  if (observations.length < 12) errors.push("D2.0 requires at least 12 morpheme observations.");
  const holdouts = observations.filter(item => item && typeof item === "object" && (item as D2Observation).split === "holdout");
  if (holdouts.length < 2) errors.push("D2.0 requires at least 2 declared holdout observations.");
  const ids = primitives.map(item => item && typeof item === "object" ? (item as { id?: unknown }).id : undefined);
  if (new Set(ids).size !== ids.length || ids.some(id => typeof id !== "string" || !id.trim())) errors.push("Primitive IDs must be unique, non-empty strings.");
  const observationIds = observations.map(item => item && typeof item === "object" ? (item as { id?: unknown }).id : undefined);
  if (new Set(observationIds).size !== observationIds.length || observationIds.some(id => typeof id !== "string" || !id.trim())) errors.push("Observation IDs must be unique, non-empty strings.");
  for (const observation of observations) {
    if (!observation || typeof observation !== "object" || !Array.isArray((observation as D2Observation).phonemes) || (observation as D2Observation).phonemes.length < 2) errors.push("Every observation requires an ordered phoneme list of at least two IDs.");
    if ((observation as D2Observation).split !== "discovery" && (observation as D2Observation).split !== "holdout") errors.push("Every observation must declare discovery or holdout split.");
  }
  return errors.length ? { valid: false, errors } : { valid: true, errors: [], manifest: candidate as D2Manifest };
}

export function executeD2Holdout(manifest: D2Manifest, observationId: string, priorOutputIds: string[] = []): D2RunResult {
  const gate = validateD2Manifest(manifest);
  const frozenManifest = gate.manifest;
  if (!gate.valid || !frozenManifest) throw new Error(gate.errors[0] ?? "The D2.0 manifest is invalid.");
  const observation = frozenManifest.observations.find(item => item.id === observationId);
  if (!observation) throw new Error("The selected observation does not exist in the frozen manifest.");
  if (observation.split !== "holdout") throw new Error("D2.0 execution is restricted to declared holdout observations.");
  const primitives: Primitive[] = frozenManifest.primitives.map(item => ({
    ...item,
    operations: ["o_bundle", "o_sequence"],
    dependencies: [],
    evidence: [`manifest:${frozenManifest.name}`],
    version: frozenManifest.grammarVersion,
  }));
  const byId = new Map(primitives.map(item => [item.id, item]));
  const operands = observation.phonemes.map(id => byId.get(id));
  if (operands.some((item): item is undefined => !item)) throw new Error("A holdout observation references an undeclared phoneme primitive.");
  const baseDerivation = derive("o_sequence", operands as Primitive[], primitives, observation.id, { experiment: frozenManifest.name, split: "holdout", grammarVersion: frozenManifest.grammarVersion });
  const measurements = measureD2Run(frozenManifest, baseDerivation, priorOutputIds);
  const derivation: Derivation = { ...baseDerivation, measurements };
  return {
    observationId,
    derivation,
    exactOrderedReconstruction: derivation.output.children.every((id, index) => id === observation.phonemes[index]) && derivation.output.children.length === observation.phonemes.length,
    novelCompositionRate: measurements.novelCompositionRate,
  };
}

export function descriptionLength(value: unknown) {
  return new TextEncoder().encode(stableJson(value)).length * 8;
}

export function measureD2Run(manifest: D2Manifest, derivation: Derivation, priorOutputIds: string[] = []): ExperimentMeasurements {
  const inventorySize = Math.max(2, manifest.primitives.length);
  const expectedOrder = derivation.input.operatorId === "o_sequence" ? derivation.input.operandIds : [...derivation.input.operandIds].sort((a, b) => a.localeCompare(b));
  const reconstructionAccuracy = expectedOrder.length === derivation.output.children.length && expectedOrder.every((id, index) => derivation.output.children[index] === id) ? 1 : 0;
  const operator = OPERATOR_REGISTRY[derivation.output.operatorId];
  const directBits = descriptionLength({ observation: derivation.output.label, phonemes: derivation.output.children });
  const positionCost = derivation.output.operatorId === "o_sequence" ? derivation.output.children.length * Math.ceil(Math.log2(inventorySize)) : 0;
  const grammarBits = descriptionLength({ grammarVersion: manifest.grammarVersion, operator: { id: operator.id, version: operator.version, invariants: operator.invariants }, arity: derivation.output.children.length }) + positionCost;
  return {
    reconstructionAccuracy,
    novelCompositionRate: priorOutputIds.includes(derivation.output.id) ? 0 : 1,
    operatorReuse: operator.observedScales.length,
    specialCaseBurden: 0,
    derivationIntegrity: derivation.output.derivationId === derivation.id && derivation.topology.length > 0 ? 1 : 0,
    directBits,
    grammarBits,
    compressionGain: Number((1 - grammarBits / directBits).toFixed(4)),
  };
}

export function evaluateDerivation(derivation: Derivation): DerivationEvaluation {
  const directBits = descriptionLength({ label: derivation.output.label, children: derivation.output.children });
  const grammarBits = descriptionLength({ operator: derivation.output.operatorId, childCount: derivation.output.children.length }) + derivation.output.children.length * 8;
  return {
    derivationIntegrity: derivation.output.derivationId === derivation.id && derivation.operations.length > 0 && derivation.topology.length > 0 ? 1 : 0,
    directBits,
    grammarBits,
    compressionGain: Number((1 - grammarBits / directBits).toFixed(4)),
    novelty: "not-stored",
  };
}
