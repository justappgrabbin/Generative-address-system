import type { Composite, D2Manifest, Derivation, EvidenceRecord, ExperimentRecord, Hypothesis, Primitive } from "./pure-synthia";

export type LaboratoryState = {
  version: 1;
  primitives: Primitive[];
  composites: Composite[];
  derivations: Derivation[];
  evidence: EvidenceRecord[];
  hypotheses: Hypothesis[];
  experiments: ExperimentRecord[];
  manifest: D2Manifest | null;
  updatedAt: number;
};

const DB_NAME = "pure-synthia";
const STORE = "laboratory";
const KEY = "active-laboratory";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Unable to open browser laboratory storage."));
  });
}

export async function loadLaboratoryState(): Promise<LaboratoryState | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, "readonly");
    const request = transaction.objectStore(STORE).get(KEY);
    request.onsuccess = () => {
      const saved = request.result as Partial<LaboratoryState> | undefined;
      resolve(saved ? {
        version: 1,
        primitives: saved.primitives ?? [],
        composites: saved.composites ?? [],
        derivations: saved.derivations ?? [],
        evidence: saved.evidence ?? [],
        hypotheses: saved.hypotheses ?? [],
        experiments: saved.experiments ?? [],
        manifest: saved.manifest ?? null,
        updatedAt: saved.updatedAt ?? Date.now(),
      } : null);
    };
    request.onerror = () => reject(request.error ?? new Error("Unable to read browser laboratory storage."));
    transaction.oncomplete = () => db.close();
  });
}

export async function saveLaboratoryState(state: LaboratoryState): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, "readwrite");
    transaction.objectStore(STORE).put({ ...state, updatedAt: Date.now() }, KEY);
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => reject(transaction.error ?? new Error("Unable to save browser laboratory storage."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Browser laboratory storage transaction was cancelled."));
  });
}
