import { describe, expect, it } from "vitest";
import { D1_GOLD_PHONEMES, D1_SEAL, runD1SealedBaseline } from "./d1-sealed-baseline";

describe("supplied sealed D1 baseline", () => {
  it("retains the source artifact's fixed corpus, split, and provenance metadata", () => {
    expect(Object.keys(D1_GOLD_PHONEMES)).toHaveLength(10);
    expect(D1_SEAL.discoverySplit).toEqual(["p", "b", "t", "d", "k", "m", "n", "f"]);
    expect(D1_SEAL.testSplit).toEqual(["g", "v"]);
    expect(D1_SEAL.manifestHash).toBe("7714d633d691145e239e37e7dbbcde0da165b73e90552405e5a459c77f3bafcf");
    expect(Object.isFrozen(D1_SEAL)).toBe(true);
    expect(Object.isFrozen(D1_SEAL.ablations)).toBe(true);
    expect(Object.isFrozen(D1_GOLD_PHONEMES)).toBe(true);
    expect(Object.isFrozen(D1_GOLD_PHONEMES.g)).toBe(true);
  });

  it("replays the actual held-out D1 phonemes as non-stored feature bundles", () => {
    const run = runD1SealedBaseline();
    const replay = runD1SealedBaseline();
    const heldOut = run.derivations.filter(derivation => derivation.input.context.split === "test");
    expect(run.derivations).toHaveLength(10);
    expect(heldOut.map(derivation => derivation.output.label)).toEqual(["D1 /g/", "D1 /v/"]);
    expect(run).toMatchObject({ generationAccuracy: 1, novelCompositionRate: 1 });
    expect(heldOut.every(derivation => derivation.input.operatorId === "o_bundle" && derivation.output.children.length === 3)).toBe(true);
    expect(run.ablations).toHaveLength(10);
    expect(run.ablations.every(ablation => ablation.matchesSeal)).toBe(true);
    expect(run.ablations.find(ablation => ablation.component === "operator:o_bundle3")).toMatchObject({ performanceAblated: 0, impact: 1 });
    expect(run.ablations.find(ablation => ablation.component === "mechanism:o_bundle-canonicalization")).toMatchObject({ metric: "orderInvariance", performanceAblated: 0, impact: 1 });
    expect(run.derivations.map(derivation => derivation.outputHash)).toEqual(replay.derivations.map(derivation => derivation.outputHash));
    expect(run.sourceSeal.manifestHash).toBe(replay.sourceSeal.manifestHash);
    heldOut.forEach(derivation => {
      const id = derivation.output.label.replace("D1 /", "").replace("/", "");
      expect(derivation.output.children).toEqual([...D1_GOLD_PHONEMES[id]!].sort((left, right) => left.localeCompare(right)));
    });
  });
});
