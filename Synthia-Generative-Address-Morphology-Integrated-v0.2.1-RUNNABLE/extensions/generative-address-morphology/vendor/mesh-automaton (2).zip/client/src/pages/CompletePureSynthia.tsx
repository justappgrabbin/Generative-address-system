import { trpc } from "@/lib/trpc";
import { ArrowLeft, Archive, ExternalLink, FileStack, FlaskConical, GitBranch, Network, Orbit } from "lucide-react";
import { useState } from "react";

type Stage = {
  id: "phase1" | "phase2" | "pass3" | "pass4";
  label: string;
  version: string;
  compatibilityHref: string;
  sourceHref: string;
  summary: string;
  modules: string;
  icon: typeof FlaskConical;
};

const stages: Stage[] = [
  { id: "phase1", label: "Phase 1", version: "primitive calculus", compatibilityHref: "/pure-synthia-compatible/phase1/index.html", sourceHref: "/pure-synthia-archive/phase1/index.html", summary: "Primitive, composite, operator, derivation, ledger, replay, hypothesis, experiment, control, and local-storage baseline.", modules: "24 source files", icon: FlaskConical },
  { id: "phase2", label: "Phase 2", version: "topology & transfer", compatibilityHref: "/pure-synthia-compatible/phase2/index.html", sourceHref: "/pure-synthia-archive/phase2/index.html", summary: "Five graph projections, state meshes, cross-scale experiments, address and dimensional evaluators, plus project, transform, and recurse operators.", modules: "35 source files", icon: GitBranch },
  { id: "pass3", label: "Pass 3", version: "discourse & automata", compatibilityHref: "/pure-synthia-compatible/pass3/index.html", sourceHref: "/pure-synthia-archive/pass3/index.html", summary: "Multi-scale text parsing, dependency graphing, finite-state machines, automata composition, discourse composition, and an eight-tab laboratory.", modules: "40 source files", icon: Network },
  { id: "pass4", label: "Pass 4 · Step 4.1", version: "emergence extension", compatibilityHref: "/pure-synthia-compatible/pass4-step41/pass4.html", sourceHref: "/pure-synthia-archive/pass4-step41/pass4.html", summary: "The supplied Pass 4 Step 4.1 surface, including emergence, multi-automata, intent, self-editor, and the versioned Pass 4 wrapper.", modules: "49 source files", icon: Orbit },
];

export default function CompletePureSynthia() {
  const [activeId, setActiveId] = useState<Stage["id"]>("pass4");
  const [mode, setMode] = useState<"compatibility" | "source">("compatibility");
  const [showManifest, setShowManifest] = useState(false);
  const manifest = trpc.archive.manifest.useQuery(undefined, { retry: false });
  const active = stages.find(stage => stage.id === activeId) ?? stages[0]!;
  const Icon = active.icon;
  const activeHref = mode === "compatibility" ? active.compatibilityHref : active.sourceHref;

  return <div className="min-h-screen bg-[#090b12] text-[#e5e7f0]">
    <header className="sticky top-0 z-20 border-b border-white/10 bg-[#0d101a]/95 px-4 py-3 backdrop-blur-xl sm:px-6">
      <div className="mx-auto flex max-w-[1800px] items-center justify-between gap-4">
        <div className="flex min-w-0 items-center gap-3"><a href="/" className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.035] text-slate-400 transition hover:border-violet-300/40 hover:text-violet-100" aria-label="Return to Mesh Automaton"><ArrowLeft className="h-4 w-4" /></a><div className="min-w-0"><p className="mono text-[9px] uppercase tracking-[0.22em] text-violet-200/60">Complete repaired source integration</p><h1 className="truncate text-base font-bold tracking-[-0.035em] text-white sm:text-lg">Pure Synthia · Unified Laboratory</h1></div></div>
        <div className="hidden items-center gap-2 sm:flex"><span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-2.5 py-1 mono text-[9px] uppercase tracking-[0.12em] text-emerald-100"><span className="h-1.5 w-1.5 rounded-full bg-emerald-200" />browser-local</span><span className="mono text-[9px] uppercase tracking-[0.12em] text-slate-500">{manifest.data ? `${manifest.data.totalFiles} originals verified` : "verifying archive"}</span></div>
      </div>
    </header>
    <main className="mx-auto grid max-w-[1800px] gap-4 p-4 lg:grid-cols-[300px_minmax(0,1fr)] lg:p-5">
      <aside className="space-y-3">
        <section className="rounded-[22px] border border-violet-200/15 bg-[#111522] p-4 shadow-xl shadow-black/20"><div className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-lg border border-violet-200/20 bg-violet-200/10 text-violet-100"><Archive className="h-4 w-4" /></span><div><p className="mono text-[9px] uppercase tracking-[0.15em] text-violet-100/70">Archive manifest</p><p className="text-sm font-bold text-white">All supplied sources present</p></div></div><p className="mt-3 text-xs leading-5 text-slate-400">All four sources remain separately preserved. The compatibility wrapper changes only documented string-to-phoneme lookup behavior so shipped examples produce a real derivation.</p></section>
        <nav className="space-y-2" aria-label="Pure Synthia source stages">{stages.map(stage => { const StageIcon = stage.icon; const selected = stage.id === activeId; return <button key={stage.id} onClick={() => setActiveId(stage.id)} className={`w-full rounded-2xl border p-3 text-left transition ${selected ? "border-violet-200/35 bg-violet-200/[0.11] shadow-lg shadow-violet-950/25" : "border-white/9 bg-[#111522] hover:border-white/18 hover:bg-white/[0.035]"}`}><div className="flex items-center gap-2.5"><span className={`grid h-8 w-8 place-items-center rounded-lg ${selected ? "bg-violet-200/17 text-violet-100" : "bg-white/[0.045] text-slate-400"}`}><StageIcon className="h-4 w-4" /></span><div className="min-w-0 flex-1"><p className="text-sm font-bold text-slate-100">{stage.label}</p><p className="mono truncate text-[9px] uppercase tracking-[0.12em] text-slate-500">{stage.version}</p></div></div></button>; })}</nav>
        <section className="rounded-2xl border border-white/9 bg-[#111522] p-4"><div className="flex items-center gap-2"><FileStack className="h-4 w-4 text-cyan-100/80" /><p className="mono text-[9px] uppercase tracking-[0.13em] text-slate-400">Two explicit layers</p></div><p className="mt-2 text-xs leading-5 text-slate-500"><strong className="font-semibold text-slate-300">Original</strong> is an unchanged source snapshot. <strong className="font-semibold text-slate-300">Compatibility</strong> is a separately versioned wrapper, so the source and the operating repair are never conflated.</p></section>
      </aside>
      <section className="min-w-0 overflow-hidden rounded-[24px] border border-white/10 bg-[#111522] shadow-2xl shadow-black/25">
        <div className="flex flex-col justify-between gap-3 border-b border-white/9 bg-white/[0.025] px-4 py-3 md:flex-row md:items-center"><div className="flex min-w-0 items-center gap-2.5"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-violet-200/10 text-violet-100"><Icon className="h-4 w-4" /></span><div className="min-w-0"><h2 className="truncate text-sm font-bold text-white">{active.label} laboratory</h2><p className="text-xs text-slate-500">{active.summary}</p></div></div><a href={activeHref} target="_blank" rel="noreferrer" className="inline-flex shrink-0 items-center gap-1.5 self-start rounded-lg border border-white/10 bg-white/[0.035] px-2.5 py-1.5 mono text-[9px] uppercase tracking-[0.11em] text-slate-300 transition hover:bg-white/[0.09] hover:text-white"><ExternalLink className="h-3.5 w-3.5" />Open {mode === "source" ? "original" : "runnable"} surface</a></div>
        <div className="flex flex-wrap items-center gap-2 border-b border-white/7 px-4 py-2"><span className="mr-auto mono text-[9px] uppercase tracking-[0.14em] text-cyan-100/65">{active.modules}</span><button onClick={() => setMode("compatibility")} className={`rounded px-2 py-1 mono text-[9px] uppercase tracking-[0.12em] ${mode === "compatibility" ? "bg-violet-200/14 text-violet-100" : "text-slate-500 hover:text-slate-200"}`}>Compatibility wrapper</button><button onClick={() => setMode("source")} className={`rounded px-2 py-1 mono text-[9px] uppercase tracking-[0.12em] ${mode === "source" ? "bg-cyan-200/12 text-cyan-100" : "text-slate-500 hover:text-slate-200"}`}>Frozen original</button><button onClick={() => setShowManifest(current => !current)} className="mono text-[9px] uppercase tracking-[0.14em] text-slate-500 transition hover:text-violet-100">{showManifest ? "Hide" : "Inspect"} verified manifest</button></div>
        {showManifest && <div className="max-h-72 overflow-auto border-b border-white/8 bg-[#090b12] p-3"><p className="mb-2 mono text-[9px] uppercase tracking-[0.14em] text-emerald-100/75">{manifest.data?.complete ? "Complete original mirror verified" : "Manifest loading"}</p>{manifest.data?.stages.map(stage => <div key={stage.id} className="mb-3 rounded-lg border border-white/8 bg-white/[0.02] p-2.5"><div className="flex justify-between gap-3"><span className="mono text-[9px] uppercase tracking-[0.12em] text-violet-100">{stage.label}</span><span className="mono text-[9px] text-emerald-200">{stage.files.length} files · {stage.complete ? "mirrored" : "review"}</span></div><div className="mt-2 grid gap-1 sm:grid-cols-2">{stage.files.map(file => <a key={file.browserPath} href={file.browserPath} target="_blank" rel="noreferrer" className="truncate mono text-[9px] text-slate-500 hover:text-cyan-100" title={`${file.relativePath} · ${file.sha256}`}>{file.relativePath}</a>)}</div></div>)}</div>}
        <iframe key={`${active.id}:${mode}`} title={`${active.label} ${mode} Pure Synthia laboratory`} src={activeHref} className="block h-[calc(100vh-218px)] min-h-[720px] w-full border-0 bg-[#0a0a0f]" />
      </section>
    </main>
  </div>;
}
