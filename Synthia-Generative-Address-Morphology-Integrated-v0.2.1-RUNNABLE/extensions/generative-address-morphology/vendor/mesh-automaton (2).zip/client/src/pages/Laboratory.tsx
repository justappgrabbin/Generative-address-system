import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useEffect, useMemo, useState } from "react";
import {
  Activity, ArrowLeft, Beaker, Binary, BookOpenCheck, Braces, CheckCircle2,
  CircleDot, Combine, Database, FileJson, FlaskConical, GitBranch, Layers3,
  Loader2, Play, Plus, RotateCcw, ShieldCheck, Sparkles, Split, Timer,
} from "lucide-react";
import {
  createPrimitive, derive, evaluateDerivation, executeD2Holdout, measureD2Run, type Composite, type ControlResult, type D2Manifest,
  type Derivation, type Operand, type OperatorId, PRELIMINARY_PRIMITIVES,
  replay, runControl, type Primitive, type ProjectionId, validateD2Manifest,
} from "@/lib/pure-synthia";
import { loadLaboratoryState, saveLaboratoryState, type LaboratoryState } from "@/lib/pure-synthia-storage";
import { buildD1FeaturePrimitives, D1_SEAL, runD1SealedBaseline } from "@/lib/d1-sealed-baseline";

const baseHypotheses = () => [
  { id: "H1", claim: "Finite primitives and operators can generate a previously unstored composite.", nullClaim: "Each target requires its own stored solution.", metric: "Novel composition rate", threshold: "Exact held-out reconstruction", status: "hypothesized" as const, evidenceIds: [] },
  { id: "H2", claim: "An operator can retain structural behavior when the operand scale changes.", nullClaim: "Each scale requires unrelated specialized operators.", metric: "Operator reuse", threshold: "Held-out D2.0 execution", status: "hypothesized" as const, evidenceIds: [] },
];
const emptyLab = (): LaboratoryState => ({ version: 1, primitives: PRELIMINARY_PRIMITIVES, composites: [], derivations: [], evidence: [], hypotheses: baseHypotheses(), experiments: [], manifest: null, updatedAt: Date.now() });
const projectionTint: Record<ProjectionId, string> = { knowledge: "#77d6f6", causal: "#f4c370", phase: "#8cf0be", temporal: "#d5a9ff", dependency: "#f3a2b2" };

function nowLabel(timestamp: number) { return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(new Date(timestamp)); }
function bytesLabel(bits: number) { return `${bits} bits`; }

export default function Laboratory() {
  const [laboratory, setLaboratory] = useState<LaboratoryState>(() => emptyLab());
  const [ready, setReady] = useState(false);
  const [operator, setOperator] = useState<OperatorId>("o_bundle");
  const [selectedIds, setSelectedIds] = useState<string[]>([PRELIMINARY_PRIMITIVES[0]!.id, PRELIMINARY_PRIMITIVES[2]!.id, PRELIMINARY_PRIMITIVES[5]!.id]);
  const [label, setLabel] = useState("candidate phoneme");
  const [activeProjection, setActiveProjection] = useState<ProjectionId>("dependency");
  const [selectedDerivationId, setSelectedDerivationId] = useState("");
  const [controlResult, setControlResult] = useState<ControlResult | null>(null);
  const [manifestText, setManifestText] = useState("");
  const [selectedHoldoutId, setSelectedHoldoutId] = useState("");
  const [newPrimitive, setNewPrimitive] = useState({ id: "", identity: "", contrast: "", position: "" });

  useEffect(() => {
    let active = true;
    loadLaboratoryState().then(saved => {
      if (active && saved) setLaboratory(saved);
    }).catch(() => {
      if (active) toast.error("Browser storage was unavailable; this tab will still run the laboratory.");
    }).finally(() => { if (active) setReady(true); });
    return () => { active = false; };
  }, []);

  const persist = (next: LaboratoryState) => {
    setLaboratory(next);
    void saveLaboratoryState(next).catch(() => toast.error("The update ran, but browser storage could not save it."));
  };

  const registry = useMemo<Operand[]>(() => [...laboratory.primitives, ...laboratory.composites], [laboratory]);
  const selectedOperands = useMemo(() => selectedIds.map(id => registry.find(item => item.id === id)).filter((item): item is Operand => Boolean(item)), [selectedIds, registry]);
  const selectedDerivation = laboratory.derivations.find(item => item.id === selectedDerivationId) ?? laboratory.derivations.at(-1) ?? null;
  const evaluation = selectedDerivation ? (selectedDerivation.measurements ? {
    derivationIntegrity: selectedDerivation.measurements.derivationIntegrity,
    directBits: selectedDerivation.measurements.directBits,
    grammarBits: selectedDerivation.measurements.grammarBits,
    compressionGain: selectedDerivation.measurements.compressionGain,
    novelty: "not-stored" as const,
  } : evaluateDerivation(selectedDerivation)) : null;
  const replayResult = selectedDerivation ? replay(selectedDerivation, registry) : null;
  const isSameScale = new Set(selectedOperands.map(item => item.scale)).size <= 1;

  const toggleOperand = (id: string) => {
    setSelectedIds(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
    setControlResult(null);
  };

  const compose = () => {
    if (selectedOperands.length < 2) return toast.error("Select at least two operands from the registry.");
    if (!isSameScale) return toast.error("Composition requires operands from the same working scale.");
    try {
      const derivation = derive(operator, selectedOperands, registry, label);
      const evidence = { id: `evidence:${derivation.id}`, kind: "observed" as const, source: "manual-composition", supports: [derivation.output.operatorId], contradicts: [], timestamp: Date.now() };
      const next: LaboratoryState = { ...laboratory, composites: [...laboratory.composites, derivation.output], derivations: [...laboratory.derivations, derivation], evidence: [...laboratory.evidence, evidence], updatedAt: Date.now() };
      persist(next);
      setSelectedDerivationId(derivation.id);
      setControlResult(null);
      toast.success(`Generated ${derivation.output.id} with a complete derivation.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The composition was rejected.");
    }
  };

  const registerPrimitive = () => {
    const id = newPrimitive.id.trim();
    if (!id || !newPrimitive.identity.trim() || !newPrimitive.contrast.trim() || !newPrimitive.position.trim()) return toast.error("Identity, contrast, position, and a stable ID are all required.");
    if (laboratory.primitives.some(item => item.id === id)) return toast.error("Primitive IDs are permanent and must be unique.");
    const primitive = createPrimitive({ id, identity: newPrimitive.identity.trim(), contrast: newPrimitive.contrast.trim(), position: newPrimitive.position.trim(), operations: ["o_bundle", "o_sequence"], dependencies: [], scale: "feature", evidence: ["researcher-entered"], version: `local-${Date.now()}` });
    persist({ ...laboratory, primitives: [...laboratory.primitives, primitive], updatedAt: Date.now() });
    setNewPrimitive({ id: "", identity: "", contrast: "", position: "" });
    toast.success("Immutable primitive record registered locally.");
  };

  const validateManifest = () => {
    try {
      const parsed = JSON.parse(manifestText) as unknown;
      const result = validateD2Manifest(parsed);
      if (!result.valid || !result.manifest) return toast.error(result.errors[0] ?? "Manifest failed the D2.0 gate.");
      persist({ ...laboratory, manifest: result.manifest, updatedAt: Date.now() });
      setSelectedHoldoutId(result.manifest.observations.find(item => item.split === "holdout")?.id ?? "");
      toast.success("Manifest passed the D2.0 structural gate and was saved locally.");
    } catch {
      toast.error("Manifest must be valid JSON.");
    }
  };

  const runD2Holdout = () => {
    if (!laboratory.manifest) return toast.error("Validate a sealed D2.0 manifest before running a holdout.");
    const observationId = selectedHoldoutId || laboratory.manifest.observations.find(item => item.split === "holdout")?.id;
    if (!observationId) return toast.error("The manifest must declare a holdout observation.");
    try {
      const run = executeD2Holdout(laboratory.manifest, observationId, laboratory.composites.map(composite => composite.id));
      const importedPrimitives = laboratory.manifest.primitives.filter(candidate => !laboratory.primitives.some(primitive => primitive.id === candidate.id)).map(candidate => ({ ...candidate, operations: ["o_bundle", "o_sequence"] as OperatorId[], dependencies: [], evidence: [`manifest:${laboratory.manifest?.name}`], version: laboratory.manifest?.grammarVersion ?? "d2.0" }));
      const evidence = { id: `evidence:${run.derivation.id}`, kind: "observed" as const, source: `d2-holdout:${run.observationId}`, supports: ["H1", "H2", "o_sequence"], contradicts: [], experimentId: `experiment:${run.derivation.id}`, timestamp: Date.now() };
      const hypotheses = laboratory.hypotheses.map(hypothesis => ["H1", "H2"].includes(hypothesis.id) ? { ...hypothesis, status: "observed" as const, evidenceIds: [...hypothesis.evidenceIds, evidence.id] } : hypothesis);
      const experiment = { id: `experiment:${run.derivation.id}`, manifestName: laboratory.manifest.name, grammarVersion: laboratory.manifest.grammarVersion, controls: ["remove-operator", "remove-primitive", "remove-position"] as ControlResult["control"][], metrics: ["reconstructionAccuracy", "novelCompositionRate", "operatorReuse", "derivationIntegrity", "compressionGain"], measurements: run.derivation.measurements ?? measureD2Run(laboratory.manifest, run.derivation, laboratory.composites.map(composite => composite.id)), derivationIds: [run.derivation.id], startedAt: Date.now(), status: "complete" as const };
      persist({ ...laboratory, primitives: [...laboratory.primitives, ...importedPrimitives], composites: [...laboratory.composites, run.derivation.output], derivations: [...laboratory.derivations, run.derivation], evidence: [...laboratory.evidence, evidence], hypotheses, experiments: [...laboratory.experiments, experiment], updatedAt: Date.now() });
      setSelectedDerivationId(run.derivation.id);
      setControlResult(null);
      toast.success(`Executed held-out composition ${run.observationId}; novelty rate: ${(run.novelCompositionRate * 100).toFixed(0)}%.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The D2.0 holdout run failed.");
    }
  };

  const loadSealedD1 = () => {
    const experimentId = `experiment:d1:${D1_SEAL.manifestHash}`;
    if (laboratory.experiments.some(experiment => experiment.id === experimentId)) return toast.message("The supplied sealed D1 baseline is already loaded locally.");
    const run = runD1SealedBaseline();
    const features = buildD1FeaturePrimitives().filter(candidate => !laboratory.primitives.some(primitive => primitive.id === candidate.id));
    const evidence = [
      { id: `evidence:d1:${D1_SEAL.manifestHash}`, kind: "observed" as const, source: D1_SEAL.source, supports: ["H-D1-01", "o_bundle"], contradicts: [], experimentId, timestamp: Date.now() },
      { id: `evidence:d1:compression:${D1_SEAL.manifestHash}`, kind: "control" as const, source: `${D1_SEAL.source}; ${D1_SEAL.compression.encodingScheme}`, supports: ["H5"], contradicts: [], experimentId, timestamp: Date.now() },
      ...D1_SEAL.ablations.map((ablation, index) => ({ id: `evidence:d1:ablation:${index}:${D1_SEAL.manifestHash}`, kind: "control" as const, source: `${D1_SEAL.source}; ${ablation.component}`, supports: ["H-D1-01"], contradicts: [], experimentId, timestamp: Date.now() })),
    ];
    const d1Hypothesis = { id: "H-D1-01", claim: "Bundling held-out D1 phonemes from supplied component features reconstructs their declared structure without lookup.", nullClaim: "Held-out phoneme reconstruction requires a stored dedicated solution.", metric: "Generation accuracy and novel composition rate", threshold: "1.00 recorded in the supplied sealed baseline", status: "tested" as const, evidenceIds: evidence.map(item => item.id) };
    const experiment = { id: experimentId, manifestName: "D1 sealed 10-phoneme baseline", grammarVersion: D1_SEAL.grammarHash, controls: ["remove-operator", "remove-primitive"] as ControlResult["control"][], metrics: ["generationAccuracy", "novelCompositionRate", "recordedCompressionGain", "ablationImpact"], derivationIds: run.derivations.map(derivation => derivation.id), startedAt: Date.now(), status: "complete" as const };
    persist({ ...laboratory, primitives: [...laboratory.primitives, ...features], composites: [...laboratory.composites, ...run.derivations.map(derivation => derivation.output)], derivations: [...laboratory.derivations, ...run.derivations], evidence: [...laboratory.evidence, ...evidence], hypotheses: [...laboratory.hypotheses.filter(hypothesis => hypothesis.id !== d1Hypothesis.id), d1Hypothesis], experiments: [...laboratory.experiments, experiment], updatedAt: Date.now() });
    setSelectedDerivationId(run.derivations.find(derivation => derivation.input.context.split === "test")?.id ?? run.derivations.at(-1)?.id ?? "");
    setControlResult(null);
    toast.success("Loaded and replayed the supplied sealed D1 baseline. D2.0 remains a separate gated experiment.");
  };

  const resetLocalLab = () => {
    const next = emptyLab();
    persist(next);
    setSelectedIds([PRELIMINARY_PRIMITIVES[0]!.id, PRELIMINARY_PRIMITIVES[2]!.id, PRELIMINARY_PRIMITIVES[5]!.id]);
    setSelectedDerivationId("");
    setControlResult(null);
    toast.success("Restored the Appendix A preliminary pass. No external data was changed.");
  };

  if (!ready) return <div className="grid min-h-screen place-items-center bg-[#101923]"><div className="flex flex-col items-center gap-4"><Loader2 className="h-6 w-6 animate-spin text-emerald-200" /><p className="mono text-xs uppercase tracking-[0.17em] text-slate-500">Opening local laboratory</p></div></div>;

  return <div className="min-h-screen bg-[#101923] text-[#e8eee8] selection:bg-cyan-300/25">
    <header className="flex min-h-[74px] items-center justify-between border-b border-white/10 bg-[#101923]/90 px-5 backdrop-blur-xl lg:px-8">
      <div className="flex items-center gap-4"><Link href="/" className="grid h-10 w-10 place-items-center rounded-[14px] border border-white/10 bg-white/[0.035] text-slate-400 transition hover:border-emerald-200/35 hover:bg-emerald-300/10 hover:text-emerald-100" aria-label="Return to Mesh Automaton"><ArrowLeft className="h-4 w-4" /></Link><div><p className="mono text-[10px] uppercase tracking-[0.22em] text-cyan-100/60">browser-local experimental runtime</p><h1 className="text-lg font-bold tracking-[-0.04em] text-white">Pure Synthia Laboratory</h1></div></div>
      <div className="hidden items-center gap-3 sm:flex"><span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-2.5 py-1 mono text-[9px] uppercase tracking-[0.12em] text-emerald-100"><span className="h-1.5 w-1.5 rounded-full bg-emerald-200" />no model calls</span><span className="mono text-[10px] text-slate-500">D2.0 · preregistered</span><Button onClick={resetLocalLab} variant="outline" className="border-white/12 bg-white/[0.03] text-slate-300 hover:bg-white/10 hover:text-white"><RotateCcw className="mr-2 h-3.5 w-3.5" />Reset local lab</Button></div>
    </header>

    <main className="mx-auto max-w-[1580px] p-4 lg:p-5">
      <section className="relative overflow-hidden rounded-[26px] border border-cyan-200/12 bg-[#172531] p-6 shadow-2xl shadow-black/20 lg:p-7"><div className="absolute -right-20 -top-24 h-80 w-80 rounded-full bg-cyan-300/[0.055] blur-3xl" /><div className="absolute bottom-0 left-[38%] h-px w-72 bg-gradient-to-r from-transparent via-emerald-200/30 to-transparent" /><div className="relative grid gap-6 lg:grid-cols-[1.3fr_auto]"><div className="max-w-3xl"><div className="mb-4 flex items-center gap-2"><span className="grid h-6 w-6 place-items-center rounded-lg border border-cyan-200/20 bg-cyan-200/10"><FlaskConical className="h-3.5 w-3.5 text-cyan-100" /></span><span className="mono text-[10px] uppercase tracking-[0.18em] text-cyan-100/65">Phase-1 composition laboratory</span></div><h2 className="max-w-2xl text-2xl font-extrabold leading-tight tracking-[-0.045em] text-white lg:text-3xl">Test a finite grammar before you scale its claims.</h2><p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">Register inspectable primitives, compose them with fixed operators, and examine the full derivation, activation mesh, controls, and replay hash. Candidate dimensional references are intentionally excluded from this runtime.</p></div><div className="grid grid-cols-3 divide-x divide-white/10 self-end rounded-2xl border border-white/10 bg-black/15 px-2 py-3 text-center"><Metric value={laboratory.primitives.length} label="primitives" /><Metric value={laboratory.composites.length} label="composites" /><Metric value={laboratory.derivations.length} label="derivations" /></div></div></section>

      <div className="mt-5 grid gap-5 xl:grid-cols-[300px_minmax(620px,1fr)_340px]">
        <aside className="space-y-4 xl:sticky xl:top-5 xl:h-[calc(100vh-116px)] xl:overflow-y-auto xl:pr-1"><Panel title="Primitive registry" icon={Binary} meta={`${laboratory.primitives.length} entries`}><p className="mb-3 text-xs leading-5 text-slate-400">The preliminary records are a small documented feature pass. Add new records explicitly; existing identities are not overwritten.</p><div className="max-h-52 space-y-1.5 overflow-y-auto pr-1">{laboratory.primitives.map(primitive => <RegistryItem key={primitive.id} operand={primitive} selected={selectedIds.includes(primitive.id)} onToggle={() => toggleOperand(primitive.id)} />)}</div><div className="mt-3 space-y-2 border-t border-white/8 pt-3"><p className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Register feature</p><input value={newPrimitive.id} onChange={event => setNewPrimitive(current => ({ ...current, id: event.target.value }))} className={inputStyle} placeholder="id · f.voice.custom" /><input value={newPrimitive.identity} onChange={event => setNewPrimitive(current => ({ ...current, identity: event.target.value }))} className={inputStyle} placeholder="identity" /><div className="grid grid-cols-2 gap-2"><input value={newPrimitive.contrast} onChange={event => setNewPrimitive(current => ({ ...current, contrast: event.target.value }))} className={inputStyle} placeholder="contrast" /><input value={newPrimitive.position} onChange={event => setNewPrimitive(current => ({ ...current, position: event.target.value }))} className={inputStyle} placeholder="position" /></div><Button onClick={registerPrimitive} className="w-full bg-white/[0.08] text-slate-100 hover:bg-white/[0.14]" variant="secondary"><Plus className="mr-2 h-3.5 w-3.5" />Register primitive</Button></div></Panel>
          <D2ManifestPanel manifest={laboratory.manifest} manifestText={manifestText} onTextChange={setManifestText} onValidate={validateManifest} selectedHoldoutId={selectedHoldoutId} onHoldoutChange={setSelectedHoldoutId} onRunHoldout={runD2Holdout} />
          <SealedD1Panel loaded={laboratory.experiments.some(experiment => experiment.id === `experiment:d1:${D1_SEAL.manifestHash}`)} onLoad={loadSealedD1} />
        </aside>

        <section className="min-w-0 space-y-5"><Panel title="Composition chamber" icon={Combine} meta={`${selectedOperands.length} operands selected`}><div className="grid gap-4 lg:grid-cols-[1fr_220px]"><div><p className="text-xs leading-5 text-slate-400">Select same-scale operands from the registry. The runtime writes an ordered or unordered composite, its projection-specific edges, and a replayable derivation.</p><div className="mt-4 rounded-2xl border border-white/9 bg-black/15 p-3"><div className="flex flex-wrap items-center gap-2">{selectedOperands.length ? selectedOperands.map(operand => <span key={operand.id} className="mono inline-flex items-center gap-1.5 rounded-lg border border-cyan-200/18 bg-cyan-200/[0.06] px-2 py-1.5 text-[10px] text-cyan-100">{operand.id}<button onClick={() => toggleOperand(operand.id)} className="ml-0.5 text-cyan-100/55 hover:text-white" aria-label={`Remove ${operand.id}`}>×</button></span>) : <span className="text-xs text-slate-500">No operands selected</span>}</div></div><div className="mt-4 grid gap-3 sm:grid-cols-2"><div><label className={labelStyle}>Operator</label><select value={operator} onChange={event => setOperator(event.target.value as OperatorId)} className={inputStyle}><option className="bg-[#172531]" value="o_bundle">o_bundle · simultaneous</option><option className="bg-[#172531]" value="o_sequence">o_sequence · ordered</option></select></div><div><label className={labelStyle}>Output label</label><input value={label} onChange={event => setLabel(event.target.value)} className={inputStyle} /></div></div></div><div className="flex flex-col justify-end gap-3 rounded-2xl border border-emerald-200/12 bg-emerald-200/[0.045] p-4"><p className="mono text-[10px] uppercase tracking-[0.14em] text-emerald-100/70">Legal transition</p><p className="text-xs leading-5 text-slate-400">{isSameScale ? "All selected operands share a working scale." : "Mixed scales are not admitted by this operator."}</p><Button onClick={compose} disabled={selectedOperands.length < 2 || !isSameScale} className="min-h-11 bg-emerald-300 text-[#10241f] hover:bg-emerald-200"><Play className="mr-2 h-4 w-4 fill-current" />Generate derivation</Button></div></div></Panel>

          <Panel title="Activation mesh" icon={GitBranch} meta={selectedDerivation ? `${selectedDerivation.topology.length} live relations` : "awaiting derivation"} action={<ProjectionChooser value={activeProjection} onChange={setActiveProjection} />}><ActivationMesh derivation={selectedDerivation} projection={activeProjection} /></Panel>
          <Panel title="Derivation ledger" icon={BookOpenCheck} meta={selectedDerivation ? selectedDerivation.outputHash : "no output"}>{laboratory.derivations.length ? <div className="grid gap-4 lg:grid-cols-[210px_1fr]"><div className="max-h-72 space-y-1.5 overflow-y-auto pr-1">{[...laboratory.derivations].reverse().map(item => <button key={item.id} onClick={() => { setSelectedDerivationId(item.id); setControlResult(null); }} className={`w-full rounded-xl border p-2.5 text-left transition ${item.id === selectedDerivation?.id ? "border-emerald-200/30 bg-emerald-200/[0.08]" : "border-white/8 bg-black/10 hover:bg-white/[0.035]"}`}><p className="truncate text-xs font-bold text-slate-100">{item.output.label}</p><p className="mono mt-1 truncate text-[9px] text-slate-500">{item.output.operatorId} · {nowLabel(item.createdAt)}</p></button>)}</div>{selectedDerivation && evaluation && <DerivationInspector derivation={selectedDerivation} evaluation={evaluation} replayMatches={replayResult?.matches ?? false} controlResult={controlResult} onControl={control => setControlResult(runControl(control, selectedDerivation, registry))} />}</div> : <EmptyLedger />}</Panel>
          {selectedDerivation?.measurements && <ExperimentMeasurementPanel measurements={selectedDerivation.measurements} />}
        </section>

        <aside className="space-y-4 xl:sticky xl:top-5 xl:h-[calc(100vh-116px)] xl:overflow-y-auto xl:pr-1"><Panel title="Core operators" icon={Braces} meta="fixed vocabulary"><OperatorCard icon={Combine} title="o_bundle" detail="Simultaneous composition" statement="Preserves every constituent. Child order is canonicalized so order alone cannot alter the output." /><OperatorCard icon={Split} title="o_sequence" detail="Ordered composition" statement="Preserves positional indexes. Reversing the same operands yields a different derivation." /></Panel><Panel title="Experimental boundary" icon={ShieldCheck} meta="enforced"><div className="space-y-3 text-xs leading-5 text-slate-400"><Boundary label="Local runtime" value="Browser computation and IndexedDB only" /><Boundary label="Excluded" value="LLMs, remote inference, embeddings, and external source calls" /><Boundary label="Deferred" value="Dimensions, gates, and Human Design remain unassigned hypotheses" /></div></Panel><Panel title="Evidence ledger" icon={BookOpenCheck} meta={`${laboratory.evidence.length} records`}><div className="space-y-2">{laboratory.hypotheses.map(hypothesis => <div key={hypothesis.id} className="rounded-xl border border-white/8 bg-black/10 p-2.5"><div className="flex items-center justify-between gap-2"><p className="mono text-[10px] text-cyan-100">{hypothesis.id}</p><span className="mono text-[9px] uppercase text-emerald-100/70">{hypothesis.status}</span></div><p className="mt-1.5 text-[11px] leading-5 text-slate-400">{hypothesis.metric}</p><p className="mono mt-1 text-[9px] text-slate-600">{hypothesis.evidenceIds.length} linked evidence</p></div>)}</div></Panel><Panel title="Manifest status" icon={Database} meta="D2.0"><p className="text-sm font-bold text-white">{laboratory.manifest ? "Structural gate passed" : "Awaiting sealed dataset"}</p><p className="mt-2 text-xs leading-5 text-slate-400">{laboratory.manifest ? `${laboratory.manifest.observations.length} observations declared; holdouts stay separate from discovery.` : "Import the D1 phoneme inventory and preregistered split to execute the full D2.0 benchmark."}</p></Panel></aside>
      </div>
    </main>
  </div>;
}

const inputStyle = "w-full rounded-xl border border-white/10 bg-black/15 px-3 py-2 text-xs text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-200/45 focus:ring-2 focus:ring-cyan-200/10";
const labelStyle = "mono mb-1.5 block text-[9px] uppercase tracking-[0.14em] text-slate-500";

function Panel({ title, icon: Icon, meta, action, children }: { title: string; icon: typeof Beaker; meta: string; action?: React.ReactNode; children: React.ReactNode }) { return <section className="overflow-hidden rounded-[22px] border border-white/10 bg-[#172531] shadow-xl shadow-black/15"><div className="flex min-h-12 items-center justify-between gap-3 border-b border-white/9 bg-white/[0.017] px-4"><div className="flex min-w-0 items-center gap-2"><Icon className="h-4 w-4 shrink-0 text-cyan-100/80" /><h3 className="truncate text-sm font-bold text-slate-100">{title}</h3></div>{action ?? <span className="mono shrink-0 text-[9px] uppercase tracking-[0.1em] text-slate-500">{meta}</span>}</div><div className="p-4">{children}</div></section>; }
function Metric({ value, label }: { value: number; label: string }) { return <div className="min-w-[72px] px-3"><p className="text-lg font-extrabold leading-none text-white">{value}</p><p className="mono mt-1 text-[9px] uppercase tracking-[0.12em] text-slate-500">{label}</p></div>; }
function D2ManifestPanel({ manifest, manifestText, onTextChange, onValidate, selectedHoldoutId, onHoldoutChange, onRunHoldout }: { manifest: D2Manifest | null; manifestText: string; onTextChange: (value: string) => void; onValidate: () => void; selectedHoldoutId: string; onHoldoutChange: (value: string) => void; onRunHoldout: () => void }) { const holdouts = manifest?.observations.filter(item => item.split === "holdout") ?? []; return <Panel title="D2.0 manifest gate" icon={FileJson} meta={manifest ? "ready" : "empty"}><p className="mb-3 text-xs leading-5 text-slate-400">Paste the sealed phoneme inventory and declared morpheme split when available. The lab rejects an underspecified benchmark rather than inventing one.</p><textarea value={manifestText} onChange={event => onTextChange(event.target.value)} className={`${inputStyle} mono min-h-28 resize-y`} placeholder='{"name":"...","grammarVersion":"...","primitives":[],"observations":[]}' /><Button onClick={onValidate} className="mt-2 w-full border-cyan-200/20 bg-cyan-200/10 text-cyan-100 hover:bg-cyan-200/18" variant="secondary"><ShieldCheck className="mr-2 h-3.5 w-3.5" />Validate & save</Button>{manifest && <div className="mt-3 border-t border-white/8 pt-3"><p className="flex items-center gap-1.5 text-[11px] text-emerald-200"><CheckCircle2 className="h-3.5 w-3.5" />{manifest.name}</p><label className={`${labelStyle} mt-3`}>Declared holdout</label><select value={selectedHoldoutId} onChange={event => onHoldoutChange(event.target.value)} className={inputStyle}>{holdouts.map(item => <option key={item.id} className="bg-[#172531]" value={item.id}>{item.id} · {item.phonemes.join(" → ")}</option>)}</select><Button onClick={onRunHoldout} disabled={!holdouts.length} className="mt-2 w-full bg-emerald-300 text-[#10241f] hover:bg-emerald-200"><Play className="mr-2 h-3.5 w-3.5 fill-current" />Run held-out D2.0</Button></div>}</Panel>; }
function SealedD1Panel({ loaded, onLoad }: { loaded: boolean; onLoad: () => void }) {
  return <Panel title="Supplied D1 baseline" icon={Database} meta={loaded ? "replayed" : "sealed source"}>
    <p className="text-xs leading-5 text-slate-400">The supplied archive contains the sealed 10-phoneme corpus, discovery/test split, reconstruction results, compression record, and ablation record. It remains a D1 feature-to-phoneme baseline.</p>
    <div className="mt-3 grid grid-cols-2 gap-2">
      <Measure label="Reconstruct" value={`${(D1_SEAL.recordedMetrics.generationAccuracy * 100).toFixed(0)}%`} tone="emerald" />
      <Measure label="Novelty" value={`${(D1_SEAL.recordedMetrics.novelCompositionRate * 100).toFixed(0)}%`} tone="cyan" />
      <Measure label="Compression" value={`${(D1_SEAL.compressionGain * 100).toFixed(0)}%`} tone="violet" />
      <Measure label="Ablations" value={String(D1_SEAL.ablations.length)} tone="emerald" />
    </div>
    <details className="mt-3 rounded-xl border border-white/8 bg-black/10 p-2.5 text-xs text-slate-400"><summary className="cursor-pointer font-semibold text-slate-200">Inspect sealed evidence record</summary><div className="mt-3 space-y-3"><div><p className="mono text-[9px] uppercase tracking-[0.12em] text-slate-500">compression record</p><p className="mt-1 leading-5">Direct: {D1_SEAL.compression.directBits} bits · grammar total: {D1_SEAL.compression.grammarBits} bits · grammar cost: {D1_SEAL.compression.grammarCostBits} bits · residual: {D1_SEAL.compression.residualBits} bits.</p></div><div><p className="mono text-[9px] uppercase tracking-[0.12em] text-slate-500">ablations</p><div className="mt-2 max-h-44 space-y-1.5 overflow-y-auto pr-1">{D1_SEAL.ablations.map(ablation => <div key={ablation.component} className="rounded-lg border border-white/8 bg-white/[0.025] px-2 py-1.5"><p className="mono break-all text-[9px] text-cyan-100/80">{ablation.component}</p><p className="mt-1 text-[10px] text-slate-500">ablated performance {ablation.performanceAblated.toFixed(2)} · impact {ablation.impact.toFixed(2)}{ablation.metric ? ` · ${ablation.metric}` : ""}</p></div>)}</div></div></div></details>
    <div className="mt-3 rounded-xl border border-white/8 bg-black/10 p-2.5"><p className="mono text-[9px] uppercase tracking-[0.1em] text-slate-500">source seal</p><p className="mono mt-1 break-all text-[9px] text-cyan-100/75">{D1_SEAL.manifestHash}</p></div>
    <Button onClick={onLoad} disabled={loaded} className="mt-3 w-full bg-violet-200/15 text-violet-100 hover:bg-violet-200/22" variant="secondary"><Database className="mr-2 h-3.5 w-3.5" />{loaded ? "D1 baseline replayed" : "Load sealed D1 baseline"}</Button>
  </Panel>;
}
function RegistryItem({ operand, selected, onToggle }: { operand: Operand; selected: boolean; onToggle: () => void }) { const isComposite = "children" in operand; return <button onClick={onToggle} className={`flex w-full items-center gap-2.5 rounded-xl border p-2.5 text-left transition ${selected ? "border-cyan-200/30 bg-cyan-200/[0.075]" : "border-white/8 bg-black/10 hover:border-white/15 hover:bg-white/[0.03]"}`}><span className={`grid h-7 w-7 place-items-center rounded-lg ${isComposite ? "bg-emerald-200/10 text-emerald-100" : "bg-cyan-200/10 text-cyan-100"}`}>{isComposite ? <Layers3 className="h-3.5 w-3.5" /> : <CircleDot className="h-3.5 w-3.5" />}</span><span className="min-w-0 flex-1"><span className="mono block truncate text-[10px] text-slate-200">{operand.id}</span><span className="block truncate text-[10px] text-slate-500">{operand.scale}</span></span><span className={`h-2 w-2 rounded-full ${selected ? "bg-cyan-200 shadow-[0_0_9px_rgba(140,225,255,.8)]" : "bg-slate-700"}`} /></button>; }
function ProjectionChooser({ value, onChange }: { value: ProjectionId; onChange: (value: ProjectionId) => void }) { return <select value={value} onChange={event => onChange(event.target.value as ProjectionId)} className="mono max-w-28 rounded-lg border border-white/10 bg-black/15 px-2 py-1.5 text-[9px] text-slate-300 outline-none"><option className="bg-[#172531]" value="dependency">dependency</option><option className="bg-[#172531]" value="knowledge">knowledge</option><option className="bg-[#172531]" value="causal">causal</option><option className="bg-[#172531]" value="phase">phase</option><option className="bg-[#172531]" value="temporal">temporal</option></select>; }
function ActivationMesh({ derivation, projection }: { derivation: Derivation | null; projection: ProjectionId }) { if (!derivation) return <div className="grid min-h-[320px] place-items-center rounded-2xl border border-dashed border-white/12 bg-black/10 px-8 text-center"><div><GitBranch className="mx-auto h-6 w-6 text-slate-600" /><p className="mt-3 text-sm text-slate-500">Generate a composition to visualize its activated topology.</p></div></div>; const activeRelations = derivation.topology.filter(item => item.projection === projection); const childCount = derivation.output.children.length; return <div className="relative min-h-[340px] overflow-hidden rounded-2xl border border-white/8 bg-[#101923] p-4"><div className="absolute inset-0 opacity-40" style={{ backgroundImage: "linear-gradient(rgba(138,199,220,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(138,199,220,.08) 1px,transparent 1px)", backgroundSize: "28px 28px" }} /><div className="relative mx-auto h-[300px] max-w-[700px]"><svg className="absolute inset-0 h-full w-full overflow-visible" viewBox="0 0 700 300" preserveAspectRatio="none"><defs><marker id="lab-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10z" fill={projectionTint[projection]} /></marker></defs>{activeRelations.map((relation, index) => { const x = 80 + (index * (540 / Math.max(1, childCount - 1))); return <path key={relation.id} d={`M ${x} 95 C ${x} 165, 350 155, 350 220`} fill="none" stroke={projectionTint[projection]} strokeOpacity=".72" strokeWidth="1.45" strokeDasharray={projection === "temporal" ? "0" : "4 5"} markerEnd="url(#lab-arrow)" />; })}</svg>{derivation.output.children.map((child, index) => <div key={child} style={{ left: `${(index * (82 / Math.max(1, childCount - 1))) + 3}%` }} className="absolute top-10 w-[104px] -translate-x-1/2 rounded-xl border border-cyan-200/25 bg-cyan-200/[0.07] p-2.5 text-center shadow-lg shadow-black/20"><p className="mono truncate text-[9px] text-cyan-100">{child.replace("f.", "")}</p><p className="mono mt-1 text-[8px] text-cyan-100/45">α {derivation.activation[index]?.activation.toFixed(2)}</p></div>)}<div className="absolute bottom-7 left-1/2 w-[154px] -translate-x-1/2 rounded-2xl border border-emerald-200/35 bg-emerald-200/[0.1] p-3 text-center shadow-[0_0_28px_rgba(105,232,181,.13)]"><Sparkles className="mx-auto h-4 w-4 text-emerald-100" /><p className="mt-1.5 truncate text-xs font-bold text-white">{derivation.output.label}</p><p className="mono mt-1 text-[9px] text-emerald-100/60">α 1.00 · generated</p></div></div><div className="relative mt-1 flex items-center justify-between gap-3 border-t border-white/8 pt-3"><span className="mono text-[10px] uppercase tracking-[0.12em]" style={{ color: projectionTint[projection] }}>{projection} projection</span><span className="mono text-[9px] text-slate-500">{activeRelations.length} relations · {derivation.ledger.transitionCount} transitions</span></div></div>; }
function DerivationInspector({ derivation, evaluation, replayMatches, controlResult, onControl }: { derivation: Derivation; evaluation: ReturnType<typeof evaluateDerivation>; replayMatches: boolean; controlResult: ControlResult | null; onControl: (control: ControlResult["control"]) => void }) { return <div className="min-w-0 space-y-4"><div className="grid gap-2 sm:grid-cols-3"><Measure label="Integrity" value={evaluation.derivationIntegrity === 1 ? "1.00" : "0.00"} tone="emerald" /><Measure label="Direct" value={bytesLabel(evaluation.directBits)} tone="cyan" /><Measure label="Grammar" value={bytesLabel(evaluation.grammarBits)} tone="violet" /></div><div className="rounded-2xl border border-white/9 bg-black/15 p-3"><div className="flex items-center justify-between gap-3"><span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Frozen output hash</span><span className={`flex items-center gap-1.5 text-[10px] ${replayMatches ? "text-emerald-200" : "text-rose-200"}`}>{replayMatches ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Activity className="h-3.5 w-3.5" />}{replayMatches ? "replay matches" : "replay differs"}</span></div><p className="mono mt-2 break-all text-[11px] text-cyan-100/80">{derivation.outputHash}</p></div><div><p className={labelStyle}>Controls</p><div className="flex flex-wrap gap-2"><Button onClick={() => onControl("remove-operator")} size="sm" variant="secondary" className="border border-white/10 bg-white/[0.04] text-slate-300 hover:bg-white/[0.1]">Remove operator</Button><Button onClick={() => onControl("remove-primitive")} size="sm" variant="secondary" className="border border-white/10 bg-white/[0.04] text-slate-300 hover:bg-white/[0.1]">Remove primitive</Button>{derivation.output.operatorId === "o_sequence" && <Button onClick={() => onControl("remove-position")} size="sm" variant="secondary" className="border border-white/10 bg-white/[0.04] text-slate-300 hover:bg-white/[0.1]">Ablate position</Button>}</div>{controlResult && <p className={`mt-2 text-xs ${controlResult.passed ? "text-emerald-200" : "text-rose-200"}`}>{controlResult.message}</p>}</div><div className="grid gap-2 sm:grid-cols-2"><InspectorRow icon={Timer} label="Recursion depth" value={String(derivation.ledger.recursionDepth)} /><InspectorRow icon={Activity} label="Edge traversals" value={String(derivation.ledger.edgesTraversed)} /><InspectorRow icon={GitBranch} label="Transitions" value={String(derivation.ledger.transitionCount)} /><InspectorRow icon={Combine} label="Compression gain" value={`${(evaluation.compressionGain * 100).toFixed(1)}%`} /></div></div>; }
function OperatorCard({ icon: Icon, title, detail, statement }: { icon: typeof Combine; title: string; detail: string; statement: string }) { return <div className="rounded-2xl border border-white/9 bg-black/10 p-3"><div className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-lg bg-violet-200/10 text-violet-100"><Icon className="h-3.5 w-3.5" /></span><div><p className="mono text-[10px] text-slate-200">{title}</p><p className="text-[10px] text-slate-500">{detail}</p></div></div><p className="mt-2.5 text-[11px] leading-5 text-slate-400">{statement}</p></div>; }
function Boundary({ label, value }: { label: string; value: string }) { return <div><p className="mono text-[9px] uppercase tracking-[0.13em] text-slate-500">{label}</p><p className="mt-1 text-xs leading-5 text-slate-300">{value}</p></div>; }
function Measure({ label, value, tone }: { label: string; value: string; tone: "emerald" | "cyan" | "violet" }) { const styles = { emerald: "border-emerald-200/18 bg-emerald-200/[0.055] text-emerald-100", cyan: "border-cyan-200/18 bg-cyan-200/[0.055] text-cyan-100", violet: "border-violet-200/18 bg-violet-200/[0.055] text-violet-100" }; return <div className={`rounded-xl border p-2.5 ${styles[tone]}`}><p className="mono text-[9px] uppercase tracking-[0.1em] opacity-60">{label}</p><p className="mt-1 text-sm font-bold">{value}</p></div>; }
function InspectorRow({ icon: Icon, label, value }: { icon: typeof Timer; label: string; value: string }) { return <div className="flex items-center justify-between rounded-xl border border-white/8 bg-black/10 px-3 py-2"><span className="flex items-center gap-2 text-[11px] text-slate-500"><Icon className="h-3.5 w-3.5" />{label}</span><span className="mono text-[11px] text-slate-200">{value}</span></div>; }
function EmptyLedger() { return <div className="grid min-h-44 place-items-center rounded-2xl border border-dashed border-white/12 bg-black/10 px-8 text-center"><div><BookOpenCheck className="mx-auto h-5 w-5 text-slate-600" /><p className="mt-2 text-sm text-slate-500">No derivation has been generated. Every valid composition will appear here with its evidence path.</p></div></div>; }
function ExperimentMeasurementPanel({ measurements }: { measurements: NonNullable<Derivation["measurements"]> }) { return <Panel title="Frozen D2.0 measurements" icon={Activity} meta="manifest derived"><div className="grid grid-cols-2 gap-2 sm:grid-cols-4"><Measure label="Reconstruction" value={`${(measurements.reconstructionAccuracy * 100).toFixed(0)}%`} tone="emerald" /><Measure label="Novelty" value={`${(measurements.novelCompositionRate * 100).toFixed(0)}%`} tone="cyan" /><Measure label="Reuse" value={`${measurements.operatorReuse} scales`} tone="violet" /><Measure label="Compression" value={`${(measurements.compressionGain * 100).toFixed(1)}%`} tone="emerald" /></div><p className="mt-3 text-[11px] leading-5 text-slate-500">Direct: {measurements.directBits} bits · Grammar + ordered-position cost: {measurements.grammarBits} bits · Special-case burden: {measurements.specialCaseBurden.toFixed(2)}</p></Panel>; }
