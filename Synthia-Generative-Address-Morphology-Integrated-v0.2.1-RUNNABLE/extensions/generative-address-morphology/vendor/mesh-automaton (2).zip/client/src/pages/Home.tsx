import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Activity, ArrowRight, Bot, Braces, CheckCircle2, ChevronDown, CircleDot,
  Compass, CornerDownRight, Database, Factory, GitBranch, Link2, Loader2,
  Network, PackagePlus, Play, Plus, Route, ScrollText, Send, Sparkles,
  TerminalSquare, Unplug, WandSparkles,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { JsonRecord, MeshSessionSnapshot, ToolProfile } from "../../../server/mesh-domain";

const PROFILE_LABELS: Record<ToolProfile, string> = {
  envelope: "Envelope",
  project: "Project",
  merge: "Merge",
  annotate: "Annotate",
  pipeline: "Pipeline",
};

const NODE_COLORS: Record<string, string> = {
  ingress: "border-sky-300/45 bg-sky-300/10 text-sky-100",
  grammar: "border-amber-300/45 bg-amber-300/10 text-amber-100",
  factory: "border-emerald-300/45 bg-emerald-300/10 text-emerald-100",
  transform: "border-violet-300/45 bg-violet-300/10 text-violet-100",
  observer: "border-rose-300/45 bg-rose-300/10 text-rose-100",
};

const MESH_SCALE = 0.65;
const NODE_WIDTH = 138;

function getNodeIcon(kind: string) {
  if (kind === "grammar") return Braces;
  if (kind === "factory") return Factory;
  if (kind === "observer") return ScrollText;
  if (kind === "ingress") return Send;
  return Activity;
}

function formatJson(value: unknown) {
  return JSON.stringify(value, null, 2);
}

function parseRecord(raw: string, label: string): JsonRecord | null {
  try {
    const parsed: unknown = JSON.parse(raw || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error();
    return parsed as JsonRecord;
  } catch {
    toast.error(`${label} must be a JSON object.`);
    return null;
  }
}

export default function Home() {
  const utils = trpc.useUtils();
  const bootstrap = trpc.mesh.bootstrap.useQuery(undefined, { retry: false });
  const sessions = trpc.mesh.list.useQuery(undefined, { retry: false });
  const [sessionId, setSessionId] = useState("");
  const session = trpc.mesh.get.useQuery({ sessionId }, { enabled: Boolean(sessionId), retry: false });
  const [workspace, setWorkspace] = useState<MeshSessionSnapshot | null>(null);
  const [activeRunId, setActiveRunId] = useState("");
  const runEvents = trpc.mesh.runEvents.useQuery({ runId: activeRunId }, { enabled: Boolean(activeRunId), retry: false });
  const [selectedNodeId, setSelectedNodeId] = useState("");
  const [sourceNodeId, setSourceNodeId] = useState("");
  const [targetNodeId, setTargetNodeId] = useState("");
  const [runInput, setRunInput] = useState("");
  const [nodeLabel, setNodeLabel] = useState("Signal node");
  const [nodeKind, setNodeKind] = useState("transform");
  const [edgeLabel, setEdgeLabel] = useState("route");
  const [toolName, setToolName] = useState("Structured envelope");
  const [toolProfile, setToolProfile] = useState<ToolProfile>("envelope");
  const [toolConfig, setToolConfig] = useState('{"labels":["explicit","traceable"]}');
  const [ruleName, setRuleName] = useState("Forward signal");
  const [ruleSymbol, setRuleSymbol] = useState("SIGNAL");
  const [ruleProduction, setRuleProduction] = useState('{"actions":[{"type":"emit","source":"{{input}}","target":"{{input}}","intent":"signal.forward"}]}');
  const drag = useRef<{ nodeId: string; startX: number; startY: number; x: number; y: number } | null>(null);

  const adopt = (next: MeshSessionSnapshot | null | undefined) => {
    if (!next) return;
    setWorkspace(next);
    setSessionId(next.id);
    setRunInput(current => current || next.defaultInput);
    setSourceNodeId(current => current || next.nodes[0]?.id || "");
    setTargetNodeId(current => current || next.nodes[1]?.id || "");
    setSelectedNodeId(current => current || next.nodes[0]?.id || "");
  };

  useEffect(() => {
    if (!sessionId && bootstrap.data) adopt(bootstrap.data);
  }, [bootstrap.data, sessionId]);

  useEffect(() => {
    if (session.data) adopt(session.data);
  }, [session.data]);

  useEffect(() => {
    if (workspace?.runs[0] && !activeRunId) setActiveRunId(workspace.runs[0].id);
  }, [workspace, activeRunId]);

  const refreshSessions = () => void utils.mesh.list.invalidate();
  const createSession = trpc.mesh.createSession.useMutation({
    onSuccess: data => { adopt(data); setActiveRunId(""); refreshSessions(); toast.success("New mesh workspace created."); },
    onError: error => toast.error(error.message),
  });
  const addNode = trpc.mesh.addNode.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); toast.success("Node added to mesh."); },
    onError: error => toast.error(error.message),
  });
  const addEdge = trpc.mesh.addEdge.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); toast.success("Directed link added."); },
    onError: error => toast.error(error.message),
  });
  const updateNode = trpc.mesh.updateNode.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); },
    onError: error => toast.error(error.message),
  });
  const updateEdge = trpc.mesh.updateEdge.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); },
    onError: error => toast.error(error.message),
  });
  const createTool = trpc.mesh.createTool.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); toast.success("Tool Factory registered the tool."); },
    onError: error => toast.error(error.message),
  });
  const addRule = trpc.mesh.addRule.useMutation({
    onSuccess: data => { adopt(data); refreshSessions(); toast.success("Grammar production registered."); },
    onError: error => toast.error(error.message),
  });
  const runCycle = trpc.mesh.runCycle.useMutation({
    onSuccess: data => {
      adopt(data.snapshot);
      setActiveRunId(data.runId);
      void utils.mesh.runEvents.invalidate({ runId: data.runId });
      refreshSessions();
      toast.success(`Cycle completed with ${data.result.summary.events as number} trace events.`);
    },
    onError: error => toast.error(error.message),
  });

  useEffect(() => {
    const onMove = (event: MouseEvent) => {
      const pending = drag.current;
      if (!pending || !workspace) return;
      const positionX = Math.max(20, Math.min(1000, (pending.x + event.clientX - pending.startX) / MESH_SCALE));
      const positionY = Math.max(35, Math.min(455, pending.y + event.clientY - pending.startY));
      setWorkspace(current => current ? {
        ...current,
        nodes: current.nodes.map(node => node.id === pending.nodeId ? { ...node, positionX, positionY } : node),
      } : current);
    };
    const onUp = () => {
      const pending = drag.current;
      if (!pending || !workspace) return;
      const current = workspace.nodes.find(node => node.id === pending.nodeId);
      drag.current = null;
      if (current) updateNode.mutate({ sessionId: workspace.id, nodeId: current.id, positionX: current.positionX, positionY: current.positionY });
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [workspace, updateNode]);

  const selectedNode = useMemo(() => workspace?.nodes.find(node => node.id === selectedNodeId) ?? workspace?.nodes[0], [workspace, selectedNodeId]);
  const selectedEvents = runEvents.data ?? [];
  const busy = createSession.isPending || addNode.isPending || addEdge.isPending || createTool.isPending || addRule.isPending || runCycle.isPending;

  if (bootstrap.isLoading || (sessionId && session.isLoading && !workspace)) {
    return <LoadingState />;
  }

  if (bootstrap.error || sessions.error || session.error) {
    return <FailureState message={bootstrap.error?.message || sessions.error?.message || session.error?.message || "The orchestration workspace could not be loaded."} />;
  }

  if (!workspace) return <LoadingState />;

  const nodeById = new Map(workspace.nodes.map(node => [node.id, node]));
  const currentRun = workspace.runs.find(run => run.id === activeRunId) ?? workspace.runs[0];

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#172129] text-[#e7ece6] selection:bg-emerald-300/30">
      <header className="relative z-20 flex min-h-[74px] items-center justify-between border-b border-white/10 bg-[#172129]/88 px-5 backdrop-blur-xl lg:px-8">
        <div className="flex items-center gap-4">
          <div className="grid h-10 w-10 place-items-center rounded-[14px] border border-emerald-200/30 bg-emerald-300/12 shadow-[0_0_34px_rgba(96,220,178,0.12)]">
            <Network className="h-5 w-5 text-emerald-200" strokeWidth={1.7} />
          </div>
          <div>
            <p className="mono text-[10px] uppercase tracking-[0.22em] text-emerald-200/70">orchestration workspace</p>
            <h1 className="text-lg font-bold tracking-[-0.04em] text-white">Mesh Automaton</h1>
          </div>
        </div>
        <a href="/pure-synthia-complete" className="grid h-9 w-9 place-items-center rounded-xl border border-cyan-200/18 bg-cyan-200/[0.06] text-cyan-100 md:hidden" aria-label="Open complete Pure Synthia laboratory"><Braces className="h-4 w-4" /></a>
        <div className="hidden items-center gap-5 md:flex">
          <StatusPill tone="emerald" label="Deterministic" />
          <div className="h-5 w-px bg-white/10" />
          <p className="mono text-xs text-slate-400">NO LLM CALLS</p>
          <a href="/pure-synthia-complete" className="mono text-[10px] uppercase tracking-[0.12em] text-cyan-100/80 transition hover:text-cyan-100">Pure Synthia complete</a>
          <Button onClick={() => createSession.mutate({ name: `Untitled mesh ${((sessions.data?.length ?? 0) + 1).toString().padStart(2, "0")}` })} disabled={busy} variant="outline" className="border-white/15 bg-white/[0.035] text-slate-200 hover:bg-white/10 hover:text-white">
            <Plus className="mr-2 h-4 w-4" />New mesh
          </Button>
        </div>
      </header>

      <main className="mx-auto grid max-w-[1680px] gap-4 p-4 lg:grid-cols-[270px_minmax(650px,1fr)_316px] lg:p-5">
        <ControlRail
          workspace={workspace}
          sessions={sessions.data ?? []}
          sessionId={sessionId}
          onSelectSession={id => { setSessionId(id); setActiveRunId(""); }}
          nodeLabel={nodeLabel}
          nodeKind={nodeKind}
          onNodeLabelChange={setNodeLabel}
          onNodeKindChange={setNodeKind}
          onAddNode={() => {
            const index = workspace.nodes.length;
            addNode.mutate({ sessionId: workspace.id, label: nodeLabel, kind: nodeKind, positionX: 104 + ((index * 177) % 780), positionY: index % 2 === 0 ? 380 : 420 });
          }}
          sourceNodeId={sourceNodeId}
          targetNodeId={targetNodeId}
          edgeLabel={edgeLabel}
          onSourceChange={setSourceNodeId}
          onTargetChange={setTargetNodeId}
          onEdgeLabelChange={setEdgeLabel}
          onAddEdge={() => {
            if (!sourceNodeId || !targetNodeId || sourceNodeId === targetNodeId) return toast.error("Choose two different mesh nodes.");
            addEdge.mutate({ sessionId: workspace.id, sourceNodeId, targetNodeId, label: edgeLabel });
          }}
          toolName={toolName}
          toolProfile={toolProfile}
          toolConfig={toolConfig}
          onToolNameChange={setToolName}
          onToolProfileChange={setToolProfile}
          onToolConfigChange={setToolConfig}
          onCreateTool={() => {
            const configuration = parseRecord(toolConfig, "Tool configuration");
            if (!configuration) return;
            createTool.mutate({ sessionId: workspace.id, name: toolName, profile: toolProfile, configuration, capabilities: ["mesh.transform"], composition: toolProfile === "pipeline" ? workspace.tools.map(tool => tool.id) : [] });
          }}
          ruleName={ruleName}
          ruleSymbol={ruleSymbol}
          ruleProduction={ruleProduction}
          onRuleNameChange={setRuleName}
          onRuleSymbolChange={setRuleSymbol}
          onRuleProductionChange={setRuleProduction}
          onCreateRule={() => {
            try {
              const parsed = JSON.parse(ruleProduction) as { actions?: unknown };
              if (!Array.isArray(parsed.actions)) throw new Error();
            } catch {
              toast.error("Grammar production must be valid JSON with an actions array.");
              return;
            }
            addRule.mutate({ sessionId: workspace.id, name: ruleName, symbol: ruleSymbol, production: ruleProduction });
          }}
          busy={busy}
        />

        <section className="min-w-0 space-y-4">
          <div className="rounded-[24px] border border-white/10 bg-[#1b2730] p-5 shadow-2xl shadow-black/10">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
              <div className="max-w-xl">
                <div className="mb-3 flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-300 shadow-[0_0_11px_rgba(110,235,183,0.9)]" />
                  <span className="mono text-[10px] uppercase tracking-[0.18em] text-emerald-200/70">{workspace.status} session</span>
                </div>
                <h2 className="text-2xl font-bold tracking-[-0.045em] text-white">{workspace.name}</h2>
                <p className="mt-1 text-sm leading-6 text-slate-400">{workspace.description}</p>
              </div>
              <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/10 p-2.5">
                <Metric value={workspace.nodes.length} label="nodes" />
                <Metric value={workspace.edges.filter(edge => edge.enabled).length} label="routes" />
                <Metric value={workspace.rules.filter(rule => rule.enabled).length} label="rules" />
                <Metric value={workspace.tools.length} label="tools" />
              </div>
            </div>
          </div>

          <section className="overflow-hidden rounded-[24px] border border-white/10 bg-[#1a252d] shadow-2xl shadow-black/10">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-white/[0.018] px-5 py-3.5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-100"><Compass className="h-4 w-4 text-emerald-200" />Mesh field</div>
              <div className="flex items-center gap-3 text-[11px] text-slate-500"><span className="mono">drag nodes to re-position</span><span className="hidden h-1 w-1 rounded-full bg-slate-600 sm:block" /><span className="hidden sm:block">edges route by priority</span></div>
            </div>
            <div className="mesh-grid relative min-h-[540px] overflow-auto p-5">
              <div className="relative h-[500px] min-w-[1070px]">
                <svg className="pointer-events-none absolute inset-0 h-full w-full overflow-visible" viewBox="0 0 1100 500" preserveAspectRatio="none" aria-hidden="true">
                  <defs>
                    <marker id="mesh-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="rgba(150,222,205,0.7)" /></marker>
                  </defs>
                  {workspace.edges.filter(edge => edge.enabled).map(edge => {
                    const source = nodeById.get(edge.sourceNodeId);
                    const target = nodeById.get(edge.targetNodeId);
                    if (!source || !target) return null;
                    const x1 = source.positionX * MESH_SCALE + NODE_WIDTH;
                    const y1 = source.positionY + 44;
                    const x2 = target.positionX * MESH_SCALE + 2;
                    const y2 = target.positionY + 44;
                    const curve = Math.max(44, Math.abs(x2 - x1) * 0.38);
                    return <g key={edge.id}><path d={`M ${x1} ${y1} C ${x1 + curve} ${y1}, ${x2 - curve} ${y2}, ${x2} ${y2}`} fill="none" stroke="rgba(136,210,194,0.5)" strokeWidth="1.35" strokeDasharray="4 5" markerEnd="url(#mesh-arrow)" /><text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 7} textAnchor="middle" fill="rgba(185,214,210,0.62)" fontSize="10" fontFamily="DM Mono">{edge.label}</text></g>;
                  })}
                </svg>
                {workspace.nodes.map(node => <MeshNodeCard key={node.id} node={node} selected={selectedNode?.id === node.id} onSelect={() => setSelectedNodeId(node.id)} onDragStart={(event) => { drag.current = { nodeId: node.id, startX: event.clientX, startY: event.clientY, x: node.positionX * MESH_SCALE, y: node.positionY }; }} />)}
                <div className="absolute bottom-4 left-4 flex items-center gap-3 rounded-xl border border-white/10 bg-[#172129]/80 px-3 py-2 backdrop-blur"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /><span className="mono text-[10px] text-slate-400">routing surface · bounded & inspectable</span></div>
              </div>
            </div>
          </section>

          <section className="rounded-[24px] border border-white/10 bg-[#1b2730] p-4 shadow-2xl shadow-black/10">
            <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2"><WandSparkles className="h-4 w-4 text-amber-200" /><h3 className="text-sm font-bold text-white">Run deterministic grammar cycle</h3></div><span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">seed {workspace.sessionSeed}</span></div>
            <div className="flex flex-col gap-3 md:flex-row"><textarea value={runInput} onChange={event => setRunInput(event.target.value)} rows={2} className="min-h-[64px] flex-1 resize-none rounded-2xl border border-white/10 bg-black/15 px-4 py-3 text-sm leading-6 text-slate-100 outline-none transition focus:border-emerald-300/50 focus:ring-2 focus:ring-emerald-300/10" placeholder="Describe a structured signal for the mesh…" /><Button onClick={() => runCycle.mutate({ sessionId: workspace.id, input: runInput })} disabled={busy} className="h-auto min-h-14 rounded-2xl bg-emerald-300 px-5 text-[#162329] shadow-[0_8px_24px_rgba(105,230,181,0.18)] hover:bg-emerald-200"><Play className="mr-2 h-4 w-4 fill-current" />{runCycle.isPending ? "Running…" : "Run cycle"}</Button></div>
          </section>
        </section>

        <InspectorPanel workspace={workspace} selectedNode={selectedNode} events={selectedEvents} currentRun={currentRun} onToggleEdge={edge => updateEdge.mutate({ sessionId: workspace.id, edgeId: edge.id, enabled: !edge.enabled })} />
      </main>
    </div>
  );
}

function ControlRail(props: {
  workspace: MeshSessionSnapshot; sessions: Array<{ id: string; name: string; status: string }>; sessionId: string; onSelectSession: (id: string) => void;
  nodeLabel: string; nodeKind: string; onNodeLabelChange: (value: string) => void; onNodeKindChange: (value: string) => void; onAddNode: () => void;
  sourceNodeId: string; targetNodeId: string; edgeLabel: string; onSourceChange: (value: string) => void; onTargetChange: (value: string) => void; onEdgeLabelChange: (value: string) => void; onAddEdge: () => void;
  toolName: string; toolProfile: ToolProfile; toolConfig: string; onToolNameChange: (value: string) => void; onToolProfileChange: (value: ToolProfile) => void; onToolConfigChange: (value: string) => void; onCreateTool: () => void;
  ruleName: string; ruleSymbol: string; ruleProduction: string; onRuleNameChange: (value: string) => void; onRuleSymbolChange: (value: string) => void; onRuleProductionChange: (value: string) => void; onCreateRule: () => void; busy: boolean;
}) {
  const [expanded, setExpanded] = useState<"mesh" | "tool" | "grammar">("mesh");
  const field = "w-full rounded-xl border border-white/10 bg-black/15 px-3 py-2 text-xs text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-emerald-300/45 focus:ring-2 focus:ring-emerald-300/10";
  return <aside className="space-y-4 lg:sticky lg:top-5 lg:h-[calc(100vh-114px)] lg:overflow-y-auto lg:pr-1">
    <section className="rounded-[22px] border border-white/10 bg-[#1b2730] p-3.5 shadow-xl shadow-black/10">
      <p className="mono mb-2 text-[10px] uppercase tracking-[0.16em] text-slate-500">active workspace</p>
      <div className="relative"><select value={props.sessionId} onChange={event => props.onSelectSession(event.target.value)} className="w-full appearance-none rounded-xl border border-white/10 bg-black/15 py-2.5 pl-3 pr-8 text-sm font-semibold text-slate-100 outline-none focus:border-emerald-300/45">{props.sessions.map(session => <option key={session.id} value={session.id} className="bg-[#1b2730]">{session.name}</option>)}</select><ChevronDown className="pointer-events-none absolute right-2.5 top-3 h-4 w-4 text-slate-500" /></div>
      <div className="mt-3 flex items-center gap-2"><StatusPill tone="emerald" label={`${props.workspace.status} state`} /><span className="mono text-[10px] text-slate-500">{props.workspace.sessionSeed}</span></div>
    </section>
    <section className="overflow-hidden rounded-[22px] border border-white/10 bg-[#1b2730] shadow-xl shadow-black/10">
      <AccordionHeader active={expanded === "mesh"} onClick={() => setExpanded(expanded === "mesh" ? "tool" : "mesh")} icon={GitBranch} title="Mesh editor" meta={`${props.workspace.nodes.length} nodes`} />
      {expanded === "mesh" && <div className="space-y-3 border-t border-white/10 p-3.5"><p className="text-xs leading-5 text-slate-400">Add named graph participants and explicit directed connections. Positions persist when you drag a node.</p><input value={props.nodeLabel} onChange={event => props.onNodeLabelChange(event.target.value)} className={field} aria-label="Node label" /><select value={props.nodeKind} onChange={event => props.onNodeKindChange(event.target.value)} className={field}><option className="bg-[#1b2730]" value="transform">Transform</option><option className="bg-[#1b2730]" value="ingress">Ingress</option><option className="bg-[#1b2730]" value="grammar">Grammar</option><option className="bg-[#1b2730]" value="factory">Factory</option><option className="bg-[#1b2730]" value="observer">Observer</option></select><Button disabled={props.busy} onClick={props.onAddNode} className="w-full bg-white/8 text-slate-100 hover:bg-white/13" variant="secondary"><Plus className="mr-2 h-3.5 w-3.5" />Add mesh node</Button><div className="my-1 border-t border-white/8" /><p className="mono text-[10px] uppercase tracking-[0.15em] text-slate-500">Connect nodes</p><select value={props.sourceNodeId} onChange={event => props.onSourceChange(event.target.value)} className={field}>{props.workspace.nodes.map(node => <option key={node.id} className="bg-[#1b2730]" value={node.id}>From · {node.label}</option>)}</select><select value={props.targetNodeId} onChange={event => props.onTargetChange(event.target.value)} className={field}>{props.workspace.nodes.map(node => <option key={node.id} className="bg-[#1b2730]" value={node.id}>To · {node.label}</option>)}</select><input value={props.edgeLabel} onChange={event => props.onEdgeLabelChange(event.target.value)} className={field} aria-label="Edge label" /><Button disabled={props.busy || props.workspace.nodes.length < 2} onClick={props.onAddEdge} className="w-full bg-emerald-300/15 text-emerald-100 hover:bg-emerald-300/23" variant="secondary"><Link2 className="mr-2 h-3.5 w-3.5" />Add directed link</Button></div>}
    </section>
    <section className="overflow-hidden rounded-[22px] border border-white/10 bg-[#1b2730] shadow-xl shadow-black/10">
      <AccordionHeader active={expanded === "tool"} onClick={() => setExpanded(expanded === "tool" ? "grammar" : "tool")} icon={Factory} title="Tool Factory" meta={`${props.workspace.tools.length} tools`} />
      {expanded === "tool" && <div className="space-y-3 border-t border-white/10 p-3.5"><p className="text-xs leading-5 text-slate-400">Fixed profiles create inspectable tools. The factory never evaluates source or calls a model.</p><input value={props.toolName} onChange={event => props.onToolNameChange(event.target.value)} className={field} aria-label="Tool name" /><select value={props.toolProfile} onChange={event => props.onToolProfileChange(event.target.value as ToolProfile)} className={field}>{Object.entries(PROFILE_LABELS).map(([value, label]) => <option key={value} value={value} className="bg-[#1b2730]">{label}</option>)}</select><textarea value={props.toolConfig} onChange={event => props.onToolConfigChange(event.target.value)} rows={3} className={`${field} mono resize-y`} aria-label="Tool configuration JSON" /><Button disabled={props.busy} onClick={props.onCreateTool} className="w-full bg-emerald-300/15 text-emerald-100 hover:bg-emerald-300/23" variant="secondary"><PackagePlus className="mr-2 h-3.5 w-3.5" />Register tool</Button></div>}
    </section>
    <section className="overflow-hidden rounded-[22px] border border-white/10 bg-[#1b2730] shadow-xl shadow-black/10">
      <AccordionHeader active={expanded === "grammar"} onClick={() => setExpanded(expanded === "grammar" ? "mesh" : "grammar")} icon={Braces} title="Grammar rules" meta={`${props.workspace.rules.length} rules`} />
      {expanded === "grammar" && <div className="space-y-3 border-t border-white/10 p-3.5"><p className="text-xs leading-5 text-slate-400">Rules are data. Production actions can emit, invoke, patch, or expand.</p><input value={props.ruleName} onChange={event => props.onRuleNameChange(event.target.value)} className={field} aria-label="Grammar rule name" /><input value={props.ruleSymbol} onChange={event => props.onRuleSymbolChange(event.target.value)} className={`${field} mono`} aria-label="Grammar symbol" /><textarea value={props.ruleProduction} onChange={event => props.onRuleProductionChange(event.target.value)} rows={4} className={`${field} mono resize-y`} aria-label="Grammar production JSON" /><Button disabled={props.busy} onClick={props.onCreateRule} className="w-full bg-amber-300/12 text-amber-100 hover:bg-amber-300/20" variant="secondary"><Plus className="mr-2 h-3.5 w-3.5" />Register production</Button></div>}
    </section>
  </aside>;
}

function InspectorPanel({ workspace, selectedNode, events, currentRun, onToggleEdge }: { workspace: MeshSessionSnapshot; selectedNode: MeshSessionSnapshot["nodes"][number] | undefined; events: Array<{ id: string; sequence: number; eventType: string; nodeId: string | null; messageId: string | null; payload: JsonRecord }>; currentRun: MeshSessionSnapshot["runs"][number] | undefined; onToggleEdge: (edge: MeshSessionSnapshot["edges"][number]) => void }) {
  const [tab, setTab] = useState<"inspect" | "trace" | "rules">("inspect");
  const tabs = [{ id: "inspect", label: "Inspect", icon: CircleDot }, { id: "trace", label: "Trace", icon: TerminalSquare }, { id: "rules", label: "Rules", icon: Braces }] as const;
  return <aside className="min-w-0 rounded-[24px] border border-white/10 bg-[#1b2730] shadow-2xl shadow-black/10 lg:sticky lg:top-5 lg:max-h-[calc(100vh-114px)] lg:overflow-hidden">
    <div className="flex border-b border-white/10">{tabs.map(item => <button key={item.id} onClick={() => setTab(item.id)} className={`flex flex-1 items-center justify-center gap-1.5 px-2 py-3 text-[11px] font-semibold transition ${tab === item.id ? "border-b-2 border-emerald-300 bg-emerald-300/[0.055] text-emerald-100" : "text-slate-500 hover:bg-white/[0.035] hover:text-slate-300"}`}><item.icon className="h-3.5 w-3.5" />{item.label}</button>)}</div>
    <div className="max-h-[520px] overflow-y-auto p-4 lg:max-h-[calc(100vh-170px)]">
      {tab === "inspect" && <div className="space-y-5">{selectedNode ? <><div><p className="mono text-[10px] uppercase tracking-[0.18em] text-slate-500">selected node</p><div className="mt-2 flex items-center gap-3"><div className={`grid h-9 w-9 place-items-center rounded-xl border ${NODE_COLORS[selectedNode.kind] ?? "border-white/15 bg-white/5 text-slate-100"}`}>{(() => { const Icon = getNodeIcon(selectedNode.kind); return <Icon className="h-4 w-4" />; })()}</div><div><h3 className="text-sm font-bold text-white">{selectedNode.label}</h3><p className="mono text-[10px] uppercase tracking-[0.13em] text-slate-500">{selectedNode.kind}</p></div></div></div><InspectorBlock title="Capabilities" content={selectedNode.capabilities.length ? selectedNode.capabilities.join("\n") : "No explicit capabilities"} /><InspectorBlock title="Configuration" content={formatJson(selectedNode.configuration)} /><InspectorBlock title="Live state" content={formatJson(selectedNode.nodeState)} /></> : <EmptyInspector />}
        <div className="border-t border-white/10 pt-4"><p className="mono mb-2 text-[10px] uppercase tracking-[0.18em] text-slate-500">Routes</p><div className="space-y-2">{workspace.edges.map(edge => <button onClick={() => onToggleEdge(edge)} key={edge.id} className="flex w-full items-center justify-between rounded-xl border border-white/8 bg-black/10 p-2.5 text-left transition hover:border-white/16 hover:bg-white/[0.035]"><span className="min-w-0"><span className="block truncate text-xs font-semibold text-slate-200">{edge.label}</span><span className="mono block text-[10px] text-slate-500">p{edge.priority} · max {edge.maxHops} hops</span></span>{edge.enabled ? <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" /> : <Unplug className="h-4 w-4 shrink-0 text-slate-600" />}</button>)}</div></div></div>}
      {tab === "trace" && <div className="space-y-4"><div><p className="mono text-[10px] uppercase tracking-[0.18em] text-slate-500">latest run</p><h3 className="mt-1 text-sm font-bold text-white">{currentRun ? currentRun.input : "No cycles recorded"}</h3>{currentRun && <p className="mono mt-1 text-[10px] text-slate-500">{currentRun.id} · {currentRun.status}</p>}</div>{events.length > 0 ? <ol className="relative space-y-3 border-l border-white/10 pl-4">{events.map(event => <li key={event.id} className="relative"><span className="absolute -left-[20px] top-1.5 h-2 w-2 rounded-full border border-emerald-200/60 bg-[#1b2730]" /><p className="mono text-[10px] text-emerald-200/75">{String(event.sequence).padStart(2, "0")} · {event.eventType}</p><p className="mt-1 line-clamp-3 text-xs leading-5 text-slate-400">{formatJson(event.payload)}</p></li>)}</ol> : <EmptyTrace />}</div>}
      {tab === "rules" && <div className="space-y-3">{workspace.rules.map(rule => <div key={rule.id} className="rounded-2xl border border-white/10 bg-black/10 p-3"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold text-slate-100">{rule.name}</p><p className="mono mt-1 text-[10px] text-amber-200/75">{rule.symbol} · priority {rule.priority}</p></div><StatusPill tone={rule.enabled ? "amber" : "slate"} label={rule.enabled ? "active" : "off"} /></div><pre className="mono mt-3 max-h-28 overflow-auto whitespace-pre-wrap rounded-xl border border-white/7 bg-black/15 p-2 text-[10px] leading-5 text-slate-500">{rule.production}</pre></div>)}<div className="pt-1"><p className="mono text-[10px] uppercase tracking-[0.18em] text-slate-500">Registered tools</p><div className="mt-2 space-y-2">{workspace.tools.map(tool => <div key={tool.id} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/10 p-2.5"><Bot className="h-3.5 w-3.5 text-emerald-200" /><span className="min-w-0 flex-1 truncate text-xs text-slate-300">{tool.name}</span><span className="mono text-[9px] uppercase text-slate-500">{tool.profile}</span></div>)}</div></div></div>}
    </div>
  </aside>;
}

function MeshNodeCard({ node, selected, onSelect, onDragStart }: { node: MeshSessionSnapshot["nodes"][number]; selected: boolean; onSelect: () => void; onDragStart: (event: React.MouseEvent<HTMLButtonElement>) => void }) {
  const Icon = getNodeIcon(node.kind);
  return <button onClick={onSelect} onMouseDown={event => { if (event.button === 0) onDragStart(event); }} style={{ left: node.positionX * MESH_SCALE, top: node.positionY }} className={`absolute z-10 w-[138px] select-none rounded-2xl border p-3 text-left shadow-xl shadow-black/15 transition duration-200 ${NODE_COLORS[node.kind] ?? "border-white/15 bg-white/5 text-slate-100"} ${selected ? "ring-2 ring-emerald-200/60 ring-offset-2 ring-offset-[#1a252d]" : "hover:-translate-y-0.5 hover:shadow-2xl"}`}><div className="flex items-start justify-between gap-2"><Icon className="h-4 w-4" strokeWidth={1.8} /><span className="mono text-[9px] uppercase tracking-[0.12em] opacity-65">{node.kind}</span></div><p className="mt-3 truncate text-xs font-bold text-white">{node.label}</p><div className="mt-2 flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-current opacity-80" /><span className="mono text-[9px] opacity-65">{typeof node.nodeState.messageCount === "number" ? node.nodeState.messageCount : 0} messages</span></div></button>;
}

function AccordionHeader({ active, onClick, icon: Icon, title, meta }: { active: boolean; onClick: () => void; icon: typeof GitBranch; title: string; meta: string }) { return <button onClick={onClick} className={`flex w-full items-center justify-between px-3.5 py-3.5 text-left transition ${active ? "bg-white/[0.035]" : "hover:bg-white/[0.025]"}`}><span className="flex items-center gap-2 text-sm font-bold text-slate-100"><Icon className={`h-4 w-4 ${active ? "text-emerald-200" : "text-slate-500"}`} />{title}</span><span className="mono text-[10px] text-slate-500">{meta}</span></button>; }
function InspectorBlock({ title, content }: { title: string; content: string }) { return <div><p className="mono mb-2 text-[10px] uppercase tracking-[0.18em] text-slate-500">{title}</p><pre className="mono max-h-40 overflow-auto whitespace-pre-wrap rounded-xl border border-white/8 bg-black/15 p-3 text-[10px] leading-5 text-slate-400">{content}</pre></div>; }
function Metric({ value, label }: { value: number; label: string }) { return <div className="px-2.5 text-center"><p className="text-lg font-extrabold leading-none text-white">{value}</p><p className="mono mt-1 text-[9px] uppercase tracking-[0.12em] text-slate-500">{label}</p></div>; }
function StatusPill({ tone, label }: { tone: "emerald" | "amber" | "slate"; label: string }) { const styles = { emerald: "border-emerald-300/25 bg-emerald-300/10 text-emerald-100", amber: "border-amber-300/25 bg-amber-300/10 text-amber-100", slate: "border-slate-400/20 bg-slate-400/10 text-slate-400" }; return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-1 mono text-[9px] uppercase tracking-[0.1em] ${styles[tone]}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{label}</span>; }
function LoadingState() { return <div className="grid min-h-screen place-items-center bg-[#172129]"><div className="flex flex-col items-center gap-4"><div className="grid h-14 w-14 place-items-center rounded-2xl border border-emerald-200/20 bg-emerald-300/10"><Loader2 className="h-5 w-5 animate-spin text-emerald-200" /></div><p className="mono text-xs uppercase tracking-[0.18em] text-slate-500">Assembling mesh workspace</p></div></div>; }
function FailureState({ message }: { message: string }) { return <div className="grid min-h-screen place-items-center bg-[#172129] p-6"><div className="max-w-md rounded-3xl border border-rose-300/20 bg-rose-300/5 p-7 text-center"><Database className="mx-auto h-7 w-7 text-rose-200" /><h2 className="mt-4 text-lg font-bold text-white">Workspace unavailable</h2><p className="mt-2 text-sm leading-6 text-slate-400">{message}</p></div></div>; }
function EmptyInspector() { return <div className="rounded-2xl border border-dashed border-white/12 p-4 text-sm text-slate-500">Select a node in the mesh to inspect its capabilities, configuration, and current state.</div>; }
function EmptyTrace() { return <div className="rounded-2xl border border-dashed border-white/12 p-4 text-sm leading-6 text-slate-500"><Route className="mb-2 h-4 w-4" />Run a grammar cycle to produce the message and execution trace.</div>; }
