import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Redirect, Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CompletePureSynthia from "./pages/CompletePureSynthia";
import { PURE_SYNTHIA_CANONICAL_ROUTE, PURE_SYNTHIA_LEGACY_ROUTE, resolvePureSynthiaRoute } from "./lib/pure-synthia-routes";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={PURE_SYNTHIA_CANONICAL_ROUTE} component={CompletePureSynthia} />
      <Route path={PURE_SYNTHIA_LEGACY_ROUTE}><Redirect to={resolvePureSynthiaRoute(PURE_SYNTHIA_LEGACY_ROUTE)} /></Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
