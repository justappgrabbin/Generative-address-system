/* @vitest-environment happy-dom */
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/trpc", () => ({
  trpc: {
    archive: {
      manifest: { useQuery: () => ({ data: undefined, isLoading: false }) },
    },
  },
}));

import App from "./App";

let root: Root | undefined;
let container: HTMLDivElement | undefined;

Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });

beforeAll(() => {
  const setAttribute = HTMLIFrameElement.prototype.setAttribute;
  vi.spyOn(HTMLIFrameElement.prototype, "setAttribute").mockImplementation(function (this: HTMLIFrameElement, name, value) {
    // The page component is rendered in full. Only the browser-native archive
    // document load is excluded from this virtual-DOM test.
    if (name.toLowerCase() === "src") return;
    return setAttribute.call(this, name, value);
  });
});

afterAll(() => vi.restoreAllMocks());

afterEach(() => {
  act(() => root?.unmount());
  container?.remove();
  root = undefined;
  container = undefined;
});

describe("Pure Synthia legacy route", () => {
  it("redirects the old complete route to the canonical laboratory and renders the unified workspace", async () => {
    window.history.replaceState({}, "", "/pure-synthia-complete");
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);

    await act(async () => {
      root?.render(<App />);
      await new Promise(resolve => setTimeout(resolve, 0));
    });

    expect(window.location.pathname).toBe("/laboratory");
    expect(container.textContent).toContain("Pure Synthia · Unified Laboratory");
    expect(container.textContent).toContain("All supplied sources present");
    expect(container.textContent).toContain("Pass 4 · Step 4.1 laboratory");
    expect(container.querySelector("iframe")).not.toBeNull();
  });
});
