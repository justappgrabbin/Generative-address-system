# Repair Log — pure-synthia-phase2

Original artifact preserved untouched alongside this repaired copy
(`pure-synthia-phase2.zip` / `pure-synthia-phase2-ORIGINAL.zip`).
Diff the two to audit every change made below.

Phase 2 is an additive extension of Phase 1 (new: graph topology
auto-recording, multi-scale meshes, address/dimensional evaluators,
cross-scale transfer testing, dataset generators, three new operators
`o_project`/`o_transform`/`o_recurse`). `src/core/*`, `src/derivation/*`,
`src/graph/graph.js`, `src/hypotheses/*`, `src/experiments/{experiment,
metrics,controls}.js`, and `src/storage/*` are carried over from Phase 1
essentially unchanged (confirmed by diff against the Phase 1 original),
so the two Phase 1 defects repaired there recur here identically and
were repaired the same way, verified independently in Phase 2's own
context rather than assumed.

---

## Repair 1 of 4

**File changed:** `src/main.js`

**Original failure:** `tests/phase1-gate.js` — byte-identical to the
Phase 1 version, carried over deliberately as a cross-phase regression
gate per the README's architecture diagram — throws a `SyntaxError` on
import: `The requested module '../src/main.js' does not provide an
export named 'createPhase1Engine'`. The suite cannot even start. The
same break affects the in-browser "Run Phase 1 Gate" button in
`index.html` (`btn-run-phase1-gate`), which dynamically imports the same
test file.

**Root cause:** Phase 2's `main.js` renamed the Phase 1 bootstrap
factory from `createPhase1Engine` to `createPhase2Engine` without
preserving the old export. The two functions are behaviorally identical
(same bootstrap: bare `SynthiaEngine` + `GraphProjectionSet` +
`OperatorRegistry` + empty primitive `Map`) — this was a naming
decision, not a behavior change — but it silently broke the export
contract the unchanged gate test depends on.

**Exact repair:**
```diff
 export function createPhase2Engine() {
   ...
   return engine;
 }
+
+// Preserved for tests/phase1-gate.js, which is intentionally carried
+// over unchanged from Phase 1 as a cross-phase regression gate (see
+// README). Identical bootstrap to createPhase2Engine; kept as a named
+// alias so the gate's import contract still resolves.
+export { createPhase2Engine as createPhase1Engine };
```

**Why this preserves the original architecture:** No behavior was
invented — `createPhase1Engine` is a pure alias for the existing,
unmodified `createPhase2Engine`. `createPhase2Engine` itself is
untouched. The fix restores an export contract, it does not change what
either factory does.

**Observable behavior changed:** Yes, in the narrow sense that the gate
test (and the "Run Phase 1 Gate" UI button) now runs instead of crashing
on import. No engine behavior, primitive, operator, or derivation output
changed.

---

## Repair 2 of 4

**File changed:** `src/core/operator.js` — `Operator.apply()`

Identical defect and identical fix to Phase 1 Repair 1/2. This file is
byte-identical to the pre-repair Phase 1 version.

**Original failure:** Calling `o_bundle.apply()` with 3 operands (its
documented n-ary use — see its own docstring `o_bundle(p_1,...,p_n)`,
its `accepts()` which explicitly permits 2+, and gate test item 2b)
threw `RangeError: o_bundle requires exactly 2 operands.`

**Root cause:** `apply()` enforced strict equality
(`operands.length !== this.arity`), contradicting `SynthiaEngine
.selectOperators()`'s existing treatment of `arity` as a *minimum*
(`op.arity <= primitives.length`) and `o_bundle`'s own `accepts()` logic.

**Exact repair:** Same as Phase 1 — changed `!==` to `<` (minimum
operand count), updated the error message.

**Why this preserves the original architecture:** `o_sequence` is
unaffected (independently re-enforces exactly-2 via its own `accepts()`,
re-verified in this codebase). Only `o_bundle`'s already-documented
n-ary behavior was restored.

**Observable behavior changed:** Yes — `o_bundle` executes instead of
crashing on 3+ operands. No change to any 2-operand call site.

---

## Repair 3 of 4

**File changed:** `src/derivation/replay.js` — `hashDerivation()`

Identical defect and identical fix to Phase 1 Repair 2/2. This file is
byte-identical to the pre-repair Phase 1 version.

**Original failure:** Gate item 10 ("Deterministic replay") failed —
identical input produced different hashes on repeat execution.

**Root cause:** The hash included `id` (incrementing counter) and
`timestamp` (`Date.now()`), both unique per call by construction,
contradicting the class's own documented equivalence class ("given
equivalent initial state, input, context, grammar version, and operator
set, reproduce the same derivation").

**Exact repair:** Same as Phase 1 — excluded `id` and `timestamp` from
the hashed payload via destructuring; all other derivation content
(input, decomposition, primitives, operators, topology, result, context)
remains hashed.

**Why this preserves the original architecture:** `Derivation` itself is
untouched — `id`/`timestamp` are still generated, stored, and displayed
exactly as before. Only the hash's input was corrected to match its own
documented contract.

**Observable behavior changed:** Yes — identical (input, context) pairs
now correctly hash identically. No change to any derivation's stored
content or display.

---

## Repair 4 of 4

**File changed:** `src/engine/address-evaluator.js` — `evaluateRetrieval()`

**Original failure:** Clicking "Test H3 Address Evaluation" in
`index.html` (`btn-eval-addresses`, which calls `evaluateH3(primitives,
addressFn, [], [])` — empty test-query/test-composition arrays by
default, with no UI control to populate them) produced
`"retrieval": null` in the results pane (`JSON.stringify(NaN) === "null"`)
instead of a defined value.

**Root cause:** `evaluateRetrieval(primitives, addressFn, testQueries)`
computed `totalScore / testQueries.length` with no guard against
`testQueries.length === 0`, producing `0 / 0 = NaN`. Every sibling
evaluation method in the same class (`evaluateGenerative`) and in the
adjacent `DimensionalEvaluator` class (`evaluatePredictive`,
`evaluateGenerative`, `evaluateTransformConsistency`) consistently
guards the identical pattern with `length > 0 ? x / length : 0`.
`evaluateRetrieval` was the single exception to an otherwise uniform
convention — an isolated, mechanical omission, not a different design.

**Exact repair:**
```diff
-    return totalScore / testQueries.length;
+    return testQueries.length > 0 ? totalScore / testQueries.length : 0;
```

**Why this preserves the original architecture:** Brings the one
outlier method in line with the guard convention already used
consistently by every other evaluation method in the same and adjacent
class. No new fallback value or semantic invented — `0` was already the
established convention for "no test cases" everywhere else in this
evaluation suite.

**Observable behavior changed:** Yes — `retrieval` now reports `0`
(consistent with `compression` and `generative` in the same result)
instead of `null`/`NaN` when no test queries are supplied. No change
when test queries are actually provided (`testQueries.length > 0`
preserves the original division exactly).

---

## Flagged, not fixed — genuine gap (inherited from Phase 1, same root cause)

**Gate item 7 ("Complexity ledger collected") still fails.** Not
patched, for the same reason as in Phase 1: `bootstrapPhonologicalPrimitives()`
is carried over unchanged and still never registers any `"grapheme"`-scale
primitives, registered phoneme identities are still slash-wrapped
(`"/p/"`, not `"p"`), and no vowel primitives exist at all. Every
string-input `execute()` call still silently decomposes to zero
primitives. See the Phase 1 repair log for full detail — nothing about
this changed in Phase 2, so it was not re-investigated as a new issue,
only re-confirmed.

**New, additional visible consequence of the same gap:** the
"Run Ablation Study" button (`btn-ablation`) in `index.html` calls
`eng.execute("pat", {})` as its test function and scores impact via
`derivation.result?.type === "composite" ? 1 : 0`. Because `"pat"` always
decomposes to zero primitives (per the above), both the baseline and the
`o_bundle`-ablated engine always score `0`, so the ablation demo always
reports zero impact regardless of whether `o_bundle` is actually present.
This is a symptom of the already-flagged gap, not a separate defect —
noted for completeness, not logged as a new repair.

## Flagged, not fixed — genuinely ambiguous, needs your call

**The `o_project`, `o_transform`, and `o_recurse` "Test" demo buttons in
`index.html` do not actually exercise the operators they claim to.**
Traced and reproduced directly (not just read statically):

- **"Test o_project"** sets input to `["phoneme.p", "Movement"]`. The
  generic `execute()` → `decompose()` pipeline only resolves array
  elements by looking them up in the *primitive* registry
  (`this.primitives.get(ref)`); `"Movement"` is a dimension name, not a
  registered primitive ID, so it's silently dropped. Only `phoneme.p`
  survives decomposition — one primitive is below every operator's
  arity-2 minimum, so `compose()` short-circuits to an empty
  `primitive_set` and `o_project` is never selected, let alone called.

- **"Test o_transform"** sets input to `["phoneme.p", { rule: "voice",
  transform: x => x }]`. Two compounding issues: (1)
  `JSON.stringify()` — used to serialize the demo value into the text
  input, exactly as the "Execute" box's own round-trip works — silently
  drops the `transform` function (JSON has no function type), so even a
  perfect pipeline could never receive a working transform. (2)
  `decompose()`'s array branch pushes *any* non-string array element
  through as-is (`typeof ref === "string" ? lookup : ref`), so the
  stripped `{rule:"voice"}` object is incorrectly admitted as if it were
  a primitive. With 2 "primitives" now present, `selectOperators()`
  picks the *first* operator (registration order: bundle, sequence,
  project, transform, recurse) whose `accepts()` returns true for a
  same-length probe — `o_sequence.accepts()` only checks
  `operands.length === 2`, so it intercepts before `o_transform` is ever
  tried. Reproduced directly: the button's input currently executes
  `o_sequence`, not `o_transform`.

- **"Test o_recurse"** sets input to `["o_bundle", [...]]`. `"o_bundle"`
  is an *operator* ID, not a primitive ID, so it's dropped by the same
  primitive-only lookup. The nested array is admitted as a pseudo-primitive
  by the same `: ref` fallback (arrays aren't strings), ending up with a
  raw array masquerading as a primitive with no `.scale`. `findForScale(undefined)`
  matches no operator, so `o_recurse` is never selected either.
  Reproduced directly: the button's current output is an empty
  `primitive_set` with one contentless member.

**Why I flagged this instead of fixing it:** unlike the four repairs
above, there is no single, obviously-intended small change here — I can
see at least three structurally different ways to make these buttons do
what their labels claim (extend `decompose()` to also resolve non-primitive
literals/operator references; change the three buttons to call
`engine.operators.get(id).apply(...)` directly, matching the pattern
`CrossScaleExperiment.testTransfer()` already uses elsewhere in this same
codebase for exactly this kind of non-standard-operand call; or tighten
`o_sequence.accepts()` to stop intercepting operand shapes it wasn't
meant for) — and each carries different scope and risk. Deciding between
them is a design call, not a mechanical repair, so per your instructions
I'm surfacing it rather than picking one myself.

---

## Verification

Gate suite before repairs (this codebase): crashed at import
(`SyntaxError`, `createPhase1Engine` not exported) — never reached
execution.

After Repair 1 (import fixed): crashed at gate item 2b (`o_bundle`
arity) — same as Phase 1's pre-repair state.

After Repairs 1–3: **11 passed, 1 failed** (item 7, the inherited,
flagged gap — not a new failure).

Repair 4 (address-evaluator) is not exercised by the gate suite; verified
separately by direct reproduction of the exact `index.html` call path,
before and after.

Full `src/` import sweep (every `.js` file individually imported):
clean, no errors. All `index.html` element IDs referenced by the script
were cross-checked against the markup: no missing-ID crashes.
