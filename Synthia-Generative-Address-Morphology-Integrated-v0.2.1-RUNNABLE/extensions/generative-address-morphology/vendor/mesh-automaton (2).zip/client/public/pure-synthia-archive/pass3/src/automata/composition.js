// src/automata/composition.js
/**
 * Automata Composition Operators
 * Compose smaller automata into larger ones — the computational analogue
 * of linguistic composition (o_bundle, o_sequence at the automaton scale).
 */
import { FiniteStateMachine, FSMState, FSMTransition } from "./fsm.js";

export class AutomataComposer {
  constructor() {
    this._fsmCounter = 0;
  }

  // Sequential composition: A then B (connect accepting states of A to initial of B)
  composeSequential(fsmA, fsmB, options = {}) {
    const newId = `fsm:seq:${++this._fsmCounter}`;
    const result = new FiniteStateMachine({
      id: newId,
      name: `${fsmA.name}_then_${fsmB.name}`,
    });

    // Copy all states from A, renaming to avoid collision
    const aMap = new Map();
    for (const s of fsmA.states.values()) {
      const newState = new FSMState({
        id: `${newId}:A:${s.id}`,
        name: s.name,
        accepting: false, // A's accepting states become non-accepting
        initial: s.initial,
      });
      aMap.set(s.id, newState.id);
      result.addState(newState);
    }

    // Copy all states from B, renaming
    const bMap = new Map();
    for (const s of fsmB.states.values()) {
      const newState = new FSMState({
        id: `${newId}:B:${s.id}`,
        name: s.name,
        accepting: s.accepting,
        initial: false, // B's initial state becomes non-initial
      });
      bMap.set(s.id, newState.id);
      result.addState(newState);
    }

    // Copy transitions from A
    for (const t of fsmA.transitions.values()) {
      result.addTransition(new FSMTransition({
        from: aMap.get(t.from),
        to: aMap.get(t.to),
        input: t.input,
        output: t.output,
      }));
    }

    // Copy transitions from B
    for (const t of fsmB.transitions.values()) {
      result.addTransition(new FSMTransition({
        from: bMap.get(t.from),
        to: bMap.get(t.to),
        input: t.input,
        output: t.output,
      }));
    }

    // Connect A's accepting states to B's initial state
    const bInitial = fsmB.getInitialState();
    if (bInitial) {
      const bInitialNew = bMap.get(bInitial.id);
      for (const s of fsmA.getAcceptingStates()) {
        result.addTransition(new FSMTransition({
          from: aMap.get(s.id),
          to: bInitialNew,
          input: options.epsilon || "ε",
          metadata: { type: "epsilon", composition: "sequential" },
        }));
      }
    }

    return result;
  }

  // Parallel composition: A and B simultaneously (union of states, product of transitions)
  composeParallel(fsmA, fsmB, options = {}) {
    const newId = `fsm:par:${++this._fsmCounter}`;
    const result = new FiniteStateMachine({
      id: newId,
      name: `${fsmA.name}_par_${fsmB.name}`,
    });

    // Create product states
    const stateMap = new Map();
    for (const sa of fsmA.states.values()) {
      for (const sb of fsmB.states.values()) {
        const pairId = `${newId}:${sa.id}:${sb.id}`;
        const pairState = new FSMState({
          id: pairId,
          name: `(${sa.name},${sb.name})`,
          accepting: sa.accepting && sb.accepting,
          initial: sa.initial && sb.initial,
        });
        stateMap.set(`${sa.id}:${sb.id}`, pairId);
        result.addState(pairState);
      }
    }

    // Create product transitions
    for (const ta of fsmA.transitions.values()) {
      for (const tb of fsmB.transitions.values()) {
        if (ta.input === tb.input || options.synchronize === false) {
          const fromPair = stateMap.get(`${ta.from}:${tb.from}`);
          const toPair = stateMap.get(`${ta.to}:${tb.to}`);
          if (fromPair && toPair) {
            result.addTransition(new FSMTransition({
              from: fromPair,
              to: toPair,
              input: ta.input === tb.input ? ta.input : `${ta.input}/${tb.input}`,
              metadata: { composition: "parallel" },
            }));
          }
        }
      }
    }

    return result;
  }

  // Kleene star: A* (zero or more repetitions of A)
  composeKleene(fsmA, options = {}) {
    const newId = `fsm:kleene:${++this._fsmCounter}`;
    const result = new FiniteStateMachine({
      id: newId,
      name: `${fsmA.name}*`,
    });

    // Copy all states
    const stateMap = new Map();
    for (const s of fsmA.states.values()) {
      const newState = new FSMState({
        id: `${newId}:${s.id}`,
        name: s.name,
        accepting: true, // All states become accepting in Kleene star
        initial: s.initial,
      });
      stateMap.set(s.id, newState.id);
      result.addState(newState);
    }

    // Copy all transitions
    for (const t of fsmA.transitions.values()) {
      result.addTransition(new FSMTransition({
        from: stateMap.get(t.from),
        to: stateMap.get(t.to),
        input: t.input,
        output: t.output,
      }));
    }

    // Add epsilon transitions from accepting back to initial
    const initial = fsmA.getInitialState();
    if (initial) {
      for (const s of fsmA.getAcceptingStates()) {
        result.addTransition(new FSMTransition({
          from: stateMap.get(s.id),
          to: stateMap.get(initial.id),
          input: options.epsilon || "ε",
          metadata: { type: "epsilon", composition: "kleene" },
        }));
      }
    }

    return result;
  }
}
