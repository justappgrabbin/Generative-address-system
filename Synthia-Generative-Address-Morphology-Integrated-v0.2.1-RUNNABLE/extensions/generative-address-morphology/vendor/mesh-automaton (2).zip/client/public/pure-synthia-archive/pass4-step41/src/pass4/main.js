// src/pass4/main.js
/**
 * Pure Synthia — Pass 4 Entry Point
 * Wraps the frozen Pass-3 baseline with Pass-4 capabilities.
 * All Pass-3 files remain untouched.
 */

// Re-export frozen Pass-3 API
export {
  Primitive,
  Composite,
  CanonicalAddress,
  Evidence,
  GraphProjectionSet,
  GraphTopologyBuilder,
  MeshRegistry,
  OperatorRegistry,
  SynthiaEngine,
  AddressEvaluator,
  DimensionalEvaluator,
  HypothesisRegistry,
  Experiment,
  ExperimentRunner,
  MetricsCollector,
  ControlSystem,
  AblationStudy,
  CrossScaleExperiment,
  SynthiaStorage,
  SyntheticDataset,
  LinguisticDataset,
  ComputationalDataset,
  MultiScaleTokenizer,
  DependencyParser,
  FiniteStateMachine,
  FSMState,
  FSMTransition,
  AutomataComposer,
} from "../main.js";

// Pass-4 additions
export { SynthiaEnginePass4 } from "./engine.js";
export { EmergenceDetector } from "../emergence/detector.js";
export { AutomataMesh, AutomataMeshRegistry } from "../emergence/multi-automata.js";

// Pass-4 factory
export async function createPass4Engine() {
  // Import here to avoid circular dependency issues
  const { createPhase3Engine, bootstrapPhonologicalPrimitives, bootstrapSampleAutomata } = await import("../main.js");
  const base = createPhase3Engine();
  bootstrapPhonologicalPrimitives(base);
  bootstrapSampleAutomata(base);

  const { SynthiaEnginePass4 } = await import("./engine.js");
  return new SynthiaEnginePass4(base);
}

// Synchronous factory (for immediate use)
export function wrapPass4(baseEngine) {
  return new SynthiaEnginePass4(baseEngine);
}
