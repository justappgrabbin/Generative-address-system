// src/parsers/dependency.js
/**
 * Simple Dependency Parser
 * Models grammatical relationships between tokens.
 * Per §9: G_D is the dependency graph projection.
 */

export class DependencyRelation {
  constructor({ head, dependent, relation, evidence = null }) {
    this.head = head;
    this.dependent = dependent;
    this.relation = relation;
    this.evidence = evidence;
  }

  toJSON() {
    return {
      head: this.head,
      dependent: this.dependent,
      relation: this.relation,
      evidence: this.evidence,
    };
  }
}

export class DependencyParser {
  constructor() {
    this.posPatterns = {
      DET: /^(the|a|an|this|that|these|those|my|your|his|her|its|our|their)$/i,
      PREP: /^(in|on|at|by|with|from|to|for|of|about|into|through|during|before|after|above|below|between|under)$/i,
      CONJ: /^(and|but|or|nor|for|yet|so|because|although|while|if|unless)$/i,
      AUX: /^(is|am|are|was|were|be|been|being|have|has|had|do|does|did|will|would|could|should|may|might|must)$/i,
      PRON: /^(i|you|he|she|it|we|they|me|him|her|us|them|myself|yourself|himself|herself|itself|ourselves|themselves)$/i,
    };
  }

  parse(tokens) {
    const relations = [];
    const posTags = tokens.map(t => this._tagPOS(t));

    let rootIdx = posTags.findIndex(p => p.pos === "VERB");
    if (rootIdx === -1) rootIdx = posTags.findIndex(p => p.pos === "NOUN");
    if (rootIdx === -1) rootIdx = 0;

    const root = tokens[rootIdx];
    relations.push(new DependencyRelation({
      head: "ROOT",
      dependent: root.id,
      relation: "root",
    }));

    for (let i = 0; i < rootIdx; i++) {
      if (posTags[i].pos === "NOUN" || posTags[i].pos === "PRON") {
        relations.push(new DependencyRelation({
          head: root.id,
          dependent: tokens[i].id,
          relation: "nsubj",
        }));
      }
    }

    for (let i = rootIdx + 1; i < tokens.length; i++) {
      if (posTags[i].pos === "NOUN" || posTags[i].pos === "PRON") {
        relations.push(new DependencyRelation({
          head: root.id,
          dependent: tokens[i].id,
          relation: "dobj",
        }));
      }
    }

    for (let i = 0; i < tokens.length - 1; i++) {
      if (posTags[i].pos === "ADJ" && (posTags[i + 1]?.pos === "NOUN")) {
        relations.push(new DependencyRelation({
          head: tokens[i + 1].id,
          dependent: tokens[i].id,
          relation: "amod",
        }));
      }
    }

    for (let i = 0; i < tokens.length - 1; i++) {
      if (posTags[i].pos === "DET" && (posTags[i + 1]?.pos === "NOUN" || posTags[i + 1]?.pos === "ADJ")) {
        relations.push(new DependencyRelation({
          head: tokens[i + 1].id,
          dependent: tokens[i].id,
          relation: "det",
        }));
      }
    }

    for (let i = 0; i < tokens.length - 1; i++) {
      if (posTags[i].pos === "PREP") {
        let headIdx = i - 1;
        while (headIdx >= 0 && posTags[headIdx].pos === "DET") headIdx--;
        if (headIdx >= 0) {
          relations.push(new DependencyRelation({
            head: tokens[headIdx].id,
            dependent: tokens[i].id,
            relation: "prep",
          }));
        }
        if (i + 1 < tokens.length) {
          relations.push(new DependencyRelation({
            head: tokens[i].id,
            dependent: tokens[i + 1].id,
            relation: "pobj",
          }));
        }
      }
    }

    return {
      tokens: tokens.map((t, i) => ({ ...t.toJSON(), pos: posTags[i].pos })),
      relations: relations.map(r => r.toJSON()),
      root: root.id,
    };
  }

  _tagPOS(token) {
    const text = token.text.toLowerCase();

    for (const [pos, pattern] of Object.entries(this.posPatterns)) {
      if (pattern.test(text)) {
        return { text, pos };
      }
    }

    if (/ing$/.test(text)) return { text, pos: "VERB" };
    if (/ed$/.test(text)) return { text, pos: "VERB" };
    if (/ly$/.test(text)) return { text, pos: "ADV" };
    if (/(tion|ness|ment|ity)$/.test(text)) return { text, pos: "NOUN" };
    if (/(able|ible|ful|less|ous|ive)$/.test(text)) return { text, pos: "ADJ" };

    if (text.length <= 3) return { text, pos: "VERB" };
    return { text, pos: "NOUN" };
  }
}
