# Pure Synthia — Pass 3 Implementation

> A Recursive Generative State Calculus for Cross-Scale Automata
> Browser-native, deterministic, experimentally grounded.

## Pass 3: Sentence/Discourse → Automata → Computational First-Class

Pass 3 scales the system upward from morphemes and phonemes to full discourse, and outward from linguistics to computation. Automata are now first-class primitives, not external datasets.

### What's New in Pass 3

| Component | What It Does |
|---|---|
| **Multi-Scale Tokenizer** | Recursively decomposes text: discourse → paragraph → sentence → clause → word → morpheme → grapheme. Every level is whole relative to children, primitive relative to parent. |
| **Dependency Parser** | POS tagging + dependency relations (nsubj, dobj, amod, det, prep, pobj) with graph edge recording. |
| **Finite State Machines** | FSM states, transitions, and runs as first-class engine primitives at the "automaton" scale. |
| **Automata Composer** | Sequential (A then B), parallel (product), and Kleene star composition of FSMs. |
| **o_automaton** | Operator that composes two FSMs using the composer. |
| **o_discourse** | Operator that composes sentences/paragraphs into higher discourse units. |
| **Engine v0.3.0** | Auto-detects input type (standard | discourse | automaton) and routes to appropriate pipeline. |

### Architecture

```
pure-synthia/
├── src/
│   ├── core/              # Primitive, Composite, Operator, Address, State, Evidence
│   ├── parsers/
│   │   ├── tokenizer.js   # Multi-scale tokenization (discourse → grapheme)
│   │   └── dependency.js  # POS + dependency parsing
│   ├── automata/
│   │   ├── fsm.js         # FiniteStateMachine, FSMState, FSMTransition
│   │   └── composition.js # Sequential, parallel, Kleene composition
│   ├── operators/         # 7 operators: bundle, sequence, project, transform, recurse, automaton, discourse
│   ├── engine/            # SynthiaEngine v0.3.0 with auto-routing
│   ├── graph/             # 5 projections + topology builder + meshes
│   ├── derivation/        # Derivation, Ledger, Replay
│   ├── hypotheses/        # H1–H6 registry
│   ├── experiments/       # Runner, Metrics, Controls, Ablation, Cross-Scale
│   ├── datasets/          # Synthetic, Linguistic, Computational
│   ├── storage/           # IndexedDB
│   └── main.js            # Pass 3 bootstrap with sample automata
├── tests/
│   └── phase1-gate.js     # Phase 1 validation
└── index.html             # Pass 3 Laboratory UI (8 tabs)
```

### Laboratory Tabs

| Tab | Function |
|---|---|
| **⚡ Execute** | Phase 1/2 operations + new o_automaton and o_discourse |
| **📝 Discourse** | Multi-scale tokenization + dependency parsing |
| **⚙️ Automata** | FSM visualization, execution, composition (seq/par/Kleene) |
| **◈ Graphs** | 5 projections, metrics, neighborhoods |
| **⌖ Addresses** | H3 evaluation |
| **◐ Dimensions** | H4 evaluation |
| **↻ Cross-Scale** | H2 operator transfer testing |
| **🔬 Experiments** | Phase 1 gate, ablation, manifest export |

### Sample Automata (Pre-loaded)

1. **Even Zeros** (`fsm:even-zeros`) — Accepts binary strings with even number of 0s
2. **Ends in 01** (`fsm:ends-01`) — Accepts binary strings ending in "01"

Both can be composed sequentially, in parallel, or via Kleene star.

### Quick Start

```bash
python3 -m http.server 8000
# Open http://localhost:8000
```

### Research Sequence Status

| Step | Status |
|---|---|
| 1. Extract linguistic primitives | ✅ |
| 2. Quantify transformations | ✅ |
| 3. Discover recurring operators | ✅ |
| 4. Map candidate dimensional correspondences | ⏳ (H3/H4 evaluators ready) |
| 5. Assign and test canonical addresses | ⏳ (H3 evaluators ready) |
| 6. Scale upward to sentence/discourse | ✅ (Pass 3) |
| 7. Test against computation (automata) | ✅ (Pass 3) |
| 8. Test against larger multi-automata systems | ⏳ (Pass 4) |

## Design Principles

- **Deterministic** — Hash-verified replay
- **Inspectable** — Every output carries complete provenance
- **Falsifiable** — Explicit null hypotheses for every claim
- **Ablation-ready** — Any component removable for impact measurement
- **Backend-free** — Browser-native only
- **Multi-scale** — Same operators work across linguistic and computational scales
