// src/operators/discourse.js
/**
 * o_discourse: compose tokens at the paragraph or discourse level.
 * Mathematical mapping: o_discourse([sentence1, sentence2, ...]) -> paragraph
 * This is the linguistic-scale analogue of o_sequence, but for higher-order units.
 */
import { Operator } from "../core/operator.js";

export function createDiscourseOperator() {
  return new Operator({
    id: "o_discourse",
    arity: 2,
    accepts: (operands, context) => {
      // operands can be sentences, paragraphs, or discourse units
      return operands.length >= 2 &&
             operands.every(op => op && (op.scale === "sentence" || op.scale === "paragraph" || op.scale === "discourse"));
    },
    transform: (operands, context) => {
      const members = operands.map((op, idx) => ({
        position: idx,
        stateId: op.id,
        scale: op.scale,
        text: op.text ? op.text.substring(0, 50) : op.id,
      }));

      // Determine resulting scale
      const scales = operands.map(o => o.scale);
      const resultScale = scales.includes("discourse") ? "discourse" :
                         scales.includes("paragraph") ? "discourse" :
                         scales.includes("sentence") ? "paragraph" : "discourse";

      return {
        operator: "o_discourse",
        members,
        scale: resultScale,
        unitCount: operands.length,
        context: { ...context },
      };
    },
    positionalRule: "order_preserving",
    invariants: ["order_sensitivity", "scale_promotion"],
    scales: ["sentence", "paragraph", "discourse"],
    evidence: [],
  });
}
