// tests/pass4-step41-verify.js
/**
 * Step 4.1 Verification
 * Validates that the Pass-4 engine wrapper correctly integrates
 * the emergence measurement apparatus without modifying Pass-3.
 */

import initPureSynthia from "../src/main.js";
import { SynthiaEnginePass4 } from "../src/pass4/engine.js";

export async function verifyStep41() {
  const results = [];
  const assert = (name, condition, details = "") => {
    const ok = !!condition;
    results.push({ step: "4.1", name, ok, details });
    return ok;
  };

  console.log("=== Pass-4 Step 4.1 Verification ===\n");

  // Setup
  const baseEngine = initPureSynthia();
  const engine = new SynthiaEnginePass4(baseEngine);

  // 1. Pass-3 engine is frozen and accessible
  assert("1. Base engine is Pass-3", engine.base.version === "0.3.0", `version=${engine.base.version}`);

  // 2. Pass-4 engine has emergence detector
  assert("2. Emergence detector exists", engine.emergenceDetector !== null);
  assert("3. Emergence enabled by default", engine.emergenceEnabled === true);

  // 4. Execute runs emergence detection
  const d1 = engine.execute("pat", { source: "verify" });
  assert("4. Execution produces derivation", d1 && d1.id);
  assert("5. Emergence log populated", engine.emergenceLog.length === 1);

  // 6. Emergence result has all 3 criteria
  const er = engine.emergenceLog[0];
  assert("6. Criterion 1 (not stored) checked", er.wasStored === false);
  assert("7. Criterion 2 (generated) checked", er.generated === true);
  assert("8. Criterion 3 (evaluated) checked", er.satisfiesCriteria === true);
  assert("9. Emergent flag set", typeof er.emergent === "boolean");

  // 10. Stored solution is detected as non-emergent
  engine.emergenceDetector.registerStored(d1.result);
  const d2 = engine.execute("pat", { source: "verify" });
  const er2 = engine.emergenceLog[engine.emergenceLog.length - 1];
  assert("10. Stored solution detected", er2.wasStored === true);
  assert("11. Stored solution not emergent", er2.emergent === false);

  // 12. Ablations work
  engine.disableEmergence();
  const before = engine.emergenceLog.length;
  engine.execute("bat", { source: "verify" });
  assert("12. Emergence disabled", engine.emergenceEnabled === false);
  assert("13. No emergence log when disabled", engine.emergenceLog.length === before);

  engine.enableEmergence();
  assert("14. Emergence re-enabled", engine.emergenceEnabled === true);

  // 15. Cross-version replay produces VERSION_MISMATCH
  const record = {
    engineState: { grammarVersion: "phase3.0" },
    derivation: { context: { _pass4Version: "phase3.0" } },
  };
  const replayResult = engine.replay(record);
  assert("15. Cross-version replay status", replayResult.status === "VERSION_MISMATCH");
  assert("16. VERSION_MISMATCH deterministic", typeof replayResult.hash === "number");

  // 17. Same-version replay delegates to base
  const sameVersionRecord = {
    engineState: { grammarVersion: "phase4.0" },
    derivation: { context: { _pass4Version: "phase4.0" } },
  };
  // This will try to replay but may fail for other reasons; we just check it doesn't VERSION_MISMATCH
  const sameReplay = engine.replay(sameVersionRecord);
  assert("17. Same-version not VERSION_MISMATCH", sameReplay.status !== "VERSION_MISMATCH");

  // 18. Rollback to Pass-3 works
  const rollbackResult = engine.rollbackTo("phase3.0");
  assert("18. Rollback succeeds", rollbackResult.rolledBack === true);
  assert("19. Emergence disabled after rollback", engine.emergenceEnabled === false);
  assert("20. Grammar version restored", engine.grammarVersion === "phase3.0");

  // 21. Pass-4 ledger tracks correctly
  assert("21. Ledger has emergenceDetections", engine.pass4Ledger.emergenceDetections >= 1);

  // 22. Compression criterion computable
  const comp = engine.compressionCriterion();
  assert("22. Compression computable", typeof comp.cgWith === "number");
  assert("23. Compression criterion defined", typeof comp.passed === "boolean");

  // Summary
  const passed = results.filter(r => r.ok).length;
  const failed = results.filter(r => !r.ok).length;
  console.log(`\n=== Results: ${passed} passed, ${failed} failed ===`);

  if (failed === 0) {
    console.log("STEP 4.1 VERIFICATION PASSED");
  } else {
    console.log("STEP 4.1 VERIFICATION FAILED");
    for (const r of results.filter(r => !r.ok)) {
      console.log(`  FAIL: ${r.name} — ${r.details}`);
    }
  }

  return { passed, failed, results, stepPassed: failed === 0 };
}

// Auto-run if loaded in browser
if (typeof window !== "undefined") {
  window.verifyStep41 = verifyStep41;
}

export default verifyStep41;
