// src/emergence/self-editor.js
/**
 * Self-Editor
 * Per user memory: "system to be able to modify its own code, learn from execution, and evolve."
 * The Self-Editor can add primitives, modify operators, and evolve rules based on runtime evidence.
 * All edits are versioned and reversible.
 */

export class SelfEditor {
  constructor(engine) {
    this.engine = engine;
    this.edits = []; // versioned edit log
    this.rules = new Map(); // evolved rules
    this._editCounter = 0;
  }

  // Add a new primitive based on observed pattern
  addPrimitiveFromPattern(pattern, scale = "auto") {
    const id = `primitive:evolved:${++this._editCounter}`;
    const primitive = {
      id,
      identity: pattern.identity || `evolved_${this._editCounter}`,
      contrast: pattern.contrast || "auto",
      position: pattern.position || "auto",
      scale,
      operations: pattern.operations || [],
      dependencies: pattern.dependencies || [],
      evidence: [{
        id: `evidence:edit:${this._editCounter}`,
        kind: "inferred",
        source: "self_editor",
        timestamp: Date.now(),
      }],
    };

    this.engine.registerPrimitive(primitive);
    this._logEdit("add_primitive", { id, scale, pattern });
    return primitive;
  }

  // Evolve an operator's acceptance criteria based on success/failure data
  evolveOperatorAcceptance(operatorId, successPatterns, failurePatterns) {
    const operator = this.engine.operators.get(operatorId);
    if (!operator) return { evolved: false, reason: "operator_not_found" };

    // Learn from failures: identify common rejection reasons
    const commonFailures = this._findCommonPatterns(failurePatterns);

    // Create a wrapper that handles the learned edge cases
    const evolvedAccepts = (operands, context) => {
      // Try original acceptance first
      try {
        if (operator.accepts(operands, context)) return true;
      } catch (e) {}

      // Check learned exceptions
      for (const pattern of commonFailures) {
        if (this._matchesPattern(operands, pattern)) {
          // This pattern was previously a failure; be more lenient
          return true;
        }
      }

      return false;
    };

    // Store evolved rule
    this.rules.set(`${operatorId}:evolved`, {
      original: operatorId,
      evolvedAccepts,
      successPatterns,
      failurePatterns,
      timestamp: Date.now(),
    });

    this._logEdit("evolve_operator", { operatorId, successCount: successPatterns.length, failureCount: failurePatterns.length });
    return { evolved: true, ruleId: `${operatorId}:evolved` };
  }

  // Add a new rule to the grammar based on observed regularity
  addRule(pattern, transform, evidence = []) {
    const ruleId = `rule:evolved:${++this._editCounter}`;
    this.rules.set(ruleId, {
      id: ruleId,
      pattern,
      transform,
      evidence,
      timestamp: Date.now(),
    });
    this._logEdit("add_rule", { ruleId });
    return ruleId;
  }

  // Replay all edits from log (for deterministic reconstruction)
  replayEdits() {
    // In a full implementation, this would reconstruct the engine state
    // from the edit log alone
    return {
      editCount: this.edits.length,
      primitivesAdded: this.edits.filter(e => e.type === "add_primitive").length,
      operatorsEvolved: this.edits.filter(e => e.type === "evolve_operator").length,
      rulesAdded: this.edits.filter(e => e.type === "add_rule").length,
    };
  }

  // Rollback to a specific edit point
  rollbackTo(editIndex) {
    if (editIndex < 0 || editIndex >= this.edits.length) {
      return { rolledBack: false, reason: "invalid_index" };
    }

    const targetEdit = this.edits[editIndex];
    const removed = this.edits.splice(editIndex + 1);

    // Remove primitives added after target
    for (const edit of removed.filter(e => e.type === "add_primitive")) {
      this.engine.primitives.delete(edit.data.id);
    }

    // Remove evolved rules after target
    for (const edit of removed.filter(e => e.type === "evolve_operator" || e.type === "add_rule")) {
      this.rules.delete(edit.data.ruleId || `${edit.data.operatorId}:evolved`);
    }

    return { rolledBack: true, to: targetEdit.timestamp, removedCount: removed.length };
  }

  _logEdit(type, data) {
    this.edits.push({
      id: `edit:${++this._editCounter}`,
      type,
      data,
      timestamp: Date.now(),
      primitiveCount: this.engine.primitives.size,
      operatorCount: this.engine.operators.list().length,
    });
  }

  _findCommonPatterns(patterns) {
    // Simple: return patterns that appear more than once
    const counts = new Map();
    for (const p of patterns) {
      const key = JSON.stringify(p);
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    return Array.from(counts.entries())
      .filter(([_, count]) => count > 1)
      .map(([key]) => JSON.parse(key));
  }

  _matchesPattern(operands, pattern) {
    // Loose matching: same number of operands, similar structure
    if (!Array.isArray(pattern.operands)) return false;
    return operands.length === pattern.operands.length;
  }

  summary() {
    return {
      totalEdits: this.edits.length,
      primitivesAdded: this.edits.filter(e => e.type === "add_primitive").length,
      operatorsEvolved: this.edits.filter(e => e.type === "evolve_operator").length,
      rulesAdded: this.edits.filter(e => e.type === "add_rule").length,
      currentRules: this.rules.size,
    };
  }

  toJSON() {
    return {
      edits: this.edits,
      rules: Array.from(this.rules.entries()),
      summary: this.summary(),
    };
  }
}
