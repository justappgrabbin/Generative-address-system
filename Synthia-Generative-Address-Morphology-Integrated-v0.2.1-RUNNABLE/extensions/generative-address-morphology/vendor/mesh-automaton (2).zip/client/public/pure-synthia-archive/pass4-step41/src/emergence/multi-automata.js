// src/emergence/multi-automata.js
/**
 * Multi-Automata Mesh
 * Synchronized mesh of multiple automata operating in parallel.
 * Per §10: A single instance can belong simultaneously to multiple meshes,
 * propagating qualified state packets.
 * Per §20: Strong success requires cross-scale generativity evidence.
 */
import { AutomataComposer } from "../automata/composition.js";

export class AutomataMesh {
  constructor(name) {
    this.name = name;
    this.automata = new Map(); // id -> { fsm, activation, qualifiers }
    this.connections = []; // inter-automata connections
    this.packets = [];
    this._composer = new AutomataComposer();
  }

  addAutomaton(fsm, qualifiers = {}) {
    this.automata.set(fsm.id, {
      fsm,
      activation: 1.0,
      qualifiers: { ...qualifiers },
      state: fsm.getInitialState()?.id || null,
    });
    return this;
  }

  removeAutomaton(fsmId) {
    this.automata.delete(fsmId);
    this.connections = this.connections.filter(c => c.from !== fsmId && c.to !== fsmId);
    return this;
  }

  // Connect output of automaton A to input of automaton B
  connect(fromFsmId, toFsmId, mapping = null) {
    this.connections.push({
      from: fromFsmId,
      to: toFsmId,
      mapping: mapping || ((output) => output),
      timestamp: Date.now(),
    });
    return this;
  }

  // Run all automata on input, propagating through connections
  run(input, maxSteps = 100) {
    const traces = new Map(); // fsmId -> trace
    const step = 0;

    // Initialize each automaton
    for (const [id, entry] of this.automata) {
      traces.set(id, {
        fsmId: id,
        steps: [],
        currentState: entry.fsm.getInitialState()?.id || null,
        accepted: false,
      });
    }

    // Simple round-robin execution with packet propagation
    let currentInput = input;
    for (let i = 0; i < maxSteps && currentInput.length > 0; i++) {
      for (const [id, entry] of this.automata) {
        const symbol = currentInput[0];
        const transitions = entry.fsm.step(entry.state || entry.fsm.getInitialState()?.id, symbol);

        if (transitions.length > 0) {
          const t = transitions[0];
          entry.state = t.to;
          const trace = traces.get(id);
          trace.steps.push({ input: symbol, from: t.from, to: t.to });
          trace.currentState = t.to;
          trace.accepted = entry.fsm.states.get(t.to)?.accepting || false;

          // Propagate to connected automata
          for (const conn of this.connections.filter(c => c.from === id)) {
            const packet = {
              from: id,
              to: conn.to,
              symbol: conn.mapping(symbol),
              step: i,
            };
            this.packets.push(packet);
          }
        }
      }
      currentInput = currentInput.slice(1);
    }

    return {
      meshName: this.name,
      input,
      traces: Array.from(traces.values()),
      packetCount: this.packets.length,
      allAccepted: Array.from(this.automata.values()).every(a => {
        const state = a.fsm.states.get(a.state);
        return state?.accepting || false;
      }),
    };
  }

  // Compose all automata in the mesh into a single product machine
  collapse() {
    const automata = Array.from(this.automata.values()).map(a => a.fsm);
    if (automata.length === 0) return null;
    if (automata.length === 1) return automata[0];

    let result = automata[0];
    for (let i = 1; i < automata.length; i++) {
      result = this._composer.composeParallel(result, automata[i]);
    }
    return result;
  }

  toJSON() {
    return {
      name: this.name,
      automataCount: this.automata.size,
      connectionCount: this.connections.length,
      automata: Array.from(this.automata.keys()),
      connections: this.connections,
    };
  }
}

export class AutomataMeshRegistry {
  constructor() {
    this.meshes = new Map();
  }

  create(name) {
    const mesh = new AutomataMesh(name);
    this.meshes.set(name, mesh);
    return mesh;
  }

  get(name) {
    return this.meshes.get(name);
  }

  toJSON() {
    return Array.from(this.meshes.values()).map(m => m.toJSON());
  }
}
