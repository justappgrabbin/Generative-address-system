// src/emergence/intent.js
/**
 * Intent Engine
 * Per user memory: "Intent Engine is the brain, Synthia Body is the bridge."
 * The Intent Engine observes runtime behavior, identifies gaps, and proposes
 * new primitives, operators, or rules to fill them.
 * This is the self-teaching, self-growing core.
 */

export class IntentEngine {
  constructor(synthiaEngine) {
    this.engine = synthiaEngine;
    this.intents = []; // recorded intents
    this.gaps = []; // identified capability gaps
    this.proposals = []; // proposed new primitives/operators
    this.learningRate = 0.1;
    this.confidenceThreshold = 0.7;
  }

  // Observe a derivation and identify what the system was trying to do
  observe(derivation, context) {
    const intent = this._inferIntent(derivation, context);
    this.intents.push(intent);

    // Check if the intent was satisfied
    const satisfied = this._checkSatisfaction(derivation, intent);
    if (!satisfied) {
      const gap = this._identifyGap(intent, derivation);
      this.gaps.push(gap);

      // Propose a solution
      const proposal = this._proposeSolution(gap);
      if (proposal) this.proposals.push(proposal);
    }

    return { intent, satisfied, gap: !satisfied ? this.gaps[this.gaps.length - 1] : null };
  }

  // Infer intent from derivation pattern
  _inferIntent(derivation, context) {
    const operators = derivation.operators;
    const primitives = derivation.primitives;
    const result = derivation.result;

    // Pattern matching on operator sequences
    let intentType = "unknown";
    if (operators.includes("o_bundle") && operators.includes("o_sequence")) {
      intentType = "compose_structure";
    } else if (operators.includes("o_automaton")) {
      intentType = "compute";
    } else if (operators.includes("o_discourse")) {
      intentType = "communicate";
    } else if (operators.includes("o_project")) {
      intentType = "reframe";
    } else if (operators.includes("o_transform")) {
      intentType = "modify";
    } else if (result?.type === "error") {
      intentType = "resolve_error";
    }

    return {
      type: intentType,
      operators,
      primitiveCount: primitives.length,
      resultType: result?.type,
      context: { ...context },
      timestamp: Date.now(),
    };
  }

  _checkSatisfaction(derivation, intent) {
    const result = derivation.result;
    if (!result) return false;
    if (result.type === "error") return false;
    if (result.type === "primitive_set" && intent.type !== "decompose") return false;
    return true;
  }

  _identifyGap(intent, derivation) {
    const result = derivation.result;
    let gapType = "unknown";
    let missing = [];

    if (result?.type === "error") {
      gapType = "operator_failure";
      missing.push(result.operator);
    } else if (result?.type === "primitive_set") {
      gapType = "no_composition";
      missing.push("applicable_operator");
    } else if (intent.type === "compute" && !result?.result?.accepted) {
      gapType = "computation_failure";
      missing.push("correct_transition");
    }

    return {
      intentType: intent.type,
      gapType,
      missing,
      derivationId: derivation.id,
      timestamp: Date.now(),
    };
  }

  _proposeSolution(gap) {
    if (gap.gapType === "operator_failure") {
      return {
        type: "new_operator_rule",
        target: gap.missing[0],
        description: `Relax acceptance criteria for ${gap.missing[0]}`,
        confidence: 0.5,
      };
    }
    if (gap.gapType === "no_composition") {
      return {
        type: "new_primitive",
        description: "Create composite primitive from uncomposed set",
        confidence: 0.6,
      };
    }
    if (gap.gapType === "computation_failure") {
      return {
        type: "fsm_correction",
        description: "Add missing transition to FSM",
        confidence: 0.7,
      };
    }
    return null;
  }

  // Apply a proposal if confidence exceeds threshold
  applyProposal(proposalIndex) {
    const proposal = this.proposals[proposalIndex];
    if (!proposal || proposal.confidence < this.confidenceThreshold) {
      return { applied: false, reason: "insufficient_confidence" };
    }

    if (proposal.type === "new_primitive") {
      // Create a composite primitive from recent uncomposed results
      const recent = this.engine.derivations.values();
      const candidates = [];
      for (const d of recent) {
        if (d.result?.type === "primitive_set") {
          candidates.push(d);
        }
      }
      if (candidates.length > 0) {
        const newest = candidates[candidates.length - 1];
        const newId = `primitive:auto:${Date.now()}`;
        this.engine.registerPrimitive({
          id: newId,
          identity: `auto_composite_${newId.split(":").pop()}`,
          scale: "auto",
          source: newest.id,
        });
        return { applied: true, created: newId };
      }
    }

    return { applied: false, reason: "unhandled_proposal_type" };
  }

  // Get learning summary
  summary() {
    return {
      intents: this.intents.length,
      gaps: this.gaps.length,
      proposals: this.proposals.length,
      satisfactionRate: this.intents.length > 0
        ? (this.intents.length - this.gaps.length) / this.intents.length
        : 0,
      topIntents: this._topIntents(),
      topGaps: this._topGaps(),
    };
  }

  _topIntents() {
    const counts = {};
    for (const i of this.intents) {
      counts[i.type] = (counts[i.type] || 0) + 1;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }

  _topGaps() {
    const counts = {};
    for (const g of this.gaps) {
      counts[g.gapType] = (counts[g.gapType] || 0) + 1;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }

  toJSON() {
    return {
      intents: this.intents.length,
      gaps: this.gaps.length,
      proposals: this.proposals.length,
      summary: this.summary(),
    };
  }
}
