// src/operators/automaton.js
/**
 * o_automaton: compose automata using sequential, parallel, or Kleene composition.
 * Mathematical mapping: o_automaton(A, B, mode) -> C where C is a composed FSM.
 * This is the computational-scale analogue of o_bundle and o_sequence.
 */
import { Operator } from "../core/operator.js";
import { AutomataComposer } from "../automata/composition.js";

export function createAutomatonOperator() {
  const composer = new AutomataComposer();

  return new Operator({
    id: "o_automaton",
    arity: 2,
    accepts: (operands, context) => {
      // operands[0] and operands[1] must be FSMs or FSM primitive references
      const isFSM = (op) => op && (op.states || op.type === "fsm" || op.scale === "automaton");
      return operands.length >= 2 && isFSM(operands[0]) && isFSM(operands[1]);
    },
    transform: (operands, context) => {
      const mode = context.mode || "sequential";
      const fsmA = operands[0]._fsm || operands[0];
      const fsmB = operands[1]._fsm || operands[1];

      let result;
      switch (mode) {
        case "parallel":
          result = composer.composeParallel(fsmA, fsmB, context);
          break;
        case "kleene":
          result = composer.composeKleene(fsmA, context);
          break;
        case "sequential":
        default:
          result = composer.composeSequential(fsmA, fsmB, context);
          break;
      }

      return {
        operator: "o_automaton",
        mode,
        fsmA: fsmA.id || fsmA.name,
        fsmB: fsmB.id || fsmB.name,
        result: result.toPrimitive(),
        stateCount: result.states.size,
        transitionCount: result.transitions.size,
        context: { ...context },
      };
    },
    invariants: ["state_preservation", "transition_completeness"],
    scales: ["automaton"],
    evidence: [],
  });
}
