// src/parsers/tokenizer.js
/**
 * Multi-Scale Tokenizer
 * Handles the recursive linguistic scale from §5:
 * features → graphemes → morphemes → words → phrases → clauses → sentences → paragraphs → discourse
 * Every level is simultaneously a completed object (whole) and a primitive (part).
 */

export class Token {
  constructor({
    id,
    type,
    text,
    children = [],
    position = 0,
    scale,
    metadata = {},
  }) {
    this.id = id;
    this.type = type;
    this.text = text;
    this.children = Object.freeze([...children]);
    this.position = position;
    this.scale = scale || type;
    this.metadata = Object.freeze({ ...metadata });
    Object.freeze(this);
  }

  toJSON() {
    return {
      id: this.id,
      type: this.type,
      text: this.text,
      children: this.children.map(c => typeof c === "object" ? c.toJSON?.() || c : c),
      position: this.position,
      scale: this.scale,
      metadata: { ...this.metadata },
    };
  }
}

export class MultiScaleTokenizer {
  constructor(options = {}) {
    this.wordSeparators = options.wordSeparators || /\s+/;
    this.sentenceTerminators = options.sentenceTerminators || /[.!?]+/;
    this.paragraphSeparators = options.paragraphSeparators || /\n\n+/;
    this.morphemePatterns = options.morphemePatterns || [
      { pattern: /(un|re|dis|pre|post|sub|super|inter|trans)(\w+)/, type: "prefix" },
      { pattern: /(\w+)(ing|ed|er|est|ly|tion|ness|ment|able|ible)/, type: "suffix" },
      { pattern: /(\w+)(s|es|ies)/, type: "plural" },
    ];
    this._tokenCounter = 0;
  }

  tokenize(input, targetScale = "auto") {
    if (typeof input !== "string") {
      return new Token({
        id: this._nextId("raw"),
        type: "raw",
        text: String(input),
        scale: "unknown",
      });
    }

    if (targetScale === "discourse" || targetScale === "auto") {
      return this._tokenizeDiscourse(input);
    }
    if (targetScale === "sentence") {
      return this._tokenizeSentences(input);
    }
    if (targetScale === "word") {
      return this._tokenizeWords(input);
    }
    if (targetScale === "grapheme") {
      return this._tokenizeGraphemes(input);
    }

    return this._tokenizeDiscourse(input);
  }

  _tokenizeDiscourse(text) {
    const paragraphs = text.split(this.paragraphSeparators).filter(p => p.trim());
    const children = paragraphs.map((para, i) => this._tokenizeParagraph(para, i));

    return new Token({
      id: this._nextId("discourse"),
      type: "discourse",
      text: text.substring(0, 200) + (text.length > 200 ? "..." : ""),
      children,
      scale: "discourse",
      metadata: { paragraphCount: children.length },
    });
  }

  _tokenizeParagraph(text, position) {
    const sentences = this._splitSentences(text);
    const children = sentences.map((sent, i) => this._tokenizeSentence(sent, i));

    return new Token({
      id: this._nextId("paragraph"),
      type: "paragraph",
      text: text.substring(0, 100) + (text.length > 100 ? "..." : ""),
      children,
      position,
      scale: "paragraph",
      metadata: { sentenceCount: children.length },
    });
  }

  _tokenizeSentence(text, position) {
    const clauses = this._splitClauses(text);
    const children = clauses.map((clause, i) => this._tokenizeClause(clause, i));

    return new Token({
      id: this._nextId("sentence"),
      type: "sentence",
      text: text.trim(),
      children,
      position,
      scale: "sentence",
      metadata: { clauseCount: children.length, wordCount: text.split(/\s+/).length },
    });
  }

  _tokenizeClause(text, position) {
    const words = text.trim().split(this.wordSeparators).filter(w => w.length > 0);
    const children = words.map((word, i) => this._tokenizeWord(word, i));

    return new Token({
      id: this._nextId("clause"),
      type: "clause",
      text: text.trim(),
      children,
      position,
      scale: "clause",
      metadata: { wordCount: children.length },
    });
  }

  _tokenizeWord(text, position) {
    const morphemes = this._decomposeMorphemes(text);
    const children = morphemes.map((m, i) => this._tokenizeMorpheme(m, i));

    return new Token({
      id: this._nextId("word"),
      type: "word",
      text,
      children,
      position,
      scale: "lexical",
      metadata: { morphemeCount: children.length, length: text.length },
    });
  }

  _tokenizeMorpheme(text, position) {
    const graphemes = text.split("");
    const children = graphemes.map((g, i) => this._tokenizeGrapheme(g, i));

    return new Token({
      id: this._nextId("morpheme"),
      type: "morpheme",
      text,
      children,
      position,
      scale: "morphemic",
      metadata: { graphemeCount: children.length },
    });
  }

  _tokenizeGrapheme(text, position) {
    return new Token({
      id: this._nextId("grapheme"),
      type: "grapheme",
      text,
      children: [],
      position,
      scale: "grapheme",
      metadata: { charCode: text.charCodeAt(0) },
    });
  }

  _splitSentences(text) {
    const matches = text.match(/[^.!?]+[.!?]+\s*/g);
    if (!matches) return [text];
    return matches.map(s => s.trim()).filter(s => s.length > 0);
  }

  _splitClauses(text) {
    const parts = text.split(/,\s*|\s+;\s*/);
    return parts.filter(p => p.trim().length > 0);
  }

  _decomposeMorphemes(word) {
    for (const pattern of this.morphemePatterns) {
      const match = word.match(pattern.pattern);
      if (match) {
        const parts = match.slice(1).filter(Boolean);
        if (parts.length > 1) return parts;
      }
    }
    return [word];
  }

  _nextId(type) {
    return `token:${type}:${++this._tokenCounter}`;
  }

  flattenToScale(token, targetScale) {
    const results = [];
    const visit = (node) => {
      if (node.scale === targetScale || node.type === targetScale) {
        results.push(node);
        return;
      }
      for (const child of node.children || []) {
        visit(child);
      }
    };
    visit(token);
    return results;
  }

  scalePath(token) {
    const path = [];
    const visit = (node, depth = 0) => {
      path.push({ type: node.type, scale: node.scale, depth, text: node.text.substring(0, 20) });
      for (const child of node.children || []) {
        visit(child, depth + 1);
      }
    };
    visit(token);
    return path;
  }
}
