# Pure Synthia — Phase 1 Implementation

> A Recursive Generative State Calculus for Cross-Scale Automata
> Browser-native, deterministic, experimentally grounded.

## What This Is

This is the **working implementation** of the Pure Synthia research proposal. It is not a mockup, not a sketch, and not a framework that delegates to external LLMs. Every file here is executable JavaScript that runs entirely in the browser.

## Architecture (Appendix I)

```
pure-synthia/
├── src/
│   ├── core/           # Primitive, Composite, Operator, Address, State, Evidence
│   ├── operators/      # o_bundle, o_sequence, Registry
│   ├── engine/         # SynthiaEngine — the execution pipeline
│   ├── derivation/     # Derivation, Ledger, Replay
│   ├── graph/          # Five graph projections (K, C, P, T, D)
│   ├── hypotheses/     # Formal hypothesis registry (H1–H6)
│   ├── experiments/    # Experiment runner, Metrics, Controls, Ablation
│   ├── storage/        # IndexedDB persistence layer
│   └── main.js         # Bootstrap and factory functions
├── tests/
│   └── phase1-gate.js  # Phase 1 validation suite (Appendix H.16)
└── index.html          # Live Laboratory UI
```

## Phase 1 Gate (Appendix H.16)

Before any dimensional or canonical-address experiments, Phase 1 validates:

1. **Feature representation** — Phonological features registered as primitives
2. **o_bundle** — Simultaneous feature composition operator
3. **o_sequence** — Ordered composition operator (order-sensitive)
4. **Deterministic decomposition/composition** — Same input → same derivation
5. **Held-out reconstruction** — Re-execution reproduces prior result
6. **Unseen-composition test** — Novel inputs generate without stored solutions
7. **Complexity-ledger collection** — Runtime measurements: N_p, N_s, N_e, N_o, D_r
8. **Compression comparison** — Grammar size vs. direct encoding baseline
9. **Operator ablation** — Clone-and-remove for impact measurement
10. **Deterministic replay** — Hash-equivalent derivation reconstruction

## Quick Start

Open `index.html` in any modern browser. No build step, no server, no dependencies.

```bash
# Optional: serve locally for ES modules
npx serve .
# or
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Using the Laboratory

1. **Execute** — Type any string (e.g., `"pat"`, `"bat"`) or JSON array of primitive IDs
2. **Quick Actions** — Click buttons to test `o_bundle`, `o_sequence`, decomposition
3. **Inspect** — View the full derivation trace, composition result, complexity ledger
4. **Replay** — Every execution captures a deterministic replay record

## Core API

```javascript
import initPureSynthia from "./src/main.js";

const engine = initPureSynthia();  // Bootstrapped with phonological primitives

// Execute on string input
const d1 = engine.execute("pat", { source: "demo" });
console.log(d1.result);

// Execute on primitive array
const d2 = engine.execute(["f.place.lab", "f.manner.stop", "f.voiceless"]);

// Inspect ledger
console.log(engine.ledger.snapshot());

// Access derivation
console.log(engine.derivations.get(d1.id));
```

## Hypotheses Under Test

| ID | Claim | Status |
|---|---|---|
| H1 | Recursive generativity from finite primitives | hypothesized |
| H2 | Cross-scale operator invariance | hypothesized |
| H3 | Canonical address utility | hypothesized |
| H4 | Dimensional correspondence | hypothesized |
| H5 | Compression via reusable primitives | hypothesized |
| H6 | Numerical law correlation | hypothesized |

No hypothesis is treated as true by default. All are evaluated through the experimental framework.

## Design Principles

- **Deterministic** — Same state + input + context → same derivation (hash-verified)
- **Inspectable** — Every output carries a complete provenance trace
- **Falsifiable** — Explicit null hypotheses and rejection criteria for every claim
- **Ablation-ready** — Any component can be removed to measure its marginal contribution
- **Backend-free** — Runs entirely in the browser; external services introduced only as measured experimental conditions

## Research Sequence (Section 21)

This implementation follows the prescribed order:

1. ✅ Extract linguistic primitives (bottom-up, starting below the letter)
2. ⏳ Quantify their transformations
3. ⏳ Discover recurring operators
4. ⏳ Map candidate dimensional correspondences
5. ⏳ Assign and test canonical addresses
6. ⏳ Scale upward to sentence/discourse level
7. ⏳ Test against computation (automata)
8. ⏳ Test against larger multi-automata systems

Phase 1 completes step 1 and establishes the infrastructure for steps 2–3.
