// src/emergence/detector.js
/**
 * Emergence Measurement Apparatus
 * Implements the §15 operational definition of emergence:
 *   A structure Y is emergent iff:
 *   1. Y ∉ StoredSolutions
 *   2. Y = F(P, O, C)  [complete derivation provenance]
 *   3. Y independently satisfies evaluation criteria
 *
 * This is a Category B mechanism: derived from the §15 criterion and
 * existing engine structures (Derivation, ComplexityLedger). The Pure
 * Synthia document defines the criterion; this file implements the
 * measurement apparatus.
 */

export class EmergenceDetector {
  constructor(engine) {
    this.engine = engine;
    this.storedSolutions = new Set();
    this.emergenceLog = [];
  }

  // Register a solution as explicitly stored (non-emergent by definition)
  registerStored(solution) {
    const hash = this._hashSolution(solution);
    this.storedSolutions.add(hash);
    return hash;
  }

  // Test whether a derivation represents emergent structure per §15
  testEmergence(derivation, evaluationCriteria = null) {
    const result = derivation.result;
    if (!result) {
      return { emergent: false, reason: "no_result", criteria: { stored: null, generated: null, evaluated: null } };
    }

    // Criterion 1: Y was not explicitly stored
    const resultHash = this._hashSolution(result);
    const wasStored = this.storedSolutions.has(resultHash);

    // Criterion 2: Y was generated from registered primitives and operators
    const generated = derivation.primitives.length > 0 && derivation.operators.length > 0;

    // Criterion 3: Y independently satisfies evaluation criteria
    let satisfiesCriteria = true;
    let criteriaResults = null;
    if (evaluationCriteria) {
      criteriaResults = this._evaluateCriteria(result, evaluationCriteria);
      satisfiesCriteria = criteriaResults.passed;
    }

    const emergent = !wasStored && generated && satisfiesCriteria;

    const record = {
      derivationId: derivation.id,
      emergent,
      wasStored,
      generated,
      satisfiesCriteria,
      criteriaResults,
      resultHash,
      primitiveCount: derivation.primitives.length,
      operatorCount: derivation.operators.length,
      timestamp: Date.now(),
    };

    this.emergenceLog.push(record);
    return record;
  }

  // Batch test a set of derivations
  batchTest(derivations, criteria = null) {
    const results = derivations.map(d => this.testEmergence(d, criteria));
    const emergentCount = results.filter(r => r.emergent).length;
    return {
      total: results.length,
      emergent: emergentCount,
      nonEmergent: results.length - emergentCount,
      rate: results.length > 0 ? emergentCount / results.length : 0,
      results,
    };
  }

  // Check if an operator's behavior at a new scale counts as emergent
  testCrossScaleEmergence(operatorId, sourceScale, targetScale, testCases) {
    const storedKey = `operator:${operatorId}:scale:${targetScale}`;
    const wasStoredApplicable = this.storedSolutions.has(storedKey);

    const op = this.engine.operators.get(operatorId);
    if (!op) {
      return { operatorId, sourceScale, targetScale, emergent: false, reason: "operator_not_found" };
    }

    let successCount = 0;
    for (const tc of testCases) {
      try {
        const adapted = tc.operands.map(o => ({ ...o, scale: targetScale }));
        op.apply(adapted, tc.context || {});
        successCount++;
      } catch (e) {}
    }

    const transferRate = testCases.length > 0 ? successCount / testCases.length : 0;
    const emergent = !wasStoredApplicable && transferRate >= 0.5;

    return {
      operatorId,
      sourceScale,
      targetScale,
      emergent,
      wasStoredApplicable,
      transferRate,
      successCount,
      totalTests: testCases.length,
    };
  }

  _hashSolution(solution) {
    const str = JSON.stringify(solution, Object.keys(solution || {}).sort());
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return `sol:${hash}`;
  }

  _evaluateCriteria(result, criteria) {
    const checks = {};
    let passed = true;

    for (const [key, testFn] of Object.entries(criteria)) {
      try {
        checks[key] = testFn(result);
        if (!checks[key]) passed = false;
      } catch (e) {
        checks[key] = false;
        passed = false;
      }
    }

    return { passed, checks };
  }

  summary() {
    const emergent = this.emergenceLog.filter(r => r.emergent);
    return {
      totalTested: this.emergenceLog.length,
      emergentCount: emergent.length,
      rate: this.emergenceLog.length > 0 ? emergent.length / this.emergenceLog.length : 0,
      byOperator: this._groupByOperator(),
    };
  }

  _groupByOperator() {
    const groups = {};
    for (const r of this.emergenceLog) {
      const op = "unknown";
      if (!groups[op]) groups[op] = { total: 0, emergent: 0 };
      groups[op].total++;
      if (r.emergent) groups[op].emergent++;
    }
    return groups;
  }

  toJSON() {
    return {
      storedCount: this.storedSolutions.size,
      logSize: this.emergenceLog.length,
      summary: this.summary(),
      recent: this.emergenceLog.slice(-20),
    };
  }
}

export default EmergenceDetector;
