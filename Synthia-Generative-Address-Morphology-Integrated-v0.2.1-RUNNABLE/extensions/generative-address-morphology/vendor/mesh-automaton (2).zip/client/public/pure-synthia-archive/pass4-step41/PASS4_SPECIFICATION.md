# PURE SYNTHIA — PASS-4 SPECIFICATION & GATE
## Version: 0.2.0-Preregistered-Draft
## Date: 2026-08-22
## Status: PROPOSED — NOT YET AUTHORIZED FOR IMPLEMENTATION

---

## 1. ARTIFACT FREEZE DECLARATIONS

### 1.1 Pass-3 Baseline (Immutable)
The artifact `pure-synthia-pass3.zip` is hereby frozen as the sealed Pass-3 baseline.
No file within the Pass-3 baseline may be modified, deleted, or superseded to accommodate
Pass-4 mechanisms. Pass-4 may only ADD files or create NEW engine versions that extend
the frozen baseline. Rollback to Pass-3 must remain possible by simple file deletion.

**Frozen Pass-3 files (40 files, 53,958 bytes):**
- `index.html` — Laboratory UI v3 (8 tabs)
- `src/main.js` — Phase 3 bootstrap
- `src/core/{primitive,composite,operator,address,state,evidence}.js`
- `src/operators/{bundle,sequence,project,transform,recurse,automaton,discourse,registry}.js`
- `src/engine/{synthia,address-evaluator,dimensional-evaluator}.js`
- `src/graph/{graph,topology,mesh}.js`
- `src/derivation/{derivation,ledger,replay}.js`
- `src/hypotheses/hypothesis.js`
- `src/experiments/{experiment,metrics,controls,cross-scale}.js`
- `src/datasets/{synthetic,linguistic,computational}.js`
- `src/storage/indexed-db.js`
- `src/parsers/{tokenizer,dependency}.js`
- `src/automata/{fsm,composition}.js`
- `tests/phase1-gate.js`
- `README.md`

### 1.2 Pass-4 Provisional Files (Unintegrated)
The following four files exist on disk but are NOT integrated into the engine,
NOT exported from `main.js`, NOT loaded by `index.html`, and NOT part of any
execution pipeline. They are classified as **provisional drafts** pending
specification approval:

- `src/emergence/detector.js` — provisional measurement apparatus for §15 criterion
- `src/emergence/multi-automata.js` — provisional AutomataMesh + AutomataMeshRegistry
- `src/emergence/intent.js` — provisional IntentEngine
- `src/emergence/self-editor.js` — provisional SelfEditor

These files may be rewritten, discarded, or replaced in whole or in part
before integration. Their current content does not constitute a commitment.

---

## 2. COMPONENT AUDIT AGAINST THE SPECIFICATION

### 2.1 Audit Framework
Each proposed Pass-4 component is classified into one of four categories:

| Category | Definition |
|---|---|
| **A. Explicitly Authorized** | Directly named, defined, or required by the Pure Synthia document |
| **B. Derivable from Defined Mechanism** | Not explicitly named, but follows necessarily from structures already in the document |
| **C. Experimental Extension** | Requires a new hypothesis (H7+) with explicit null hypothesis and rejection threshold |
| **D. Application-Layer** | Useful for operation but not part of the core calculus; must not affect experimental validity |

### 2.2 Component-by-Component Audit

#### 2.2.1 Emergence Measurement Apparatus
**Classification: B — Derivable Measurement Mechanism**

**Grounding:**
- §15 provides the **operational definition** of emergence as three jointly necessary criteria:
  1. `Y ∉ StoredSolutions`
  2. `Y = F(P, O, C)`
  3. `Y` independently satisfies evaluation criteria
- §15 explicitly states: "This is a stronger bar than 'produced something unexpected.'"
- Appendix H.8 defines `novelCompositionRate = N_correct_not_stored / N_correct_outputs`,
  which is the quantitative measure of criterion 1.

**Classification Justification:**
The Pure Synthia document defines the **criterion** for emergence (§15) and the
**metric** for measuring it (Appendix H.8). It does **not** name, mandate, or
prescribe any specific software class called "EmergenceDetector." The provisional
file `src/emergence/detector.js` is a **derived measurement apparatus** that
implements the §15 criterion using existing engine structures (`Derivation`,
`ComplexityLedger`, hash functions). It is a Category B mechanism because it
follows necessarily from the defined criterion and existing infrastructure.

**Required Hypothesis:** None new. The apparatus serves H1 (recursive generativity)
by measuring whether the claimed generativity actually produces novel structures.

**Constraint:** The measurement apparatus must implement the **exact** three-part
criterion from §15 without relaxation. Criterion 3 ("independently satisfies
evaluation criteria") must not be reduced to mere novelty or unexpectedness.

---

#### 2.2.2 Multi-Automata Meshes
**Classification: B — Derivable from Defined Mechanism**

**Grounding:**
- §10 defines `M(x) = {M_local, M_personal, M_value, M_scale, M_group}` and states:
  "A single instance can belong simultaneously to multiple meshes, propagating
  qualified state packets, not full memory copies."
- §20 states: "Strong success requires cross-scale generativity evidence."
- The `MeshRegistry` and `StateMesh` classes in `src/graph/mesh.js` (Pass 2)
  already implement the core mesh mechanism.

**Derivation:**
A mesh whose members are automata (rather than linguistic primitives) is a
direct specialization of the existing `StateMesh` class. The provisional
`AutomataMesh` file extends `StateMesh` with FSM-specific connection semantics
(inter-automata wiring, product collapse). This is a scale-specific
instantiation, not a new architectural primitive.

**Required Hypothesis:** None new. Falls under H2 (cross-scale operator invariance)
and H5 (compression) via mesh reuse.

**Constraint:** Must use the existing `MeshRegistry` API. Must not introduce
new mesh types beyond the five defined in §10.

---

#### 2.2.3 Intent Engine
**Classification: C — Experimental Extension**

**Grounding:**
- The Pure Synthia document does NOT mention "intent" as a technical term.
- §14 discusses "the system learns from execution," but this is framed as
  operator discovery and primitive registration, not intent inference.
- The user's memory instructions reference an "Intent Engine" as "the brain,"
  but this is external to the formal specification.

**Required Hypothesis (H7):**
> **H7 — Intent Inference Utility**
> Claim: An intent-inference mechanism that observes derivation patterns and
> proposes new primitives/operators improves generative accuracy compared to
> random or frequency-based proposal.
> Null: Intent inference provides no improvement over baseline proposal methods.
> Metric: `proposalAccuracy = N_useful_proposals / N_total_proposals`
> Threshold: **0.30** (preregistered Pass-4 assumption; see §5.2)
> Test: Compare intent-guided proposal vs. random proposal on held-out test set.

**Classification Justification:** Intent inference is not derivable from any
mechanism in the document. It introduces a new layer (observation → inference →
proposal) that is not part of the core calculus `execute(X) → Δ(Y)`. It must
therefore carry its own falsifiable hypothesis.

**Constraint:** Must be implementable as a **wrapper** around the existing engine,
not as a modification to `SynthiaEngine.execute()`. Must be ablatable:
`S^{-IntentEngine}` must reduce to the Pass-3 baseline without code changes.

**Independence:** H7 is tested independently from H8 and H9. Rejection of H7
does not prevent H8 or H9 from being tested against the same sealed Pass-3 baseline.

---

#### 2.2.4 Self-Editor / Self-Modification
**Classification: C — Experimental Extension (HIGH RISK)**

**Grounding:**
- The Pure Synthia document does NOT authorize self-modification of the engine.
- §13 states: "The grammar version must be recorded in every derivation."
  This implies grammar changes are **epochal events** (version bumps), not
  continuous self-edits.
- §16 states: "Learning creates new versioned records, never mutates history."
  This is compatible with adding new primitives, but NOT with modifying existing
  operators or rules.
- The user's memory instructions reference "self-editing, self-growing organism,"
  but this is external to the formal specification.

**Required Hypothesis (H8):**
> **H8 — Self-Editing Utility**
> Claim: A system that modifies its own operator acceptance criteria based on
> runtime success/failure data achieves higher cross-scale transfer rates than
> a fixed-grammar control.
> Null: Self-editing provides no improvement over fixed grammar with equivalent
> initial primitive/operator vocabulary.
> Metric: `selfEditDelta = transferRate_with_editing - transferRate_fixed`
> Threshold: **0.10** (preregistered Pass-4 assumption; see §5.2)
> Test: Run identical cross-scale battery (Appendix H.3.4) with and without
> self-editing enabled. Grammar version must be bumped on every edit.

**Additional Invariant (§13 Compliance):**
Every self-edit MUST increment `grammarVersion`. Derivations produced before
and after an edit MUST have different grammar versions. Cross-version replay
must produce a deterministic `VERSION_MISMATCH` outcome (see §7.2).

**Classification Justification:** Self-modification is the most invasive
proposed mechanism. It directly challenges the document's immutability
principles (§16) and versioning requirements (§13). It requires the strongest
experimental controls and the most explicit pass/fail criteria.

**Constraint:** Self-editing MUST NOT modify frozen Pass-3 files. All edits
must be stored as **new records** (new primitives, new operator wrappers,
new rules) with versioned provenance. The original Pass-3 primitive and
operator set must remain intact and addressable.

**Independence:** H8 is tested independently from H7 and H9. Rejection of H8
does not prevent H7 or H9 from being tested against the same sealed Pass-3 baseline.

---

#### 2.2.5 Automatic Primitive/Operator/Rule Expansion
**Classification: C — Experimental Extension**

**Grounding:**
- §14 discusses "the system discovers operators through observation," but
  frames this as a **human-driven** research activity, not an automatic process.
- Appendix H.3 describes datasets as **provided by researchers**, not generated
  by the system itself.
- No mechanism in the document authorizes automatic rule generation.

**Required Hypothesis (H9):**
> **H9 — Automatic Expansion Utility**
> Claim: An automatic expansion mechanism that creates new primitives from
> uncomposed token sets and new operators from repeated derivation patterns
> reduces special-case burden (Appendix H.12) compared to manual registration.
> Null: Automatic expansion increases special-case burden or reduces
> generative accuracy.
> Metric: `specialCaseBurden` (Appendix H.12) and `generationAccuracy` (H.8)
> Threshold: **SCB reduction ≥ 0.05** (preregistered Pass-4 assumption; see §5.2)
> Test: Run full Phase-1 gate (Appendix H.16) with and without auto-expansion.
> Compare SCB and accuracy. Expansion must not break any Phase-1 gate test.

**Constraint:** Auto-expanded primitives/operators must be tagged with
`source: "auto_expansion"` and carry evidence records. They must be
ablatable: `S^{-auto_expanded}` must restore the manually-registered set.

**Independence:** H9 is tested independently from H7 and H8. Rejection of H9
does not prevent H7 or H8 from being tested against the same sealed Pass-3 baseline.

---

## 3. ADMITTED STRUCTURES FOR PASS-4

### 3.1 Explicitly Authorized (Category A)
| Structure | Source | File |
|---|---|---|
| (none in Pass-4; all Category-A structures were admitted in Pass 1–3) | — | — |

### 3.2 Derivable (Category B)
| Structure | Derivation | File |
|---|---|---|
| Emergence measurement apparatus | §15 criterion + existing Derivation/Ledger | `src/emergence/detector.js` (provisional) |
| AutomataMesh | StateMesh (§10) + FSM primitives (Pass 3) | `src/emergence/multi-automata.js` (provisional) |
| AutomataMeshRegistry | MeshRegistry (Pass 2) | Extends existing registry |
| Inter-automata connections | §10 packet propagation + FSM transitions | New methods on AutomataMesh |
| Product collapse | AutomataComposer.composeParallel (Pass 3) | Reuses existing operator |

### 3.3 Experimental Extensions (Category C)
| Structure | Hypothesis | File |
|---|---|---|
| IntentEngine | H7 | `src/emergence/intent.js` (provisional) |
| SelfEditor | H8 | `src/emergence/self-editor.js` (provisional) |
| Auto-expansion | H9 | New file: `src/emergence/expansion.js` (not yet written) |

### 3.4 Application-Layer (Category D)
| Structure | Purpose | Constraint |
|---|---|---|
| Pass-4 Laboratory UI tab | Visualization | Must not modify existing 8 tabs |
| Intent stream logger | Debugging | Must not affect derivation output |
| Self-edit audit trail | Accountability | Must be append-only |

---

## 4. IMPLEMENTATION ORDER

Pass-4 implementation, if authorized, must follow this strict sequence:

```
Step 4.1: Emergence measurement apparatus integration (Category B)
Step 4.2: AutomataMesh integration (Category B)
Step 4.3: H7 registration and IntentEngine integration (Category C — independent)
Step 4.4: H7 ablation and evaluation
Step 4.5: H8 registration and SelfEditor integration (Category C — independent)
Step 4.6: H8 ablation and evaluation
Step 4.7: H9 registration and auto-expansion integration (Category C — independent)
Step 4.8: H9 ablation and evaluation
Step 4.9: Combined-condition experiments (H7+H8, H7+H9, H8+H9, H7+H8+H9)
Step 4.10: Full Pass-4 gate (all H1–H9 + ablations + replay verification)
```

**Independence Rule:** Steps 4.3–4.4 (H7), 4.5–4.6 (H8), and 4.7–4.8 (H9) are
**independently testable** from the same sealed Pass-3 baseline. Failure or
rejection of H7 does not prevent H8 from being tested. Failure of H8 does not
prevent H9 from being tested. Combined-condition experiments (Step 4.9) may
begin only after the individual hypotheses are sealed.

**Gate Rule:** Steps 4.1–4.2 must pass before any Category C mechanism is tested.

---

## 5. HYPOTHESES TESTED IN PASS-4

### 5.1 Inherited Hypotheses (from Pass 1–3)
All H1–H6 remain active and must be re-tested after each Pass-4 integration step.
No Pass-4 mechanism may cause regression on H1–H6 without explicit documentation.

### 5.2 New Hypotheses (Pass-4 specific)

| ID | Claim | Null | Metric | Threshold | Test |
|---|---|---|---|---|---|
| **H7** | Intent inference improves proposal accuracy | No improvement over random | `proposalAccuracy` | **≥ 0.30** | Intent-guided vs. random proposal on held-out set |
| **H8** | Self-editing improves cross-scale transfer | No improvement over fixed grammar | `selfEditDelta` | **≥ 0.10** | Cross-scale battery with/without editing |
| **H9** | Auto-expansion reduces special-case burden | SCB increases or accuracy drops | `SCB_delta`, `accuracy_delta` | **SCB ↓ ≥ 0.05**, accuracy non-decreasing | Phase-1 gate with/without auto-expansion |

### 5.3 Preregistered Assumptions (Threshold Provenance)
The thresholds for H7, H8, and H9 are **preregistered Pass-4 assumptions**.
They are **not** derived from the original Pure Synthia specification, which
contains no numerical thresholds for these mechanisms (they are not mentioned
in the document). Their provenance is recorded as follows:

| Threshold | Value | Provenance | Evidence Record |
|---|---|---|---|
| H7: proposalAccuracy | 0.30 | Preregistered assumption — Pass-4 contract v0.2 | `evidence:assumption:H7_threshold` |
| H8: selfEditDelta | 0.10 | Preregistered assumption — Pass-4 contract v0.2 | `evidence:assumption:H8_threshold` |
| H9: SCB reduction | 0.05 | Preregistered assumption — Pass-4 contract v0.2 | `evidence:assumption:H9_threshold` |

These thresholds may be revised **only** by a new preregistered contract version.
They may not be adjusted post-hoc to fit experimental results.

### 5.4 Emergence as Measurement (not Hypothesis)
Emergence detection (§15) is the **apparatus** for testing H1, not a hypothesis itself.
The operational definition is:
1. `Y ∉ StoredSolutions` (hash not in stored set)
2. `Y = F(P, O, C)` (derivation provenance is complete)
3. `Y` independently satisfies evaluation criteria (metric ≥ threshold)

All three must be true. If any is false, the structure is **not emergent**.

---

## 6. FROZEN DATASETS & HELD-OUT CASES

### 6.1 Reuse Pass-3 Datasets
Pass-4 must use the **exact same** synthetic, linguistic, and computational
datasets as Pass-3. No new dataset generation is permitted for hypothesis testing.
New datasets may be created for **exploratory** purposes only, marked as
`exploratory: true` and excluded from formal hypothesis evaluation.

### 6.2 Held-Out Cases
The following cases are **frozen** and must be used as held-out tests:

| Case | Source | Purpose |
|---|---|---|
| "The cat sleeps on the mat." | LinguisticDataset (Pass 3) | Discourse parsing + dependency baseline |
| "A dog runs fast." | LinguisticDataset (Pass 3) | Cross-sentence discourse composition |
| `fsm:even-zeros` run on "0101" | ComputationalDataset (Pass 3) | Automata execution baseline |
| `fsm:ends-01` run on "101" | ComputationalDataset (Pass 3) | Automata rejection baseline |
| Balanced delimiters (depth 5) | SyntheticDataset (Pass 3) | Recursive structure baseline |

These cases must produce **identical derivations** (hash-equivalent) in Pass-4
as they did in Pass-3, unless a Pass-4 mechanism explicitly and documentably
improves the result. Any change must be logged with before/after hashes.

---

## 7. DETERMINISTIC REPLAY REQUIREMENTS

### 7.1 Pass-3 Replay Invariance
All Pass-3 derivations must remain replayable with identical hashes.
The replay engine (`src/derivation/replay.js`) must not be modified.

### 7.2 Cross-Version Replay
Cross-version replay is defined as replaying a derivation recorded under
`grammarVersion = V1` in an engine whose current `grammarVersion = V2` where `V1 ≠ V2`.

**Outcome:** Cross-version replay MUST produce a deterministic `VERSION_MISMATCH`
result. This is not a failure or exception; it is the **defined and expected**
outcome. The mismatch result itself must be reproducible:

```
replay(record_V1, engine_V2) → { status: "VERSION_MISMATCH", v1: V1, v2: V2 }
```

The `VERSION_MISMATCH` outcome must have a deterministic hash that is identical
across all cross-version replay attempts with the same `(V1, V2)` pair.

### 7.3 Same-Version Replay
Replay within the same grammar version MUST remain fully deterministic:
```
replay(record_V1, engine_V1) → { status: "REPRODUCED", derivation }
hash(derivation) == hash(record_V1.derivation)
```

### 7.4 Replay Verification Test
```
For each held-out case:
  1. Capture replay record in Pass-3 engine (V = "phase3.0")
  2. Replay in Pass-4 engine WITHOUT Category C mechanisms (V = "phase3.0")
     → Assert status == "REPRODUCED" AND hash matches
  3. Replay in Pass-4 engine WITH Category C mechanisms (V = "phase4.X")
     → Assert status == "VERSION_MISMATCH"
  4. Assert VERSION_MISMATCH hash is deterministic across repeated attempts
```

---

## 8. COMPLEXITY & COMPRESSION ACCOUNTING

### 8.1 Ledger Extensions
Pass-4 may add the following fields to the ComplexityLedger (append-only):

| Field | Description | Added By |
|---|---|---|
| `intentsInferred` | Count of intent observations | IntentEngine |
| `gapsIdentified` | Count of capability gaps | IntentEngine |
| `proposalsGenerated` | Count of proposed solutions | IntentEngine |
| `proposalsApplied` | Count of proposals exceeding confidence threshold | IntentEngine |
| `selfEdits` | Count of grammar modifications | SelfEditor |
| `autoPrimitives` | Count of auto-expanded primitives | Auto-expansion |
| `emergenceDetections` | Count of structures meeting §15 criteria | Emergence apparatus |

### 8.2 Compression Accounting (Single Unambiguous Criterion)
Pass-4 must report compression metrics **with and without** Category C mechanisms.
The pass/fail criterion is defined by a single equation:

```
Let CG_with    = compression_gain(engine_with_pass4)
Let CG_without = compression_gain(engine_without_pass4)

Pass-4 compression criterion:
  CG_with ≥ CG_without - 0.05
```

Where `compression_gain` is defined per Appendix H.11:
```
compression_gain = 1 - (L(G) + L(X|G)) / L_direct(X)
```

**Interpretation:**
- If `CG_with < CG_without - 0.05`, the Pass-4 mechanism has increased description
  length by more than 5 percentage points relative to baseline. This is a **fail**.
- If `CG_with ≥ CG_without - 0.05`, the mechanism is within acceptable overhead.
  This is a **pass**.
- The criterion remains valid when compression gain is negative (i.e., when the
  grammar is larger than direct representation). In that case, both `CG_with` and
  `CG_without` are negative, and the difference must still satisfy the inequality.

**No other compression rule is used.** The additive `+0.05` and multiplicative
`1.05×` rules from v0.1 are **replaced** by this single equation.

---

## 9. EMERGENCE CRITERIA (§15 Operational Definition)

### 9.1 Exact Criteria
A structure Y is emergent **if and only if**:

1. **Non-stored:** `hash(Y) ∉ StoredSolutions`
   - StoredSolutions is a Set of deterministic hashes of all explicitly stored
     composites, training examples, and cached results.
   - The hash function must be deterministic and collision-resistant.

2. **Generated:** `Y = F(P, O, C)`
   - There exists a complete derivation `Δ(Y)` with non-empty `primitives`,
     `operators`, and `context` fields.
   - The derivation must be reproducible (§17).

3. **Evaluated:** `evaluate(Y) ≥ threshold`
   - Y must independently satisfy domain-specific evaluation criteria.
   - For linguistic structures: `generationAccuracy ≥ 0.7` (Appendix H.8)
   - For automata: `run().accepted == true` AND `path` is valid
   - For cross-scale: `transferRate ≥ 0.5` (Appendix H.6)

### 9.2 Negative Criteria (NOT Emergence)
The following do **not** constitute emergence:
- **Novelty alone:** "Produced something unexpected" (§15 explicitly rejects this)
- **Random generation:** Output of a random process with no derivation provenance
- **Memorization:** Y whose hash is in StoredSolutions, even if generated again
- **Partial satisfaction:** Meeting 2 of 3 criteria (all 3 are required)

### 9.3 Emergence Logging
Every emergence test must produce a record:
```
{
  derivationId,
  emergent: boolean,
  wasStored: boolean,
  generated: boolean,
  satisfiesCriteria: boolean,
  resultHash,
  timestamp
}
```

---

## 10. REQUIRED ABLATIONS

### 10.1 Per-Mechanism Ablations
Each Category C mechanism must have a dedicated ablation:

| Mechanism | Ablation Name | Control |
|---|---|---|
| IntentEngine (H7) | `S^{-Intent}` | Random proposal baseline |
| SelfEditor (H8) | `S^{-SelfEdit}` | Fixed grammar (Pass-3 baseline) |
| Auto-expansion (H9) | `S^{-AutoExpand}` | Manual registration only |

### 10.2 Combined Ablations
| Ablation | Description |
|---|---|
| `S^{-AllCatC}` | Pass-3 baseline with only Categories A and B |
| `S^{-H7,H8}` | Pass-4 with auto-expansion but no intent/self-edit |
| `S^{-H8,H9}` | Pass-4 with intent but no self-edit/auto-expand |

### 10.3 Ablations for Category B
| Ablation | Description |
|---|---|
| `S^{-EmergenceApparatus}` | Pass-3 baseline without emergence measurement |
| `S^{-AutomataMesh}` | Pass-3 baseline without multi-automata mesh |

### 10.4 Ablation Protocol
For each ablation:
1. Clone engine from Pass-3 baseline
2. Remove target mechanism(s)
3. Run identical test suite
4. Record `ΔPerformance = metric_with - metric_without`
5. If `ΔPerformance < 0`, the mechanism **harms** performance and must be rejected or redesigned

---

## 11. ROLLBACK / VERSIONING INVARIANTS

### 11.1 Active Registry vs. Historical Record
Pass-4 distinguishes two distinct namespaces:

| Namespace | Mutability | Scope |
|---|---|---|
| **Active Grammar Registry** | Mutable (add/remove/deactivate) | The set of primitives, operators, and rules currently available to `execute()` |
| **Historical Record** | Immutable (append-only) | All derivations, edit logs, and provenance traces ever created |

**Rollback affects only the Active Grammar Registry.** When a rollback to edit N
is executed:
- Phase-4 records created after edit N are **deactivated** (removed from active registry)
- Phase-4 records created after edit N **remain** in the Historical Record
- All derivations produced by deactivated records **remain** in the derivation archive
- Provenance traces **remain** recoverable

**Phase-3 records are protected.** No rollback may deactivate, modify, or remove
any primitive, operator, or derivation with `version: "phase3.0"`.

### 11.2 Grammar Versioning
- `grammarVersion` is a semantic string: `phase4.X` where X increments on every self-edit
- All derivations record the grammar version used at creation time
- Cross-version replay produces deterministic `VERSION_MISMATCH` (see §7.2)

### 11.3 Edit Log
The SelfEditor must maintain an append-only edit log:
```
{
  id: "edit:N",
  type: "add_primitive" | "evolve_operator" | "add_rule",
  data: { ... },
  timestamp,
  grammarVersion,
  primitiveCount_before,
  primitiveCount_after
}
```

### 11.4 Rollback to Preregistered Cases
Rollback testing uses **five preregistered rollback cases**, not random selection:

| Case | Description | Target Edit |
|---|---|---|
| RB-1 | Rollback after first primitive addition | Edit 1 |
| RB-2 | Rollback after operator evolution | First `evolve_operator` edit |
| RB-3 | Rollback after rule addition | First `add_rule` edit |
| RB-4 | Rollback after 10 edits | Edit 10 (or last if < 10) |
| RB-5 | Rollback to Pass-3 baseline | Edit 0 (pre-Pass-4 state) |

Each rollback case must restore the exact active-registry state expected at the
target point. Verification: `primitiveCount == expected AND operatorSet == expected`.

### 11.5 Rollback Invariant
**No rollback may modify any Pass-3 primitive or operator.**
Pass-3 primitives are tagged `version: "phase3.0"` and are protected.
Only `version: "phase4.X"` entities may be deactivated by rollback.

---

## 12. EXPLICIT PASS / FAIL CRITERIA

### 12.1 Pass-4 Gate (Mandatory)
Before Pass-4 is declared complete, the following must ALL pass:

| # | Criterion | Threshold |
|---|---|---|
| 1 | Phase-1 gate (H.16) passes without regression | 10/10 |
| 2 | Phase-2 graph metrics are non-degenerate | ≥ 1 edge per projection |
| 3 | Phase-3 discourse parsing produces valid token trees | 100% on held-out cases |
| 4 | Phase-3 automata execute correctly on held-out cases | 100% |
| 5 | H7 (Intent) proposal accuracy ≥ threshold | ≥ 0.30 |
| 6 | H8 (Self-edit) transfer rate delta ≥ threshold | ≥ 0.10 |
| 7 | H9 (Auto-expand) SCB reduction ≥ threshold | ≥ 0.05 |
| 8 | Emergence detection correctly identifies stored vs. generated | 100% on synthetic cases |
| 9 | Deterministic replay: Pass-3 derivations hash-match in Pass-4 | 100% |
| 10 | Rollback restores exact active-registry state | 100% on 5 preregistered cases |
| 11 | Compression: `CG_with ≥ CG_without - 0.05` | Satisfied |
| 12 | No Pass-3 file modified | File hash verification |

### 12.2 Failure Modes
If any criterion fails:
- **Criterion 1–4 fail:** Pass-4 mechanism has broken the baseline. Halt. Debug.
- **Criterion 5 fail:** H7 is rejected. IntentEngine must be disabled by default.
- **Criterion 6 fail:** H8 is rejected. SelfEditor must be disabled by default.
- **Criterion 7 fail:** H9 is rejected. Auto-expansion must be disabled by default.
- **Criterion 8 fail:** Emergence apparatus is buggy. Fix before proceeding.
- **Criterion 9 fail:** Determinism is broken. Halt. Debug.
- **Criterion 10 fail:** Rollback is unsafe. Halt. Fix versioning.
- **Criterion 11 fail:** Pass-4 mechanisms are too costly. Optimize or disable.
- **Criterion 12 fail:** Pass-3 integrity violated. Restore from zip. Halt.

**Independence Preservation:** Failure of criterion 5 (H7) does not cause criteria
6–7 to be skipped. H8 and H9 are evaluated independently against the same sealed
Pass-3 baseline. Combined-condition testing (criterion 5+6, 5+7, etc.) occurs only
after individual hypothesis evaluation is sealed.

---

## 13. BEHAVIORS NOT PERMITTED

The following behaviors are **explicitly prohibited** in Pass-4:

1. **Modifying Pass-3 files.** No file frozen in §1.1 may be edited.
2. **Mutating history.** Per §16, learning creates new records. No in-place edits.
3. **Silent self-modification.** All self-edits must be logged, versioned, and auditable.
4. **Bypassing hypothesis testing.** No Category C mechanism may be enabled without
   its corresponding hypothesis being registered and tested.
5. **Treating emergence as novelty.** The §15 three-criteria definition is mandatory.
6. **Cross-version replay without VERSION_MISMATCH.** Replay across grammar versions
   must produce the deterministic `VERSION_MISMATCH` outcome.
7. **Deleting Pass-3 primitives.** Auto-expansion may add, never remove.
8. **Modifying operator invariants.** An operator's `invariants` array is immutable.
9. **Using external services without experimental controls.** Per §19, any external
   service must be a measured experimental condition with explicit null hypothesis.
10. **Claiming H7/H8/H9 as true by default.** All Category C hypotheses start at
    "hypothesized" and must earn "supported" through measurement.
11. **Post-hoc threshold adjustment.** The preregistered thresholds (0.30, 0.10, 0.05)
    may not be adjusted to fit experimental results.
12. **Historical record deletion.** Rollback may deactivate from active registry but
    must never delete derivations, edit logs, or provenance traces.

---

## 14. SIGN-OFF REQUIRED

This specification is **PROPOSED** and **NOT AUTHORIZED** for implementation.
The following must occur before any Pass-4 integration begins:

1. [ ] Specification reviewed for consistency with Pure Synthia document
2. [ ] Component audit approved (Categories A/B/C/D)
3. [ ] Hypotheses H7/H8/H9 approved with exact metrics and thresholds
4. [ ] Threshold provenance recorded as preregistered assumptions
5. [ ] Held-out cases frozen and hashes recorded
6. [ ] Ablations approved
7. [ ] Rollback invariants approved (active registry vs. historical record)
8. [ ] Preregistered rollback cases approved
9. [ ] Compression criterion approved (single equation)
10. [ ] Cross-version replay behavior approved (deterministic VERSION_MISMATCH)
11. [ ] Pass/fail criteria approved
12. [ ] Prohibited behaviors acknowledged

**Author:** (system)
**Reviewer:** (awaiting user approval)
**Status:** PENDING AUTHORIZATION

---

## APPENDIX A: PASS-3 BASELINE HASHES

```
pure-synthia-pass3.zip: 53,958 bytes
Files: 40
SHA-256: [to be computed upon freeze confirmation]
```

## APPENDIX B: PROVISIONAL FILE CHECKSUMS

```
src/emergence/detector.js: [provisional — may be rewritten]
src/emergence/multi-automata.js: [provisional — may be rewritten]
src/emergence/intent.js: [provisional — may be rewritten]
src/emergence/self-editor.js: [provisional — may be rewritten]
```

## APPENDIX C: THRESHOLD ASSUMPTIONS REGISTRY

| Hypothesis | Threshold | Value | Source | Immutable After |
|---|---|---|---|---|
| H7 | proposalAccuracy | 0.30 | Pass-4 Spec v0.2 §5.2 | Authorization |
| H8 | selfEditDelta | 0.10 | Pass-4 Spec v0.2 §5.2 | Authorization |
| H9 | SCB reduction | 0.05 | Pass-4 Spec v0.2 §5.2 | Authorization |

---
*End of Pass-4 Specification & Gate v0.2*
