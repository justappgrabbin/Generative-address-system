// src/main.js
/**
 * Pure Synthia — Pass 3 Entry Point
 * Sentence/Discourse → Automata → Computational First-Class
 */
import { Primitive } from "./core/primitive.js";
import { Composite } from "./core/composite.js";
import { CanonicalAddress } from "./core/address.js";
import { Evidence } from "./core/evidence.js";
import { GraphProjectionSet } from "./graph/graph.js";
import { GraphTopologyBuilder } from "./graph/topology.js";
import { MeshRegistry } from "./graph/mesh.js";
import { OperatorRegistry } from "./operators/registry.js";
import { SynthiaEngine } from "./engine/synthia.js";
import { AddressEvaluator } from "./engine/address-evaluator.js";
import { DimensionalEvaluator } from "./engine/dimensional-evaluator.js";
import { HypothesisRegistry } from "./hypotheses/hypothesis.js";
import { Experiment, ExperimentRunner } from "./experiments/experiment.js";
import { MetricsCollector } from "./experiments/metrics.js";
import { ControlSystem, AblationStudy } from "./experiments/controls.js";
import { CrossScaleExperiment } from "./experiments/cross-scale.js";
import { SynthiaStorage } from "./storage/indexed-db.js";
import { SyntheticDataset } from "./datasets/synthetic.js";
import { LinguisticDataset } from "./datasets/linguistic.js";
import { ComputationalDataset } from "./datasets/computational.js";
import { MultiScaleTokenizer } from "./parsers/tokenizer.js";
import { DependencyParser } from "./parsers/dependency.js";
import { FiniteStateMachine, FSMState, FSMTransition } from "./automata/fsm.js";
import { AutomataComposer } from "./automata/composition.js";

export {
  Primitive,
  Composite,
  CanonicalAddress,
  Evidence,
  GraphProjectionSet,
  GraphTopologyBuilder,
  MeshRegistry,
  OperatorRegistry,
  SynthiaEngine,
  AddressEvaluator,
  DimensionalEvaluator,
  HypothesisRegistry,
  Experiment,
  ExperimentRunner,
  MetricsCollector,
  ControlSystem,
  AblationStudy,
  CrossScaleExperiment,
  SynthiaStorage,
  SyntheticDataset,
  LinguisticDataset,
  ComputationalDataset,
  MultiScaleTokenizer,
  DependencyParser,
  FiniteStateMachine,
  FSMState,
  FSMTransition,
  AutomataComposer,
};

// Pass 3 convenience factory
export function createPhase3Engine() {
  const graphs = new GraphProjectionSet();
  const operators = new OperatorRegistry();
  const engine = new SynthiaEngine({
    primitiveRegistry: new Map(),
    operatorRegistry: operators,
    graphs,
  });
  return engine;
}

// Bootstrap phonological primitives (Phase 1)
export function bootstrapPhonologicalPrimitives(engine) {
  const features = [
    { id: "f.voice", identity: "voiced", contrast: "[±voice]", position: "manner-independent", scale: "sub-phonemic" },
    { id: "f.voiceless", identity: "voiceless", contrast: "[±voice]", position: "manner-independent", scale: "sub-phonemic" },
    { id: "f.place.lab", identity: "labial", contrast: "[place=labial]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.place.alv", identity: "alveolar", contrast: "[place=alveolar]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.place.vel", identity: "velar", contrast: "[place=velar]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.manner.stop", identity: "stop", contrast: "[manner=stop]", position: "manner", scale: "sub-phonemic" },
    { id: "f.manner.fric", identity: "fricative", contrast: "[manner=fricative]", position: "manner", scale: "sub-phonemic" },
    { id: "f.manner.nas", identity: "nasal", contrast: "[manner=nasal]", position: "manner", scale: "sub-phonemic" },
  ];

  for (const f of features) {
    engine.registerPrimitive(new Primitive(f));
  }

  const phonemes = [
    { id: "phoneme.p", identity: "/p/", scale: "phonemic", features: ["f.place.lab", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.b", identity: "/b/", scale: "phonemic", features: ["f.place.lab", "f.manner.stop", "f.voice"] },
    { id: "phoneme.t", identity: "/t/", scale: "phonemic", features: ["f.place.alv", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.d", identity: "/d/", scale: "phonemic", features: ["f.place.alv", "f.manner.stop", "f.voice"] },
    { id: "phoneme.k", identity: "/k/", scale: "phonemic", features: ["f.place.vel", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.m", identity: "/m/", scale: "phonemic", features: ["f.place.lab", "f.manner.nas", "f.voice"] },
    { id: "phoneme.n", identity: "/n/", scale: "phonemic", features: ["f.place.alv", "f.manner.nas", "f.voice"] },
  ];

  for (const p of phonemes) {
    engine.registerPrimitive(new Primitive({
      id: p.id,
      identity: p.identity,
      contrast: "phoneme",
      position: "onset",
      scale: p.scale,
      dependencies: p.features,
    }));
  }

  return engine;
}

// Register candidate dimensions (Phase 2)
export function bootstrapDimensions(evaluator) {
  const dimensions = [
    { id: "D1", macroName: "Movement", macroChain: ["Energy", "Creation", "Seeing", "Landscape", "Environment"], microName: "Individuality", microChain: ["Activity", "Reaction", "Limitation", "Perspective", "Relation"], keynote: "I Define" },
    { id: "D2", macroName: "Evolution", macroChain: ["Gravity", "Memory", "Taste", "Love", "Light"], microName: "The Mind", microChain: ["Character", "Separation", "Nature", "Integration", "Spirit"], keynote: "I Remember" },
    { id: "D3", macroName: "Being", macroChain: ["Matter", "Matter", "Touch", "Sex", "Survival"], microName: "The Body", microChain: ["Biology", "Chemistry", "Objectivity", "Geometry", "Trajectory"], keynote: "I Am" },
    { id: "D4", macroName: "Design", macroChain: ["Structure", "Progress", "Smelt", "Life", "Art"], microName: "The Ego", microChain: ["Homo Sapiens", "Growth", "Decay", "Continuity", "Manifestation"], keynote: "I Design" },
    { id: "D5", macroName: "Space", macroChain: ["Form", "Illusion", "Hearing", "Music", "Freedom"], microName: "Personality", microChain: ["Type", "Fantasy", "Subjectivity", "Rhythm", "Timing"], keynote: "I Think" },
  ];

  for (const d of dimensions) {
    evaluator.registerCandidate(d);
  }

  return evaluator;
}

// Pass 3: Create sample FSMs
export function bootstrapSampleAutomata(engine) {
  // FSM that accepts strings with even number of 0s
  const evenZeros = new FiniteStateMachine({
    id: "fsm:even-zeros",
    name: "EvenZeros",
    states: [
      new FSMState({ id: "q0", name: "q0", initial: true, accepting: true }),
      new FSMState({ id: "q1", name: "q1", accepting: false }),
    ],
    transitions: [
      new FSMTransition({ from: "q0", to: "q1", input: "0" }),
      new FSMTransition({ from: "q0", to: "q0", input: "1" }),
      new FSMTransition({ from: "q1", to: "q0", input: "0" }),
      new FSMTransition({ from: "q1", to: "q1", input: "1" }),
    ],
    alphabet: ["0", "1"],
  });

  // FSM that accepts strings ending in "01"
  const ends01 = new FiniteStateMachine({
    id: "fsm:ends-01",
    name: "Ends01",
    states: [
      new FSMState({ id: "s0", name: "s0", initial: true }),
      new FSMState({ id: "s1", name: "s1" }),
      new FSMState({ id: "s2", name: "s2", accepting: true }),
    ],
    transitions: [
      new FSMTransition({ from: "s0", to: "s0", input: "0" }),
      new FSMTransition({ from: "s0", to: "s0", input: "1" }),
      new FSMTransition({ from: "s0", to: "s1", input: "0" }),
      new FSMTransition({ from: "s1", to: "s2", input: "1" }),
      new FSMTransition({ from: "s2", to: "s1", input: "0" }),
      new FSMTransition({ from: "s2", to: "s0", input: "1" }),
    ],
    alphabet: ["0", "1"],
  });

  engine.registerAutomaton(evenZeros);
  engine.registerAutomaton(ends01);

  return engine;
}

// Default export: fully bootstrapped Pass 3 engine
export default function initPureSynthia() {
  const engine = createPhase3Engine();
  bootstrapPhonologicalPrimitives(engine);
  bootstrapSampleAutomata(engine);
  return engine;
}
