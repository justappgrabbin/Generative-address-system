# Repair Log — pure-synthia-phase1

Original artifact preserved untouched alongside this repaired copy
(`pure-synthia-phase1__1_.zip` / `pure-synthia-phase1-ORIGINAL.zip`).
Diff the two to audit every change made below.

---

## Repair 1 of 2

**File changed:** `src/core/operator.js` — `Operator.apply()`

**Original failure:** Calling `o_bundle.apply(operands, context)` with 3
operands throws `RangeError: o_bundle requires exactly 2 operands.` This
crashes: the `phase1-gate.js` test suite (item 2b), the `index.html`
"bundle" demo button, and the README Core API quick-start example — all
three call `o_bundle` with 3 operands as the documented use case.

**Root cause:** `apply()` enforced strict operand-count equality
(`operands.length !== this.arity`). This contradicts:
  (a) `o_bundle`'s own docstring, which documents it as n-ary:
      `o_bundle(p_1, ..., p_n) -> X`
  (b) `o_bundle`'s own `accepts()` function, which explicitly permits 2+
      operands (`if (operands.length < 2) return false;`)
  (c) `SynthiaEngine.selectOperators()`, which already treats `arity` as
      a *minimum*, not an exact count (`op.arity <= primitives.length`)

The base `Operator` class's enforcement was inconsistent with how the
rest of the codebase — including one of only two shipped operators —
already treated the same field.

**Exact repair:**
```diff
  apply(operands, context = {}) {
-   if (!Array.isArray(operands) || operands.length !== this.arity) {
+   if (!Array.isArray(operands) || operands.length < this.arity) {
      throw new RangeError(
-       `${this.id} requires exactly ${this.arity} operands.`,
+       `${this.id} requires at least ${this.arity} operands.`,
      );
    }
```

**Why this preserves the original architecture:** `o_sequence` is
unaffected — it independently re-enforces exactly-2 operands via its own
`accepts()` (`operands.length === 2`), verified by direct test after the
change. Only `o_bundle`'s already-documented, already-intended n-ary
behavior was restored. No operator's designed contract changed; the
generic enforcement was made consistent with the specific contracts
already written into `bundle.js`, `sequence.js`, and `synthia.js`.

**Observable behavior changed:** Yes. `o_bundle` now executes
successfully when called with 3+ operands (previously: crash) — matching
the README example, the UI demo, and the gate test's expected outcome.
Every 2-operand call site (all of `o_sequence`'s usage, and any 2-operand
`o_bundle` call) is byte-identical in behavior to before.

---

## Repair 2 of 2

**File changed:** `src/derivation/replay.js` — `ReplayEngine.hashDerivation()`

**Original failure:** `phase1-gate.js` item 10 ("Deterministic replay")
failed: two derivations produced from the identical input (`"pat"`,
`{}`) hashed to different values (e.g. `hash1=1091507333,
hash2=876829540`).

**Root cause:** The function hashed `JSON.stringify(derivation.toJSON())`
in full. `toJSON()` includes `id` (a monotonically incrementing counter,
`derivation:${++_derivationCounter}`) and `timestamp` (`Date.now()`) —
both unique per call *by construction*, regardless of whether the
underlying computation was deterministic. This directly contradicts the
class's own docstring:

> "Deterministic Replay: given equivalent initial state, input, context,
> grammar version, and operator set, reproduce the same derivation.
> Hash(Delta_original) == Hash(Delta_replayed)"

`id` and `timestamp` are not part of that documented equivalence class,
so including them in the hash made the stated invariant impossible to
satisfy for any two separate calls.

**Exact repair:**
```diff
  hashDerivation(derivation) {
-   // Simple deterministic hash for comparison
-   const str = JSON.stringify(derivation.toJSON());
-   let hash = 0;
+   // Simple deterministic hash for comparison.
+   // Excludes 'id' and 'timestamp': both are unique per execution by
+   // construction (incrementing counter / wall clock) and are not part
+   // of the equivalence class this hash is defined over (see class
+   // docstring: "given equivalent initial state, input, context,
+   // grammar version, and operator set, reproduce the same derivation").
+   const { id, timestamp, ...content } = derivation.toJSON();
+   const str = JSON.stringify(content);
+   let hash = 0;
```

**Why this preserves the original architecture:** Nothing about the
`Derivation` object itself changed — `id` and `timestamp` are still
generated, stored, and displayed in the UI exactly as before. Only the
replay-equivalence hash computation was corrected to match the
equivalence class its own docstring already defined.

**Observable behavior changed:** Yes. Identical (input, context) pairs
now correctly produce identical replay hashes, as designed. No change to
any derivation's stored content, the UI's derivation display, or any
non-replay code path.

---

## Flagged, not fixed — genuine gap (left as a legitimate negative result)

**Gate item 7 ("Complexity ledger collected") still fails.** This was
NOT patched.

`SynthiaEngine.decompose()` does per-character lookup for string inputs,
trying primitive scale `"grapheme"` -> `"phoneme"` -> `"sub-phonemic"` by
identity match. However:

- No `"grapheme"`-scale primitives are registered anywhere in
  `bootstrapPhonologicalPrimitives()` (main.js) — that lookup always
  misses.
- Registered phoneme identities are slash-wrapped (`"/p/"`, `"/b/"`,
  etc.) and never match bare split characters (`"p"`, `"b"`).
- No vowel primitives exist at all (only consonant place/manner/voice
  features) — so `"a"` in the README's own `"pat"`/`"bat"` examples has
  no possible match under any fix that only adds consonant mappings.

Net effect: every string-input `execute()` call silently decomposes to
zero primitives. It does not crash (falls through to an "unregistered"
branch), so it wasn't caught by import/smoke checks — it surfaces only
as an empty ledger and an empty `primitive_set` result. This is why the
README's primary "Execute a string" walkthrough, the `index.html`
"decompose" demo button, and gate items 4-6 all silently no-op on the
string path (4-6 pass trivially, since two empty results are still
"equal"; item 7 fails because nothing is ever counted).

**Why not fixed:** Repairing this requires inventing a
grapheme-to-phoneme dataset (letter primitive IDs, contrast values, and
an entire vowel inventory) that does not exist anywhere in this
artifact. That is new scientific/content authorship, not a mechanical
wiring fix, and falls outside "repair, not redesign." Flagged for your
decision instead.

---

## Flagged, not fixed — conceptually unusual, functioning as designed

- **`CanonicalAddress` (`src/core/address.js`)** uses Human-Design /
  astrology-style fields (`gate`, `line`, `color`, `tone`, `zodiac`,
  `house`, `arcSecond`, ...). Unusual, but fully implemented, internally
  consistent, and its own docstring explicitly scopes it as independent
  of any scientific claim ("supports addresses without requiring the
  scientific hypothesis concerning those addresses"). Not touched.

- **`Composite` class is defined/exported but never instantiated by the
  live pipeline.** `SynthiaEngine.compose()` returns plain descriptor
  objects rather than `new Composite(...)`, and `registerComposite()` is
  never called from `execute()` — `engine.composites` stays permanently
  empty. Could be intentional Phase 1 scoping (README: "establishes the
  infrastructure for steps 2-3") or an oversight. Genuinely ambiguous —
  left alone rather than guessed at.

---

## Verification

Full gate suite before repairs: **crashed** (uncaught `RangeError` at
item 2b, suite never completes).

Full gate suite after both repairs: **11 passed, 1 failed** (item 7,
flagged above as a genuine gap, not a repair-suite artifact).

All other modules (`core/*`, `graph/*`, `hypotheses/*`,
`experiments/*`, `storage/*`) were individually import-checked and
cross-referenced against the README/docstrings; no further defects
found. All `index.html` DOM element IDs referenced by the inline script
were confirmed to exist in the markup — no UI wiring breaks.
