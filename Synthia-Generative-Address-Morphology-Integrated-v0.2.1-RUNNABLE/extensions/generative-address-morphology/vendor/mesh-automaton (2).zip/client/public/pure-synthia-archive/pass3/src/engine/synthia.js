// src/engine/synthia.js
/**
 * SynthiaEngine v3: Pass 3
 * Sentence/Discourse parsing, Automata as first-class primitives,
 * Computational datasets as native inputs.
 */
import { Derivation, nextDerivationId } from "../derivation/derivation.js";
import { ComplexityLedger } from "../derivation/ledger.js";
import { ReplayEngine } from "../derivation/replay.js";
import { RuntimeState } from "../core/state.js";
import { GraphTopologyBuilder } from "../graph/topology.js";
import { MeshRegistry } from "../graph/mesh.js";
import { MultiScaleTokenizer } from "../parsers/tokenizer.js";
import { DependencyParser } from "../parsers/dependency.js";

export class SynthiaEngine {
  constructor({
    primitiveRegistry = new Map(),
    operatorRegistry,
    graphs,
    version = "0.3.0",
    grammarVersion = "phase3.0",
    operatorVersion = "phase3.0",
  }) {
    this.primitives = primitiveRegistry;
    this.operators = operatorRegistry;
    this.graphs = graphs;
    this.ledger = new ComplexityLedger();
    this.replayEngine = new ReplayEngine(this);
    this.version = version;
    this.grammarVersion = grammarVersion;
    this.operatorVersion = operatorVersion;
    this.useAddressing = true;
    this.useDimensions = true;
    this.runtimeStates = new Map();
    this.derivations = new Map();
    this.composites = new Map();

    this.topologyBuilder = new GraphTopologyBuilder(graphs);
    this.meshRegistry = new MeshRegistry();

    // Pass 3 additions
    this.tokenizer = new MultiScaleTokenizer();
    this.dependencyParser = new DependencyParser();
    this.automata = new Map(); // id -> FiniteStateMachine
  }

  execute(input, context = {}) {
    const derivationId = nextDerivationId();

    // Detect input type and route appropriately
    const inputType = this._detectInputType(input);

    if (inputType === "automaton") {
      return this._executeAutomaton(input, context, derivationId);
    }
    if (inputType === "discourse" || (typeof input === "string" && input.length > 20)) {
      return this._executeDiscourse(input, context, derivationId);
    }

    // Standard Phase 1/2 pipeline
    const decomposition = this.decompose(input, context);
    this.ledger.record({ primitivesActivated: decomposition.primitives.length });

    if (typeof input === "string") {
      for (let i = 0; i < decomposition.primitives.length; i++) {
        this.topologyBuilder.recordDecomposition(input, decomposition.primitives[i], i, context);
      }
    }

    const primitives = this.resolve(decomposition, context);
    const selectedOperators = this.selectOperators(primitives, context);
    this.ledger.record({ operationsExecuted: selectedOperators.length });

    const topology = this.activateTopology(primitives, context);
    this.ledger.record({
      statesGenerated: topology.activatedStates.length,
      edgesTraversed: topology.traversedEdges,
    });

    const result = this.compose({
      primitives,
      operators: selectedOperators,
      topology,
      context,
    });
    this.ledger.record({ statesGenerated: 1 });

    if (result && result.type === "composite" && selectedOperators.length > 0) {
      this.topologyBuilder.recordComposition(
        selectedOperators[0].id,
        primitives,
        { id: derivationId, ...result },
        context
      );
    }

    const derivation = new Derivation({
      id: derivationId,
      input,
      decomposition: decomposition.steps,
      primitives: primitives.map(p => p.id),
      operators: selectedOperators.map(o => o.id),
      topology: topology.summary,
      result,
      context,
    });

    this.derivations.set(derivationId, derivation);
    this._autoMesh(primitives, derivationId, context);

    return derivation;
  }

  // Pass 3: Discourse execution pipeline
  _executeDiscourse(input, context, derivationId) {
    const text = typeof input === "string" ? input : input.text;
    const targetScale = context.targetScale || "auto";

    // Tokenize at all scales
    const tokenTree = this.tokenizer.tokenize(text, targetScale);
    this.ledger.record({ statesGenerated: this._countTokens(tokenTree) });

    // Parse dependencies at sentence level
    const sentences = this.tokenizer.flattenToScale(tokenTree, "sentence");
    const dependencyParses = [];
    for (const sentence of sentences) {
      const words = this.tokenizer.flattenToScale(sentence, "word");
      if (words.length > 0) {
        const parse = this.dependencyParser.parse(words);
        dependencyParses.push(parse);
        // Record dependency edges in graph
        for (const rel of parse.relations) {
          this.graphs.dependency.addEdge(rel.head, rel.dependent, rel.relation);
        }
      }
    }

    const result = {
      type: "discourse_parse",
      tokenTree: tokenTree.toJSON(),
      sentenceCount: sentences.length,
      dependencyParses,
      scalePath: this.tokenizer.scalePath(tokenTree),
    };

    const derivation = new Derivation({
      id: derivationId,
      input: text.substring(0, 200),
      decomposition: [{ type: "tokenization", scale: "discourse" }],
      primitives: [],
      operators: ["tokenizer", "dependency_parser"],
      topology: { sentences: sentences.length, dependencies: dependencyParses.length },
      result,
      context,
    });

    this.derivations.set(derivationId, derivation);
    return derivation;
  }

  // Pass 3: Automaton execution pipeline
  _executeAutomaton(input, context, derivationId) {
    const fsm = input._fsm || input;
    const testString = context.testString || "";

    // Register the FSM as a primitive if not already
    if (!this.automata.has(fsm.id)) {
      this.automata.set(fsm.id, fsm);
      this.registerPrimitive({
        id: fsm.id,
        identity: fsm.name,
        scale: "automaton",
        type: "fsm",
        stateCount: fsm.states?.size || 0,
        transitionCount: fsm.transitions?.size || 0,
      });
    }

    // Run the automaton
    const runResult = testString ? fsm.run(testString) : { accepted: false, path: [], reason: "no_test_string" };

    this.ledger.record({
      statesGenerated: fsm.states?.size || 0,
      operationsExecuted: fsm.transitions?.size || 0,
    });

    const result = {
      type: "automaton_run",
      fsmId: fsm.id,
      fsmName: fsm.name,
      testString,
      accepted: runResult.accepted,
      path: runResult.path,
      finalState: runResult.finalState,
      stateCount: fsm.states?.size || 0,
      transitionCount: fsm.transitions?.size || 0,
    };

    const derivation = new Derivation({
      id: derivationId,
      input: { fsmId: fsm.id, testString },
      decomposition: [{ type: "automaton", states: fsm.states?.size || 0 }],
      primitives: [fsm.id],
      operators: ["automaton_run"],
      topology: { stateCount: fsm.states?.size || 0 },
      result,
      context,
    });

    this.derivations.set(derivationId, derivation);
    return derivation;
  }

  _detectInputType(input) {
    if (input && (input.states || input.type === "fsm" || input._fsm)) {
      return "automaton";
    }
    if (typeof input === "string" && input.length > 50) {
      return "discourse";
    }
    if (input && input.type === "discourse") {
      return "discourse";
    }
    return "standard";
  }

  _countTokens(token) {
    let count = 1;
    for (const child of token.children || []) {
      count += this._countTokens(child);
    }
    return count;
  }

  decompose(input, context) {
    const steps = [];
    const foundPrimitives = [];

    if (typeof input === "string") {
      const chars = input.split("");
      for (let i = 0; i < chars.length; i++) {
        const char = chars[i];
        const primitive = this.findPrimitiveByIdentity(char, "grapheme") ||
                         this.findPrimitiveByIdentity(char, "phoneme") ||
                         this.findPrimitiveByIdentity(char, "sub-phonemic");
        if (primitive) {
          foundPrimitives.push(primitive);
          steps.push({ position: i, input: char, primitiveId: primitive.id, identity: primitive.identity });
        } else {
          steps.push({ position: i, input: char, primitiveId: null, identity: char, note: "unregistered" });
        }
      }
    } else if (Array.isArray(input)) {
      for (let i = 0; i < input.length; i++) {
        const ref = input[i];
        const primitive = typeof ref === "string" ? this.primitives.get(ref) : ref;
        if (primitive) {
          foundPrimitives.push(primitive);
          steps.push({ position: i, primitiveId: primitive.id });
        }
      }
    } else if (input && typeof input === "object" && input.id) {
      const primitive = this.primitives.get(input.id);
      if (primitive) {
        foundPrimitives.push(primitive);
        steps.push({ position: 0, primitiveId: primitive.id });
      }
    }

    return { primitives: foundPrimitives, steps };
  }

  resolve(decomposition, context) {
    return decomposition.primitives;
  }

  selectOperators(primitives, context) {
    if (primitives.length === 0) return [];
    const scale = primitives[0].scale;
    const candidates = this.operators.findForScale(scale);
    const selected = [];
    for (const op of candidates) {
      if (op.arity <= primitives.length) {
        try {
          const testOperands = primitives.slice(0, op.arity);
          if (op.accepts(testOperands, context)) {
            selected.push(op);
          }
        } catch (e) {}
      }
    }
    return selected;
  }

  activateTopology(primitives, context) {
    const activatedStates = [];
    let traversedEdges = 0;

    for (const p of primitives) {
      if (!this.runtimeStates.has(p.id)) {
        this.runtimeStates.set(p.id, new RuntimeState(p.id, 0.5));
      }
      const state = this.runtimeStates.get(p.id);
      const prevActivation = state.activation;
      state.updateActivation(0.8, Date.now());
      activatedStates.push(p.id);

      this.topologyBuilder.recordActivation(p.id, 0.8, prevActivation, { timestamp: Date.now() });

      if (this.graphs && this.graphs.dependency) {
        const edges = this.graphs.dependency.edgesFrom(p.id);
        traversedEdges += edges.length;
      }
    }

    return {
      activatedStates,
      traversedEdges,
      summary: { activatedStates, traversedEdges },
    };
  }

  compose({ primitives, operators, topology, context }) {
    if (operators.length === 0 || primitives.length < 2) {
      return {
        type: "primitive_set",
        members: primitives.map(p => ({ id: p.id, identity: p.identity })),
      };
    }

    const op = operators[0];
    const operands = primitives.slice(0, op.arity);

    try {
      const result = op.apply(operands, context);
      return {
        type: "composite",
        operator: op.id,
        result,
        operands: operands.map(o => o.id),
      };
    } catch (e) {
      return {
        type: "error",
        error: e.message,
        operator: op.id,
      };
    }
  }

  _autoMesh(primitives, derivationId, context) {
    const meshName = `derivation:${derivationId}`;
    const mesh = this.meshRegistry.create(meshName, "local");
    for (const p of primitives) {
      mesh.join(p.id, { derivationId, scale: p.scale });
    }
    if (primitives.length > 0) {
      const scale = primitives[0].scale;
      const scaleMesh = this.meshRegistry.get(`scale:${scale}`) ||
                       this.meshRegistry.create(`scale:${scale}`, "scale");
      for (const p of primitives) {
        scaleMesh.join(p.id, { derivationId });
      }
    }
  }

  findPrimitiveByIdentity(identity, scale) {
    for (const p of this.primitives.values()) {
      if (p.identity === identity && p.scale === scale) {
        return p;
      }
    }
    return null;
  }

  registerPrimitive(primitive) {
    this.primitives.set(primitive.id, primitive);
    return this;
  }

  registerComposite(composite) {
    this.composites.set(composite.id, composite);
    return this;
  }

  registerAutomaton(fsm) {
    this.automata.set(fsm.id, fsm);
    this.registerPrimitive({
      id: fsm.id,
      identity: fsm.name,
      scale: "automaton",
      type: "fsm",
      stateCount: fsm.states?.size || 0,
      transitionCount: fsm.transitions?.size || 0,
    });
    return this;
  }

  clone() {
    const cloned = new SynthiaEngine({
      primitiveRegistry: new Map(this.primitives),
      operatorRegistry: this.operators,
      graphs: this.graphs,
      version: this.version,
      grammarVersion: this.grammarVersion,
      operatorVersion: this.operatorVersion,
    });
    cloned.useAddressing = this.useAddressing;
    cloned.useDimensions = this.useDimensions;
    return cloned;
  }

  toJSON() {
    return {
      version: this.version,
      grammarVersion: this.grammarVersion,
      operatorVersion: this.operatorVersion,
      primitives: Array.from(this.primitives.values()).map(p => p.toJSON?.() || p),
      derivations: Array.from(this.derivations.values()).map(d => d.toJSON()),
      composites: Array.from(this.composites.values()).map(c => c.toJSON()),
      ledger: this.ledger.toJSON(),
      runtimeStates: Array.from(this.runtimeStates.values()).map(s => s.toJSON()),
      graphMetrics: this.topologyBuilder ? this.topologyBuilder.metrics() : {},
      meshes: this.meshRegistry ? this.meshRegistry.toJSON() : [],
      automataCount: this.automata.size,
    };
  }
}
