// src/automata/fsm.js
/**
 * Finite State Machine as first-class primitive.
 * Per §21 Step 7: Test against computation (automata).
 * FSMs are primitives at the "automaton" scale, composed like linguistic objects.
 */

export class FSMState {
  constructor({ id, name, accepting = false, initial = false, metadata = {} }) {
    this.id = id;
    this.name = name;
    this.accepting = accepting;
    this.initial = initial;
    this.metadata = { ...metadata };
    Object.freeze(this);
  }

  toJSON() {
    return { id: this.id, name: this.name, accepting: this.accepting, initial: this.initial, metadata: this.metadata };
  }
}

export class FSMTransition {
  constructor({ from, to, input, output = null, metadata = {} }) {
    this.from = from;
    this.to = to;
    this.input = input;
    this.output = output;
    this.metadata = { ...metadata };
    Object.freeze(this);
  }

  toJSON() {
    return { from: this.from, to: this.to, input: this.input, output: this.output, metadata: this.metadata };
  }
}

export class FiniteStateMachine {
  constructor({ id, name, states = [], transitions = [], alphabet = [] }) {
    this.id = id;
    this.name = name;
    this.states = new Map(states.map(s => [s.id, s]));
    this.transitions = new Map();
    this.alphabet = new Set(alphabet);
    this._transitionCounter = 0;

    for (const t of transitions) {
      this.addTransition(t);
    }
  }

  addState(state) {
    this.states.set(state.id, state);
    return this;
  }

  addTransition(transition) {
    const tid = `trans:${this.id}:${++this._transitionCounter}`;
    this.transitions.set(tid, transition);
    if (transition.input) this.alphabet.add(transition.input);
    return tid;
  }

  getInitialState() {
    for (const s of this.states.values()) {
      if (s.initial) return s;
    }
    return this.states.values().next().value || null;
  }

  getAcceptingStates() {
    return Array.from(this.states.values()).filter(s => s.accepting);
  }

  // Step the machine on an input symbol
  step(stateId, input) {
    const matches = [];
    for (const t of this.transitions.values()) {
      if (t.from === stateId && t.input === input) {
        matches.push(t);
      }
    }
    return matches;
  }

  // Run the machine on an input string
  run(inputString) {
    let current = this.getInitialState();
    if (!current) return { accepted: false, path: [], reason: "no_initial_state" };

    const path = [{ state: current.id, input: null }];

    for (const symbol of inputString) {
      const transitions = this.step(current.id, symbol);
      if (transitions.length === 0) {
        return { accepted: false, path, reason: "no_transition", stuckAt: symbol };
      }
      // Deterministic: take first match
      const t = transitions[0];
      current = this.states.get(t.to);
      path.push({ state: current.id, input: symbol, transition: t.toJSON() });
    }

    return {
      accepted: current.accepting,
      path,
      finalState: current.id,
    };
  }

  // Convert to a primitive-compatible structure
  toPrimitive() {
    return {
      id: this.id,
      identity: this.name,
      scale: "automaton",
      type: "fsm",
      stateCount: this.states.size,
      transitionCount: this.transitions.size,
      alphabet: Array.from(this.alphabet),
      states: Array.from(this.states.values()).map(s => s.toJSON()),
      transitions: Array.from(this.transitions.values()).map(t => t.toJSON()),
    };
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      states: Array.from(this.states.values()).map(s => s.toJSON()),
      transitions: Array.from(this.transitions.values()).map(t => t.toJSON()),
      alphabet: Array.from(this.alphabet),
    };
  }

  static fromJSON(data) {
    const fsm = new FiniteStateMachine({
      id: data.id,
      name: data.name,
      states: data.states.map(s => new FSMState(s)),
      transitions: data.transitions.map(t => new FSMTransition(t)),
      alphabet: data.alphabet,
    });
    return fsm;
  }
}
