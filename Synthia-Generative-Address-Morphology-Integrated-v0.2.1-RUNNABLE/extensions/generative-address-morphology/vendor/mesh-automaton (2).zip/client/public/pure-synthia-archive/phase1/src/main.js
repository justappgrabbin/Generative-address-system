// src/main.js
/**
 * Pure Synthia — Phase 1 Entry Point
 * Browser-native, deterministic, recursively generative state calculus.
 */
import { Primitive } from "./core/primitive.js";
import { Composite } from "./core/composite.js";
import { CanonicalAddress } from "./core/address.js";
import { Evidence } from "./core/evidence.js";
import { GraphProjectionSet } from "./graph/graph.js";
import { OperatorRegistry } from "./operators/registry.js";
import { SynthiaEngine } from "./engine/synthia.js";
import { HypothesisRegistry } from "./hypotheses/hypothesis.js";
import { Experiment, ExperimentRunner } from "./experiments/experiment.js";
import { MetricsCollector } from "./experiments/metrics.js";
import { ControlSystem, AblationStudy } from "./experiments/controls.js";
import { SynthiaStorage } from "./storage/indexed-db.js";

// Export the full API
export {
  Primitive,
  Composite,
  CanonicalAddress,
  Evidence,
  GraphProjectionSet,
  OperatorRegistry,
  SynthiaEngine,
  HypothesisRegistry,
  Experiment,
  ExperimentRunner,
  MetricsCollector,
  ControlSystem,
  AblationStudy,
  SynthiaStorage,
};

// Convenience factory for Phase 1 bootstrap
export function createPhase1Engine() {
  const graphs = new GraphProjectionSet();
  const operators = new OperatorRegistry();
  const engine = new SynthiaEngine({
    primitiveRegistry: new Map(),
    operatorRegistry: operators,
    graphs,
  });
  return engine;
}

// Bootstrap with Appendix A phonological primitives
export function bootstrapPhonologicalPrimitives(engine) {
  const features = [
    { id: "f.voice", identity: "voiced", contrast: "[±voice]", position: "manner-independent", scale: "sub-phonemic" },
    { id: "f.voiceless", identity: "voiceless", contrast: "[±voice]", position: "manner-independent", scale: "sub-phonemic" },
    { id: "f.place.lab", identity: "labial", contrast: "[place=labial]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.place.alv", identity: "alveolar", contrast: "[place=alveolar]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.place.vel", identity: "velar", contrast: "[place=velar]", position: "articulation-point", scale: "sub-phonemic" },
    { id: "f.manner.stop", identity: "stop", contrast: "[manner=stop]", position: "manner", scale: "sub-phonemic" },
    { id: "f.manner.fric", identity: "fricative", contrast: "[manner=fricative]", position: "manner", scale: "sub-phonemic" },
    { id: "f.manner.nas", identity: "nasal", contrast: "[manner=nasal]", position: "manner", scale: "sub-phonemic" },
  ];

  for (const f of features) {
    engine.registerPrimitive(new Primitive(f));
  }

  // Register phonemes as composites of features (pre-computed for Phase 1)
  const phonemes = [
    { id: "phoneme.p", identity: "/p/", scale: "phonemic", features: ["f.place.lab", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.b", identity: "/b/", scale: "phonemic", features: ["f.place.lab", "f.manner.stop", "f.voice"] },
    { id: "phoneme.t", identity: "/t/", scale: "phonemic", features: ["f.place.alv", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.d", identity: "/d/", scale: "phonemic", features: ["f.place.alv", "f.manner.stop", "f.voice"] },
    { id: "phoneme.k", identity: "/k/", scale: "phonemic", features: ["f.place.vel", "f.manner.stop", "f.voiceless"] },
    { id: "phoneme.m", identity: "/m/", scale: "phonemic", features: ["f.place.lab", "f.manner.nas", "f.voice"] },
    { id: "phoneme.n", identity: "/n/", scale: "phonemic", features: ["f.place.alv", "f.manner.nas", "f.voice"] },
  ];

  for (const p of phonemes) {
    engine.registerPrimitive(new Primitive({
      id: p.id,
      identity: p.identity,
      contrast: "phoneme",
      position: "onset",
      scale: p.scale,
      dependencies: p.features,
    }));
  }

  return engine;
}

// Default export: fully bootstrapped engine
export default function initPureSynthia() {
  const engine = createPhase1Engine();
  bootstrapPhonologicalPrimitives(engine);
  return engine;
}
