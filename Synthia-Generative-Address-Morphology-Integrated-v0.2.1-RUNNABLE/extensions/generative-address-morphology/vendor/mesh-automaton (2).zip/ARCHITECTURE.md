# Mesh Automaton Architecture

## Purpose

Mesh Automaton is a deterministic orchestration workspace. It replaces a table-oriented coordinator with a directed graph of independently configured nodes. A cycle begins with a grammar expansion, turns that expansion into explicit messages and tool-composition plans, routes messages across enabled mesh edges, invokes only registered deterministic tools, and records every decision as a durable trace. The system makes no LLM or generative-model requests.

## Execution Model

The workspace persists a `MeshSession` with a bounded graph of nodes and directed edges. A node holds its stable configuration and mutable state. An edge controls whether and how a message can travel, including explicit priority and hop limits. Each run derives its deterministic outcome from the persisted session seed, rule priorities, stable identifiers, edge priorities, and message sequence numbers. Identical starting mesh state and input produce equivalent execution plans and results.

| Layer | Responsibility | Determinism boundary |
|---|---|---|
| Mesh model | Nodes, directed edges, state, and graph positions | Stable IDs, explicit edge order, bounded hops |
| Generative grammar | Expands production rules into structured actions and messages | Rules are ranked by priority, then stable rule ID |
| Tool Factory | Registers, creates, validates, composes, and invokes known tool profiles | No dynamic evaluation, remote inference, or arbitrary code execution |
| Router | Routes messages only through enabled outgoing edges | Edge priority, then stable edge ID |
| Trace ledger | Records grammar, message, tool, and state events | Append-only sequence per run |

## Domain Model

The persistent model uses six core records. A `MeshSession` owns `MeshNode`, `MeshEdge`, `GrammarRule`, and `ToolDefinition` records. A `MeshRun` freezes an execution attempt, while `RunEvent` provides a chronological audit trail with event payloads, route paths, tool output, and state patches.

| Record | Key fields | Role |
|---|---|---|
| MeshSession | name, seed, description, lifecycle state | Resumable orchestration workspace |
| MeshNode | label, kind, capabilities, configuration, state, x/y | Graph participant with durable state |
| MeshEdge | source, target, label, priority, enabled, transform | Explicit message route |
| GrammarRule | symbol, priority, production JSON, enabled | Production rule that emits plans and actions |
| ToolDefinition | profile, capabilities, configuration, composition | Factory-created deterministic tool |
| MeshRun / RunEvent | seed, status, summary, sequence, type, payload | Replayable cycle history and observability |

## Deterministic Tool Factory

The Tool Factory is intentionally closed over a small, inspectable vocabulary of profiles: `envelope`, `project`, `merge`, `annotate`, and `pipeline`. A factory request selects a profile, validates declared capabilities, normalizes configuration, and persists a tool definition. Pipeline tools compose named registered tools in a fixed stored order. Invocation passes a structured envelope through each stage, returning output and a per-stage execution report. The factory never interprets generated source code, invokes a language model, or calls external model APIs.

## Generative Grammar

Each grammar rule is a declarative production such as `CYCLE → EMIT → INVOKE → PROPAGATE`. Productions contain JSON action descriptors rather than code. Supported action descriptors create a tool, emit a structured message, invoke a registered tool, patch node state, or request a named route. Template interpolation is restricted to known cycle variables, including `input`, `runId`, `seed`, and grammar attributes. Expansion uses an ordered queue with an explicit maximum depth and action budget.

## Mesh Routing and State Propagation

Messages are envelopes with an origin node, target selector, payload, route path, hop counter, and originating grammar rule. The router starts at the selected source node and traverses only enabled edges. At each hop, edges are considered by ascending priority followed by their stable ID. A receiving node receives the structured envelope, updates compact execution metadata in its state, and can invoke a matching tool when the grammar plan requests it. Routing terminates when a message reaches its target, has no legal onward edge, or reaches the configured hop limit. Every routing decision becomes a `RunEvent`.

## Workspace Experience

The workspace is an asymmetric dark canvas with a compact control rail, a central graph field, and a contextual inspector. Users can add and link nodes, create tools and grammar rules, run a deterministic cycle, and then inspect the grammar plan, message ledger, execution trace, and state deltas. The graph is a visual map of the persisted model, not a decorative view over an unrelated table.

## Safety and Scope

The first implementation supports deterministic in-process profiles only. It excludes arbitrary code execution, remote tool connectors, background daemons, self-modification, financial actions, and LLM access. This keeps a run reproducible, inspectable, and compatible with request-scoped application hosting.
