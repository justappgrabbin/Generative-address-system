import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const meshSessions = mysqlTable("mesh_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  sessionSeed: varchar("sessionSeed", { length: 64 }).notNull(),
  defaultInput: text("defaultInput").notNull(),
  status: mysqlEnum("status", ["idle", "running", "complete", "failed"]).default("idle").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("mesh_sessions_status_idx").on(table.status)]);

export const meshNodes = mysqlTable("mesh_nodes", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  label: varchar("label", { length: 120 }).notNull(),
  kind: varchar("kind", { length: 40 }).notNull(),
  capabilities: text("capabilities").notNull(),
  configuration: text("configuration").notNull(),
  nodeState: text("nodeState").notNull(),
  positionX: int("positionX").notNull(),
  positionY: int("positionY").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("mesh_nodes_session_idx").on(table.sessionId)]);

export const meshEdges = mysqlTable("mesh_edges", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  sourceNodeId: varchar("sourceNodeId", { length: 64 }).notNull().references(() => meshNodes.id, { onDelete: "cascade" }),
  targetNodeId: varchar("targetNodeId", { length: 64 }).notNull().references(() => meshNodes.id, { onDelete: "cascade" }),
  label: varchar("label", { length: 120 }).notNull(),
  priority: int("priority").notNull().default(1),
  maxHops: int("maxHops").notNull().default(8),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("mesh_edges_session_idx").on(table.sessionId),
  index("mesh_edges_source_idx").on(table.sourceNodeId),
]);

export const grammarRules = mysqlTable("grammar_rules", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 120 }).notNull(),
  symbol: varchar("symbol", { length: 80 }).notNull(),
  priority: int("priority").notNull().default(1),
  production: text("production").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("grammar_rules_session_symbol_idx").on(table.sessionId, table.symbol)]);

export const toolDefinitions = mysqlTable("tool_definitions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 120 }).notNull(),
  profile: varchar("profile", { length: 40 }).notNull(),
  capabilities: text("capabilities").notNull(),
  configuration: text("configuration").notNull(),
  composition: text("composition").notNull(),
  factoryGenerated: boolean("factoryGenerated").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("tool_definitions_session_idx").on(table.sessionId)]);

export const meshRuns = mysqlTable("mesh_runs", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  runSeed: varchar("runSeed", { length: 64 }).notNull(),
  input: text("input").notNull(),
  status: mysqlEnum("status", ["running", "complete", "failed"]).notNull(),
  summary: text("summary").notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
}, table => [index("mesh_runs_session_idx").on(table.sessionId)]);

export const meshRunEvents = mysqlTable("mesh_run_events", {
  id: varchar("id", { length: 64 }).primaryKey(),
  runId: varchar("runId", { length: 64 }).notNull().references(() => meshRuns.id, { onDelete: "cascade" }),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => meshSessions.id, { onDelete: "cascade" }),
  sequence: int("sequence").notNull(),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  nodeId: varchar("nodeId", { length: 64 }),
  messageId: varchar("messageId", { length: 64 }),
  payload: text("payload").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [
  index("mesh_run_events_run_sequence_idx").on(table.runId, table.sequence),
  index("mesh_run_events_session_idx").on(table.sessionId),
]);

export type MeshSession = typeof meshSessions.$inferSelect;
export type MeshNode = typeof meshNodes.$inferSelect;
export type MeshEdge = typeof meshEdges.$inferSelect;
export type GrammarRule = typeof grammarRules.$inferSelect;
export type ToolDefinition = typeof toolDefinitions.$inferSelect;
export type MeshRun = typeof meshRuns.$inferSelect;
export type MeshRunEvent = typeof meshRunEvents.$inferSelect;
