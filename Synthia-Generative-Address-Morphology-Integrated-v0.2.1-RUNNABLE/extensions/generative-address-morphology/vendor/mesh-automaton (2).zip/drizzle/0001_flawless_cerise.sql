CREATE TABLE `grammar_rules` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`symbol` varchar(80) NOT NULL,
	`priority` int NOT NULL DEFAULT 1,
	`production` text NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `grammar_rules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mesh_edges` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`sourceNodeId` varchar(64) NOT NULL,
	`targetNodeId` varchar(64) NOT NULL,
	`label` varchar(120) NOT NULL,
	`priority` int NOT NULL DEFAULT 1,
	`maxHops` int NOT NULL DEFAULT 8,
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mesh_edges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mesh_nodes` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`label` varchar(120) NOT NULL,
	`kind` varchar(40) NOT NULL,
	`capabilities` text NOT NULL,
	`configuration` text NOT NULL,
	`nodeState` text NOT NULL,
	`positionX` int NOT NULL,
	`positionY` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mesh_nodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mesh_run_events` (
	`id` varchar(64) NOT NULL,
	`runId` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`sequence` int NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`nodeId` varchar(64),
	`messageId` varchar(64),
	`payload` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mesh_run_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mesh_runs` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`runSeed` varchar(64) NOT NULL,
	`input` text NOT NULL,
	`status` enum('running','complete','failed') NOT NULL,
	`summary` text NOT NULL,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `mesh_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mesh_sessions` (
	`id` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`description` text NOT NULL,
	`sessionSeed` varchar(64) NOT NULL,
	`defaultInput` text NOT NULL,
	`status` enum('idle','running','complete','failed') NOT NULL DEFAULT 'idle',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mesh_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tool_definitions` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`profile` varchar(40) NOT NULL,
	`capabilities` text NOT NULL,
	`configuration` text NOT NULL,
	`composition` text NOT NULL,
	`factoryGenerated` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tool_definitions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `grammar_rules` ADD CONSTRAINT `grammar_rules_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_edges` ADD CONSTRAINT `mesh_edges_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_edges` ADD CONSTRAINT `mesh_edges_sourceNodeId_mesh_nodes_id_fk` FOREIGN KEY (`sourceNodeId`) REFERENCES `mesh_nodes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_edges` ADD CONSTRAINT `mesh_edges_targetNodeId_mesh_nodes_id_fk` FOREIGN KEY (`targetNodeId`) REFERENCES `mesh_nodes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_nodes` ADD CONSTRAINT `mesh_nodes_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_run_events` ADD CONSTRAINT `mesh_run_events_runId_mesh_runs_id_fk` FOREIGN KEY (`runId`) REFERENCES `mesh_runs`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_run_events` ADD CONSTRAINT `mesh_run_events_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mesh_runs` ADD CONSTRAINT `mesh_runs_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `tool_definitions` ADD CONSTRAINT `tool_definitions_sessionId_mesh_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `mesh_sessions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `grammar_rules_session_symbol_idx` ON `grammar_rules` (`sessionId`,`symbol`);--> statement-breakpoint
CREATE INDEX `mesh_edges_session_idx` ON `mesh_edges` (`sessionId`);--> statement-breakpoint
CREATE INDEX `mesh_edges_source_idx` ON `mesh_edges` (`sourceNodeId`);--> statement-breakpoint
CREATE INDEX `mesh_nodes_session_idx` ON `mesh_nodes` (`sessionId`);--> statement-breakpoint
CREATE INDEX `mesh_run_events_run_sequence_idx` ON `mesh_run_events` (`runId`,`sequence`);--> statement-breakpoint
CREATE INDEX `mesh_run_events_session_idx` ON `mesh_run_events` (`sessionId`);--> statement-breakpoint
CREATE INDEX `mesh_runs_session_idx` ON `mesh_runs` (`sessionId`);--> statement-breakpoint
CREATE INDEX `mesh_sessions_status_idx` ON `mesh_sessions` (`status`);--> statement-breakpoint
CREATE INDEX `tool_definitions_session_idx` ON `tool_definitions` (`sessionId`);