# Neural Foundry

Neural Foundry is a construction language for neural computation. It treats a network as a typed graph of four orthogonal operators rather than as a catalog of named architectures.

## Mathematical vocabulary

Let a state be a finite tensor \(x \in \mathbb{R}^d\), and let \(t\) be a discrete execution step.

### Transformation

\[
T(x) = \phi(Wx + b)
\]

`W`, `b`, and the activation \(\phi\) are configurable and trainable. This operator changes representation without owning time or relationships.

### Memory

\[
m_{t+1} = U(m_t, x_t; \theta), \qquad y_t = R(m_{t+1})
\]

`U` may replace, exponentially integrate, accumulate, or gate state. The runtime retains `m` between forward calls.

### Relation

\[
r(q, C) = \phi(W_q q + \sum_i \alpha_i W_c c_i), \qquad
\alpha = \operatorname{softmax}(s(q, C) / \tau)
\]

The relation determines interaction and routing. Local neighborhoods, attention contexts, graph edges, and comparisons are connection/configuration choices, not separate primitive kinds.

### Generation / Selection

\[
p(y \mid x) = \operatorname{softmax}(g_\theta(x)/\tau)
\]

The operator produces scored candidates and a selected next state. Sampling, decoding, energy minimization, and policy selection are interchangeable selection rules.

## Why the four are composable

The operators separate four different questions:

1. **What representation changes?** Transformation.
2. **What persists?** Memory.
3. **What interacts?** Relation.
4. **What comes next?** Generation / Selection.

The separation is useful because common architectures differ mostly in wiring, dimensionality, local-vs-global relation, and update/loss rules. The primitives can therefore repeat, branch, merge, or form cycles. A node is never required to know whether it is participating in a CNN, an RNN, or a future architecture.

## Network Genome

```ts
{
  version: 1,
  id: string,
  name: string,
  seed: number,
  nodes: [{
    id: string,
    primitive: "transformation" | "memory" | "relation" | "generation",
    label: string,
    config: { inputSize, outputSize, activation?, update?, temperature?, neighborhood?, classes? },
    position?: { x, y }
  }],
  connections: [{
    id: string,
    from: string,
    fromPort: string,
    to: string,
    toPort: string,
    transform?: "identity" | "project" | "sum" | "concat"
  }],
  state: Record<string, number[]>,
  learning: { name: "sgd" | "hebbian" | "reinforce" | "none", learningRate, loss? },
  metadata?: { species?, tags?, description? }
}
```

## Type and execution rules

- A connection must reference existing node IDs and ports.
- Tensor ports carry vector values; a direct connection should preserve dimensions.
- `project` is an explicit dimension adapter; `sum` merges compatible streams.
- Required ports must have an incoming connection, or the node is treated as an input node.
- Cycles are allowed and are interpreted through persistent runtime state.
- A genome is executable if it has at least one node and no missing nodes, ports, or invalid dimensions.
- A generator is not mandatory for execution, but validation warns when no explicit next-state output exists.

## Species and examples

The built-in templates are deliberately compositions: layered mappings, neighborhood relation, stateful loop, context selector, message graph, latent bridge, attractor field, cell field, and predictive simulator. They are examples of wiring, not special runtime classes.