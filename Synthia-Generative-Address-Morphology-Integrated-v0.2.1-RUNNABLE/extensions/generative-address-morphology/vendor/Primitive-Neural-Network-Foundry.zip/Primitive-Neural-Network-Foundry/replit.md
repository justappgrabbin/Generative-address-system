# Neural Foundry

Neural Foundry is a local-first construction language and workbench for composing, training, evaluating, and evolving neural networks from four orthogonal primitives.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/neural-foundry/src/index.ts` — primitive contracts, runtime implementations, genome validation, execution, training, optimizers, checkpoints, species, and evolution.
- `docs/neural-foundry.md` — mathematical definitions, composition rules, and the Network Genome schema.
- `artifacts/neural-foundry/src/App.tsx` — the interactive workbench, composition atlas, primitive contract browser, genome editor, and training lab.
- `artifacts/neural-foundry/src/index.css` — the Foundry visual system and responsive instrument shell.

## Architecture decisions

- The four primitives are capability-level operators: Transformation, Memory, Relation, and Generation / Selection; named architectures are only compositions.
- The Network Genome is backend-neutral JSON and carries graph structure, configuration, learning rules, seed, and serializable state.
- The reference trainer uses deterministic finite-difference gradients so every structurally valid generated graph has a correct trainable path; local, Hebbian, reinforcement, and competitive mechanisms remain pluggable.
- Checkpoints contain both learned parameters and persistent module state, allowing continuation without rebuilding the architecture.

## Product

- Compose and inspect typed neural primitives in a live genome.
- Load and compare reconstructed MLP, CNN, RNN/LSTM, Transformer, GNN, VAE/VQ-VAE, Hopfield, neural cellular automata, and world-model species.
- Train generated networks with batching, splits, metrics, early stopping, clipping, optimizers, freezing, per-module rates, online learning, and checkpoint resume.
- Mutate or cross genomes, retrain offspring, compare parent and child fitness, and retain or discard the result locally.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
