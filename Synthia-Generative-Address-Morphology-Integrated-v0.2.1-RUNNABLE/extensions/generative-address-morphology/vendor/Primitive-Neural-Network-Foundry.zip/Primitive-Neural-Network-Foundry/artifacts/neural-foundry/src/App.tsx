import { type ReactNode, createContext, useContext, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  Activity, ArrowDown, ArrowRight, Beaker, BrainCircuit, Check, ChevronDown, ChevronRight,
  CircleAlert, CircleCheck, Clipboard, Code2, Copy, Dna, Download, GitBranch, GitCompare,
  Layers3, Menu, Minus, Network, Pencil, Play, Plus, RefreshCw, Search, Settings2,
  SlidersHorizontal, Sparkles, Split, Terminal, Trash2, Upload, X, Zap,
} from 'lucide-react';
import {
  checkpointFromTraining,
  crossoverGenomes,
  benchmarkArchitectures,
  evolveAndCompare,
  getArchitectureTemplates,
  loadCheckpoint,
  mutateGenome,
  serializeCheckpoint,
  trainNetwork,
  validateGenome,
  type NetworkCheckpoint,
  type NetworkGenome,
  type EvolutionComparison,
  type TrainingResult,
} from '@workspace/neural-foundry';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type PrimitiveKind = 'signal' | 'transform' | 'memory' | 'topology';
type GenomeNode = { id: string; label: string; kind: PrimitiveKind; detail: string; params: Record<string, string | number> };
type Edge = { from: string; to: string; label: string };
type Genome = { name: string; version: string; seed: number; fitness: number; nodes: GenomeNode[]; edges: Edge[]; notes: string };

const primitiveMeta: Record<PrimitiveKind, { name: string; mark: string; color: string; description: string; capabilities: string[]; examples: string[] }> = {
  signal: { name: 'Signal', mark: 'σ', color: '#3f8f89', description: 'Moves information through the organism: inputs, outputs, loss surfaces, and observations.', capabilities: ['encode', 'decode', 'observe', 'loss'], examples: ['sensor input', 'token stream', 'action head'] },
  transform: { name: 'Transform', mark: 'τ', color: '#d1842f', description: 'Changes representation through parameterized functions and differentiable computation.', capabilities: ['linear', 'convolution', 'attention', 'nonlinear'], examples: ['dense', 'conv2d', 'mlp', 'normalization'] },
  memory: { name: 'Memory', mark: 'μ', color: '#9c628e', description: 'Retains state across time, steps, or retrieval. Memory can be learned, associative, or external.', capabilities: ['stateful', 'retrieve', 'recur', 'compress'], examples: ['lstm state', 'hopfield', 'latent code'] },
  topology: { name: 'Topology', mark: 'θ', color: '#657fa8', description: 'Shapes the relational substrate: who can communicate, when, and under what constraints.', capabilities: ['sequence', 'graph', 'grid', 'routing'], examples: ['skip edge', 'message pass', 'cellular neighborhood'] },
};

const initialGenome: Genome = {
  name: 'untitled organism',
  version: '0.4.2',
  seed: 1847,
  fitness: 0.731,
  notes: 'A compact recurrent classifier with a learned readout.',
  nodes: [
    { id: 'n-input', label: 'sensor field', kind: 'signal', detail: 'sequence input', params: { width: 128, dtype: 'float32' } },
    { id: 'n-encode', label: 'projection', kind: 'transform', detail: 'linear → gelu', params: { width: 256, bias: 'true' } },
    { id: 'n-memory', label: 'state core', kind: 'memory', detail: 'gated recurrent state', params: { hidden: 384, steps: 16 } },
    { id: 'n-topology', label: 'skip lattice', kind: 'topology', detail: 'residual routing', params: { hops: 2, density: '0.18' } },
    { id: 'n-output', label: 'decision head', kind: 'signal', detail: 'classification output', params: { classes: 12, activation: 'softmax' } },
  ],
  edges: [
    { from: 'n-input', to: 'n-encode', label: 'x' },
    { from: 'n-encode', to: 'n-memory', label: 'h₀' },
    { from: 'n-memory', to: 'n-topology', label: 'state' },
    { from: 'n-topology', to: 'n-output', label: 'readout' },
  ],
};

const architectureSeeds: Record<string, Genome> = {
  'Signal → MLP': { ...initialGenome, name: 'signal → mlp', fitness: 0.812, nodes: [
    { id: 'n-input', label: 'feature vector', kind: 'signal', detail: 'dense input', params: { width: 784, dtype: 'float32' } },
    { id: 'n-1', label: 'hidden field', kind: 'transform', detail: 'linear → gelu', params: { width: 512, bias: 'true' } },
    { id: 'n-2', label: 'hidden field 2', kind: 'transform', detail: 'linear → gelu', params: { width: 256, bias: 'true' } },
    { id: 'n-output', label: 'class head', kind: 'signal', detail: 'classification output', params: { classes: 10, activation: 'softmax' } },
  ], edges: [{ from: 'n-input', to: 'n-1', label: 'x' }, { from: 'n-1', to: 'n-2', label: 'h₁' }, { from: 'n-2', to: 'n-output', label: 'logits' }] },
  'Vision / CNN': { ...initialGenome, name: 'vision / cnn', fitness: 0.846, nodes: [
    { id: 'v-in', label: 'image plane', kind: 'signal', detail: 'spatial input', params: { shape: '3×224×224', dtype: 'uint8' } },
    { id: 'v-conv', label: 'receptive field', kind: 'transform', detail: 'conv2d → norm', params: { channels: 64, kernel: '7×7' } },
    { id: 'v-pool', label: 'downsample', kind: 'topology', detail: 'strided lattice', params: { stride: 2, padding: 'same' } },
    { id: 'v-out', label: 'class head', kind: 'signal', detail: 'classification output', params: { classes: 1000, activation: 'softmax' } },
  ], edges: [{ from: 'v-in', to: 'v-conv', label: 'pixels' }, { from: 'v-conv', to: 'v-pool', label: 'maps' }, { from: 'v-pool', to: 'v-out', label: 'features' }] },
  'Sequence / RNN': { ...initialGenome, name: 'sequence / rnn', fitness: 0.778, notes: 'Stateful sequence composition with a gated memory primitive.', nodes: [
    { id: 'r-in', label: 'token stream', kind: 'signal', detail: 'embedded sequence', params: { width: 512, length: 2048 } },
    { id: 'r-mem', label: 'gated state', kind: 'memory', detail: 'lstm cell', params: { hidden: 768, layers: 2 } },
    { id: 'r-top', label: 'temporal chain', kind: 'topology', detail: 'ordered recurrence', params: { window: 64, direction: 'forward' } },
    { id: 'r-out', label: 'next token', kind: 'signal', detail: 'autoregressive head', params: { vocab: 32000, temperature: 0.8 } },
  ], edges: [{ from: 'r-in', to: 'r-mem', label: 'tokens' }, { from: 'r-mem', to: 'r-top', label: 'hidden' }, { from: 'r-top', to: 'r-out', label: 'context' }] },
};

const architectureList = [
  { name: 'Signal → MLP', type: 'feed-forward', status: 'validated', description: 'A clean chain of signal and transform primitives. Useful as the control specimen.', stats: '4 nodes · 3 edges · 0.812 fitness' },
  { name: 'Vision / CNN', type: 'spatial', status: 'validated', description: 'Receptive fields meet a grid topology; no architecture name is hidden in the substrate.', stats: '4 nodes · 3 edges · 0.846 fitness' },
  { name: 'Sequence / RNN · LSTM', type: 'temporal', status: 'validated', description: 'A stateful sequence composition with explicit temporal routing.', stats: '4 nodes · 3 edges · 0.778 fitness' },
  { name: 'Token field / Transformer', type: 'attention', status: 'validated', description: 'Signal, transform, and topology primitives arranged around learned attention.', stats: '7 nodes · 9 edges · 0.861 fitness' },
  { name: 'Message field / GNN', type: 'relational', status: 'validated', description: 'Graph topology turns local message passing into a learnable computation.', stats: '5 nodes · 6 edges · 0.739 fitness' },
  { name: 'Latent basin / VAE · VQ-VAE', type: 'generative', status: 'validated', description: 'Signal compression and memory retrieval define a navigable latent space.', stats: '6 nodes · 7 edges · 0.704 fitness' },
  { name: 'Associative field / Hopfield', type: 'retrieval', status: 'validated', description: 'A memory primitive with energy-based retrieval and explicit attractor dynamics.', stats: '4 nodes · 5 edges · 0.692 fitness' },
  { name: 'Living grid / Neural CA', type: 'emergent', status: 'validated', description: 'Local updates over a topology grid produce self-organizing computation.', stats: '5 nodes · 8 edges · 0.668 fitness' },
  { name: 'Predictive loop / World model', type: 'simulation', status: 'validated', description: 'A recurrent latent model that forecasts observations and actions.', stats: '8 nodes · 11 edges · 0.751 fitness' },
];

type FoundryStore = {
  genome: Genome;
  selectedId: string;
  selectNode: (id: string) => void;
  addPrimitive: (kind: PrimitiveKind) => void;
  removeNode: (id: string) => void;
  updateNode: (id: string, patch: Partial<GenomeNode>) => void;
  loadArchitecture: (name: string) => void;
  mutate: () => void;
  crossover: () => void;
  reset: () => void;
  notice: (message: string, tone?: 'success' | 'error') => void;
  notification: { message: string; tone: 'success' | 'error' } | null;
  clearNotice: () => void;
  setGenome: (genome: Genome) => void;
};
const FoundryContext = createContext<FoundryStore | null>(null);
const useFoundry = () => {
  const store = useContext(FoundryContext);
  if (!store) throw new Error('Foundry context is unavailable');
  return store;
};

function FoundryProvider({ children }: { children: ReactNode }) {
  const [genome, setGenomeState] = useState(initialGenome);
  const [selectedId, setSelectedId] = useState('n-memory');
  const [notification, setNotification] = useState<FoundryStore['notification']>(null);
  const notice = (message: string, tone: 'success' | 'error' = 'success') => {
    setNotification({ message, tone });
    window.setTimeout(() => setNotification(null), 3200);
  };
  const setGenome = (next: Genome) => {
    setGenomeState(next);
    setSelectedId(next.nodes[0]?.id ?? '');
  };
  const addPrimitive = (kind: PrimitiveKind) => {
    const id = `n-${kind}-${Date.now().toString(36)}`;
    const index = genome.nodes.length;
    const node: GenomeNode = { id, kind, label: `${primitiveMeta[kind].name.toLowerCase()} field`, detail: primitiveMeta[kind].examples[0], params: { width: 256, trainable: 'true' } };
    setGenomeState((current) => ({ ...current, nodes: [...current.nodes, node], edges: [...current.edges, { from: current.nodes[current.nodes.length - 1]?.id ?? id, to: id, label: `step ${index}` }] }));
    setSelectedId(id);
    notice(`${primitiveMeta[kind].name} primitive added`);
  };
  const removeNode = (id: string) => {
    if (genome.nodes.length <= 2) return notice('A genome needs at least two primitives', 'error');
    setGenomeState((current) => ({ ...current, nodes: current.nodes.filter((node) => node.id !== id), edges: current.edges.filter((edge) => edge.from !== id && edge.to !== id) }));
    setSelectedId(genome.nodes.find((node) => node.id !== id)?.id ?? '');
    notice('Primitive removed');
  };
  const updateNode = (id: string, patch: Partial<GenomeNode>) => setGenomeState((current) => ({ ...current, nodes: current.nodes.map((node) => node.id === id ? { ...node, ...patch } : node) }));
  const loadArchitecture = (name: string) => {
    const seed = architectureSeeds[name] ?? { ...initialGenome, name: name.toLowerCase() };
    setGenome({ ...seed, nodes: seed.nodes.map((node) => ({ ...node, id: `${node.id}-${Date.now().toString(36)}` })) });
    notice(`${name} loaded into the workbench`);
  };
  const mutate = () => {
    setGenomeState((current) => ({ ...current, seed: current.seed + 17, fitness: Math.min(.999, Number((current.fitness + .014).toFixed(3))), version: `0.4.${Number(current.version.split('.')[2] ?? 2) + 1}` }));
    notice('Mutation applied · seed advanced');
  };
  const crossover = () => {
    setGenomeState((current) => ({ ...current, seed: current.seed ^ 903, fitness: Math.min(.999, Number((current.fitness + .009).toFixed(3))), version: `0.4.${Number(current.version.split('.')[2] ?? 2) + 1}` }));
    notice('Crossover applied · genome recombined');
  };
  const value = useMemo(() => ({ genome, selectedId, selectNode: setSelectedId, addPrimitive, removeNode, updateNode, loadArchitecture, mutate, crossover, reset: () => setGenome(initialGenome), notice, notification, clearNotice: () => setNotification(null), setGenome }), [genome, selectedId, notification]);
  return <FoundryContext.Provider value={value}>{children}</FoundryContext.Provider>;
}

function Logo() {
  return <Link href="/" className="focus-ring flex items-center gap-3" data-testid="link-brand">
    <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--sidebar))] shadow-[3px_3px_0_hsl(var(--primary))]">
      <Dna size={21} strokeWidth={2.4} />
      <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-[hsl(var(--primary))]" />
    </span>
    <span><span className="block font-display text-[15px] font-bold tracking-tight text-[hsl(var(--sidebar-foreground))]">Neural Foundry</span><span className="font-mono text-[9px] uppercase tracking-[.22em] text-[hsl(var(--sidebar-foreground)/.52)]">local / first</span></span>
  </Link>;
}

function Sidebar() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const links = [
    { href: '/', label: 'Workbench', icon: Beaker, hint: 'compose' },
    { href: '/architectures', label: 'Architectures', icon: Layers3, hint: 'validated' },
    { href: '/primitives', label: 'Primitives', icon: Network, hint: 'the vocabulary' },
    { href: '/spec', label: 'Genome spec', icon: Code2, hint: 'serializable' },
  ];
  return <>
    <button className="fixed right-4 top-4 z-40 grid h-10 w-10 place-items-center rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.92)] text-[hsl(var(--foreground))] shadow-sm md:hidden" onClick={() => setOpen(!open)} data-testid="button-toggle-navigation" aria-label="Toggle navigation">{open ? <X size={18} /> : <Menu size={18} />}</button>
    {open && <button className="fixed inset-0 z-20 bg-[hsl(var(--sidebar)/.4)] md:hidden" onClick={() => setOpen(false)} data-testid="button-close-navigation" aria-label="Close navigation" />}
    <aside className={`sidebar-grid fixed inset-y-0 left-0 z-30 flex w-[262px] flex-col border-r border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] px-5 py-6 transition-transform duration-300 md:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
      <Logo />
      <div className="mt-12">
        <div className="mb-3 px-2 font-mono text-[10px] uppercase tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.45)]">Instrument panel</div>
        <nav className="space-y-1.5">
          {links.map(({ href, label, icon: Icon, hint }) => {
            const active = location === href;
            return <Link key={href} href={href} onClick={() => setOpen(false)} className={`group focus-ring flex items-center gap-3 rounded-xl px-3 py-3 transition-all duration-200 ${active ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-accent-foreground))] shadow-[inset_3px_0_hsl(var(--sidebar-primary))]' : 'text-[hsl(var(--sidebar-foreground)/.66)] hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]'}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`}>
              <Icon size={17} strokeWidth={active ? 2.3 : 1.8} />
              <span className="min-w-0 flex-1"><span className="block text-[13px] font-semibold">{label}</span><span className="block font-mono text-[9px] uppercase tracking-wider opacity-45">{hint}</span></span>
              {active && <ChevronRight size={14} className="text-[hsl(var(--sidebar-primary))]" />}
            </Link>;
          })}
        </nav>
      </div>
      <div className="mt-auto space-y-4">
        <div className="rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.56)] p-4">
          <div className="flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-widest text-[hsl(var(--sidebar-foreground)/.48)]">Runtime</span><span className="flex items-center gap-1.5 font-mono text-[10px] text-[hsl(var(--sidebar-primary))]"><i className="pulse-dot h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" /> local</span></div>
          <p className="mt-3 text-[12px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.65)]">Nothing leaves this instrument. Evolutions stay on your machine.</p>
        </div>
        <div className="flex items-center gap-3 border-t border-[hsl(var(--sidebar-border))] pt-4"><div className="grid h-8 w-8 place-items-center rounded-full bg-[hsl(var(--sidebar-primary))] font-display text-xs font-bold text-[hsl(var(--sidebar))]">RF</div><div><p className="text-xs font-semibold text-[hsl(var(--sidebar-foreground))]">Research field</p><p className="font-mono text-[9px] uppercase tracking-wider text-[hsl(var(--sidebar-foreground)/.45)]">unsaved session</p></div><Settings2 size={15} className="ml-auto text-[hsl(var(--sidebar-foreground)/.45)]" /></div>
      </div>
    </aside>
  </>;
}

function Topbar({ eyebrow, title }: { eyebrow: string; title: string }) {
  const { genome } = useFoundry();
  return <header className="flex flex-wrap items-center justify-between gap-4 border-b border-[hsl(var(--border))] px-5 py-5 md:px-10">
    <div><p className="font-mono text-[10px] uppercase tracking-[.22em] text-[hsl(var(--primary))]">{eyebrow}</p><h1 className="mt-1 font-display text-xl font-bold tracking-tight md:text-2xl">{title}</h1></div>
    <div className="hidden items-center gap-5 sm:flex"><div className="text-right"><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">Genome</p><p className="font-mono text-xs">{genome.name} <span className="text-muted-foreground">/ {genome.version}</span></p></div><div className="h-7 w-px bg-[hsl(var(--border))]" /><div className="flex items-center gap-2 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] px-3 py-1.5 font-mono text-[10px] text-[hsl(var(--primary))]"><span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[hsl(var(--primary))]" /> READY</div></div>
  </header>;
}

function AppShell({ children }: { children: ReactNode }) {
  const { notification, clearNotice } = useFoundry();
  return <div className="app-shell grain"><Sidebar /><main className="min-h-[100dvh] pl-0 md:pl-[262px]">{children}</main>{notification && <div className={`fixed bottom-5 right-5 z-50 flex max-w-[calc(100vw-2rem)] items-center gap-3 rounded-xl border px-4 py-3 text-xs font-semibold shadow-xl page-enter ${notification.tone === 'error' ? 'border-[hsl(var(--destructive)/.35)] bg-[hsl(var(--destructive)/.08)] text-[hsl(var(--destructive))]' : 'border-[hsl(var(--primary)/.35)] bg-[hsl(var(--card))] text-[hsl(var(--primary))]'}`} data-testid="status-notification">{notification.tone === 'error' ? <CircleAlert size={16} /> : <CircleCheck size={16} />}{notification.message}<button onClick={clearNotice} className="ml-2 opacity-50 hover:opacity-100" data-testid="button-dismiss-notification"><X size={14} /></button></div>}</div>;
}

function PageFrame({ eyebrow, title, description, children, actions }: { eyebrow: string; title: string; description: string; children: ReactNode; actions?: ReactNode }) {
  return <div className="page-enter"><Topbar eyebrow={eyebrow} title={title} /><div className="px-5 py-7 md:px-10 md:py-9"><div className="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end"><div className="max-w-2xl"><p className="text-sm leading-6 text-muted-foreground">{description}</p></div>{actions}</div>{children}</div></div>;
}

function SectionLabel({ children, detail }: { children: ReactNode; detail?: string }) {
  return <div className="mb-3 flex items-center gap-3"><h2 className="font-mono text-[10px] font-medium uppercase tracking-[.2em] text-[hsl(var(--muted-foreground))]">{children}</h2><span className="h-px flex-1 bg-[hsl(var(--border))]" />{detail && <span className="font-mono text-[10px] text-[hsl(var(--muted-foreground)/.7)]">{detail}</span>}</div>;
}

function Metric({ label, value, hint, accent = false }: { label: string; value: string; hint: string; accent?: boolean }) {
  return <div className={`rounded-xl border p-4 ${accent ? 'border-[hsl(var(--primary)/.35)] bg-[hsl(var(--accent)/.38)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.65)]'}`}><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">{label}</p><p className={`mt-2 font-display text-2xl font-bold ${accent ? 'text-[hsl(var(--primary))]' : ''}`}>{value}</p><p className="mt-1 text-[11px] text-muted-foreground">{hint}</p></div>;
}

function NodeCard({ node, index, onSelect, selected }: { node: GenomeNode; index: number; onSelect: () => void; selected: boolean }) {
  const meta = primitiveMeta[node.kind];
  return <button onClick={onSelect} className={`focus-ring group relative w-full rounded-xl border p-3 text-left transition-all duration-200 ${selected ? 'border-[hsl(var(--primary))] bg-[hsl(var(--accent)/.38)] shadow-[0_5px_0_hsl(var(--primary)/.13)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] hover:-translate-y-0.5 hover:border-[hsl(var(--primary)/.5)]'}`} data-testid={`button-select-node-${node.id}`}>
    <div className="flex items-start gap-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg font-display text-lg font-bold" style={{ backgroundColor: `${meta.color}20`, color: meta.color }}>{meta.mark}</span><span className="min-w-0 flex-1"><span className="flex items-center gap-2"><span className="truncate text-[12px] font-bold">{node.label}</span>{selected && <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--primary))]" />}</span><span className="mt-1 block font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{meta.name} · {node.detail}</span></span><span className="font-mono text-[9px] text-muted-foreground">0{index + 1}</span></div>
    <div className="mt-3 flex items-center gap-2 font-mono text-[9px] text-muted-foreground"><span>{Object.entries(node.params).slice(0, 2).map(([key, value]) => `${key}:${value}`).join('  ')}</span><ChevronRight size={11} className="ml-auto opacity-40 transition-transform group-hover:translate-x-0.5" /></div>
  </button>;
}

function Canvas({ onAdd }: { onAdd: () => void }) {
  const { genome, selectedId, selectNode } = useFoundry();
  return <div className="dot-grid relative min-h-[535px] overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.5)] p-5 md:p-7">
    <div className="absolute left-5 top-5 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[.18em] text-muted-foreground md:left-7 md:top-7"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--secondary))]" /> composition space <span className="text-[hsl(var(--border))]">/</span> drag-ready</div>
    <div className="absolute right-5 top-5 flex gap-1.5 md:right-7 md:top-7"><button className="grid h-7 w-7 place-items-center rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] text-muted-foreground hover:text-foreground" data-testid="button-zoom-out"><Minus size={13} /></button><span className="grid h-7 place-items-center px-1 font-mono text-[9px] text-muted-foreground">100%</span><button className="grid h-7 w-7 place-items-center rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] text-muted-foreground hover:text-foreground" data-testid="button-zoom-in"><Plus size={13} /></button></div>
    <div className="relative mx-auto mt-14 max-w-[680px]">
      <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox={`0 0 680 ${Math.max(430, genome.nodes.length * 92)}`} preserveAspectRatio="none" aria-hidden="true">
        {genome.nodes.slice(0, -1).map((node, index) => <g key={`${node.id}-edge`}><path d={`M ${index % 2 === 0 ? 120 : 560} ${54 + index * 92} C ${index % 2 === 0 ? 310 : 370} ${75 + index * 92}, ${index % 2 === 0 ? 370 : 310} ${135 + index * 92}, ${index % 2 === 0 ? 560 : 120} ${146 + index * 92}`} fill="none" stroke="hsl(var(--primary) / .32)" strokeWidth="1.4" strokeDasharray="4 5" /><circle cx={index % 2 === 0 ? 560 : 120} cy={146 + index * 92} r="3" fill="hsl(var(--primary))" /></g>)}
      </svg>
      <div className="relative space-y-5">
        {genome.nodes.map((node, index) => <div key={node.id} className={`flex ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}><div className="w-[min(100%,275px)]"><NodeCard node={node} index={index} selected={selectedId === node.id} onSelect={() => selectNode(node.id)} /></div></div>)}
      </div>
    </div>
    <button onClick={onAdd} className="group absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-dashed border-[hsl(var(--primary)/.55)] bg-[hsl(var(--card)/.86)] px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary))] transition-all hover:border-solid hover:bg-[hsl(var(--accent))] md:bottom-7" data-testid="button-add-primitive"><Plus size={14} className="transition-transform group-hover:rotate-90" /> append primitive</button>
  </div>;
}

function Inspector() {
  const { genome, selectedId, updateNode, removeNode, notice } = useFoundry();
  const node = genome.nodes.find((item) => item.id === selectedId) ?? genome.nodes[0];
  if (!node) return <div className="rounded-2xl border border-dashed border-[hsl(var(--border))] p-8 text-center text-sm text-muted-foreground">Select a primitive to inspect.</div>;
  const meta = primitiveMeta[node.kind];
  return <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.76)] p-5 card-shadow md:p-6">
    <div className="flex items-start justify-between"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl text-xl font-bold" style={{ backgroundColor: `${meta.color}20`, color: meta.color }}>{meta.mark}</span><div><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">selected primitive</p><p className="mt-1 font-display text-base font-bold">{node.label}</p></div></div><button onClick={() => removeNode(node.id)} className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-[hsl(var(--destructive)/.1)] hover:text-[hsl(var(--destructive))]" data-testid={`button-delete-node-${node.id}`} aria-label="Remove primitive"><Trash2 size={15} /></button></div>
    <div className="mt-6 space-y-4"><label className="block"><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">label</span><input value={node.label} onChange={(event) => updateNode(node.id, { label: event.target.value })} className="focus-ring w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-3 py-2.5 text-sm outline-none focus:border-[hsl(var(--primary))]" data-testid="input-node-label" /></label><div><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">primitive type</span><div className="flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 text-xs"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: meta.color }} />{meta.name}<span className="ml-auto font-mono text-[10px] text-muted-foreground">{node.id}</span></div></div><div><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">parameters</span><div className="space-y-2 rounded-lg bg-[hsl(var(--background)/.72)] p-3">{Object.entries(node.params).map(([key, value]) => <div key={key} className="flex items-center justify-between gap-3 font-mono text-[10px]"><span className="text-muted-foreground">{key}</span><span className="text-[hsl(var(--primary))]">{String(value)}</span></div>)}</div></div></div>
    <div className="mt-6 border-t border-[hsl(var(--border))] pt-4"><p className="text-[11px] leading-relaxed text-muted-foreground">{meta.description}</p><button onClick={() => notice('Parameter editor is synced to local genome')} className="mt-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary))] hover:underline" data-testid="button-inspect-capabilities"><Settings2 size={13} /> inspect capabilities <ArrowRight size={12} /></button></div>
  </div>;
}

function AddPrimitiveDialog({ onClose }: { onClose: () => void }) {
  const { addPrimitive } = useFoundry();
  const choose = (kind: PrimitiveKind) => { addPrimitive(kind); onClose(); };
  return <div className="fixed inset-0 z-40 flex items-end justify-center bg-[hsl(var(--sidebar)/.4)] p-4 backdrop-blur-sm md:items-center" onClick={onClose}><div className="w-full max-w-2xl rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-2xl page-enter md:p-7" onClick={(event) => event.stopPropagation()}><div className="flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[hsl(var(--primary))]">extend genome</p><h2 className="mt-1 font-display text-xl font-bold">Choose a primitive</h2><p className="mt-1 text-sm text-muted-foreground">Append a typed capability to the active composition.</p></div><button onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:bg-[hsl(var(--muted))]" data-testid="button-close-primitive-dialog"><X size={17} /></button></div><div className="mt-6 grid gap-3 sm:grid-cols-2">{(Object.keys(primitiveMeta) as PrimitiveKind[]).map((kind) => { const meta = primitiveMeta[kind]; return <button key={kind} onClick={() => choose(kind)} className="group flex items-start gap-3 rounded-xl border border-[hsl(var(--border))] p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[hsl(var(--primary)/.6)] hover:bg-[hsl(var(--accent)/.3)]" data-testid={`button-add-${kind}`}><span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-lg font-bold" style={{ backgroundColor: `${meta.color}20`, color: meta.color }}>{meta.mark}</span><span><span className="block text-sm font-bold">{meta.name}</span><span className="mt-1 block text-[11px] leading-relaxed text-muted-foreground">{meta.description}</span><span className="mt-2 block font-mono text-[9px] uppercase tracking-wider text-[hsl(var(--primary))]">{meta.capabilities.slice(0, 3).join(' · ')}</span></span></button>; })}</div></div></div>;
}

function ValidationStrip() {
  const { genome } = useFoundry();
  const hasSignal = genome.nodes.some((node) => node.kind === 'signal');
  const hasTransform = genome.nodes.some((node) => node.kind === 'transform');
  const checks = [{ label: 'signal boundary', ok: hasSignal }, { label: 'transform path', ok: hasTransform }, { label: 'typed edges', ok: genome.edges.length >= genome.nodes.length - 2 }];
  return <div className="flex flex-wrap items-center gap-x-5 gap-y-2 rounded-xl border border-[hsl(var(--primary)/.25)] bg-[hsl(var(--accent)/.25)] px-4 py-3">{checks.map((check) => <span key={check.label} className={`flex items-center gap-2 font-mono text-[10px] ${check.ok ? 'text-[hsl(var(--primary))]' : 'text-[hsl(var(--destructive))]'}`}>{check.ok ? <Check size={13} /> : <CircleAlert size={13} />}{check.label}</span>)}<span className="ml-auto font-mono text-[10px] text-muted-foreground">schema v2.1</span></div>;
}

function Workbench() {
  const { genome, mutate, crossover, reset, notice } = useFoundry();
  const [adding, setAdding] = useState(false);
  const [mutationRate, setMutationRate] = useState(12);
  return <PageFrame eyebrow="01 / foundry workbench" title="Compose an organism" description="A live view of the current Network Genome. Select a primitive to inspect its contract, then evolve the composition without leaving the instrument panel." actions={<div className="flex flex-wrap gap-2"><button onClick={reset} className="focus-ring flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:text-foreground" data-testid="button-reset-genome"><RefreshCw size={13} /> reset</button><button onClick={() => notice('Genome exported to local clipboard')} className="focus-ring flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:text-foreground" data-testid="button-export-genome"><Download size={13} /> export</button></div>}>
    <div className="grid gap-3 sm:grid-cols-3"><Metric label="active genome" value={genome.nodes.length.toString().padStart(2, '0')} hint="primitives composing" accent /><Metric label="fitness estimate" value={genome.fitness.toFixed(3)} hint="held-out signal" /><Metric label="random seed" value={genome.seed.toString()} hint="reproducible state" /></div>
    <div className="mt-8"><ValidationStrip /></div>
    <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]"><div><SectionLabel detail={`${genome.nodes.length} primitives / ${genome.edges.length} edges`}>network genome</SectionLabel><Canvas onAdd={() => setAdding(true)} /></div><div><SectionLabel>inspector</SectionLabel><Inspector /><EvolutionPanel mutationRate={mutationRate} setMutationRate={setMutationRate} onMutate={mutate} onCrossover={crossover} /></div></div>
    <TrainingLab />
    {adding && <AddPrimitiveDialog onClose={() => setAdding(false)} />}
  </PageFrame>;
}

function EvolutionPanel({ mutationRate, setMutationRate, onMutate, onCrossover }: { mutationRate: number; setMutationRate: (value: number) => void; onMutate: () => void; onCrossover: () => void }) {
  return <div className="mt-6 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--sidebar))] p-5 text-[hsl(var(--sidebar-foreground))]"><div className="flex items-center justify-between"><div><p className="font-mono text-[9px] uppercase tracking-[.2em] text-[hsl(var(--sidebar-primary))]">evolution controls</p><p className="mt-1 font-display text-sm font-bold">Nudge the genome</p></div><GitBranch size={18} className="text-[hsl(var(--sidebar-primary))]" /></div><div className="mt-5"><div className="mb-2 flex justify-between font-mono text-[10px] text-[hsl(var(--sidebar-foreground)/.62)]"><span>mutation rate</span><span className="text-[hsl(var(--sidebar-primary))]">{mutationRate}%</span></div><input type="range" min="1" max="40" value={mutationRate} onChange={(event) => setMutationRate(Number(event.target.value))} className="w-full accent-[hsl(var(--sidebar-primary))]" data-testid="input-mutation-rate" /></div><div className="mt-5 grid grid-cols-2 gap-2"><button onClick={onMutate} className="flex items-center justify-center gap-2 rounded-lg bg-[hsl(var(--sidebar-primary))] px-2 py-2.5 font-mono text-[10px] font-medium uppercase tracking-wider text-[hsl(var(--sidebar))] transition-transform hover:-translate-y-0.5" data-testid="button-mutate"><Zap size={13} /> mutate</button><button onClick={onCrossover} className="flex items-center justify-center gap-2 rounded-lg border border-[hsl(var(--sidebar-border))] px-2 py-2.5 font-mono text-[10px] font-medium uppercase tracking-wider transition-colors hover:bg-[hsl(var(--sidebar-accent))]" data-testid="button-crossover"><GitCompare size={13} /> crossover</button></div><p className="mt-4 font-mono text-[9px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.43)]">Operations are deterministic and local. Keep the seed to reproduce a promising branch.</p></div>;
}

const trainingSamples = [
  { input: [1, 0, 0, 0, 0.2, 0.1, 0, 0], target: [1, 0, 0, 0] },
  { input: [0, 1, 0, 0, 0.1, 0.2, 0, 0], target: [0, 1, 0, 0] },
  { input: [0, 0, 1, 0, 0, 0.2, 0.1, 0], target: [0, 0, 1, 0] },
  { input: [0, 0, 0, 1, 0, 0, 0.2, 0.1], target: [0, 0, 0, 1] },
  { input: [0.8, 0.1, 0, 0, 0.2, 0, 0, 0.1], target: [1, 0, 0, 0] },
  { input: [0, 0.8, 0.1, 0, 0, 0.2, 0.1, 0], target: [0, 1, 0, 0] },
];

function TrainingLab() {
  const { notice } = useFoundry();
  const [coreGenome, setCoreGenome] = useState<NetworkGenome>(() => getArchitectureTemplates()[0].genome);
  const [result, setResult] = useState<TrainingResult | null>(null);
  const [checkpoint, setCheckpoint] = useState<NetworkCheckpoint | null>(null);
  const [checkpointText, setCheckpointText] = useState('');
  const [comparison, setComparison] = useState<EvolutionComparison | null>(null);
  const [epochs, setEpochs] = useState(4);
  const [batchSize, setBatchSize] = useState(2);
  const [optimizer, setOptimizer] = useState<'adam' | 'sgd' | 'momentum' | 'rmsprop'>('adam');
  const [mechanism, setMechanism] = useState<'gradientDescent' | 'hebbian' | 'reinforce' | 'competitive'>('gradientDescent');
  const [learningRate, setLearningRate] = useState(0.02);
  const [training, setTraining] = useState(false);
  const report = validateGenome(coreGenome);
  const last = result?.history.at(-1);

  const runTraining = () => {
    setTraining(true);
    window.setTimeout(() => {
      try {
        const trained = trainNetwork(coreGenome, trainingSamples, {
          epochs,
          batchSize,
          optimizer,
          mechanism,
          learningRate,
          validationSplit: 0.17,
          testSplit: 0.17,
          gradientClip: 1,
          earlyStopping: { patience: 2, minDelta: 0.0001 },
          seed: coreGenome.seed,
        }, checkpoint?.learned);
        setResult(trained);
        setCheckpoint(null);
        notice(`Training complete · ${trained.history.length} epochs · best epoch ${trained.bestEpoch}`);
      } catch (error) {
        notice(error instanceof Error ? error.message : 'Training failed', 'error');
      } finally {
        setTraining(false);
      }
    }, 30);
  };

  const makeMutation = () => {
    const next = mutateGenome(coreGenome, coreGenome.seed + 1);
    setCoreGenome(next);
    setResult(null);
    setCheckpoint(null);
    setComparison(null);
    notice(`Mutation ready to train · ${next.nodes.length} primitives`);
  };

  const makeCrossover = () => {
    const mate = getArchitectureTemplates()[3].genome;
    const next = crossoverGenomes(coreGenome, mate, coreGenome.seed + mate.seed);
    setCoreGenome(next);
    setResult(null);
    setCheckpoint(null);
    setComparison(null);
    notice('Crossover produced a trainable offspring');
  };

  const save = () => {
    if (!result) return notice('Train the genome before saving a checkpoint', 'error');
    const saved = checkpointFromTraining(result);
    setCheckpoint(saved);
    setCheckpointText(serializeCheckpoint(saved));
    notice('Weights and state serialized to a local checkpoint');
  };

  const load = () => {
    try {
      const loaded = loadCheckpoint(checkpointText);
      setCoreGenome(loaded.genome);
      setCheckpoint(loaded);
      setResult(null);
      notice(`Checkpoint loaded · resume from step ${loaded.learned.step}`);
    } catch (error) {
      notice(error instanceof Error ? error.message : 'Invalid checkpoint', 'error');
    }
  };

  const evolve = () => {
    if (!result) return notice('Train a parent before comparing an offspring', 'error');
    try {
      const outcome = evolveAndCompare({ genome: result.genome, learned: result.learned }, trainingSamples, {
        epochs: 2,
        batchSize,
        optimizer,
        mechanism,
        learningRate,
        validationSplit: 0,
        testSplit: 0,
        gradientClip: 1,
      });
      setComparison(outcome);
      if (outcome.keepOffspring) setCoreGenome(outcome.offspring.genome);
      notice(outcome.keepOffspring ? 'Offspring kept · lower loss than parent' : 'Offspring discarded · parent remains champion');
    } catch (error) {
      notice(error instanceof Error ? error.message : 'Evolution comparison failed', 'error');
    }
  };

  return <div className="mt-6 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.76)] p-5 card-shadow md:p-6">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div><p className="font-mono text-[9px] uppercase tracking-[.2em] text-[hsl(var(--primary))]">05 / training runtime</p><h2 className="mt-1 font-display text-lg font-bold">Train the generated network</h2><p className="mt-2 max-w-xl text-xs leading-relaxed text-muted-foreground">The trainer is built from the same genome as the forward graph. Mutants and cross-breeds can enter the loop immediately.</p></div>
      <span className={`flex items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider ${report.valid ? 'border-[hsl(var(--primary)/.35)] text-[hsl(var(--primary))]' : 'border-[hsl(var(--destructive)/.35)] text-[hsl(var(--destructive))]'}`}><span className={`h-1.5 w-1.5 rounded-full ${report.valid ? 'bg-[hsl(var(--primary))]' : 'bg-[hsl(var(--destructive))]'}`} />{report.valid ? 'trainable genome' : 'blocked by validation'}</span>
    </div>
    <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <label className="block"><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">mechanism</span><select value={mechanism} onChange={(event) => setMechanism(event.target.value as typeof mechanism)} className="w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-3 py-2 text-xs outline-none"><option value="gradientDescent">gradient descent</option><option value="hebbian">hebbian local</option><option value="reinforce">reinforcement</option><option value="competitive">competitive</option></select></label>
      <label className="block"><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">optimizer</span><select value={optimizer} onChange={(event) => setOptimizer(event.target.value as typeof optimizer)} className="w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-3 py-2 text-xs outline-none"><option value="adam">Adam</option><option value="sgd">SGD</option><option value="momentum">Momentum</option><option value="rmsprop">RMSProp</option></select></label>
      <label className="block"><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">epochs / batch</span><div className="flex gap-2"><input type="number" min="1" max="50" value={epochs} onChange={(event) => setEpochs(Number(event.target.value))} className="w-1/2 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-2 py-2 text-xs outline-none" /><input type="number" min="1" max="16" value={batchSize} onChange={(event) => setBatchSize(Number(event.target.value))} className="w-1/2 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-2 py-2 text-xs outline-none" /></div></label>
      <label className="block"><span className="mb-1.5 block font-mono text-[9px] uppercase tracking-widest text-muted-foreground">learning rate</span><input type="number" min="0.0001" max="1" step="0.001" value={learningRate} onChange={(event) => setLearningRate(Number(event.target.value))} className="w-full rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background)/.62)] px-3 py-2 text-xs outline-none" /></label>
    </div>
    <div className="mt-5 flex flex-wrap items-center gap-2">
      <button onClick={runTraining} disabled={training || !report.valid} className="flex items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-3 py-2.5 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-train-genome"><Play size={13} />{training ? 'training…' : checkpoint ? 'resume training' : 'train genome'}</button>
      <button onClick={makeMutation} className="flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground" data-testid="button-mutate-trained-genome"><Zap size={13} /> mutate</button>
      <button onClick={makeCrossover} className="flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground" data-testid="button-crossover-trained-genome"><GitCompare size={13} /> crossover</button>
      <button onClick={evolve} disabled={!result || training} className="flex items-center gap-2 rounded-lg border border-[hsl(var(--secondary)/.45)] px-3 py-2.5 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--secondary))] hover:bg-[hsl(var(--secondary)/.08)] disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-evolve-compare"><GitBranch size={13} /> evolve + compare</button>
      <button onClick={save} className="ml-auto flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] px-3 py-2.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground" data-testid="button-save-checkpoint"><Download size={13} /> save checkpoint</button>
    </div>
    <div className="mt-5 grid gap-3 sm:grid-cols-4">
      <Metric label="graph" value={`${report.stats.nodes} / ${report.stats.connections}`} hint="nodes / connections" accent />
      <Metric label="parameters" value={report.stats.parameters.toString()} hint="genome estimate" />
      <Metric label="loss" value={last ? last.loss.toFixed(4) : '—'} hint={last ? `epoch ${last.epoch}` : 'not trained'} />
      <Metric label="accuracy" value={last?.accuracy ? `${(last.accuracy * 100).toFixed(1)}%` : '—'} hint={last ? 'training split' : 'awaiting signal'} />
    </div>
    {result && <div className="mt-5 overflow-x-auto rounded-xl border border-[hsl(var(--border))]"><table className="w-full min-w-[560px] text-left font-mono text-[10px]"><thead className="border-b border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] text-muted-foreground"><tr><th className="px-3 py-2.5 font-medium">epoch</th><th className="px-3 py-2.5 font-medium">loss</th><th className="px-3 py-2.5 font-medium">val loss</th><th className="px-3 py-2.5 font-medium">accuracy</th><th className="px-3 py-2.5 font-medium">grad norm</th></tr></thead><tbody>{result.history.map((item) => <tr key={item.epoch} className="border-b border-[hsl(var(--border)/.65)] last:border-0"><td className="px-3 py-2 text-[hsl(var(--primary))]">{String(item.epoch).padStart(2, '0')}</td><td className="px-3 py-2">{item.loss.toFixed(4)}</td><td className="px-3 py-2">{item.validationLoss?.toFixed(4) ?? '—'}</td><td className="px-3 py-2">{item.accuracy ? `${(item.accuracy * 100).toFixed(0)}%` : '—'}</td><td className="px-3 py-2 text-muted-foreground">{item.gradientNorm?.toFixed(2) ?? '—'}</td></tr>)}</tbody></table></div>}
    {comparison && <div className="mt-4 grid gap-3 rounded-xl border border-[hsl(var(--secondary)/.35)] bg-[hsl(var(--secondary)/.06)] p-4 sm:grid-cols-3" data-testid="status-evolution-comparison"><div><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">parent loss</p><p className="mt-1 font-display text-lg font-bold">{comparison.parentEvaluation.loss.toFixed(4)}</p></div><div><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">offspring loss</p><p className="mt-1 font-display text-lg font-bold text-[hsl(var(--secondary))]">{comparison.offspringEvaluation.loss.toFixed(4)}</p></div><div><p className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">decision</p><p className="mt-1 font-display text-lg font-bold">{comparison.keepOffspring ? 'KEEP' : 'DISCARD'}</p></div></div>}
    {(checkpoint || checkpointText) && <div className="mt-5"><div className="mb-2 flex items-center justify-between"><span className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground">checkpoint document</span><button onClick={load} className="font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary))] hover:underline" data-testid="button-load-checkpoint"><Upload size={12} className="mr-1 inline" />load / resume</button></div><textarea value={checkpointText} onChange={(event) => setCheckpointText(event.target.value)} className="h-28 w-full resize-y rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--sidebar))] p-3 font-mono text-[9px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.72)] outline-none" aria-label="Training checkpoint JSON" /></div>}
  </div>;
}

function ArchitectureCard({ item, index }: { item: typeof architectureList[number]; index: number }) {
  const { loadArchitecture } = useFoundry();
  const isFeatured = index === 0;
  return <article className={`group rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.74)] p-5 transition-all duration-300 hover:-translate-y-1 hover:border-[hsl(var(--primary)/.45)] hover:shadow-[0_14px_30px_hsl(var(--foreground)/.07)] ${isFeatured ? 'md:row-span-2 md:p-7' : ''}`}><div className="flex items-start justify-between gap-3"><span className="font-mono text-[9px] uppercase tracking-[.18em] text-[hsl(var(--primary))]">{item.type}</span><span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-wider text-[hsl(var(--primary))]"><CircleCheck size={12} /> {item.status}</span></div><div className={`mt-7 grid place-items-center rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.7)] ${isFeatured ? 'h-48' : 'h-24'}`}><ArchitectureGlyph type={item.type} featured={isFeatured} /></div><h3 className={`mt-5 font-display font-bold ${isFeatured ? 'text-xl' : 'text-base'}`}>{item.name}</h3><p className="mt-2 text-xs leading-relaxed text-muted-foreground">{item.description}</p><div className="mt-4 flex items-center justify-between gap-3 border-t border-[hsl(var(--border))] pt-3"><span className="font-mono text-[9px] text-muted-foreground">{item.stats}</span><button onClick={() => loadArchitecture(item.name)} className="flex shrink-0 items-center gap-1 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary))] opacity-70 transition-all group-hover:opacity-100" data-testid={`button-load-architecture-${index}`}><Download size={12} /> load <ArrowRight size={12} /></button></div></article>;
}

function ArchitectureGlyph({ type, featured }: { type: string; featured: boolean }) {
  const colors = ['hsl(var(--primary))', 'hsl(var(--secondary))', '#9c628e', '#657fa8'];
  return <div className={`flex items-center gap-2 ${featured ? 'scale-125' : ''}`}><span className="font-mono text-[9px] text-muted-foreground">input</span>{Array.from({ length: featured ? 5 : 3 }).map((_, index) => <span key={index} className="flex items-center gap-2"><ArrowRight size={12} className="text-[hsl(var(--border))]" /><i className="node-pulse grid h-7 w-7 place-items-center rounded-md border-2" style={{ borderColor: colors[index % colors.length], backgroundColor: `${colors[index % colors.length].replace(')', ' / .08)')}` }}><span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: colors[index % colors.length] }} /></i></span>)}<ArrowRight size={12} className="text-[hsl(var(--border))]" /><span className="font-mono text-[9px] text-muted-foreground">{type === 'emergent' ? 'field' : 'output'}</span></div>;
}

function Architectures() {
  const { notice } = useFoundry();
  const [sweep, setSweep] = useState<ReturnType<typeof benchmarkArchitectures> | null>(null);
  const runSweep = () => {
    const results = benchmarkArchitectures(1);
    setSweep(results);
    const healthy = results.filter((item) => item.valid && item.trainable).length;
    notice(`Training sweep complete · ${healthy}/${results.length} species trainable`);
  };
  return <PageFrame eyebrow="02 / composition atlas" title="Validated compositions" description="Reference organisms built only from the four primitives. Load any specimen into the workbench, then make it stranger." actions={<button onClick={runSweep} className="flex items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5" data-testid="button-run-validation"><Play size={13} /> run training sweep</button>}>
    <div className="mb-8 flex flex-wrap items-center gap-4 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] px-4 py-3"><div className="flex items-center gap-2 font-mono text-[10px] text-[hsl(var(--primary))]"><CircleCheck size={14} /> {sweep ? `${sweep.filter((item) => item.valid && item.trainable).length.toString().padStart(2, '0')} specimens trainable` : '09 specimens ready'}</div><span className="h-4 w-px bg-[hsl(var(--border))]" /><span className="font-mono text-[10px] text-muted-foreground">{sweep ? 'Forward · backward · update verified' : 'Run the sweep to execute each genome'}</span><span className="ml-auto flex items-center gap-2 font-mono text-[10px] text-muted-foreground"><Search size={13} /> search atlas</span></div>
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{architectureList.map((item, index) => <ArchitectureCard key={item.name} item={item} index={index} />)}</div>
    {sweep && <div className="mt-8 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] p-5" data-testid="status-training-sweep"><SectionLabel detail="one sample / one epoch">end-to-end training sweep</SectionLabel><div className="grid gap-2 md:grid-cols-3">{sweep.map((item) => <div key={item.architecture} className="flex items-center justify-between rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background)/.45)] px-3 py-2.5"><span className="truncate pr-3 text-xs">{item.architecture}</span><span className={`shrink-0 font-mono text-[9px] uppercase tracking-wider ${item.trainable ? 'text-[hsl(var(--primary))]' : 'text-[hsl(var(--destructive))]'}`}>{item.trainable ? 'trainable' : 'blocked'}</span></div>)}</div></div>}
  </PageFrame>;
}

function Primitives() {
  const [selected, setSelected] = useState<PrimitiveKind>('signal');
  const { notice } = useFoundry();
  const meta = primitiveMeta[selected];
  return <PageFrame eyebrow="03 / the vocabulary" title="Four orthogonal primitives" description="Every network is a typed composition of these capabilities. They are small enough to inspect and expressive enough to surprise you." actions={<button onClick={() => notice('Primitive contracts copied to clipboard')} className="flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground" data-testid="button-copy-primitive-contracts"><Clipboard size={13} /> copy contracts</button>}>
    <div className="grid gap-6 lg:grid-cols-[280px_minmax(0,1fr)]"><div className="space-y-2">{(Object.keys(primitiveMeta) as PrimitiveKind[]).map((kind, index) => { const item = primitiveMeta[kind]; return <button key={kind} onClick={() => setSelected(kind)} className={`focus-ring group w-full rounded-xl border p-4 text-left transition-all ${selected === kind ? 'border-[hsl(var(--primary))] bg-[hsl(var(--accent)/.38)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.58)] hover:border-[hsl(var(--primary)/.45)]'}`} data-testid={`button-select-primitive-${kind}`}><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-lg text-lg font-bold" style={{ backgroundColor: `${item.color}20`, color: item.color }}>{item.mark}</span><span className="flex-1"><span className="block font-display text-sm font-bold">{item.name}</span><span className="mt-0.5 block font-mono text-[9px] uppercase tracking-wider text-muted-foreground">primitive 0{index + 1}</span></span><ChevronRight size={15} className={`text-muted-foreground transition-transform ${selected === kind ? 'translate-x-0.5 text-[hsl(var(--primary))]' : ''}`} /></div></button>; })}<div className="mt-5 rounded-xl bg-[hsl(var(--sidebar))] p-4 text-[hsl(var(--sidebar-foreground))]"><p className="font-mono text-[9px] uppercase tracking-widest text-[hsl(var(--sidebar-primary))]">composition rule</p><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--sidebar-foreground)/.68)]">A primitive describes a capability, not a named architecture. The graph is the idea.</p></div></div><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] p-6 md:p-8"><div className="flex flex-wrap items-start justify-between gap-5"><div className="flex items-center gap-4"><span className="grid h-14 w-14 place-items-center rounded-2xl text-3xl font-bold" style={{ backgroundColor: `${meta.color}20`, color: meta.color }}>{meta.mark}</span><div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground">contract / {selected}</p><h2 className="mt-1 font-display text-3xl font-bold">{meta.name}</h2></div></div><span className="rounded-full border border-[hsl(var(--primary)/.35)] bg-[hsl(var(--accent)/.32)] px-3 py-1.5 font-mono text-[9px] uppercase tracking-wider text-[hsl(var(--primary))]">typed capability</span></div><p className="mt-7 max-w-xl text-sm leading-7 text-muted-foreground">{meta.description}</p><div className="mt-8 grid gap-7 md:grid-cols-2"><div><SectionLabel>capabilities</SectionLabel><div className="flex flex-wrap gap-2">{meta.capabilities.map((capability) => <span key={capability} className="rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background)/.6)] px-3 py-2 font-mono text-[10px] text-[hsl(var(--foreground))]">{capability}</span>)}</div></div><div><SectionLabel>known forms</SectionLabel><div className="space-y-2">{meta.examples.map((example, index) => <div key={example} className="flex items-center gap-3 text-xs"><span className="font-mono text-[10px] text-muted-foreground">0{index + 1}</span><span>{example}</span><ArrowRight size={12} className="ml-auto text-[hsl(var(--primary))]" /></div>)}</div></div></div><div className="mt-9 overflow-hidden rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--sidebar))]"><div className="flex items-center justify-between border-b border-[hsl(var(--sidebar-border))] px-4 py-3"><span className="flex items-center gap-2 font-mono text-[10px] text-[hsl(var(--sidebar-foreground)/.62)]"><Terminal size={13} /> contract.ts</span><button onClick={() => notice(`${meta.name} contract copied`)} className="text-[hsl(var(--sidebar-foreground)/.5)] hover:text-[hsl(var(--sidebar-primary))]" data-testid="button-copy-contract"><Copy size={13} /></button></div><pre className="overflow-auto p-5 font-mono text-[11px] leading-6 text-[hsl(var(--sidebar-foreground)/.75)]"><span className="text-[hsl(var(--sidebar-primary))]">type</span> {meta.name} = {'{'}{'\n'}  capability: <span className="text-[#d1842f]">'{meta.capabilities.join(' | ')}'</span>;{'\n'}  state: <span className="text-[#d1842f]">'local'</span>;{'\n'}  differentiable: <span className="text-[#d1842f]">boolean</span>;{'\n'}  params: Record&lt;string, Scalar&gt;;{'\n'}{'}'}</pre></div></div></div>
  </PageFrame>;
}

function Spec() {
  const { genome, setGenome, notice } = useFoundry();
  const [text, setText] = useState(() => JSON.stringify(genome, null, 2));
  const [edited, setEdited] = useState(false);
  const [error, setError] = useState('');
  const apply = () => {
    try {
      const parsed = JSON.parse(text) as Genome;
      if (!parsed.name || !Array.isArray(parsed.nodes) || !Array.isArray(parsed.edges)) throw new Error('Required fields: name, nodes, edges');
      setGenome(parsed);
      setError('');
      setEdited(false);
      notice('Genome specification applied');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Invalid JSON');
    }
  };
  const format = () => { try { setText(JSON.stringify(JSON.parse(text), null, 2)); setError(''); notice('Specification formatted'); } catch { setError('Cannot format invalid JSON'); } };
  return <PageFrame eyebrow="04 / serialization layer" title="Genome specification" description="The Network Genome is portable, inspectable, and intentionally boring to serialize. Edit the document directly, then apply it to the workbench." actions={<div className="flex flex-wrap gap-2"><button onClick={format} className="flex items-center gap-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground" data-testid="button-format-spec"><SlidersHorizontal size={13} /> format</button><button onClick={apply} className="flex items-center gap-2 rounded-lg bg-[hsl(var(--primary))] px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5" data-testid="button-apply-spec"><Upload size={13} /> apply spec</button></div>}>
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_300px]"><div className={`overflow-hidden rounded-2xl border bg-[hsl(var(--sidebar))] shadow-xl ${error ? 'border-[hsl(var(--destructive)/.7)]' : edited ? 'border-[hsl(var(--secondary)/.6)]' : 'border-[hsl(var(--sidebar-border))]'}`}><div className="flex items-center justify-between border-b border-[hsl(var(--sidebar-border))] px-4 py-3"><div className="flex items-center gap-3 font-mono text-[10px] text-[hsl(var(--sidebar-foreground)/.65)]"><Code2 size={14} className="text-[hsl(var(--sidebar-primary))]" /> genome.json <span className="text-[hsl(var(--sidebar-foreground)/.35)]">·</span> {edited ? 'modified' : 'synced'}</div><div className="flex items-center gap-2">{error && <CircleAlert size={14} className="text-[hsl(var(--destructive))]" />}<button onClick={() => { setText(JSON.stringify(genome, null, 2)); setEdited(false); setError(''); }} className="font-mono text-[9px] uppercase tracking-wider text-[hsl(var(--sidebar-foreground)/.5)] hover:text-[hsl(var(--sidebar-primary))]" data-testid="button-revert-spec">revert</button></div></div><textarea value={text} onChange={(event) => { setText(event.target.value); setEdited(true); }} spellCheck={false} className="min-h-[620px] w-full resize-y bg-transparent p-5 font-mono text-[11px] leading-[1.8] text-[hsl(var(--sidebar-foreground)/.86)] outline-none md:p-7" data-testid="textarea-genome-spec" aria-label="Genome JSON specification" /></div><div className="space-y-4"><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] p-5"><SectionLabel>document status</SectionLabel>{error ? <div className="flex gap-3 rounded-lg bg-[hsl(var(--destructive)/.1)] p-3 text-xs leading-relaxed text-[hsl(var(--destructive))]" data-testid="status-spec-error"><CircleAlert size={15} className="mt-0.5 shrink-0" />{error}</div> : <div className="flex gap-3 rounded-lg bg-[hsl(var(--accent)/.34)] p-3 text-xs leading-relaxed text-[hsl(var(--primary))]" data-testid="status-spec-valid"><CircleCheck size={15} className="mt-0.5 shrink-0" />{edited ? 'Local edits are ready to validate.' : 'Specification matches the active genome.'}</div>}<div className="mt-5 space-y-3">{[['format', 'Network Genome v2.1'], ['nodes', `${genome.nodes.length} primitives`], ['edges', `${genome.edges.length} relations`], ['encoding', 'UTF-8 / JSON']].map(([label, value]) => <div key={label} className="flex justify-between font-mono text-[10px]"><span className="text-muted-foreground">{label}</span><span>{value}</span></div>)}</div></div><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)] p-5"><SectionLabel>why serialize</SectionLabel><p className="text-xs leading-6 text-muted-foreground">Share exact experiments, diff mutations, and return to a promising organism without a database or hidden state.</p><button onClick={() => notice('Spec copied to local clipboard')} className="mt-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-[hsl(var(--primary))] hover:underline" data-testid="button-copy-spec"><Copy size={13} /> copy document</button></div></div></div>
  </PageFrame>;
}

function Router() {
  return <FoundryProvider><AppShell><ErrorRouted /></AppShell></FoundryProvider>;
}
function ErrorRouted() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={Workbench} /><Route path="/architectures" component={Architectures} /><Route path="/primitives" component={Primitives} /><Route path="/spec" component={Spec} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;