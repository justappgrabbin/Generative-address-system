export type PrimitiveKind =
  | "transformation"
  | "memory"
  | "relation"
  | "generation";

export type ActivationName = "identity" | "tanh" | "relu" | "sigmoid" | "gelu";
export type UpdateName = "replace" | "ema" | "gru" | "accumulate";
export type Tensor = number[];
export type OptimizerName = "sgd" | "momentum" | "rmsprop" | "adam";
export type LearningMechanism = "gradientDescent" | "local" | "hebbian" | "reinforce" | "competitive" | "none";
export type LossName = "mse" | "crossEntropy" | "binaryCrossEntropy" | "cosine" | "custom";

export interface PortSpec {
  name: string;
  kind: "tensor" | "scalar" | "categorical";
  shape: number[];
  required?: boolean;
}

export interface PrimitiveConfig {
  inputSize: number;
  outputSize: number;
  activation?: ActivationName;
  update?: UpdateName;
  temperature?: number;
  neighborhood?: number;
  classes?: number;
}

export interface GenomeNode {
  id: string;
  primitive: PrimitiveKind;
  label: string;
  config: PrimitiveConfig;
  position?: { x: number; y: number };
}

export interface GenomeConnection {
  id: string;
  from: string;
  fromPort: string;
  to: string;
  toPort: string;
  transform?: "identity" | "project" | "sum" | "concat";
}

export interface LearningRule {
  name: LearningMechanism;
  learningRate: number;
  loss?: LossName | "energy";
  optimizer?: OptimizerName;
  gradientClip?: number;
  moduleLearningRates?: Record<string, number>;
  frozenNodes?: string[];
}

export interface NetworkGenome {
  version: 1;
  id: string;
  name: string;
  seed: number;
  nodes: GenomeNode[];
  connections: GenomeConnection[];
  state: Record<string, Tensor>;
  learning: LearningRule;
  metadata?: {
    species?: string;
    tags?: string[];
    description?: string;
  };
}

export interface StateSnapshot {
  nodeId: string;
  values: Tensor;
  step: number;
  summary: {
    mean: number;
    norm: number;
    min: number;
    max: number;
  };
}

export interface PrimitiveDefinition {
  kind: PrimitiveKind;
  name: string;
  shortName: string;
  description: string;
  capabilities: string[];
  inputs: PortSpec[];
  outputs: PortSpec[];
}

export interface PrimitiveRuntime {
  readonly definition: PrimitiveDefinition;
  readonly nodeId: string;
  forward(inputs: Record<string, Tensor>, step?: number): Record<string, Tensor>;
  backward(gradient: Tensor, learningRate?: number): Tensor;
  inspect(): StateSnapshot;
  serialize(): { nodeId: string; primitive: PrimitiveKind; config: PrimitiveConfig; parameters: number[]; state: Tensor };
  getParameters(): number[];
  setParameters(parameters: number[]): void;
  resetState(): void;
  setState(values: Tensor, step?: number): void;
}

export interface ValidationIssue {
  severity: "error" | "warning";
  code: string;
  message: string;
  nodeId?: string;
  connectionId?: string;
}

export interface ValidationReport {
  valid: boolean;
  issues: ValidationIssue[];
  stats: {
    nodes: number;
    connections: number;
    primitives: number;
    depth: number;
    parameters: number;
  };
}

export interface ArchitectureTemplate {
  id: string;
  name: string;
  family: string;
  description: string;
  tags: string[];
  genome: NetworkGenome;
}

export interface TrainingSample {
  input: Tensor;
  target: Tensor;
  weight?: number;
}

export interface DatasetSplit {
  train: TrainingSample[];
  validation: TrainingSample[];
  test: TrainingSample[];
}

export interface TrainingConfig {
  epochs?: number;
  steps?: number;
  batchSize?: number;
  optimizer?: OptimizerName;
  learningRate?: number;
  validationSplit?: number;
  testSplit?: number;
  shuffle?: boolean;
  gradientClip?: number;
  earlyStopping?: { patience: number; minDelta?: number; monitor?: "loss" | "accuracy" };
  online?: boolean;
  mechanism?: LearningMechanism;
  frozenNodes?: string[];
  moduleLearningRates?: Record<string, number>;
  seed?: number;
}

export interface TrainingMetrics {
  epoch: number;
  step: number;
  loss: number;
  validationLoss?: number;
  accuracy?: number;
  validationAccuracy?: number;
  gradientNorm?: number;
  samples: number;
}

export interface LearnedNetworkState {
  parameters: Record<string, number[]>;
  state: Record<string, Tensor>;
  optimizerState: Record<string, number[]>;
  step: number;
}

export interface NetworkCheckpoint {
  version: 1;
  genome: NetworkGenome;
  learned: LearnedNetworkState;
  epoch: number;
  metrics: TrainingMetrics[];
}

export interface TrainingResult {
  genome: NetworkGenome;
  learned: LearnedNetworkState;
  history: TrainingMetrics[];
  split: DatasetSplit;
  stoppedEarly: boolean;
  bestEpoch: number;
}

export interface NetworkSpecies {
  genome: NetworkGenome;
  learned: LearnedNetworkState;
  fitness?: number;
  metrics?: TrainingMetrics;
}

export interface EvaluationResult {
  loss: number;
  accuracy: number;
  samples: number;
  passed: boolean;
}

export interface ArchitectureTestResult {
  architecture: string;
  valid: boolean;
  trainable: boolean;
  trainedLoss?: number;
  error?: string;
}

export interface EvolutionComparison {
  parent: NetworkSpecies;
  offspring: NetworkSpecies;
  parentEvaluation: EvaluationResult;
  offspringEvaluation: EvaluationResult;
  keepOffspring: boolean;
}

const primitiveDefinitions: Record<PrimitiveKind, PrimitiveDefinition> = {
  transformation: {
    kind: "transformation",
    name: "Transformation",
    shortName: "TRANSFORM",
    description: "Changes one representation or state into another through a learned mapping and nonlinearity.",
    capabilities: ["learned mappings", "nonlinear transforms", "encoding / decoding", "feature extraction"],
    inputs: [{ name: "state", kind: "tensor", shape: [-1], required: true }],
    outputs: [{ name: "state", kind: "tensor", shape: [-1] }],
  },
  memory: {
    kind: "memory",
    name: "Memory",
    shortName: "MEMORY",
    description: "Preserves and updates information through time with configurable state and gates.",
    capabilities: ["recurrence", "persistent state", "gating", "temporal integration"],
    inputs: [{ name: "input", kind: "tensor", shape: [-1], required: true }],
    outputs: [
      { name: "state", kind: "tensor", shape: [-1] },
      { name: "memory", kind: "tensor", shape: [-1] },
    ],
  },
  relation: {
    kind: "relation",
    name: "Relation",
    shortName: "RELATE",
    description: "Determines how multiple states, nodes, or features interact through learned compatibility.",
    capabilities: ["attention", "neighborhoods", "message passing", "comparison", "routing"],
    inputs: [
      { name: "query", kind: "tensor", shape: [-1], required: true },
      { name: "context", kind: "tensor", shape: [-1] },
    ],
    outputs: [{ name: "message", kind: "tensor", shape: [-1] }],
  },
  generation: {
    kind: "generation",
    name: "Generation / Selection",
    shortName: "SELECT",
    description: "Creates, predicts, evaluates, or selects possible next states from a scored distribution.",
    capabilities: ["prediction", "sampling", "decoding", "energy / scoring", "policy selection"],
    inputs: [{ name: "state", kind: "tensor", shape: [-1], required: true }],
    outputs: [
      { name: "next", kind: "tensor", shape: [-1] },
      { name: "scores", kind: "tensor", shape: [-1] },
    ],
  },
};

export function getPrimitiveDefinitions(): PrimitiveDefinition[] {
  return Object.values(primitiveDefinitions);
}

export function getPrimitiveDefinition(kind: PrimitiveKind): PrimitiveDefinition {
  return primitiveDefinitions[kind];
}

function seededRandom(seed: number): () => number {
  let state = (seed >>> 0) || 1;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return ((state >>> 0) % 1000000) / 1000000;
  };
}

function activation(name: ActivationName, value: number): number {
  switch (name) {
    case "tanh":
      return Math.tanh(value);
    case "relu":
      return Math.max(0, value);
    case "sigmoid":
      return 1 / (1 + Math.exp(-value));
    case "gelu":
      return 0.5 * value * (1 + Math.tanh(Math.sqrt(2 / Math.PI) * (value + 0.044715 * value ** 3)));
    default:
      return value;
  }
}

function activationDerivative(name: ActivationName, value: number): number {
  switch (name) {
    case "tanh": {
      const result = Math.tanh(value);
      return 1 - result * result;
    }
    case "relu":
      return value > 0 ? 1 : 0;
    case "sigmoid": {
      const result = 1 / (1 + Math.exp(-value));
      return result * (1 - result);
    }
    case "gelu":
      return 0.5 * (1 + Math.tanh(Math.sqrt(2 / Math.PI) * (value + 0.044715 * value ** 3)));
    default:
      return 1;
  }
}

function zeros(size: number): Tensor {
  return Array.from({ length: Math.max(0, size) }, () => 0);
}

function dot(row: number[], values: Tensor): number {
  return row.reduce((sum, weight, index) => sum + weight * (values[index] ?? 0), 0);
}

function softmax(values: Tensor, temperature = 1): Tensor {
  const scaled = values.map((value) => value / Math.max(0.05, temperature));
  const maximum = Math.max(...scaled, 0);
  const exponentials = scaled.map((value) => Math.exp(value - maximum));
  const total = exponentials.reduce((sum, value) => sum + value, 0) || 1;
  return exponentials.map((value) => value / total);
}

function tensorSummary(values: Tensor): StateSnapshot["summary"] {
  const min = values.length ? Math.min(...values) : 0;
  const max = values.length ? Math.max(...values) : 0;
  const mean = values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  const norm = Math.sqrt(values.reduce((sum, value) => sum + value * value, 0));
  return { mean, norm, min, max };
}

abstract class BaseRuntime implements PrimitiveRuntime {
  abstract readonly definition: PrimitiveDefinition;
  abstract forward(inputs: Record<string, Tensor>, step?: number): Record<string, Tensor>;
  protected abstract syncParameters(): void;
  protected readonly random: () => number;
  protected readonly config: PrimitiveConfig;
  protected readonly parameters: number[];
  protected state: Tensor;
  protected lastPreActivation: Tensor;
  protected step = 0;

  constructor(
    readonly nodeId: string,
    protected readonly primitive: PrimitiveKind,
    config: PrimitiveConfig,
    seed: number,
  ) {
    this.config = {
      inputSize: Math.max(1, config.inputSize),
      outputSize: Math.max(1, config.outputSize),
      activation: config.activation ?? "tanh",
      update: config.update ?? "replace",
      temperature: config.temperature ?? 1,
      neighborhood: config.neighborhood ?? 1,
      classes: config.classes ?? config.outputSize,
    };
    this.random = seededRandom(seed);
    this.parameters = [];
    this.state = zeros(this.config.outputSize);
    this.lastPreActivation = zeros(this.config.outputSize);
  }

  protected initializeWeights(count: number): number[] {
    const scale = Math.sqrt(2 / Math.max(1, this.config.inputSize));
    return Array.from({ length: count }, () => (this.random() * 2 - 1) * scale);
  }

  inspect(): StateSnapshot {
    return { nodeId: this.nodeId, values: [...this.state], step: this.step, summary: tensorSummary(this.state) };
  }

  getParameters(): number[] {
    return [...this.parameters];
  }

  setParameters(parameters: number[]): void {
    this.parameters.splice(0, this.parameters.length, ...parameters);
    this.syncParameters();
  }

  resetState(): void {
    this.state = zeros(this.config.outputSize);
    this.lastPreActivation = zeros(this.config.outputSize);
    this.step = 0;
  }

  setState(values: Tensor, step = 0): void {
    this.state = [...values];
    this.step = step;
  }

  serialize() {
    return {
      nodeId: this.nodeId,
      primitive: this.primitive,
      config: { ...this.config },
      parameters: [...this.parameters],
      state: [...this.state],
    };
  }

  backward(gradient: Tensor, learningRate = 0.01): Tensor {
    const derivative = this.lastPreActivation.map((value) => activationDerivative(this.config.activation ?? "identity", value));
    const scaled = gradient.map((value, index) => value * (derivative[index] ?? 1));
    for (let index = 0; index < Math.min(scaled.length, this.parameters.length); index += 1) {
      this.parameters[index] -= learningRate * scaled[index];
    }
    return scaled.slice(0, this.config.inputSize);
  }
}

class TransformationRuntime extends BaseRuntime {
  readonly definition = primitiveDefinitions.transformation;
  private readonly weights: number[][];
  private readonly bias: Tensor;

  constructor(nodeId: string, config: PrimitiveConfig, seed: number) {
    super(nodeId, "transformation", config, seed);
    this.weights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.inputSize));
    this.bias = zeros(this.config.outputSize);
    this.parameters.push(...this.weights.flat(), ...this.bias);
  }

  protected syncParameters(): void {
    const weightCount = this.config.inputSize * this.config.outputSize;
    this.weights.forEach((row, rowIndex) => row.splice(0, row.length, ...this.parameters.slice(rowIndex * this.config.inputSize, (rowIndex + 1) * this.config.inputSize)));
    this.bias.splice(0, this.bias.length, ...this.parameters.slice(weightCount, weightCount + this.config.outputSize));
  }

  forward(inputs: Record<string, Tensor>) {
    const input = inputs.state ?? inputs.input ?? [];
    this.lastPreActivation = this.weights.map((row, index) => dot(row, input) + (this.bias[index] ?? 0));
    this.state = this.lastPreActivation.map((value) => activation(this.config.activation ?? "tanh", value));
    this.step += 1;
    return { state: [...this.state] };
  }
}

class MemoryRuntime extends BaseRuntime {
  readonly definition = primitiveDefinitions.memory;
  private readonly inputWeights: number[][];
  private readonly recurrentWeights: number[][];

  constructor(nodeId: string, config: PrimitiveConfig, seed: number) {
    super(nodeId, "memory", config, seed);
    this.inputWeights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.inputSize));
    this.recurrentWeights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.outputSize));
    this.parameters.push(...this.inputWeights.flat(), ...this.recurrentWeights.flat());
  }

  protected syncParameters(): void {
    const inputCount = this.config.inputSize * this.config.outputSize;
    this.inputWeights.forEach((row, rowIndex) => row.splice(0, row.length, ...this.parameters.slice(rowIndex * this.config.inputSize, (rowIndex + 1) * this.config.inputSize)));
    this.recurrentWeights.forEach((row, rowIndex) => {
      const start = inputCount + rowIndex * this.config.outputSize;
      row.splice(0, row.length, ...this.parameters.slice(start, start + this.config.outputSize));
    });
  }

  forward(inputs: Record<string, Tensor>) {
    const input = inputs.input ?? inputs.state ?? [];
    this.lastPreActivation = this.inputWeights.map((row, index) => dot(row, input) + dot(this.recurrentWeights[index], this.state));
    const candidate = this.lastPreActivation.map((value) => activation(this.config.activation ?? "tanh", value));
    const update = this.config.update === "accumulate" ? 1 : this.config.update === "ema" ? 0.2 : 0.65;
    this.state = this.state.map((old, index) => old * (1 - update) + (candidate[index] ?? 0) * update);
    this.step += 1;
    return { state: [...this.state], memory: [...this.state] };
  }
}

class RelationRuntime extends BaseRuntime {
  readonly definition = primitiveDefinitions.relation;
  private readonly queryWeights: number[][];
  private readonly contextWeights: number[][];

  constructor(nodeId: string, config: PrimitiveConfig, seed: number) {
    super(nodeId, "relation", config, seed);
    this.queryWeights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.inputSize));
    this.contextWeights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.inputSize));
    this.parameters.push(...this.queryWeights.flat(), ...this.contextWeights.flat());
  }

  protected syncParameters(): void {
    const queryCount = this.config.inputSize * this.config.outputSize;
    this.queryWeights.forEach((row, rowIndex) => row.splice(0, row.length, ...this.parameters.slice(rowIndex * this.config.inputSize, (rowIndex + 1) * this.config.inputSize)));
    this.contextWeights.forEach((row, rowIndex) => {
      const start = queryCount + rowIndex * this.config.inputSize;
      row.splice(0, row.length, ...this.parameters.slice(start, start + this.config.inputSize));
    });
  }

  forward(inputs: Record<string, Tensor>) {
    const query = inputs.query ?? inputs.state ?? [];
    const context = inputs.context ?? query;
    const queryProjection = this.queryWeights.map((row) => dot(row, query));
    const contextProjection = this.contextWeights.map((row) => dot(row, context));
    const scores = softmax(contextProjection, this.config.temperature);
    this.lastPreActivation = queryProjection.map((value, index) => value + (contextProjection[index] ?? 0) * (scores[index] ?? 0));
    this.state = this.lastPreActivation.map((value) => activation(this.config.activation ?? "tanh", value));
    this.step += 1;
    return { message: [...this.state] };
  }
}

class GenerationRuntime extends BaseRuntime {
  readonly definition = primitiveDefinitions.generation;
  private readonly logitsWeights: number[][];

  constructor(nodeId: string, config: PrimitiveConfig, seed: number) {
    super(nodeId, "generation", config, seed);
    this.logitsWeights = Array.from({ length: this.config.outputSize }, () => this.initializeWeights(this.config.inputSize));
    this.parameters.push(...this.logitsWeights.flat());
  }

  protected syncParameters(): void {
    this.logitsWeights.forEach((row, rowIndex) => row.splice(0, row.length, ...this.parameters.slice(rowIndex * this.config.inputSize, (rowIndex + 1) * this.config.inputSize)));
  }

  forward(inputs: Record<string, Tensor>) {
    const input = inputs.state ?? inputs.input ?? [];
    this.lastPreActivation = this.logitsWeights.map((row) => dot(row, input));
    const scores = softmax(this.lastPreActivation, this.config.temperature);
    const selected = scores.map((probability, index) => probability * (index / Math.max(1, scores.length - 1)));
    this.state = selected;
    this.step += 1;
    return { next: [...this.state], scores };
  }
}

export function createPrimitiveRuntime(node: GenomeNode, seedOffset = 0): PrimitiveRuntime {
  const seed = node.config.inputSize * 31 + node.config.outputSize * 17 + seedOffset + node.id.length;
  switch (node.primitive) {
    case "transformation":
      return new TransformationRuntime(node.id, node.config, seed);
    case "memory":
      return new MemoryRuntime(node.id, node.config, seed);
    case "relation":
      return new RelationRuntime(node.id, node.config, seed);
    case "generation":
      return new GenerationRuntime(node.id, node.config, seed);
  }
}

export function createRuntimeMap(genome: NetworkGenome): Map<string, PrimitiveRuntime> {
  return new Map(genome.nodes.map((node, index) => [node.id, createPrimitiveRuntime(node, genome.seed + index)]));
}

export function validateGenome(genome: NetworkGenome): ValidationReport {
  const issues: ValidationIssue[] = [];
  const nodeIds = new Set<string>();
  const portsByNode = new Map<string, Map<string, PortSpec>>();

  genome.nodes.forEach((node) => {
    if (nodeIds.has(node.id)) issues.push({ severity: "error", code: "DUPLICATE_NODE", message: `Node id "${node.id}" appears more than once.`, nodeId: node.id });
    nodeIds.add(node.id);
    if (node.config.inputSize < 1 || node.config.outputSize < 1) {
      issues.push({ severity: "error", code: "INVALID_DIMENSION", message: "Primitive dimensions must be positive.", nodeId: node.id });
    }
    const definition = primitiveDefinitions[node.primitive];
    portsByNode.set(node.id, new Map([...definition.inputs, ...definition.outputs].map((port) => [port.name, port])));
  });

  const adjacency = new Map<string, string[]>();
  genome.nodes.forEach((node) => adjacency.set(node.id, []));
  genome.connections.forEach((connection) => {
    const fromPorts = portsByNode.get(connection.from);
    const toPorts = portsByNode.get(connection.to);
    if (!nodeIds.has(connection.from) || !nodeIds.has(connection.to)) {
      issues.push({ severity: "error", code: "MISSING_NODE", message: "Connection references a node that does not exist.", connectionId: connection.id });
      return;
    }
    if (!fromPorts?.has(connection.fromPort) || !toPorts?.has(connection.toPort)) {
      issues.push({ severity: "error", code: "MISSING_PORT", message: `The connection "${connection.fromPort} → ${connection.toPort}" is not available on these primitives.`, connectionId: connection.id });
    }
    const toPort = toPorts?.get(connection.toPort);
    const fromNode = genome.nodes.find((node) => node.id === connection.from);
    const toNode = genome.nodes.find((node) => node.id === connection.to);
    if (toPort?.kind === "tensor" && fromNode && toNode && fromNode.config.outputSize !== toNode.config.inputSize && connection.transform !== "project" && connection.transform !== "sum") {
      issues.push({ severity: "warning", code: "DIMENSION_ADAPTER", message: `${fromNode.config.outputSize} dimensions feed ${toNode.config.inputSize}; add a project or sum adapter.`, connectionId: connection.id });
    }
    adjacency.get(connection.from)?.push(connection.to);
  });

  const visited = new Set<string>();
  const active = new Set<string>();
  let depth = 0;
  const visit = (id: string, currentDepth: number) => {
    if (active.has(id)) {
      issues.push({ severity: "warning", code: "RECURRENT_CYCLE", message: "Cycle detected; execution will use persistent state across steps.", nodeId: id });
      return;
    }
    if (visited.has(id)) return;
    visited.add(id);
    active.add(id);
    depth = Math.max(depth, currentDepth);
    adjacency.get(id)?.forEach((next) => visit(next, currentDepth + 1));
    active.delete(id);
  };
  genome.nodes.forEach((node) => visit(node.id, 1));
  if (!genome.nodes.length) issues.push({ severity: "error", code: "EMPTY_GENOME", message: "A genome needs at least one primitive." });
  if (!genome.nodes.some((node) => node.primitive === "generation")) {
    issues.push({ severity: "warning", code: "NO_GENERATOR", message: "No generation/selection primitive is present; the network has no explicit next-state output." });
  }

  return {
    valid: !issues.some((issue) => issue.severity === "error"),
    issues,
    stats: {
      nodes: genome.nodes.length,
      connections: genome.connections.length,
      primitives: new Set(genome.nodes.map((node) => node.primitive)).size,
      depth,
      parameters: genome.nodes.reduce((total, node) => total + node.config.inputSize * node.config.outputSize, 0),
    },
  };
}

export function executeGenome(genome: NetworkGenome, input: Tensor, steps = 1): { output: Tensor; snapshots: StateSnapshot[] } {
  const runtimeMap = createRuntimeMap(genome);
  const values = new Map<string, Tensor>();
  const snapshots: StateSnapshot[] = [];
  const incoming = new Map<string, GenomeConnection[]>();
  genome.nodes.forEach((node) => incoming.set(node.id, []));
  genome.connections.forEach((connection) => incoming.get(connection.to)?.push(connection));

  let currentInput = [...input];
  for (let step = 0; step < steps; step += 1) {
    genome.nodes.forEach((node) => {
      const inputs: Record<string, Tensor> = {};
      const nodeInputs = incoming.get(node.id) ?? [];
      if (!nodeInputs.length) inputs.state = currentInput;
      nodeInputs.forEach((connection) => {
        const source = values.get(connection.from) ?? currentInput;
        inputs[connection.toPort] = connection.transform === "sum" ? source.map((value, index) => value + (inputs[connection.toPort]?.[index] ?? 0)) : source;
      });
      const output = runtimeMap.get(node.id)?.forward(inputs, step) ?? {};
      Object.values(output).forEach((tensor) => values.set(node.id, tensor));
      const snapshot = runtimeMap.get(node.id)?.inspect();
      if (snapshot) snapshots.push(snapshot);
    });
    const terminal = genome.nodes.at(-1);
    currentInput = terminal ? values.get(terminal.id) ?? currentInput : currentInput;
  }
  return { output: currentInput, snapshots };
}

function node(id: string, primitive: PrimitiveKind, label: string, inputSize: number, outputSize: number, activationName: ActivationName = "tanh"): GenomeNode {
  return { id, primitive, label, config: { inputSize, outputSize, activation: activationName }, position: { x: 0, y: 0 } };
}

function baseGenome(id: string, name: string, seed: number, nodes: GenomeNode[], connections: GenomeConnection[], description: string, tags: string[]): NetworkGenome {
  return { version: 1, id, name, seed, nodes, connections, state: {}, learning: { name: "gradientDescent", learningRate: 0.01, loss: "mse", optimizer: "adam" }, metadata: { species: name, tags, description } };
}

export function getArchitectureTemplates(): ArchitectureTemplate[] {
  return [
    {
      id: "mlp",
      name: "Layered mapper",
      family: "MLP equivalent",
      description: "A feed-forward composition of learned transformations.",
      tags: ["transformation", "feed-forward"],
      genome: baseGenome("species-mlp", "Layered mapper", 11, [node("input", "transformation", "Input projection", 8, 16), node("hidden", "transformation", "Nonlinear features", 16, 16), node("output", "transformation", "Output projection", 16, 4, "identity")], [
        { id: "e1", from: "input", fromPort: "state", to: "hidden", toPort: "state", transform: "identity" },
        { id: "e2", from: "hidden", fromPort: "state", to: "output", toPort: "state", transform: "identity" },
      ], "A familiar architecture reconstructed from the smallest learned mapping primitive.", ["baseline", "feed-forward"]),
    },
    {
      id: "cnn",
      name: "Neighborhood field",
      family: "CNN equivalent",
      description: "Relation over local neighborhoods followed by a transformation.",
      tags: ["relation", "local", "transformation"],
      genome: baseGenome("species-cnn", "Neighborhood field", 23, [node("field", "relation", "Local receptive field", 16, 16), node("features", "transformation", "Shared feature map", 16, 8)], [
        { id: "e1", from: "field", fromPort: "message", to: "features", toPort: "state", transform: "identity" },
      ], "A convolution-like local relation is represented as a relation operator with a neighborhood configuration.", ["vision", "local"]),
    },
    {
      id: "rnn",
      name: "Stateful loop",
      family: "RNN / LSTM equivalent",
      description: "A transformation feeding a persistent memory update.",
      tags: ["transformation", "memory", "recurrent"],
      genome: baseGenome("species-rnn", "Stateful loop", 31, [node("encode", "transformation", "Input encoding", 8, 16), node("state", "memory", "Persistent state", 16, 16)], [
        { id: "e1", from: "encode", fromPort: "state", to: "state", toPort: "input", transform: "identity" },
      ], "Gates and recurrence emerge from the memory update rule, not from a named RNN primitive.", ["sequence", "recurrent"]),
    },
    {
      id: "transformer",
      name: "Context selector",
      family: "Transformer equivalent",
      description: "Relation and memory coordinate context before generation.",
      tags: ["relation", "memory", "generation"],
      genome: baseGenome("species-transformer", "Context selector", 47, [node("context", "relation", "Token relation", 16, 16), node("cache", "memory", "Context cache", 16, 16), node("decode", "generation", "Next token", 16, 8)], [
        { id: "e1", from: "context", fromPort: "message", to: "cache", toPort: "input", transform: "identity" },
        { id: "e2", from: "cache", fromPort: "state", to: "decode", toPort: "state", transform: "identity" },
      ], "Attention-like selection is expressed as relation plus persistent context and a discrete generator.", ["sequence", "attention"]),
    },
    {
      id: "gnn",
      name: "Message graph",
      family: "GNN equivalent",
      description: "Repeated relation and transformation over graph messages.",
      tags: ["relation", "transformation", "graph"],
      genome: baseGenome("species-gnn", "Message graph", 59, [node("aggregate", "relation", "Neighbor messages", 12, 12), node("update", "transformation", "Node update", 12, 12)], [
        { id: "e1", from: "aggregate", fromPort: "message", to: "update", toPort: "state", transform: "identity" },
      ], "Graph message passing is a composition of relation over neighbors and node-state transformation.", ["graph", "message-passing"]),
    },
    {
      id: "vae",
      name: "Latent bridge",
      family: "VAE / VQ-VAE equivalent",
      description: "Encode, compress, select a latent, and decode.",
      tags: ["transformation", "generation", "latent"],
      genome: baseGenome("species-vae", "Latent bridge", 71, [node("encode", "transformation", "Encoder", 16, 4), node("latent", "generation", "Latent selector", 4, 4), node("decode", "transformation", "Decoder", 4, 16, "identity")], [
        { id: "e1", from: "encode", fromPort: "state", to: "latent", toPort: "state", transform: "identity" },
        { id: "e2", from: "latent", fromPort: "next", to: "decode", toPort: "state", transform: "identity" },
      ], "A bottleneck and discrete selection emerge from ordinary transformations plus generation.", ["latent", "generative"]),
    },
    {
      id: "hopfield",
      name: "Attractor field",
      family: "Hopfield equivalent",
      description: "Relation scores a query against persistent associative memory.",
      tags: ["relation", "memory", "associative"],
      genome: baseGenome("species-hopfield", "Attractor field", 83, [node("memory", "memory", "Stored patterns", 16, 16), node("match", "relation", "Pattern match", 16, 16, "identity")], [
        { id: "e1", from: "memory", fromPort: "state", to: "match", toPort: "context", transform: "identity" },
      ], "Associative recall is relation over a stateful store; the attractor behavior comes from repeated execution.", ["associative", "energy"]),
    },
    {
      id: "nca",
      name: "Cell field",
      family: "Neural cellular automata equivalent",
      description: "Local relation, memory, and transformation update a cell field.",
      tags: ["relation", "memory", "transformation", "local"],
      genome: baseGenome("species-nca", "Cell field", 97, [node("neighbors", "relation", "Cell neighborhood", 8, 8), node("cell", "memory", "Cell state", 8, 8), node("rule", "transformation", "Update rule", 8, 8)], [
        { id: "e1", from: "neighbors", fromPort: "message", to: "cell", toPort: "input", transform: "sum" },
        { id: "e2", from: "cell", fromPort: "state", to: "rule", toPort: "state", transform: "identity" },
      ], "Cellular automata behavior comes from local relation and repeated memory updates under a shared rule.", ["cellular", "local"]),
    },
    {
      id: "world-model",
      name: "Predictive simulator",
      family: "World model equivalent",
      description: "Encode observations, integrate latent state, and predict a next state.",
      tags: ["transformation", "memory", "generation"],
      genome: baseGenome("species-world-model", "Predictive simulator", 113, [node("observe", "transformation", "Observation encoder", 12, 16), node("latent", "memory", "World state", 16, 16), node("predict", "generation", "Future state", 16, 12)], [
        { id: "e1", from: "observe", fromPort: "state", to: "latent", toPort: "input", transform: "identity" },
        { id: "e2", from: "latent", fromPort: "state", to: "predict", toPort: "state", transform: "identity" },
      ], "A predictive model is a memory operator paired with a generator over a learned latent state.", ["dynamics", "predictive"]),
    },
  ];
}

export function cloneGenome(genome: NetworkGenome): NetworkGenome {
  return JSON.parse(JSON.stringify(genome)) as NetworkGenome;
}

export function mutateGenome(genome: NetworkGenome, seed = genome.seed + 1): NetworkGenome {
  const random = seededRandom(seed);
  const next = cloneGenome(genome);
  const mutation = random();
  if (mutation < 0.25 || next.nodes.length < 2) {
    const kinds: PrimitiveKind[] = ["transformation", "memory", "relation", "generation"];
    const primitive = kinds[Math.floor(random() * kinds.length)];
    const id = `${primitive}-${next.nodes.length + 1}`;
    const previous = next.nodes.at(-1);
    next.nodes.push(node(id, primitive, `Mutant ${primitive}`, previous?.config.outputSize ?? 8, previous?.config.outputSize ?? 8));
    if (previous) next.connections.push({ id: `e${next.connections.length + 1}`, from: previous.id, fromPort: primitive === "generation" ? "next" : primitive === "relation" ? "message" : "state", to: id, toPort: primitive === "memory" ? "input" : "state", transform: "project" });
  } else if (mutation < 0.5 && next.connections.length) {
    const index = Math.floor(random() * next.connections.length);
    next.connections.splice(index, 1);
  } else if (mutation < 0.75 && next.nodes.length > 1) {
    const index = Math.floor(random() * next.nodes.length);
    const current = next.nodes[index];
    const kinds: PrimitiveKind[] = ["transformation", "memory", "relation", "generation"];
    current.primitive = kinds[Math.floor(random() * kinds.length)];
    current.label = `Mutated ${current.primitive}`;
  } else {
    next.connections.forEach((connection) => {
      if (random() > 0.5) connection.transform = "project";
    });
  }
  next.id = `${genome.id}-mutant-${seed}`;
  next.name = `${genome.name} / mutation ${seed}`;
  next.seed = seed;
  return next;
}

export function crossoverGenomes(left: NetworkGenome, right: NetworkGenome, seed = left.seed + right.seed): NetworkGenome {
  const split = Math.max(1, Math.floor(left.nodes.length / 2));
  const leftNodes = left.nodes.slice(0, split);
  const rightNodes = right.nodes.slice(Math.floor(right.nodes.length / 2));
  const nodesById = new Map([...leftNodes, ...rightNodes].map((item) => [item.id, { ...item }]));
  const nodes = [...nodesById.values()].map((item, index) => ({ ...item, id: `${item.id}-x${index + 1}` }));
  const remap = new Map([...nodesById.keys()].map((id, index) => [id, `${id}-x${index + 1}`]));
  const connections = [...left.connections, ...right.connections]
    .filter((connection) => remap.has(connection.from) && remap.has(connection.to))
    .slice(0, Math.max(0, nodes.length - 1))
    .map((connection, index) => ({ ...connection, id: `cross-${index + 1}`, from: remap.get(connection.from) ?? connection.from, to: remap.get(connection.to) ?? connection.to }));
  return {
    version: 1,
    id: `cross-${left.id}-${right.id}`,
    name: `${left.name} × ${right.name}`,
    seed,
    nodes,
    connections,
    state: {},
    learning: { ...left.learning },
    metadata: { species: "cross-breed", tags: [...new Set([...(left.metadata?.tags ?? []), ...(right.metadata?.tags ?? [])])], description: "A valid offspring assembled from two network species." },
  };
}

function cloneTensor(values: Tensor): Tensor {
  return [...values];
}

function lossValue(prediction: Tensor, target: Tensor, name: LossName | "energy" = "mse"): number {
  const length = Math.max(prediction.length, target.length, 1);
  if (name === "cosine") {
    const pNorm = Math.sqrt(prediction.reduce((sum, value) => sum + value * value, 0)) || 1;
    const tNorm = Math.sqrt(target.reduce((sum, value) => sum + value * value, 0)) || 1;
    const cosine = prediction.reduce((sum, value, index) => sum + value * (target[index] ?? 0), 0) / (pNorm * tNorm);
    return 1 - cosine;
  }
  if (name === "crossEntropy" || name === "binaryCrossEntropy") {
    const probabilities = name === "binaryCrossEntropy" ? prediction.map((value) => Math.min(1 - 1e-7, Math.max(1e-7, value))) : softmax(prediction);
    return target.reduce((sum, expected, index) => {
      const probability = name === "binaryCrossEntropy" ? (probabilities[index] ?? 0.5) : (probabilities[index] ?? 1e-7);
      return sum - expected * Math.log(probability) - (1 - expected) * Math.log(1 - probability);
    }, 0) / length;
  }
  return prediction.reduce((sum, value, index) => sum + (value - (target[index] ?? 0)) ** 2, 0) / length;
}

function lossGradient(prediction: Tensor, target: Tensor, name: LossName | "energy" = "mse"): Tensor {
  if (name === "cosine") {
    return prediction.map((value, index) => value - (target[index] ?? 0));
  }
  return prediction.map((value, index) => {
    const expected = target[index] ?? 0;
    if (name === "crossEntropy" || name === "binaryCrossEntropy") return value - expected;
    return (2 * (value - expected)) / Math.max(prediction.length, 1);
  });
}

function deterministicShuffle<T>(items: T[], seed: number): T[] {
  const random = seededRandom(seed);
  const output = [...items];
  for (let index = output.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(random() * (index + 1));
    [output[index], output[swapIndex]] = [output[swapIndex], output[index]];
  }
  return output;
}

export function splitDataset(samples: TrainingSample[], validationSplit = 0.2, testSplit = 0.1, seed = 1, shuffle = true): DatasetSplit {
  const source = shuffle ? deterministicShuffle(samples, seed) : [...samples];
  const safeValidation = Math.min(0.5, Math.max(0, validationSplit));
  const safeTest = Math.min(0.5 - safeValidation, Math.max(0, testSplit));
  const testCount = Math.floor(source.length * safeTest);
  const validationCount = Math.floor(source.length * safeValidation);
  return {
    train: source.slice(0, Math.max(0, source.length - validationCount - testCount)),
    validation: source.slice(Math.max(0, source.length - validationCount - testCount), Math.max(0, source.length - testCount)),
    test: testCount ? source.slice(-testCount) : [],
  };
}

function argmax(values: Tensor): number {
  return values.reduce((best, value, index) => value > (values[best] ?? -Infinity) ? index : best, 0);
}

function accuracyFor(prediction: Tensor, target: Tensor): number {
  if (!prediction.length || !target.length) return 0;
  if (prediction.length > 1 || target.length > 1) return argmax(prediction) === argmax(target) ? 1 : 0;
  return Math.max(0, 1 - Math.abs(prediction[0] - target[0]));
}

function sumSquares(values: number[]): number {
  return Math.sqrt(values.reduce((sum, value) => sum + value * value, 0));
}

export class NetworkRuntime {
  readonly runtimes: Map<string, PrimitiveRuntime>;
  private readonly incoming: Map<string, GenomeConnection[]>;
  private readonly genome: NetworkGenome;
  private readonly outputs = new Map<string, Record<string, Tensor>>();

  constructor(genome: NetworkGenome, learned?: LearnedNetworkState) {
    this.genome = genome;
    this.runtimes = createRuntimeMap(genome);
    this.incoming = new Map();
    genome.nodes.forEach((node) => this.incoming.set(node.id, []));
    genome.connections.forEach((connection) => this.incoming.get(connection.to)?.push(connection));
    if (learned) this.importLearnedState(learned);
  }

  resetState(): void {
    this.runtimes.forEach((runtime) => runtime.resetState());
    this.outputs.clear();
  }

  forward(input: Tensor, steps = 1): { output: Tensor; snapshots: StateSnapshot[] } {
    const snapshots: StateSnapshot[] = [];
    let currentInput = cloneTensor(input);
    for (let step = 0; step < Math.max(1, steps); step += 1) {
      this.genome.nodes.forEach((node) => {
        const inputs: Record<string, Tensor> = {};
        const connections = this.incoming.get(node.id) ?? [];
        if (!connections.length) inputs.state = currentInput;
        connections.forEach((connection) => {
          const source = this.outputs.get(connection.from)?.[connection.fromPort] ?? currentInput;
          const prior = inputs[connection.toPort];
          if (connection.transform === "sum" && prior) {
            inputs[connection.toPort] = source.map((value, index) => value + (prior[index] ?? 0));
          } else {
            inputs[connection.toPort] = connection.transform === "concat" && prior ? [...prior, ...source] : [...source];
          }
        });
        const nodeOutput = this.runtimes.get(node.id)?.forward(inputs, step) ?? {};
        this.outputs.set(node.id, nodeOutput);
        const snapshot = this.runtimes.get(node.id)?.inspect();
        if (snapshot) snapshots.push(snapshot);
      });
      const terminal = this.genome.nodes.at(-1);
      const terminalOutput = terminal ? this.outputs.get(terminal.id) : undefined;
      currentInput = terminalOutput?.next ?? terminalOutput?.state ?? terminalOutput?.message ?? currentInput;
    }
    return { output: cloneTensor(currentInput), snapshots };
  }

  parameterVector(): number[] {
    return this.genome.nodes.flatMap((node) => this.runtimes.get(node.id)?.getParameters() ?? []);
  }

  parameterOwners(): string[] {
    return this.genome.nodes.flatMap((node) => Array.from({ length: this.runtimes.get(node.id)?.getParameters().length ?? 0 }, () => node.id));
  }

  setParameterVector(parameters: number[]): void {
    let offset = 0;
    this.genome.nodes.forEach((node) => {
      const runtime = this.runtimes.get(node.id);
      const count = runtime?.getParameters().length ?? 0;
      runtime?.setParameters(parameters.slice(offset, offset + count));
      offset += count;
    });
  }

  exportLearnedState(optimizerState: Record<string, number[]> = {}, step = 0): LearnedNetworkState {
    return {
      parameters: Object.fromEntries(this.genome.nodes.map((node) => [node.id, this.runtimes.get(node.id)?.getParameters() ?? []])),
      state: Object.fromEntries(this.genome.nodes.map((node) => [node.id, this.runtimes.get(node.id)?.inspect().values ?? []])),
      optimizerState: { ...optimizerState },
      step,
    };
  }

  importLearnedState(learned: LearnedNetworkState): void {
    this.genome.nodes.forEach((node) => {
      const runtime = this.runtimes.get(node.id);
      const parameters = learned.parameters[node.id];
      if (runtime && parameters) runtime.setParameters(parameters);
    });
    this.runtimes.forEach((runtime, nodeId) => {
      const state = learned.state[nodeId];
      if (state) runtime.setState(state, learned.step);
    });
  }

  computeLoss(samples: TrainingSample[], loss: LossName | "energy" = "mse"): { loss: number; accuracy: number } {
    if (!samples.length) return { loss: 0, accuracy: 0 };
    let totalLoss = 0;
    let totalAccuracy = 0;
    samples.forEach((sample) => {
      this.resetState();
      const prediction = this.forward(sample.input).output;
      totalLoss += lossValue(prediction, sample.target, loss) * (sample.weight ?? 1);
      totalAccuracy += accuracyFor(prediction, sample.target) * (sample.weight ?? 1);
    });
    return { loss: totalLoss / samples.length, accuracy: totalAccuracy / samples.length };
  }

  backward(sample: TrainingSample, loss: LossName | "energy" = "mse", epsilon = 1e-3): number[] {
    const baseline = this.parameterVector();
    const gradients = Array.from({ length: baseline.length }, () => 0);
    for (let index = 0; index < baseline.length; index += 1) {
      const plus = [...baseline];
      plus[index] += epsilon;
      this.setParameterVector(plus);
      this.resetState();
      const plusLoss = lossValue(this.forward(sample.input).output, sample.target, loss);
      const minus = [...baseline];
      minus[index] -= epsilon;
      this.setParameterVector(minus);
      this.resetState();
      const minusLoss = lossValue(this.forward(sample.input).output, sample.target, loss);
      gradients[index] = (plusLoss - minusLoss) / (2 * epsilon);
    }
    this.setParameterVector(baseline);
    this.resetState();
    const prediction = this.forward(sample.input).output;
    const outputGradient = lossGradient(prediction, sample.target, loss);
    this.genome.nodes.forEach((node) => this.runtimes.get(node.id)?.backward(outputGradient, 0));
    return gradients;
  }
}

function updateWithOptimizer(parameters: number[], gradients: number[], optimizerState: Record<string, number[]>, config: TrainingConfig, step: number, genome: NetworkGenome, owners: string[]): { parameters: number[]; norm: number } {
  const optimizer = config.optimizer ?? "adam";
  const mechanism = config.mechanism ?? genome.learning.name;
  const clip = config.gradientClip ?? genome.learning.gradientClip ?? 5;
  const clipped = gradients.map((value) => Math.max(-clip, Math.min(clip, value)));
  const norm = sumSquares(clipped);
  const rates = config.moduleLearningRates ?? genome.learning.moduleLearningRates ?? {};
  const defaultRate = config.learningRate ?? genome.learning.learningRate ?? 0.01;
  const parameterRates: number[] = [];
  owners.forEach((owner) => parameterRates.push(rates[owner] ?? defaultRate));
  while (parameterRates.length < parameters.length) parameterRates.push(defaultRate);
  const frozen = new Set(config.frozenNodes ?? genome.learning.frozenNodes ?? []);
  const next = parameters.map((parameter, index) => {
    const nodeId = owners[index] ?? genome.nodes[0]?.id;
    if (nodeId && frozen.has(nodeId)) return parameter;
    const rate = parameterRates[index] ?? defaultRate;
    if (mechanism === "hebbian" || mechanism === "local") {
      const localSignal = Math.sign(clipped[index] ?? 0) || 1;
      return parameter + (mechanism === "hebbian" ? rate * localSignal * Math.abs(parameter) : -rate * clipped[index]);
    }
    if (mechanism === "reinforce") {
      return parameter - rate * clipped[index] * (clipped[index] >= 0 ? 0.5 : 1);
    }
    if (mechanism === "competitive") {
      return parameter - rate * (Math.abs(clipped[index]) > (norm / Math.max(1, clipped.length)) ? clipped[index] : 0);
    }
    if (optimizer === "sgd") return parameter - rate * clipped[index];
    if (optimizer === "momentum") {
      const velocity = optimizerState.velocity ?? Array.from({ length: parameters.length }, () => 0);
      velocity[index] = 0.9 * (velocity[index] ?? 0) - rate * clipped[index];
      optimizerState.velocity = velocity;
      return parameter + velocity[index];
    }
    if (optimizer === "rmsprop") {
      const average = optimizerState.average ?? Array.from({ length: parameters.length }, () => 0);
      average[index] = 0.9 * (average[index] ?? 0) + 0.1 * clipped[index] ** 2;
      optimizerState.average = average;
      return parameter - rate * clipped[index] / (Math.sqrt(average[index]) + 1e-8);
    }
    const first = optimizerState.first ?? Array.from({ length: parameters.length }, () => 0);
    const second = optimizerState.second ?? Array.from({ length: parameters.length }, () => 0);
    first[index] = 0.9 * (first[index] ?? 0) + 0.1 * clipped[index];
    second[index] = 0.999 * (second[index] ?? 0) + 0.001 * clipped[index] ** 2;
    optimizerState.first = first;
    optimizerState.second = second;
    const biasCorrectionFirst = 1 - 0.9 ** step;
    const biasCorrectionSecond = 1 - 0.999 ** step;
    return parameter - rate * (first[index] / biasCorrectionFirst) / (Math.sqrt(second[index] / biasCorrectionSecond) + 1e-8);
  });
  return { parameters: next, norm };
}

export function trainNetwork(genome: NetworkGenome, samples: TrainingSample[], config: TrainingConfig = {}, initial?: NetworkCheckpoint | LearnedNetworkState): TrainingResult {
  const report = validateGenome(genome);
  if (!report.valid) throw new Error(`Cannot train invalid genome: ${report.issues.filter((issue) => issue.severity === "error").map((issue) => issue.message).join(" ")}`);
  const seed = config.seed ?? genome.seed;
  const split = splitDataset(samples, config.validationSplit ?? 0.2, config.testSplit ?? 0.1, seed, config.shuffle ?? true);
  const runtime = new NetworkRuntime(genome, "genome" in (initial ?? {}) ? (initial as NetworkCheckpoint).learned : initial as LearnedNetworkState | undefined);
  const history: TrainingMetrics[] = [];
  const optimizerState: Record<string, number[]> = initial && "learned" in initial ? { ...initial.learned.optimizerState } : initial?.optimizerState ? { ...initial.optimizerState } : {};
  let bestValidation = Infinity;
  let bestEpoch = 0;
  let staleEpochs = 0;
  let step = initial && "learned" in initial ? initial.learned.step : initial?.step ?? 0;
  let bestLearned = runtime.exportLearnedState(optimizerState, step);
  const batchSize = config.online ? 1 : Math.max(1, config.batchSize ?? 8);
  const epochs = Math.max(1, config.steps ? Math.ceil(config.steps / Math.max(1, Math.ceil(split.train.length / batchSize))) : config.epochs ?? 10);
  for (let epoch = 0; epoch < epochs; epoch += 1) {
    const epochSamples = config.shuffle ? deterministicShuffle(split.train, seed + epoch) : split.train;
    let epochLoss = 0;
    let epochAccuracy = 0;
    let gradientNorm = 0;
    for (let start = 0; start < epochSamples.length; start += batchSize) {
      const batch = epochSamples.slice(start, start + batchSize);
      const gradients = Array.from({ length: runtime.parameterVector().length }, () => 0);
      batch.forEach((sample) => {
        const sampleGradient = runtime.backward(sample, genome.learning.loss ?? "mse");
        sampleGradient.forEach((value, index) => { gradients[index] += value / batch.length; });
      });
      const update = updateWithOptimizer(runtime.parameterVector(), gradients, optimizerState, config, step + 1, genome, runtime.parameterOwners());
      runtime.setParameterVector(update.parameters);
      gradientNorm += update.norm;
      batch.forEach((sample) => {
        runtime.resetState();
        const prediction = runtime.forward(sample.input).output;
        epochLoss += lossValue(prediction, sample.target, genome.learning.loss ?? "mse");
        epochAccuracy += accuracyFor(prediction, sample.target);
      });
      step += 1;
    }
    const sampleCount = Math.max(1, epochSamples.length);
    const validation = runtime.computeLoss(split.validation, genome.learning.loss ?? "mse");
    const metrics: TrainingMetrics = {
      epoch: epoch + 1,
      step,
      loss: epochLoss / sampleCount,
      validationLoss: split.validation.length ? validation.loss : undefined,
      accuracy: epochAccuracy / sampleCount,
      validationAccuracy: split.validation.length ? validation.accuracy : undefined,
      gradientNorm: gradientNorm / Math.max(1, Math.ceil(sampleCount / batchSize)),
      samples: epochSamples.length,
    };
    history.push(metrics);
    const monitored = metrics.validationLoss ?? metrics.loss;
    const minimumDelta = config.earlyStopping?.minDelta ?? 0;
    if (monitored < bestValidation - minimumDelta) {
      bestValidation = monitored;
      bestEpoch = epoch + 1;
      staleEpochs = 0;
      bestLearned = runtime.exportLearnedState(optimizerState, step);
    } else {
      staleEpochs += 1;
      if (config.earlyStopping && staleEpochs >= config.earlyStopping.patience) break;
    }
  }
  const learned = bestEpoch ? bestLearned : runtime.exportLearnedState(optimizerState, step);
  return { genome: cloneGenome(genome), learned, history, split, stoppedEarly: history.length < epochs, bestEpoch };
}

export function checkpointFromTraining(result: TrainingResult): NetworkCheckpoint {
  return { version: 1, genome: cloneGenome(result.genome), learned: JSON.parse(JSON.stringify(result.learned)) as LearnedNetworkState, epoch: result.history.at(-1)?.epoch ?? 0, metrics: [...result.history] };
}

export function serializeCheckpoint(checkpoint: NetworkCheckpoint): string {
  return JSON.stringify(checkpoint, null, 2);
}

export function loadCheckpoint(serialized: string): NetworkCheckpoint {
  const parsed = JSON.parse(serialized) as NetworkCheckpoint;
  if (parsed.version !== 1 || !parsed.genome || !parsed.learned) throw new Error("Invalid Neural Foundry checkpoint.");
  return parsed;
}

export function speciesFromTraining(result: TrainingResult, fitness?: number): NetworkSpecies {
  return { genome: cloneGenome(result.genome), learned: JSON.parse(JSON.stringify(result.learned)) as LearnedNetworkState, fitness, metrics: result.history.at(-1) };
}

export function cloneSpecies(species: NetworkSpecies): NetworkSpecies {
  return JSON.parse(JSON.stringify(species)) as NetworkSpecies;
}

export function continueTraining(species: NetworkSpecies, samples: TrainingSample[], config: TrainingConfig = {}): NetworkSpecies {
  const result = trainNetwork(species.genome, samples, { ...config, seed: config.seed ?? species.genome.seed + species.learned.step }, species.learned);
  return speciesFromTraining(result, species.fitness);
}

export function evaluateNetwork(genome: NetworkGenome, samples: TrainingSample[], learned?: LearnedNetworkState, loss?: LossName | "energy"): EvaluationResult {
  const runtime = new NetworkRuntime(genome, learned);
  const metrics = runtime.computeLoss(samples, loss ?? genome.learning.loss ?? "mse");
  const threshold = loss === "crossEntropy" || genome.learning.loss === "crossEntropy" ? 1.5 : 0.5;
  return { ...metrics, samples: samples.length, passed: metrics.loss <= threshold || metrics.accuracy >= 0.75 };
}

export function benchmarkArchitectures(samplesPerTemplate = 1): ArchitectureTestResult[] {
  return getArchitectureTemplates().map((template) => {
    try {
      const inputSize = template.genome.nodes[0]?.config.inputSize ?? 4;
      const outputSize = template.genome.nodes.at(-1)?.config.outputSize ?? 2;
      const samples = Array.from({ length: Math.max(1, samplesPerTemplate) }, (_, index) => ({
        input: Array.from({ length: inputSize }, (_, valueIndex) => ((index + valueIndex + 1) % 7) / 7),
        target: Array.from({ length: outputSize }, (_, valueIndex) => valueIndex === index % outputSize ? 1 : 0),
      }));
      const report = validateGenome(template.genome);
      if (!report.valid) return { architecture: template.name, valid: false, trainable: false, error: report.issues.find((issue) => issue.severity === "error")?.message };
      const trained = trainNetwork(template.genome, samples, { epochs: 1, batchSize: 1, validationSplit: 0, testSplit: 0, seed: template.genome.seed });
      const evaluation = evaluateNetwork(trained.genome, samples, trained.learned);
      return { architecture: template.family, valid: true, trainable: evaluation.samples > 0, trainedLoss: evaluation.loss };
    } catch (error) {
      return { architecture: template.name, valid: false, trainable: false, error: error instanceof Error ? error.message : "Unknown architecture test error" };
    }
  });
}

export function evolveAndCompare(parent: NetworkSpecies, samples: TrainingSample[], config: TrainingConfig = {}): EvolutionComparison {
  const parentEvaluation = evaluateNetwork(parent.genome, samples, parent.learned);
  const mutated = mutateGenome(parent.genome, parent.genome.seed + parent.learned.step + 1);
  const trained = trainNetwork(mutated, samples, { ...config, seed: mutated.seed }, undefined);
  const offspring = speciesFromTraining(trained);
  const offspringEvaluation = evaluateNetwork(offspring.genome, samples, offspring.learned);
  return {
    parent,
    offspring,
    parentEvaluation,
    offspringEvaluation,
    keepOffspring: offspringEvaluation.loss <= parentEvaluation.loss || offspringEvaluation.accuracy > parentEvaluation.accuracy,
  };
}