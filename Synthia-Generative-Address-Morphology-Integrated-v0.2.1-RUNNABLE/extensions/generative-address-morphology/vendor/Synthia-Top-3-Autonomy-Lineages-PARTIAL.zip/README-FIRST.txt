SYNTHIA — TOP 3 AUTONOMY LINEAGES
=================================

Requested:
1) Synthia-Organism-OS-r22.0-COHERENT-EXECUTION-PHONE-MERGE.zip
2) Adaya-Automaton-ORGANISM-v0_11_15-r21_15-ATO-FACTORY-ARMS-SYNTHIA.zip
3) Synthia-Atomic-Organism-v1.0.0.zip

IMPORTANT
---------
The exact binary archives for the three requested historical builds are not all
currently recoverable from the accessible Library/Drive surfaces.

This bundle therefore DOES NOT pretend checksum files are the source archives.

Included:
- r22 coherent verification + MERGE-STATUS
- r21.15 exact recorded SHA-256 provenance
- Atomic Organism v1.0.0 exact recorded SHA-256 provenance
- 00-Synthia-Core-Organism-r21.21.zip, the actual available later organism chassis
  source, included separately as a usable reference rather than mislabeled as r21.15
  or r22.

Recorded hashes:
r21.15 ATO/Factory/Arms:
7188eab42410ce5083fb921bd09a8dd1deba73319313f4bef12847bbd8ccf573

Atomic Organism v1.0.0:
c41db406aa9d9a7b922aa15fdbac5f13d70eb7854c6f0125722407574ec9dd5d

r22 coherent source (from verification):
daf9c2b7ab195c78f7c8c9cbb37c2c5cf985642ab847f67486141826f6753f92

No historical archive was reconstructed or silently substituted.
