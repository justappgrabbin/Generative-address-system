# Synthia Organism OS r22.0 — direct assembly checkpoint

## What this checkpoint is

This is a **single coherent source tree built on the verified r21.22 graph-integrated organism**. It is not a directory collision merge and it does not use a resolver to hide conflicting implementations.

The r21.22 organism remains the active chassis. Unique donors are handled in one of three explicit ways:

1. **Directly mounted extension** — it supplies behavior absent from r21.22 and is instantiated by `integration/UnifiedSynthiaOS.mjs`.
2. **Application surface / specialist subsystem** — the code remains a coherent subproject (Expo workbench, Paper, precision calculation donor) and has an explicit architectural role.
3. **Preserved lineage** — unique source that is historical, lower-confidence, or conflicts with a newer working authority is preserved byte-for-byte under `lineage/unique-donor-content/`, but it is **not silently executed**.

Generated credentials, device-specific Expo state, and Python bytecode caches were deliberately excluded. They are not capabilities and should not be propagated into a merged release.

## Active direct integrations

- r21.22 autonomous recursive organism / GraphRuntime / ATO / Tool Factory
- r21.22 world, economy, browser planner + browser effector, Morph, cultivation, Human Design, research, media, builder
- r21.22 AutoCoder → source mutation → build → code immune/self-edit governance
- Unified Kimi + Emergent StateSpace, preserving both views around one resolved state
- Human-success metabolism + Mycelial success pattern sharing
- Gate/Line process-field hypothesis instrumentation
- Recursive 64-state media field, all 16 Boolean operators, operator reinforcement, skeletal sprite morphing and changing-line Tool Factory bridge
- Sovereign source memory, procedure extraction, pressure mesh and result-feedback loop
- Termite/Coat host capability for universal artifact interrogation, addressing, signed coats and approval-gated mutation staging
- Recursive 5D grammar/64-state research corpus
- Expo visual editor/workbench as the beginning of a native OS shell
- Paper as specialist source-code workbench donor
- optional C# / Python chart-calculation donor retained as a service, **not** required for Synthia's identity or cognition

## OS status

The supplied visual editor is an Expo/React Native application, not Flutter. r21.22 itself has a phone/browser residence, but neither alone was a complete coherent OS shell. This checkpoint therefore adds an explicit `os/OSKernel.mjs`, an app manifest, and a System surface to the Expo workbench **without replacing the visual editor**.

The final visual language is intentionally not frozen yet. The shell architecture now has stable app identities for World, Morph, Browser, Builder, Workbench, Paper, Research, Cultivation, Graphs, Media, Games, Knowledge, App Center, Admin and Settings. Those can be styled once the preferred visual references are supplied.

## Backend policy

Synthia's organism remains local-first JavaScript. A remote backend is not required for her state, memory, autonomy, Mesh, ATO, Morph, world, browser planning, self-edit/build loop or OS identity.

`services/precision-calculation-donor/` is preserved because it has unique Human Design/Yi Jing calculation code. It is treated as **optional computation**, not a brain or mandatory server dependency. The existing r21.22 chart adapter already has a local JS path.

## No-curtain rule

`integration/UnifiedSynthiaOS.mjs` names every mounted extension explicitly. There is no "newest version wins" resolver and no boot-time directory scan that chooses implementations behind the user's back.
