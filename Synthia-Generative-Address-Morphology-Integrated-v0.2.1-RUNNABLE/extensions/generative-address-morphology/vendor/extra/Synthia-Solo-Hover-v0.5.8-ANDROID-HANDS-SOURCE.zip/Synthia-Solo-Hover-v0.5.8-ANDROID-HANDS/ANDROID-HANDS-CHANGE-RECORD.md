# Solo 5.8 Android Hands Change Record

## Baseline
Source authority: Synthia-Solo-Hover-v0.5.8-FINAL-CHECKPOINT. Existing organism, UI, Solo runtime, persistence, browser-hand planner/memory/form automaton, vendor continuation, Linux scripts, tests and state were preserved.

## Added
- Android permission/body source under `android/`.
- Floating-dot foreground service using Android overlay permission.
- AccessibilityService for cross-app tree inspection, click, gesture and text-entry actions.
- Loopback-only HTTP bridge on `127.0.0.1:18758`.
- Linux-side `AndroidHandExecutor` and backend launch script.

## Changed
`src/solo/browser-hand-adapter.mjs` now selects AndroidHandExecutor only when `SYNTHIA_ANDROID_HAND=1` (or a bridge URL is supplied). Existing Chromium/CDP behavior remains the fallback and was not removed.

## Security boundary
The bridge binds to loopback only. Android still requires the user to explicitly grant overlay permission and enable the AccessibilityService. No code bypasses Android permission controls.

## Status
- Existing Solo 5.8 organism/runtime: preserved.
- Existing CDP hand: preserved.
- Android hand source: WIRED at source level from SoloBrowserHand -> AndroidHandExecutor -> loopback bridge -> AccessibilityService.
- Floating dot source: WIRED at source level to Android overlay permission/service.
- Linux backend selector: WIRED at source level through environment variables.
- Bundled Linux container/rootfs inside APK: PRESENTLY NOT INCLUDED. This package does not claim a standalone APK until a rootfs/Node runtime is selected and packaged.
- Device verification: NOT VERIFIED. It has not been installed/executed on an Android device from this environment.
