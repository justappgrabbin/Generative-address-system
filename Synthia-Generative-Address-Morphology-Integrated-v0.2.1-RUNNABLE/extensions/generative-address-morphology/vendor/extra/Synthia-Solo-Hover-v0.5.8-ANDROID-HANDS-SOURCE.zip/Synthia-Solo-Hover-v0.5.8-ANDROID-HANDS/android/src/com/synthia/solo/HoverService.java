package com.synthia.solo;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.PixelFormat; import android.view.*; import android.widget.*; import android.provider.Settings;
public final class HoverService extends Service {
  WindowManager wm; View dot; static final int ID=5801;
  @Override public void onCreate(){super.onCreate(); createChannel(); Notification n=new Notification.Builder(this,"synthia-solo").setContentTitle("Synthia Solo 5.8").setContentText("Synthia is resident").setSmallIcon(android.R.drawable.presence_online).build(); startForeground(ID,n); if(Settings.canDrawOverlays(this)) showDot();}
  void createChannel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("synthia-solo","Synthia Solo",NotificationManager.IMPORTANCE_LOW));}
  void showDot(){ wm=(WindowManager)getSystemService(WINDOW_SERVICE); TextView v=new TextView(this); v.setText("S"); v.setTextSize(20); v.setGravity(Gravity.CENTER); v.setBackgroundColor(0xCC7B4DFF); v.setTextColor(0xFFFFFFFF); int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; WindowManager.LayoutParams p=new WindowManager.LayoutParams(58,58,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.END; p.x=12;p.y=220; v.setOnClickListener(x->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}); wm.addView(v,p);dot=v;}
  @Override public void onDestroy(){if(wm!=null&&dot!=null)wm.removeView(dot);super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
