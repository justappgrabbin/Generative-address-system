package com.synthia.solo;
import android.app.*; import android.os.*; import android.provider.Settings; import android.content.*; import android.net.Uri; import android.view.*; import android.widget.*;
public final class MainActivity extends Activity {
  TextView status;
  @Override public void onCreate(Bundle b){ super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(32,32,32,32);
    status=new TextView(this); status.setTextSize(16); l.addView(status);
    Button overlay=new Button(this); overlay.setText("Allow floating dot"); overlay.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())))); l.addView(overlay);
    Button access=new Button(this); access.setText("Enable Synthia hands"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); l.addView(access);
    Button start=new Button(this); start.setText("Start Synthia Solo"); start.setOnClickListener(v->{ Intent i=new Intent(this,HoverService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); refresh();}); l.addView(start);
    setContentView(l); refresh(); }
  @Override protected void onResume(){super.onResume();refresh();}
  void refresh(){ if(status!=null) status.setText("Solo 5.8 Android body\nOverlay: "+(Settings.canDrawOverlays(this)?"ON":"OFF")+"\nHands: enable Synthia in Accessibility settings\nBackend: Linux must expose Solo on localhost; Android hand bridge listens on 127.0.0.1:18758"); }
}
