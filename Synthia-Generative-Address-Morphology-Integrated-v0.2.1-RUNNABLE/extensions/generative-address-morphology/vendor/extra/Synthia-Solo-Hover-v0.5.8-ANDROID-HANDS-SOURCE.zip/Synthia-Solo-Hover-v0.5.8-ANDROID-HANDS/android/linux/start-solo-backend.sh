#!/usr/bin/env sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)"
cd "$HERE"
export SYNTHIA_ANDROID_HAND=1
export SYNTHIA_ANDROID_HAND_URL=http://127.0.0.1:18758
exec node src/ui/server.mjs --host 127.0.0.1 --port 8787
