const freeze = (v) => Object.freeze(v);

/** Android cross-app hand client.
 * Talks only to the loopback bridge exposed by SynthiaAccessibilityService.
 * The Linux backend remains authoritative; Android owns permissioned phone I/O.
 */
export class AndroidHandExecutor {
  constructor({ baseUrl = process.env.SYNTHIA_ANDROID_HAND_URL || 'http://127.0.0.1:18758' } = {}) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.started = false;
    this.viewport = { width: 430, height: 760 };
  }
  static isConfigured() { return process.env.SYNTHIA_ANDROID_HAND === '1' || Boolean(process.env.SYNTHIA_ANDROID_HAND_URL); }
  async request(path, body = undefined) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const res = await fetch(`${this.baseUrl}${path}`, {
        method: body === undefined ? 'GET' : 'POST',
        headers: body === undefined ? {} : { 'content-type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body), signal: controller.signal,
      });
      const text = await res.text();
      let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
      if (!res.ok) throw new Error(`Android hand ${res.status}: ${data?.error || text}`);
      return data;
    } finally { clearTimeout(timer); }
  }
  async ready() { await this.request('/health'); this.started = true; return this; }
  async inspectPage() { await this.ready(); return this.request('/tree'); }
  async screenshot() { return null; }
  async navigate(url) { await this.ready(); await this.request('/open', { url }); return this.snapshot(); }
  async back() { await this.ready(); await this.request('/global', { action: 'back' }); return this.snapshot(); }
  async forward() { return this.snapshot(); }
  async reload() { await this.ready(); await this.request('/global', { action: 'reload' }); return this.snapshot(); }
  async clickPoint(x, y) { await this.ready(); return this.request('/tap', { x, y }); }
  async clickAction(id) { await this.ready(); return this.request('/node/click', { id }); }
  async fillDraft(draft) {
    await this.ready();
    const entries = (draft?.entries || []).filter(e => e.value !== null && e.value !== undefined);
    return this.request('/form/fill', { entries });
  }
  async submitForm(formId) { await this.ready(); return this.request('/form/submit', { formId }); }
  async evaluate() { throw new Error('DOM evaluate is not available through Android Accessibility; use node actions'); }
  async snapshot() { const page = await this.inspectPage(); return freeze({ ...page }); }
  async close() { this.started = false; }
}
export default AndroidHandExecutor;
