# Synthia Coherent Autonomy v0.1.0

This build follows the correction that **Termux is not Cynthia's runtime**.

## Non-negotiable authorities

1. `Pure-Synthia-Trainable-Assembly-v0.4.2.zip`
2. `Synthia-Universal-Execution-Spine-v0.4.0.zip`

Their original archives are preserved under `authority-original/`.

The live browser runtime uses:
- the Universal Execution Spine directly;
- Trainable StateSpace directly;
- Trainable ATO directly;
- the complete compiled Trainable Klein toolkit through a static CommonJS loader;
- Trainable registration/book/scientist/journal logic through browser copies where only
  `node:crypto` is replaced by a compatibility module.

## What autonomy adds

- heartbeat/watch loop;
- persistent task queue;
- Pure Synthia call and chat;
- local JavaScript execution in an isolated Web Worker;
- confidence-earned automatic JS tasks;
- local persistence;
- Trainable learning journal;
- optional Termux shell faculty.

Shell commands are deliberately manual. They are not required for Cynthia to think, call,
learn, run JavaScript or use her execution spine.

## Button gate

There are 18 action buttons. The project will not treat the UI contract as valid unless:
- every button action appears in `button-contract.mjs`;
- no button action is duplicated;
- every contract action appears in the HTML;
- browser boot confirms UES wiring and Trainable StateSpace/ATO/Klein exports;
- the browser SHA-256 compatibility check passes.

Run:

```bash
npm test
```

## Build APK on the phone

Keep the project directory intact, then in Termux:

```bash
cd /path/to/Synthia-Coherent-Autonomy-v0.1.0
export ANDROID_JAR="$PREFIX/share/aapt/android.jar"
bash build-apk.sh
```

Output:

`~/storage/downloads/Synthia-Autonomy/Synthia-Coherent-Autonomy-v0.1.0.apk`

The Android wrapper serves packaged files from `127.0.0.1` so ES modules work reliably.
It exposes an optional Termux `RUN_COMMAND` bridge, but the browser-native Synthia runtime
does not depend on that bridge.
