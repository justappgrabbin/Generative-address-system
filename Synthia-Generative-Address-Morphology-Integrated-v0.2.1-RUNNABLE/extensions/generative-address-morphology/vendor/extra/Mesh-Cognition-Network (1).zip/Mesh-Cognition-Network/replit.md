# Automata Mesh

Automata Mesh is a distributed capability mesh. Typed network nodes contribute semantic, sequence, visual, code, game, and app capabilities. A connected viewer selects a filter that changes the context lens, visible nodes, active tools, and generated view. The current core remains local and symbolic rather than requiring an external LLM.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/automata-mesh run dev` — run the web interface
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/automata-mesh/` — React/Vite interface and speculative-lab visual system
- `artifacts/api-server/src/routes/mesh.ts` — mesh API and inquiry interaction loop
- `artifacts/api-server/src/lib/mesh-engine.ts` — symbolic tokenization, capability/filter seeds, recursive lattice encoding, neural network initialization/training, activation, grammar generation, parsing, semantic graphing, analogy, and artifact generation
- `lib/db/src/schema/mesh.ts` — PostgreSQL/Drizzle schema for role automata, distributed capability nodes, connection filters, grammars, memory, events, inquiries, and artifacts
- `lib/api-spec/openapi.yaml` — source-of-truth API contract
- `artifacts/automata-mesh/src/index.css` — source-of-truth theme tokens

## Architecture decisions

- The engine is deterministic and local. It uses symbolic objects, relations, feature vectors, weighted rules, and procedural artifact generation instead of requiring an LLM or external AI credential.
- Role automata and capability networks are separate layers: roles describe participating agents, while typed capability nodes describe the neural/tool substrate available to a connection.
- A connection carries a viewer key and filter key. Filters expose different network types, context lenses, and output capabilities; the same inquiry is intentionally view-dependent.
- Each capability network is a local feed-forward trainable model with an 81-value input vector: 64 primitive slots, five dimensions, and bounded recursive coordinates. Inquiry processing trains the networks permitted by the active filter.
- Each automaton carries recognition and generation grammars independently. A speaker generates a rule; an auditor parses it, temporarily borrows it when needed, and promotes it after usage crosses a threshold.
- Shared memory is separate from agent grammar state. Inquiries can strengthen a reusable mesh memory while individual agents also adapt through interaction.
- API types and server validation are generated from the OpenAPI document; regenerate them after contract changes.
- Initialization is guarded by a process-local promise so concurrent first requests do not seed duplicate agents.

## Product

- Connect as a viewer, choose a context filter, submit natural-language inquiries, and inspect the filter-specific execution trace.
- Watch specialized automata activate, share, morph, and evolve.
- Inspect shared memories and event history.
- Generate symbolic text, relational images, animated video traces, source code, playable HTML game loops, and context-aware HTML app views.
- Build custom neural networks and train them manually or through filtered inquiry samples; inspect architecture, training steps, loss, and status in the Neural Network Lab.
- Observe grammar learning as recognition rules, generation rules, frequencies, and interaction counts change.

## User preferences

- Prefer symbolic, generative mechanisms that do not require an LLM for the core behavior.
- Use Klein-inspired objects, relations, grammar rules, inheritance, analogy, and interaction-driven learning as the conceptual direction.

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`.
- Run `pnpm --filter @workspace/db run push` after changing the mesh schema; this is for the development database.
- The historical-language paper is available through Klein's canonical index. The separate generative-semantic-rules paper is available locally in `attached_assets/` and has been OCR'd for implementation guidance.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
