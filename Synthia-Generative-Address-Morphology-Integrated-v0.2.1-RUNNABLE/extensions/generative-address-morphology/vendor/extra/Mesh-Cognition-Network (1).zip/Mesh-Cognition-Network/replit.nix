{pkgs}: {
  deps = [
    pkgs.tesseract
  ];
}
