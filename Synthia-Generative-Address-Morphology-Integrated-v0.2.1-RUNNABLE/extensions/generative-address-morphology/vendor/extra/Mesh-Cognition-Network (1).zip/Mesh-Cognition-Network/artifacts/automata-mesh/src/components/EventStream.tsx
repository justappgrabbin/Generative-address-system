import { useState, useEffect } from "react"
import { useListMeshEvents, getListMeshEventsQueryKey } from "@workspace/api-client-react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Terminal, Rss } from "lucide-react"
import { cn } from "@/lib/utils"

export function EventStream() {
  const { data: events, isLoading, error } = useListMeshEvents({
    query: {
      refetchInterval: 3000,
      queryKey: getListMeshEventsQueryKey(),
    }
  })

  if (error) {
    return null
  }

  return (
    <Card className="h-full flex flex-col border-y-0 border-r-0 border-l rounded-none bg-background">
      <CardHeader className="py-3 px-4 h-14 shrink-0 flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground uppercase tracking-widest">
          <Terminal className="h-4 w-4" />
          Event Stream
        </CardTitle>
        <Rss className="h-4 w-4 text-primary animate-pulse" />
      </CardHeader>
      <CardContent className="flex-1 p-0 overflow-hidden relative">
         <div className="absolute inset-x-0 top-0 h-4 bg-gradient-to-b from-background to-transparent z-10 pointer-events-none" />
         <div className="absolute inset-x-0 bottom-0 h-4 bg-gradient-to-t from-background to-transparent z-10 pointer-events-none" />
        
        <ScrollArea className="h-full">
          <div className="p-4 space-y-3 font-mono text-xs">
            {isLoading ? (
              Array(8).fill(0).map((_, i) => (
                <div key={i} className="flex gap-2">
                  <Skeleton className="h-4 w-12" />
                  <Skeleton className="h-4 flex-1" />
                </div>
              ))
            ) : events?.length === 0 ? (
              <div className="text-muted-foreground text-center py-8 opacity-50">
                Awaiting signals...
              </div>
            ) : (
              events?.map((event) => (
                <div key={event.id} className="group relative pr-2 hover:bg-muted/50 p-1 -mx-1 rounded-sm transition-colors border border-transparent hover:border-border/50">
                  <div className="flex items-start gap-2 mb-1">
                    <span className="text-muted-foreground shrink-0 opacity-50">
                      {new Date(event.createdAt).toLocaleTimeString(undefined, {
                        hour12: false,
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      })}
                    </span>
                    <Badge variant="outline" className={cn(
                      "text-[9px] h-4 py-0 px-1 border-primary/20",
                      event.kind === "activation" && "text-primary border-primary/50 bg-primary/10",
                      event.kind === "generation" && "text-secondary border-secondary/50 bg-secondary/10",
                      event.kind === "morph" && "text-purple-400 border-purple-500/50 bg-purple-500/10",
                      event.kind === "evolve" && "text-pink-400 border-pink-500/50 bg-pink-500/10"
                    )}>
                      {event.kind}
                    </Badge>
                    <span className="text-primary font-bold">{event.agentName}</span>
                  </div>
                  <div className="pl-14 text-foreground/80 leading-relaxed group-hover:text-foreground break-words whitespace-pre-wrap">
                    {event.message}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
