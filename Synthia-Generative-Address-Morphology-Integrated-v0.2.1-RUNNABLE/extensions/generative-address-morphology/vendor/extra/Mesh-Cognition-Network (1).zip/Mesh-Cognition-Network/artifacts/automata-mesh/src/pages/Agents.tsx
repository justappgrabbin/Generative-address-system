import { useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { useListMeshAgents, useMorphMeshAgent, useEvolveMeshAgent, getListMeshAgentsQueryKey, getListMeshEventsQueryKey } from "@workspace/api-client-react"
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { Cpu, Zap, Activity, Repeat, Edit2 } from "lucide-react"

export default function Agents() {
  const queryClient = useQueryClient()
  const { data: agents, isLoading } = useListMeshAgents({
    query: { refetchInterval: 10000, queryKey: getListMeshAgentsQueryKey() } // Poll to show status changes
  })

  const evolveAgent = useEvolveMeshAgent()
  const morphAgent = useMorphMeshAgent()

  const [morphingId, setMorphingId] = useState<number | null>(null)
  const [newRole, setNewRole] = useState("")

  const handleEvolve = (id: number) => {
    evolveAgent.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMeshAgentsQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListMeshEventsQueryKey() })
      }
    })
  }

  const handleMorph = (id: number) => {
    if (!newRole.trim()) return
    morphAgent.mutate({ id, data: { role: newRole } }, {
      onSuccess: () => {
        setMorphingId(null)
        setNewRole("")
        queryClient.invalidateQueries({ queryKey: getListMeshAgentsQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListMeshEventsQueryKey() })
      }
    })
  }

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6">
      <div className="flex items-end justify-between border-b border-border pb-4">
        <div>
          <h1 className="text-3xl font-mono text-primary flex items-center gap-3">
            <Cpu className="h-8 w-8" />
            Automata Roster
          </h1>
          <p className="text-muted-foreground mt-2 text-sm font-mono">
            Inspect, evolve, and direct the specialized logic entities comprising the mesh.
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, i) => (
             <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {agents?.map(agent => (
            <Card key={agent.id} className="flex flex-col group hover:border-primary/50 transition-colors">
              <CardHeader className="pb-3 border-b border-border/50">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl bg-muted/50 w-12 h-12 flex items-center justify-center border border-border/50">
                      {agent.glyph}
                    </div>
                    <div>
                      <CardTitle className="text-xl text-foreground font-bold">{agent.name}</CardTitle>
                      <div className="font-mono text-xs text-primary mt-1 flex items-center gap-2 uppercase">
                        {agent.role}
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className={`
                    uppercase font-mono text-[10px] 
                    ${agent.status === 'listening' ? 'text-muted-foreground' : ''}
                    ${agent.status === 'thinking' ? 'text-primary border-primary animate-pulse' : ''}
                    ${agent.status === 'sharing' ? 'text-secondary border-secondary' : ''}
                    ${agent.status === 'evolving' ? 'text-purple-400 border-purple-500 animate-pulse' : ''}
                  `}>
                    {agent.status}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="py-4 flex-1 space-y-4">
                <p className="text-sm text-foreground/80 leading-relaxed min-h-[40px]">
                  {agent.description}
                </p>

                <div className="space-y-2">
                  <div className="text-xs font-mono text-muted-foreground uppercase flex items-center gap-2">
                    <Activity className="h-3 w-3" /> Focus Vectors
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {agent.focus.map((f, i) => (
                      <span key={i} className="text-[10px] font-mono px-2 py-0.5 bg-muted text-muted-foreground border border-border/50">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono border-t border-border/50 pt-4 mt-2">
                  <div>
                    <span className="text-muted-foreground block mb-1">Activation Level</span>
                    <div className="h-1.5 w-full bg-muted overflow-hidden relative">
                       <div 
                         className="absolute left-0 top-0 bottom-0 bg-secondary transition-all" 
                         style={{ width: `${agent.activation * 100}%` }}
                       />
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground block mb-1">Generation</span>
                    <span className="text-foreground font-bold">Gen {agent.generation}</span>
                  </div>
                </div>

                {morphingId === agent.id && (
                   <div className="mt-4 p-3 bg-muted/30 border border-primary/30 flex flex-col gap-3 animate-in slide-in-from-top-2">
                      <Input 
                        placeholder="New declarative role..." 
                        value={newRole}
                        onChange={(e) => setNewRole(e.target.value)}
                        className="h-8 text-xs bg-background"
                        autoFocus
                      />
                      <div className="flex gap-2 justify-end">
                        <Button variant="ghost" size="sm" onClick={() => setMorphingId(null)} className="h-7 text-xs">Cancel</Button>
                        <Button 
                          size="sm" 
                          onClick={() => handleMorph(agent.id)}
                          disabled={!newRole.trim() || morphAgent.isPending}
                          className="h-7 text-xs"
                        >
                          Execute Morph
                        </Button>
                      </div>
                   </div>
                )}
              </CardContent>

              <CardFooter className="pt-0 pb-4 flex gap-2 border-t border-transparent group-hover:border-border/50 transition-colors">
                 <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => {
                      setNewRole(agent.role)
                      setMorphingId(agent.id)
                    }}
                    disabled={morphingId === agent.id}
                 >
                   <Edit2 className="h-4 w-4 mr-2" /> Morph
                 </Button>
                 <Button 
                    variant="secondary" 
                    className="flex-1"
                    onClick={() => handleEvolve(agent.id)}
                    disabled={evolveAgent.isPending}
                 >
                   <Zap className="h-4 w-4 mr-2" /> Evolve
                 </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
