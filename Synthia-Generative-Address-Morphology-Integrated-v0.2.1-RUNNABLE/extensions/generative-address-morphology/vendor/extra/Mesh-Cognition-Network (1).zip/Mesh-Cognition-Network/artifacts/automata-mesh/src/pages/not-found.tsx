import { Link } from "wouter"
import { AlertCircle } from "lucide-react"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground">
      <AlertCircle className="w-16 h-16 text-destructive mb-4" />
      <h1 className="text-4xl font-mono font-bold tracking-tight mb-2 uppercase">404 Signal Lost</h1>
      <p className="text-muted-foreground font-mono mb-8">The requested sector does not exist in the mesh topology.</p>
      <Link href="/">
        <span className="cursor-pointer border border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground font-mono px-6 py-2 transition-colors uppercase tracking-widest text-sm">
          Return to Hub
        </span>
      </Link>
    </div>
  )
}
