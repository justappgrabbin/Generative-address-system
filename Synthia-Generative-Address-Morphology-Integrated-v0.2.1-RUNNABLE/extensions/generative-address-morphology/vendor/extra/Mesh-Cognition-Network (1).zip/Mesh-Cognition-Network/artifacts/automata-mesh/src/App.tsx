import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';

import { Sidebar } from '@/components/Sidebar';
import { EventStream } from '@/components/EventStream';
import InquiryWorkspace from '@/pages/InquiryWorkspace';
import Agents from '@/pages/Agents';
import Networks from '@/pages/Networks';
import Memory from '@/pages/Memory';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    }
  }
});

function Router() {
  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      <Sidebar />
      <main className="flex-1 flex flex-col min-w-0">
        <Switch>
          <Route path="/" component={InquiryWorkspace} />
          <Route path="/agents" component={Agents} />
          <Route path="/networks" component={Networks} />
          <Route path="/memory" component={Memory} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <aside className="w-[320px] shrink-0 h-full hidden lg:block">
        <EventStream />
      </aside>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
