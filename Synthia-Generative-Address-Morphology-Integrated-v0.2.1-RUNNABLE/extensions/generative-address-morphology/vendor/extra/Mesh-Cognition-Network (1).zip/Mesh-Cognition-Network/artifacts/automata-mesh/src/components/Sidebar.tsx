import * as React from "react"
import { Link, useLocation } from "wouter"
import { cn } from "@/lib/utils"
import { Activity, Brain, Cpu, Database, Network } from "lucide-react"

const navItems = [
  { href: "/", label: "Workspace", icon: Network },
  { href: "/agents", label: "Automata", icon: Cpu },
  { href: "/networks", label: "Neural Nets", icon: Brain },
  { href: "/memory", label: "Memory", icon: Database },
]

export function Sidebar() {
  const [location] = useLocation()

  return (
    <div className="flex h-full w-[240px] flex-col border-r bg-sidebar text-sidebar-foreground">
      <div className="flex h-14 items-center border-b px-4 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,hsl(var(--primary)/0.1)_50%,transparent_100%)] opacity-50 animate-pulse" />
        <Activity className="mr-2 h-5 w-5 text-primary" />
        <span className="font-mono font-bold tracking-widest text-primary uppercase text-sm z-10">Mesh.OS</span>
      </div>
      
      <div className="flex-1 py-4 flex flex-col gap-1 px-3">
        {navItems.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href))
          return (
            <Link key={item.href} href={item.href} className="block">
              <div
                data-testid={`nav-link-${item.label.toLowerCase()}`}
                className={cn(
                  "flex items-center gap-3 rounded-none px-3 py-2 text-sm font-mono transition-all border border-transparent",
                  isActive
                    ? "bg-primary/10 text-primary border-primary/30 shadow-[inset_0_0_10px_rgba(6,182,212,0.1)]"
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:border-sidebar-border"
                )}
              >
                <item.icon className={cn("h-4 w-4", isActive ? "text-primary" : "text-muted-foreground")} />
                {item.label}
              </div>
            </Link>
          )
        })}
      </div>

      <div className="p-4 border-t border-border">
        <div className="text-[10px] uppercase font-mono text-muted-foreground tracking-widest flex justify-between items-center">
          <span>System Status</span>
          <span className="flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse"></span>
            <span className="text-primary">Online</span>
          </span>
        </div>
      </div>
    </div>
  )
}
