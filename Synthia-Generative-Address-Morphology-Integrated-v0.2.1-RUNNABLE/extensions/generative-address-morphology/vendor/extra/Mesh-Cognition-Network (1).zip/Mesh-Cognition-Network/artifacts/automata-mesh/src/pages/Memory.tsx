import { useListMeshMemory } from "@workspace/api-client-react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Database, Link2, Share2, Clock } from "lucide-react"

export default function Memory() {
  const { data: memories, isLoading } = useListMeshMemory()

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6">
      <div className="flex items-end justify-between border-b border-border pb-4">
        <div>
          <h1 className="text-3xl font-mono text-primary flex items-center gap-3">
            <Database className="h-8 w-8" />
            Shared Memory Core
          </h1>
          <p className="text-muted-foreground mt-2 text-sm font-mono">
            Rules, heuristics, and extracted knowledge shared bidirectionally among the automata mesh.
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {Array(4).fill(0).map((_, i) => (
             <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : memories?.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground border border-dashed border-border flex flex-col items-center gap-4">
           <Database className="h-12 w-12 opacity-20" />
           <p className="font-mono">Memory core empty. Run inquiries to populate.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {memories?.map(memory => (
            <Card key={memory.id} className="relative overflow-hidden group">
              <div 
                className="absolute left-0 top-0 bottom-0 w-1 bg-secondary opacity-50 group-hover:opacity-100 transition-opacity" 
              />
              <CardContent className="p-5 pl-6 flex gap-6 items-start">
                
                {/* Visual Connection indicator */}
                <div className="flex flex-col items-center gap-2 mt-1">
                  <div className="w-8 h-8 rounded-full border border-secondary flex items-center justify-center bg-secondary/10">
                    <Share2 className="h-4 w-4 text-secondary" />
                  </div>
                  <div className="text-[10px] font-mono text-muted-foreground text-center">
                    STR<br/>
                    <span className="text-foreground">{memory.strength.toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex-1 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                        {memory.label}
                      </h3>
                      <div className="text-xs font-mono text-primary flex items-center gap-2 mt-1">
                        <Link2 className="h-3 w-3" />
                        Source: {memory.source}
                      </div>
                    </div>
                    <div className="text-xs font-mono text-muted-foreground flex items-center gap-1.5 opacity-50">
                      <Clock className="h-3 w-3" />
                      {new Date(memory.createdAt).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="bg-muted/30 border border-border/50 p-4 font-mono text-sm leading-relaxed text-foreground/80">
                    {memory.content}
                  </div>
                  
                  <div className="pt-2 flex items-center gap-2">
                    <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                      Feature Vector Snapshot:
                    </span>
                    <div className="flex gap-0.5">
                      {memory.featureVector.slice(0, 16).map((val, i) => (
                        <div 
                          key={i} 
                          className="w-1.5 h-3" 
                          style={{ 
                            backgroundColor: val > 0.5 ? 'var(--color-primary)' : 'var(--color-muted)',
                            opacity: val > 0.5 ? val : 0.3
                          }} 
                        />
                      ))}
                      <span className="text-[10px] font-mono text-muted-foreground ml-1">...</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
