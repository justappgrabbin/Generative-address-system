import { useEffect, useState } from "react"
import { useQueryClient } from "@tanstack/react-query"
import { useGetMeshOverview, useListMeshCapabilities, useRunMeshInquiry, getGetMeshOverviewQueryKey, getListMeshAgentsQueryKey, getListMeshCapabilitiesQueryKey, getListMeshEventsQueryKey, getListMeshMemoryQueryKey } from "@workspace/api-client-react"
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { AppWindow, Brain, Code2, Cpu, Database, Eye, Gamepad2, Image as ImageIcon, Send, Type, Video, Zap } from "lucide-react"

type LatticeState = {
  primitive: number
  dimensions: number[]
  filterStage: number
  behavior: number
  motivation: number
  sense: number
  base: number
  degree: number
  minute: number
  second: number
  arc: number
  archetype: number
  environment: number
  recursionDepth: number
}

const initialLattice: LatticeState = {
  primitive: 0, dimensions: [0, 0, 0, 0, 0], filterStage: 0,
  behavior: 0, motivation: 0, sense: 0, base: 0, degree: 0,
  minute: 0, second: 0, arc: 0, archetype: 0, environment: 0, recursionDepth: 1,
}

export default function InquiryWorkspace() {
  const queryClient = useQueryClient()
  const { data: overview, isLoading: overviewLoading } = useGetMeshOverview({
    query: { refetchInterval: 5000, queryKey: getGetMeshOverviewQueryKey() }
  })
  const { data: capabilities } = useListMeshCapabilities({
    query: { refetchInterval: 15000, queryKey: getListMeshCapabilitiesQueryKey() }
  })
  
  const runInquiry = useRunMeshInquiry()
  const [query, setQuery] = useState("")
  const [outputModes, setOutputModes] = useState<string[]>(["text"])
  const [viewerKey, setViewerKey] = useState("viewer-01")
  const [filterKey, setFilterKey] = useState("generalist")
  const [lattice, setLattice] = useState<LatticeState>(initialLattice)
  
  // Keep track of the last result directly
  const [lastResult, setLastResult] = useState<any>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim() || outputModes.length === 0) return

    runInquiry.mutate({
      data: {
        query: query.trim(),
         outputModes: outputModes as any[],
         viewerKey,
         filterKey,
         lattice,
      }
    }, {
      onSuccess: (result) => {
        setLastResult(result)
        setQuery("")
        // Invalidate everything to show the new state
        queryClient.invalidateQueries({ queryKey: getGetMeshOverviewQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListMeshAgentsQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListMeshEventsQueryKey() })
        queryClient.invalidateQueries({ queryKey: getListMeshMemoryQueryKey() })
         queryClient.invalidateQueries({ queryKey: getListMeshCapabilitiesQueryKey() })
      }
    })
  }

  const toggleMode = (mode: string) => {
    setOutputModes(prev => 
      prev.includes(mode) 
        ? prev.filter(m => m !== mode)
        : [...prev, mode]
    )
  }

  const activeFilter = capabilities?.filters.find((filter) => filter.key === filterKey)
  const isModeAllowed = (mode: string) => mode === "text" || !activeFilter || activeFilter.allowedCapabilities.includes(mode)
  const changeFilter = (nextKey: string) => {
    setFilterKey(nextKey)
    const nextFilter = capabilities?.filters.find((filter) => filter.key === nextKey)
    if (nextFilter) {
      setOutputModes((previous) => ["text", ...previous.filter((mode) => nextFilter.allowedCapabilities.includes(mode) && mode !== "text")])
    }
  }

  const modeOptions = [
    { key: "text", label: "TEXT", icon: Type },
    { key: "image", label: "IMAGE", icon: ImageIcon },
    { key: "video", label: "VIDEO", icon: Video },
    { key: "code", label: "CODE", icon: Code2 },
    { key: "game", label: "GAME", icon: Gamepad2 },
    { key: "app", label: "APP", icon: AppWindow },
  ]

  const latticeSignature = `P${String(lattice.primitive).padStart(2, "0")}.${lattice.dimensions.join("")}.F${String(lattice.filterStage + 1).padStart(2, "0")}.B${lattice.behavior}M${lattice.motivation}S${lattice.sense}B${lattice.base}.A${String(lattice.archetype + 1).padStart(2, "0")}/E${String(lattice.environment + 1).padStart(2, "0")}·R${lattice.recursionDepth}`
  const updateLattice = (key: keyof LatticeState, value: number) => setLattice((previous) => ({ ...previous, [key]: value }))

  return (
    <div className="flex-1 h-full flex flex-col overflow-hidden p-6 gap-6">
      
      {/* Overview Stats */}
      <div className="grid grid-cols-4 gap-4 shrink-0">
        <StatCard title="Active Agents" value={overview?.active} total={overview?.agents} icon={Cpu} loading={overviewLoading} />
        <StatCard title="Shared Memories" value={overview?.memories} icon={Database} loading={overviewLoading} />
        <StatCard title="Inquiries Processed" value={overview?.inquiries} icon={Brain} loading={overviewLoading} />
        <StatCard title="Artifacts Generated" value={overview?.artifacts} icon={Zap} loading={overviewLoading} />
      </div>

      {/* Main Workspace Area */}
      <div className="flex-1 flex gap-6 min-h-0">
        
        {/* Inquiry Input Column */}
        <div className="w-1/3 flex flex-col gap-4">
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Signal Generator
              </CardTitle>
              <CardDescription className="font-mono text-xs">
                Inject a query into the local mesh network.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <form onSubmit={handleSubmit} className="flex flex-col h-full gap-6">
                
                 <div className="space-y-3 border border-primary/20 bg-primary/5 p-3">
                   <Label className="font-mono text-xs text-primary uppercase tracking-widest flex items-center gap-2"><Eye className="h-3 w-3" /> Connection Filter</Label>
                   <div className="grid grid-cols-2 gap-2">
                     <Input value={viewerKey} onChange={(event) => setViewerKey(event.target.value)} placeholder="viewer identity" className="font-mono text-xs bg-background/60" />
                     <select value={filterKey} onChange={(event) => changeFilter(event.target.value)} className="h-9 border border-input bg-background/60 px-2 text-xs font-mono text-foreground">
                       {capabilities?.filters.map((filter) => <option key={filter.key} value={filter.key}>{filter.name}</option>)}
                     </select>
                   </div>
                   <p className="text-[10px] leading-relaxed text-muted-foreground font-mono">{activeFilter?.description ?? "Loading connection filters…"}</p>
                   <div className="flex flex-wrap gap-1">
                     {(capabilities?.nodes ?? []).filter((node) => node.capabilities.some((capability) => activeFilter?.allowedCapabilities.includes(capability))).map((node) => (
                       <span key={node.id} className="border border-secondary/30 bg-secondary/5 px-1.5 py-1 text-[9px] font-mono text-secondary">{node.networkType}</span>
                     ))}
                   </div>
                 </div>

                 <div className="space-y-3">
                   <Label className="font-mono text-xs text-primary uppercase tracking-widest">Capability Outputs</Label>
                   <div className="grid grid-cols-3 gap-2">
                     {modeOptions.map(({ key, label, icon: ModeIcon }) => {
                       const allowed = isModeAllowed(key)
                       return (
                         <label key={key} className={`flex items-center gap-2 cursor-pointer border p-2 transition-colors ${allowed ? "hover:bg-muted/50" : "opacity-35 cursor-not-allowed"}`}>
                           <Checkbox
                             checked={outputModes.includes(key)}
                             disabled={!allowed}
                             onCheckedChange={() => toggleMode(key)}
                             data-testid={`mode-${key}`}
                           />
                           <ModeIcon className="h-3.5 w-3.5 text-muted-foreground" />
                           <span className="font-mono text-[10px]">{label}</span>
                         </label>
                       )
                     })}
                   </div>
                 </div>

                 <div className="space-y-3 border border-orange-400/25 bg-orange-400/5 p-3">
                   <div className="flex items-center justify-between">
                     <Label className="font-mono text-xs text-orange-200 uppercase tracking-widest">Recursive Lattice</Label>
                     <span className="font-mono text-[9px] text-orange-300">{latticeSignature}</span>
                   </div>
                   <p className="text-[10px] leading-relaxed text-muted-foreground font-mono">
                     64 primitives · 5 dimensions · 13 filters · 6 behaviors / motivations / senses · 5 bases · 12 archetypes / environments
                   </p>
                   <LatticeSlider label="Primitive" value={lattice.primitive} max={63} onChange={(value) => updateLattice("primitive", value)} />
                   <div className="grid grid-cols-2 gap-2">
                     <LatticeSlider label="Filter stage" value={lattice.filterStage} max={12} onChange={(value) => updateLattice("filterStage", value)} />
                     <LatticeSlider label="Recursion depth" value={lattice.recursionDepth} max={8} onChange={(value) => updateLattice("recursionDepth", value)} />
                   </div>
                   <div className="grid grid-cols-5 gap-2">
                     {lattice.dimensions.map((value, index) => (
                       <LatticeSlider key={index} label={`D${index + 1}`} value={value} max={4} onChange={(next) => setLattice((previous) => ({ ...previous, dimensions: previous.dimensions.map((item, itemIndex) => itemIndex === index ? next : item) }))} />
                     ))}
                   </div>
                   <div className="grid grid-cols-4 gap-2">
                     <LatticeSlider label="Beh" value={lattice.behavior} max={5} onChange={(value) => updateLattice("behavior", value)} />
                     <LatticeSlider label="Mot" value={lattice.motivation} max={5} onChange={(value) => updateLattice("motivation", value)} />
                     <LatticeSlider label="Sense" value={lattice.sense} max={5} onChange={(value) => updateLattice("sense", value)} />
                     <LatticeSlider label="Base" value={lattice.base} max={4} onChange={(value) => updateLattice("base", value)} />
                   </div>
                   <div className="grid grid-cols-5 gap-2">
                     <LatticeSlider label="Deg" value={lattice.degree} max={29} onChange={(value) => updateLattice("degree", value)} />
                     <LatticeSlider label="Min" value={lattice.minute} max={59} onChange={(value) => updateLattice("minute", value)} />
                     <LatticeSlider label="Sec" value={lattice.second} max={59} onChange={(value) => updateLattice("second", value)} />
                     <LatticeSlider label="Arc" value={lattice.arc} max={99} onChange={(value) => updateLattice("arc", value)} />
                     <LatticeSlider label="Arch" value={lattice.archetype} max={11} onChange={(value) => updateLattice("archetype", value)} />
                   </div>
                   <LatticeSlider label="Environment" value={lattice.environment} max={11} onChange={(value) => updateLattice("environment", value)} />
                 </div>

                <div className="flex-1 flex flex-col gap-3">
                  <Label className="font-mono text-xs text-primary uppercase tracking-widest">Inquiry Payload</Label>
                  <textarea
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Enter natural language sequence for analysis..."
                    className="flex-1 w-full bg-background/50 border border-input p-4 font-mono text-sm focus:outline-none focus:border-primary resize-none placeholder:text-muted-foreground/50"
                    data-testid="input-query"
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={runInquiry.isPending || !query.trim() || outputModes.length === 0}
                  className="w-full h-14 text-lg"
                  data-testid="button-submit-inquiry"
                >
                  {runInquiry.isPending ? (
                    <span className="flex items-center gap-2">
                      <Zap className="h-5 w-5 animate-pulse" />
                      Synthesizing...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Send className="h-5 w-5" />
                      Execute Inquiry
                    </span>
                  )}
                </Button>

              </form>
            </CardContent>
          </Card>
        </div>

        {/* Output/Analysis Column */}
        <div className="flex-1 flex flex-col gap-4">
          <Card className="flex-1 overflow-auto flex flex-col">
            <CardHeader className="pb-4 shrink-0 bg-background z-20">
              <CardTitle className="text-xl">Network Synthesis</CardTitle>
              <CardDescription className="font-mono text-xs">
                Observation of mesh processing and output encoding.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto pt-0 pb-6 relative">
               
              {!lastResult && !runInquiry.isPending && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground font-mono gap-4 opacity-50">
                  <Database className="h-16 w-16" />
                  <p>AWAITING SIGNAL INPUT</p>
                </div>
              )}

              {runInquiry.isPending && (
                <div className="h-full flex flex-col font-mono text-sm gap-4">
                  <div className="flex items-center gap-3 text-primary animate-pulse">
                    <Zap className="h-4 w-4" />
                    <span>Propagating inquiry through mesh...</span>
                  </div>
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-40 w-full" />
                </div>
              )}

              {lastResult && !runInquiry.isPending && (
                <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  
                  {/* Synthesis Text */}
                  <div className="space-y-3">
                    <h3 className="font-mono text-xs text-primary tracking-widest border-b border-primary/20 pb-2">DECODED RESPONSE</h3>
                    <div className="font-sans text-lg leading-relaxed text-foreground/90 whitespace-pre-wrap">
                      {lastResult.response}
                    </div>
                  </div>

                  {/* Active Agents */}
                  <div className="space-y-3">
                    <h3 className="font-mono text-xs text-secondary tracking-widest border-b border-secondary/20 pb-2">ENGAGED AUTOMATA</h3>
                    <div className="flex flex-wrap gap-2">
                      {lastResult.activatedAgents.map((agent: any) => (
                        <Badge key={agent.id} variant="secondary" className="px-3 py-1 font-mono">
                          <span className="mr-2 opacity-50">{agent.glyph}</span>
                          {agent.name}
                        </Badge>
                      ))}
                    </div>

                   {lastResult.perspective && (
                     <div className="space-y-3">
                       <h3 className="font-mono text-xs text-cyan-300 tracking-widest border-b border-cyan-500/20 pb-2">CONNECTED PERSPECTIVE</h3>
                       <div className="border border-cyan-400/30 bg-cyan-400/5 p-4 space-y-3">
                         <div className="flex flex-wrap gap-3 font-mono text-xs">
                           <span className="text-cyan-200">VIEWER: {lastResult.perspective.viewerKey}</span>
                           <span className="text-muted-foreground">FILTER: {lastResult.perspective.filterKey}</span>
                         </div>
                         <div className="flex flex-wrap gap-1.5">
                           {lastResult.perspective.contextLens.map((lens: string) => <Badge key={lens} variant="outline" className="font-mono text-[10px]">{lens}</Badge>)}
                         </div>
                         <p className="text-xs font-mono text-muted-foreground">
                           This connection can see {lastResult.capabilityNodes?.map((node: any) => node.networkType).join(" · ") || "no"} network types. Another filter produces a different context and tool view.
                         </p>
                       </div>
                     </div>
                   )}

                   {lastResult.latticeContext && (
                     <div className="border border-orange-400/30 bg-orange-400/5 p-4 font-mono text-xs">
                       <div className="text-orange-200 uppercase tracking-widest mb-2">TRAINING LATTICE SAMPLE</div>
                       <div className="text-foreground/80">{lastResult.latticeContext.signature}</div>
                       <div className="text-muted-foreground mt-2">Primitive {lastResult.latticeContext.primitive} · filter {lastResult.latticeContext.filter} · {lastResult.latticeContext.archetype}/{lastResult.latticeContext.environment} · {lastResult.latticeContext.coordinate}</div>
                     </div>
                   )}

                   {lastResult.neuralNetworks?.length > 0 && (
                     <div className="space-y-3">
                       <h3 className="font-mono text-xs text-cyan-300 tracking-widest border-b border-cyan-500/20 pb-2">TRAINED NETWORKS</h3>
                       <div className="grid grid-cols-2 gap-2">
                         {lastResult.neuralNetworks.map((network: any) => (
                           <div key={network.id} className="border border-cyan-400/20 bg-cyan-400/5 p-3 font-mono text-xs">
                             <div className="flex justify-between gap-2"><span className="text-cyan-200">{network.networkType}</span><span className="text-muted-foreground">{network.status}</span></div>
                             <div className="text-muted-foreground mt-2">{network.inputSize} → {network.hiddenLayers.join(" → ")} → {network.outputSize}</div>
                             <div className="text-foreground/80 mt-1">step {network.trainingSteps} · loss {network.loss.toFixed(4)}</div>
                           </div>
                         ))}
                       </div>
                     </div>
                   )}
                  </div>

                  {/* Generated Artifacts */}
                  {lastResult.artifacts && lastResult.artifacts.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-mono text-xs text-purple-400 tracking-widest border-b border-purple-500/20 pb-2">EXTRACTED ARTIFACTS</h3>
                      <div className="grid grid-cols-2 gap-4">
                        {lastResult.artifacts.map((art: any) => (
                          <div key={art.id} className="border border-border bg-card p-4 relative group hover:border-purple-500/50 transition-colors">
                            <Badge className="absolute top-2 right-2 text-[10px] bg-purple-500/10 text-purple-400 hover:bg-purple-500/20">{art.kind}</Badge>
                            <h4 className="font-mono text-sm mb-2 pr-12">{art.title}</h4>
                            
                             {art.kind === 'text' ? (
                               <div className="text-xs text-muted-foreground font-mono bg-background/50 p-2 border border-input/50 h-24 overflow-y-auto">
                                 {art.content}
                               </div>
                             ) : art.kind === 'code' ? (
                               <pre className="text-[10px] leading-relaxed text-green-300 font-mono bg-background/70 p-2 border border-input/50 h-32 overflow-y-auto whitespace-pre-wrap">
                                 {art.content}
                               </pre>
                             ) : art.mimeType === 'text/html' ? (
                               <iframe title={art.title} srcDoc={art.content} sandbox="" className="w-full h-32 border border-input/50 bg-background" />
                            ) : art.mimeType.startsWith('image/svg') ? (
                              <div 
                                className="w-full h-32 flex items-center justify-center bg-background/50 border border-input/50 p-2 [&>svg]:w-full [&>svg]:h-full"
                                dangerouslySetInnerHTML={{__html: art.content}}
                              />
                            ) : (
                              <div className="w-full h-32 flex flex-col items-center justify-center bg-background/50 border border-input/50 text-muted-foreground font-mono text-xs">
                                <ImageIcon className="h-6 w-6 mb-2 opacity-50" />
                                {art.mimeType}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Execution Trace */}
                  <div className="space-y-3">
                    <h3 className="font-mono text-xs text-muted-foreground tracking-widest border-b border-border pb-2">EXECUTION TRACE</h3>
                    <div className="font-mono text-xs space-y-1 bg-muted/20 p-4 border border-border/50 text-muted-foreground">
                      {lastResult.trace.map((step: string, i: number) => (
                        <div key={i} className="flex gap-2">
                          <span className="opacity-50">{(i+1).toString().padStart(2, '0')}</span>
                          <span>{step}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                   {lastResult.semanticNetwork && (
                     <div className="space-y-4">
                       <h3 className="font-mono text-xs text-orange-300 tracking-widest border-b border-orange-500/20 pb-2">SEMANTIC DEEP STRUCTURE</h3>
                       <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                         <div className="border border-border bg-card/60 p-4 space-y-3">
                           <div className="flex items-center justify-between">
                             <span className="font-mono text-xs text-muted-foreground uppercase">Object / relation nodes</span>
                             <Badge variant="outline">{lastResult.semanticNetwork.nodes.length}</Badge>
                           </div>
                           <div className="flex flex-wrap gap-2">
                             {lastResult.semanticNetwork.nodes.slice(-12).map((node: any) => (
                               <span key={node.id} className={`text-[10px] font-mono px-2 py-1 border ${node.kind === "relation" ? "border-orange-400/40 text-orange-200 bg-orange-400/10" : "border-primary/30 text-primary bg-primary/5"}`}>
                                 {node.kind === "relation" ? "R" : "O"} · {node.label}
                               </span>
                             ))}
                           </div>
                         </div>
                         <div className="border border-border bg-card/60 p-4 space-y-3">
                           <div className="flex items-center justify-between">
                             <span className="font-mono text-xs text-muted-foreground uppercase">Semantic triples</span>
                             <Badge variant="outline">{lastResult.semanticNetwork.triples.length}</Badge>
                           </div>
                           <div className="space-y-2 max-h-28 overflow-y-auto">
                             {lastResult.semanticNetwork.triples.slice(0, 6).map((triple: any) => (
                               <div key={triple.id} className="font-mono text-xs text-foreground/80">
                                 <span className="text-primary">{triple.subject}</span>
                                 <span className="text-orange-300"> —{triple.relation}→ </span>
                                 <span className="text-secondary">{triple.object ?? "∅"}</span>
                                 <span className="text-muted-foreground ml-2">[{triple.confidence.toFixed(2)}]</span>
                               </div>
                             ))}
                           </div>
                         </div>
                       </div>
                       {lastResult.analogies?.map((analogy: any, index: number) => (
                         <div key={index} className="border border-orange-400/30 bg-orange-400/5 p-4 font-mono text-xs">
                           <div className="text-orange-200 uppercase tracking-widest mb-2">ATO / XNOR analogy operator</div>
                           <div className="text-foreground/80">
                             source [{analogy.source.join("")}] → operator [{analogy.operator.join("")}] → target [{analogy.target.join("")}]
                           </div>
                           <div className="text-muted-foreground mt-2">{analogy.interpretation}</div>
                         </div>
                       ))}
                       {lastResult.semanticNetwork.rules?.slice(0, 3).map((rule: any) => (
                         <div key={rule.id} className="border border-primary/20 bg-primary/5 p-3 font-mono text-xs flex flex-wrap items-center gap-x-3 gap-y-1">
                           <span className="text-primary">{rule.name}</span>
                           <span className="text-muted-foreground">{rule.surfacePattern}</span>
                           <span className="text-orange-300">→</span>
                           <span className="text-foreground/80">{rule.semanticPattern}</span>
                           <Badge variant="outline" className="ml-auto">{rule.status} · {rule.confidence.toFixed(2)}</Badge>
                         </div>
                       ))}
                     </div>
                   )}

                  {/* Learned Memory */}
                  {lastResult.learned && (
                    <div className="space-y-3">
                      <h3 className="font-mono text-xs text-green-500 tracking-widest border-b border-green-500/20 pb-2">MESH LEARNING EVENT</h3>
                      <div className="border border-green-500/30 bg-green-500/5 p-4 text-sm font-mono flex items-start gap-3">
                        <Database className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                        <div>
                          <div className="text-green-400 font-bold mb-1">Extracted: {lastResult.learned.label}</div>
                          <div className="text-green-500/70">{lastResult.learned.content}</div>
                        </div>
                      </div>
                    </div>
                  )}

                </div>
              )}
            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  )
}

function LatticeSlider({ label, value, max, onChange }: { label: string, value: number, max: number, onChange: (value: number) => void }) {
  return (
    <label className="block min-w-0">
      <span className="flex justify-between text-[9px] font-mono text-muted-foreground uppercase">
        <span>{label}</span><span className="text-orange-200">{value}</span>
      </span>
      <input type="range" min={0} max={max} value={value} onChange={(event) => onChange(Number(event.target.value))} className="w-full accent-orange-300 h-3" />
    </label>
  )
}

function StatCard({ title, value, total, icon: Icon, loading }: { title: string, value?: number, total?: number, icon: any, loading: boolean }) {
  return (
    <Card className="bg-card">
      <CardContent className="p-4 flex items-center justify-between">
        <div>
          <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider mb-1">{title}</p>
          {loading ? (
            <Skeleton className="h-8 w-16" />
          ) : (
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold font-mono text-foreground">{value || 0}</span>
              {total !== undefined && (
                <span className="text-sm font-mono text-muted-foreground">/ {total}</span>
              )}
            </div>
          )}
        </div>
        <div className="h-10 w-10 bg-primary/10 flex items-center justify-center border border-primary/20">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </CardContent>
    </Card>
  )
}