---
name: Klein paper access
description: The previously unavailable generative-semantic-rules paper is now available locally; the canonical-host issue still applies only to remote access.
---

The canonical university-host entry for the generative-semantic-rules paper is still broken or protected for remote automated access, but the user supplied a local copy in `attached_assets/Auto-Inference_Semantic_Structure_Rules_in_Generative_Semanrti_1786044254416.pdf`, which was OCR'd and read successfully. The related `Historical Change in LanguageCover plus.pdf` paper remains readable through `webFetch`.

The readable paper supports a population model in which each participant has recognition and generation grammars, speakers produce forms, auditors parse them, rule frequencies change through use, and temporary borrowed rules can become permanent after a threshold.

**Why:** The formal semantic inference paper is now available for implementation guidance, but its scanned OCR requires care around formulas and diagrams.

**How to apply:** Use the local upload as the source for semantic triples, bidirectional surface/semantic rules, tentative grammar revisions, and transformation-based inference. Treat OCR'd formulas as needing visual cross-checks before exact reproduction.