from pathlib import Path
import json
import re
import fitz

ROOT = Path("attached_assets")
OUT = Path(".agents/outputs/klein-papers")
OUT.mkdir(parents=True, exist_ok=True)

records = []
for pdf_path in sorted(ROOT.glob("*.pdf")):
    doc = fitz.open(pdf_path)
    text_parts = []
    headings = []
    image_pages = []
    for page_number, page in enumerate(doc, start=1):
        text = page.get_text("text")
        text_parts.append(text)
        blocks = page.get_text("dict").get("blocks", [])
        if any(block.get("type") == 1 for block in blocks) or page.get_images(full=True):
            image_pages.append(page_number)
        for line in text.splitlines():
            clean = " ".join(line.split())
            if clean and (
                re.match(r"^(?:[IVXLC]+\.|[A-Z]\.|[0-9]+\.)\s+", clean)
                or clean.isupper() and len(clean) > 5
            ):
                headings.append({"page": page_number, "text": clean[:240]})
    full_text = "\n".join(text_parts)
    stem = pdf_path.stem[:70]
    sample_pages = sorted(set([1, max(1, doc.page_count // 2), doc.page_count]))
    rendered = []
    for page_number in sample_pages:
        page = doc[page_number - 1]
        pix = page.get_pixmap(matrix=fitz.Matrix(1.25, 1.25), alpha=False)
        image_path = OUT / f"{stem}-page-{page_number}.png"
        pix.save(image_path)
        rendered.append(str(image_path))
    text_path = OUT / f"{stem}.txt"
    text_path.write_text(full_text, encoding="utf-8")
    records.append({
        "file": str(pdf_path),
        "pages": doc.page_count,
        "title": (full_text[:2500].replace("\n", " ")[:500]),
        "characters": len(full_text),
        "headings": headings[:80],
        "image_pages": image_pages,
        "text": str(text_path),
        "rendered": rendered,
    })

(OUT / "index.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
print(json.dumps(records, indent=2))