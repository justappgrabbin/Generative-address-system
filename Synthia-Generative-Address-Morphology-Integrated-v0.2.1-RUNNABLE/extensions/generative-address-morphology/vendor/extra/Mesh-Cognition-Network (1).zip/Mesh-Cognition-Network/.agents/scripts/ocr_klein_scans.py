from pathlib import Path
import subprocess
import fitz

ROOT = Path("attached_assets")
OUT = Path(".agents/outputs/klein-papers/ocr")
OUT.mkdir(parents=True, exist_ok=True)

targets = [
    ROOT / "Auto-Inference_Semantic_Structure_Rules_in_Generative_Semanrti_1786044254416.pdf",
    ROOT / "Computer_Simulation_of_Language_Contact_Models_1786044254388.pdf",
    ROOT / "I-CHING_Example_from_[CURRENT_ANTHROPOLOGY_1983_(1)_1786044254294.pdf",
]

for pdf_path in targets:
    doc = fitz.open(pdf_path)
    out_txt = OUT / f"{pdf_path.stem}.ocr.txt"
    with out_txt.open("w", encoding="utf-8") as handle:
        handle.write(f"SOURCE: {pdf_path.name}\nPAGES: {doc.page_count}\n\n")
        for page_number, page in enumerate(doc, start=1):
            pix = page.get_pixmap(matrix=fitz.Matrix(2.2, 2.2), alpha=False)
            image_path = OUT / f"{pdf_path.stem}-page-{page_number}.png"
            pix.save(image_path)
            proc = subprocess.run(
                ["tesseract", str(image_path), "stdout", "--psm", "3"],
                check=True,
                capture_output=True,
                text=True,
            )
            handle.write(f"\n===== PAGE {page_number} =====\n")
            handle.write(proc.stdout)
            image_path.unlink(missing_ok=True)
    print(out_txt)