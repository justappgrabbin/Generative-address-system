---
name: Uploaded Klein corpus
description: Five locally uploaded papers establish the Automata Mesh design principles for semantic networks, analogy, grammar induction, morphology, and language contact.
---

The uploaded corpus establishes a unified direction for Automata Mesh:

- Automatic inference paper: semantic deep structure is a time-aware network of numbered objects and relations represented as triples; surface↔semantic rules are bidirectional, generation and parsing use the same mappings in opposite directions, and rule induction proceeds tentatively with lexical/category revisions, transformations, positive/negative testing, and rollback.
- Analogical foundations and I Ching papers: ATOs are reversible Boolean/XNOR operators over feature vectors; analogy transfers relational difference, can work across verbal/visual domains, and can reorganize a whole classification space from a selected transform pair.
- Language contact papers: individuals have grammars with usage frequencies; speakers generate, auditors parse, unfamiliar rules may be borrowed, and grammar drift emerges from interaction, social context, time, and learning heuristics. Semantic and behavioral rules can be learned in the same framework.
- Generative morphology volume: lexical entries should carry syntactic, semantic, morphological, and phonological feature bundles; redundancy and word-formation rules should be explicit data rather than hidden string tricks.

**Why:** These papers are complementary parts of one symbolic architecture, not isolated inspiration. The mesh should expose the intermediate semantic and grammatical state so its outputs remain inspectable.

**How to apply:** Prefer explicit semantic triples, reversible feature-vector analogy, data-defined bidirectional rules, tentative inference with negative evidence, and context-sensitive interaction over opaque generation. Keep external LLMs optional rather than foundational.