export const SENTENCE_SYSTEM_PY = `
import math
import numpy as np

class SentenceSystem:
    def __init__(self):
        # Default Weights (can be evolved)
        self.weights = {
            'S': 1.0, # Semantic field
            'E': 1.0, # Emotional polarity
            'R': 1.0, # Rhythmic structure
            'I': 1.0  # Intention charge
        }
        
        # Collapse Engine Constants
        self.alpha = 1.0
        self.beta = 0.5
        
    def calculate_ssv(self, s, e, r, i):
        """
        Calculate Sentence Signature Vector (SSV)
        SSV = w1*S + w2*E + w3*R + w4*I
        Returns a numpy array representing the vector
        """
        # In a real NLP context, these would be embeddings. 
        # Here we represent them as scalar magnitudes for the formula demo
        # or simplified 4D vectors. Let's assume 4D vector output.
        
        # Simplified: The SSV is a vector where each component is weighted
        vec = np.array([
            self.weights['S'] * s,
            self.weights['E'] * e,
            self.weights['R'] * r,
            self.weights['I'] * i
        ])
        return vec

    def resonance_function(self, ssv1, ssv2):
        """
        Rx = cos_similarity(SSV1, SSV2)
        """
        dot_product = np.dot(ssv1, ssv2)
        norm_a = np.linalg.norm(ssv1)
        norm_b = np.linalg.norm(ssv2)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
            
        return dot_product / (norm_a * norm_b)

    def collapse_engine(self, D, G, C, tau):
        """
        CI = alpha * D * G * C * (1 - e^(-beta * tau))
        """
        # D: Dimensional factor
        # G: Gate factor
        # C: Contextual factor
        # tau: time
        
        time_decay = 1 - math.exp(-self.beta * tau)
        ci = self.alpha * D * G * C * time_decay
        return ci

# Initialize System
system = SentenceSystem()

# Example Calculation
print("Initializing Sentence System Core...")

# 1. Define two "Sentence" states (Solution vs Design Vector)
# Values range 0.0 to 1.0 for this simulation
# (Semantic, Emotional, Rhythmic, Intention)
s1_params = (0.8, 0.4, 0.9, 0.5) 
s2_params = (0.9, 0.3, 0.8, 0.6) # The User's "Design Vector"

ssv1 = system.calculate_ssv(*s1_params)
ssv2 = system.calculate_ssv(*s2_params)

print(f"SSV 1 Vector: {ssv1}")
print(f"SSV 2 Vector: {ssv2}")

# 2. Calculate Resonance
resonance = system.resonance_function(ssv1, ssv2)
print(f"Resonance (Rx): {resonance:.4f}")

# 3. Calculate Collapse Point (Inflection)
# Simulating time passing (tau)
print("\\ncalculating Inflection Points...")
for tau in range(0, 6):
    ci = system.collapse_engine(D=1.2, G=0.9, C=1.5, tau=tau)
    status = "STABLE" if ci < 1.0 else "MUTATING -> MIRROR STATE"
    print(f"Time {tau}: CI = {ci:.4f} [{status}]")

print("\\nSystem Ready. Awaiting Input...")
`;
