import React, { useEffect, useRef, useState } from 'react';
import { Terminal as TerminalIcon, ChevronUp, ChevronDown, Activity, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

export interface LogEntry {
  id: string;
  timestamp: Date;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

interface TerminalProps {
  logs: LogEntry[];
  isOpen: boolean;
  onToggle: () => void;
}

export function GNNTerminal({ logs, isOpen, onToggle }: TerminalProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, isOpen]);

  return (
    <motion.div 
      initial={false}
      animate={{ height: isOpen ? '200px' : '40px' }}
      className="fixed bottom-0 left-0 right-0 z-50 glass-panel border-t border-primary/30 mx-4 mb-4 rounded-lg overflow-hidden flex flex-col shadow-2xl"
    >
      <div 
        onClick={onToggle}
        className="h-10 flex items-center justify-between px-4 bg-black/60 cursor-pointer hover:bg-white/5 transition-colors border-b border-white/5"
      >
        <div className="flex items-center gap-2 text-primary font-mono text-sm">
          <TerminalIcon className="w-4 h-4" />
          <span>GNN_TERMINAL_V1</span>
          <span className="ml-2 px-2 py-0.5 rounded-full bg-primary/10 text-[10px] animate-pulse">LIVE</span>
        </div>
        <div className="flex items-center gap-2">
           <div className="flex gap-1 h-1 w-16 bg-white/10 rounded-full overflow-hidden">
             <motion.div 
               className="h-full bg-primary" 
               animate={{ width: ["0%", "100%", "50%"] }} 
               transition={{ duration: 2, repeat: Infinity }}
             />
           </div>
           {isOpen ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronUp className="w-4 h-4 text-muted-foreground" />}
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 bg-black/80"
      >
        <AnimatePresence>
          {logs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-start gap-3 group"
            >
              <span className="text-muted-foreground shrink-0 select-none">
                [{log.timestamp.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}]
              </span>
              <span className={cn(
                "break-all",
                log.type === 'info' && "text-blue-400",
                log.type === 'success' && "text-primary",
                log.type === 'warning' && "text-yellow-400",
                log.type === 'error' && "text-destructive"
              )}>
                <span className="opacity-50 mr-2 select-none">
                  {log.type === 'info' && '>>'}
                  {log.type === 'success' && 'OK'}
                  {log.type === 'warning' && '!!'}
                  {log.type === 'error' && 'XX'}
                </span>
                {log.message}
              </span>
            </motion.div>
          ))}
          {logs.length === 0 && (
            <div className="text-muted-foreground opacity-50 italic">Waiting for system events...</div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
