import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Cpu, 
  Cloud, 
  Loader2, 
  Play, 
  Check, 
  X, 
  History,
  Zap,
  AlertCircle,
  Download,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  AIProvider, 
  generateEvolution, 
  initWebLLM, 
  isWebLLMReady, 
  getWebLLMProgress,
  getEvolutionHistory,
  EvolutionResult
} from '@/lib/evolution-engine';

interface EvolutionPanelProps {
  currentCode: string;
  onApplyEvolution: (code: string) => void;
}

interface AIConfig {
  backend: AIProvider;
  modelId: string;
  temperature: number;
  maxTokens: number;
}

export function EvolutionPanel({ currentCode, onApplyEvolution }: EvolutionPanelProps) {
  const [provider, setProvider] = useState<AIProvider>('openai');
  const [modelId, setModelId] = useState<string>('gpt-4o');
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [streamedOutput, setStreamedOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<EvolutionResult[]>([]);
  
  const [webllmStatus, setWebllmStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [webllmProgress, setWebllmProgress] = useState(0);
  const [webllmStatusText, setWebllmStatusText] = useState('');

  useEffect(() => {
    const loadConfig = async () => {
      try {
        const response = await fetch('/api/settings/ai_config');
        if (response.ok) {
          const setting = await response.json();
          if (setting?.value) {
            const config = setting.value as AIConfig;
            if (config.backend === 'llamacpp') {
              setProvider('openai');
            } else {
              setProvider(config.backend);
            }
            setModelId(config.modelId);
          }
        }
      } catch (err) {
        console.error('Failed to load AI config:', err);
      }
    };
    loadConfig();
  }, []);

  useEffect(() => {
    if (provider === 'webllm' && webllmStatus === 'idle') {
      loadWebLLM();
    }
  }, [provider]);

  const loadWebLLM = async () => {
    setWebllmStatus('loading');
    const success = await initWebLLM((progress, status) => {
      setWebllmProgress(progress);
      setWebllmStatusText(status);
    });
    setWebllmStatus(success ? 'ready' : 'error');
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    setGeneratedCode('');
    setStreamedOutput('');
    
    try {
      const result = await generateEvolution(
        { prompt, originalCode: currentCode, provider },
        (chunk) => setStreamedOutput(prev => prev + chunk)
      );
      setGeneratedCode(result.generatedCode);
      loadHistory();
    } catch (err: any) {
      setError(err.message || 'Evolution failed');
    } finally {
      setIsGenerating(false);
    }
  };

  const loadHistory = async () => {
    try {
      const data = await getEvolutionHistory();
      setHistory(data);
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleApply = () => {
    if (generatedCode) {
      onApplyEvolution(generatedCode);
      setGeneratedCode('');
      setPrompt('');
    }
  };

  return (
    <div className="h-full flex flex-col gap-4" data-testid="evolution-panel">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-secondary animate-pulse" />
          <h2 className="text-xl font-display text-secondary tracking-wider">SELF-EVOLUTION ENGINE</h2>
        </div>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono transition-colors",
            showHistory ? "bg-secondary/20 text-secondary" : "bg-white/5 text-muted-foreground hover:text-white"
          )}
          data-testid="button-toggle-history"
        >
          <History className="w-3 h-3" />
          HISTORY ({history.length})
        </button>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-xs font-mono text-muted-foreground">AI BACKEND:</span>
        <div className="flex gap-2">
          <button
            onClick={() => setProvider('openai')}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all",
              provider === 'openai'
                ? "bg-primary/20 text-primary border border-primary/50"
                : "bg-white/5 text-muted-foreground hover:bg-white/10"
            )}
            data-testid="button-provider-openai"
          >
            <Cloud className="w-4 h-4" />
            OPENAI (Cloud)
          </button>
          <button
            onClick={() => setProvider('webllm')}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded text-xs font-mono transition-all relative",
              provider === 'webllm'
                ? "bg-secondary/20 text-secondary border border-secondary/50"
                : "bg-white/5 text-muted-foreground hover:bg-white/10"
            )}
            data-testid="button-provider-webllm"
          >
            <Cpu className="w-4 h-4" />
            WEBLLM (Local)
            {webllmStatus === 'ready' && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {provider === 'webllm' && webllmStatus !== 'ready' && (
        <div className="glass-panel rounded-lg p-4 border border-secondary/30">
          {webllmStatus === 'loading' ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-secondary">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading SmolLM2 (360M, Quantized)...
              </div>
              <div className="w-full bg-black/40 rounded-full h-2">
                <div 
                  className="bg-secondary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${webllmProgress}%` }}
                />
              </div>
              <div className="text-xs text-muted-foreground truncate">{webllmStatusText}</div>
            </div>
          ) : webllmStatus === 'error' ? (
            <div className="flex flex-col gap-2 text-sm text-destructive">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                WebLLM failed to load. GPU memory may be insufficient.
              </div>
              <p className="text-xs text-muted-foreground">Try OpenAI backend instead, or use a device with more GPU memory.</p>
              <button onClick={loadWebLLM} className="text-xs underline text-secondary">Retry</button>
            </div>
          ) : (
            <button
              onClick={loadWebLLM}
              className="flex items-center gap-2 text-sm text-secondary hover:underline"
            >
              <Download className="w-4 h-4" />
              Click to load local LLM (~3GB download)
            </button>
          )}
        </div>
      )}

      <AnimatePresence mode="wait">
        {showHistory ? (
          <motion.div
            key="history"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex-1 overflow-auto space-y-2"
          >
            {history.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                No evolution history yet
              </div>
            ) : (
              history.map((item, i) => (
                <div
                  key={item.id || i}
                  className="glass-panel rounded-lg p-3 border border-white/5 hover:border-primary/30 transition-colors cursor-pointer"
                  onClick={() => {
                    setGeneratedCode(item.generatedCode);
                    setShowHistory(false);
                  }}
                  data-testid={`history-item-${item.id}`}
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className={cn(
                      "px-2 py-0.5 rounded",
                      item.provider === 'webllm' ? "bg-secondary/20 text-secondary" : "bg-primary/20 text-primary"
                    )}>
                      {item.provider.toUpperCase()}
                    </span>
                    <span className={cn(
                      "px-2 py-0.5 rounded",
                      item.status === 'applied' ? "bg-green-500/20 text-green-400" :
                      item.status === 'failed' ? "bg-red-500/20 text-red-400" :
                      "bg-yellow-500/20 text-yellow-400"
                    )}>
                      {item.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-sm text-foreground truncate">{item.prompt}</div>
                </div>
              ))
            )}
          </motion.div>
        ) : (
          <motion.div
            key="generator"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col gap-4 min-h-0"
          >
            <div className="space-y-2">
              <label className="text-xs font-mono text-muted-foreground">EVOLUTION PROMPT:</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe how to evolve the code... (e.g., 'Add error handling and optimize the SSV calculation')"
                className="w-full h-24 bg-black/40 border border-white/10 rounded-lg p-3 text-sm font-mono text-foreground placeholder:text-muted-foreground/50 resize-none focus:outline-none focus:border-primary/50"
                data-testid="input-evolution-prompt"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim() || (provider === 'webllm' && webllmStatus !== 'ready')}
              className={cn(
                "flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-mono text-sm transition-all",
                isGenerating || !prompt.trim() || (provider === 'webllm' && webllmStatus !== 'ready')
                  ? "bg-muted text-muted-foreground cursor-not-allowed"
                  : "bg-gradient-to-r from-primary/80 to-secondary/80 text-black hover:from-primary hover:to-secondary shadow-lg hover:shadow-primary/25"
              )}
              data-testid="button-generate"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  EVOLVING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  GENERATE EVOLUTION
                </>
              )}
            </button>

            {error && (
              <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-lg">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            {(streamedOutput || generatedCode) && (
              <div className="flex-1 flex flex-col min-h-0 glass-panel rounded-lg border border-white/5 overflow-hidden">
                <div className="px-4 py-2 bg-black/40 border-b border-white/5 flex items-center justify-between">
                  <span className="text-xs font-mono text-muted-foreground">GENERATED CODE</span>
                  {generatedCode && (
                    <div className="flex gap-2">
                      <button
                        onClick={handleApply}
                        className="flex items-center gap-1 px-2 py-1 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded text-xs font-mono"
                        data-testid="button-apply-evolution"
                      >
                        <Check className="w-3 h-3" /> APPLY
                      </button>
                      <button
                        onClick={() => { setGeneratedCode(''); setStreamedOutput(''); }}
                        className="flex items-center gap-1 px-2 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-xs font-mono"
                        data-testid="button-discard-evolution"
                      >
                        <X className="w-3 h-3" /> DISCARD
                      </button>
                    </div>
                  )}
                </div>
                <pre className="flex-1 p-4 text-xs font-mono overflow-auto text-green-400/90 whitespace-pre-wrap">
                  {generatedCode || streamedOutput}
                  {isGenerating && <span className="animate-pulse">|</span>}
                </pre>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
