import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal, Cpu, Gamepad2, FileCode, Settings, Minimize2, Maximize2, X, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import gnnBackground from "@assets/generated_images/futuristic_gnn_ai_core_interface_background.png";

interface GNNLayoutProps {
  children: React.ReactNode;
  activeMode: string;
  onModeChange: (mode: string) => void;
  onOpenSettings: () => void;
}

export function GNNLayout({ children, activeMode, onModeChange, onOpenSettings }: GNNLayoutProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-background text-foreground font-sans selection:bg-primary selection:text-black scanlines">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 opacity-40 pointer-events-none"
        style={{
          backgroundImage: `url(${gnnBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />
      
      {/* Grid Overlay */}
      <div className="absolute inset-0 z-0 bg-[linear-gradient(rgba(0,255,42,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,42,0.03)_1px,transparent_1px)] bg-[size:50px_50px] pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 flex flex-col h-screen p-4 gap-4">
        
        {/* Header / HUD Top */}
        <header className="flex flex-col md:flex-row items-center justify-between p-4 glass-panel rounded-lg border-glow animate-in slide-in-from-top duration-700 gap-4 md:gap-0">
          <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-4">
              <div className="relative w-10 h-10 flex items-center justify-center border border-primary rounded-full animate-pulse-slow">
                <Cpu className="w-6 h-6 text-primary" />
                <div className="absolute inset-0 rounded-full bg-primary/20 blur-md" />
              </div>
              <div>
                <h1 className="text-2xl font-display font-bold tracking-widest text-white uppercase text-glow">
                  GNN <span className="text-primary">NEXUS</span>
                </h1>
                <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                  <span className="text-primary">● ONLINE</span>
                  <span>v.2.4.9</span>
                </div>
              </div>
            </div>
            
            {/* Mobile Settings Button */}
            <button 
              onClick={onOpenSettings}
              className="md:hidden p-2 rounded-full hover:bg-white/10 text-primary transition-colors border border-transparent hover:border-primary/50"
            >
              <Settings className="w-5 h-5 animate-[spin_10s_linear_infinite]" />
            </button>
          </div>

          <nav className="flex items-center gap-2 bg-black/40 p-1 rounded-md border border-white/10 w-full md:w-auto overflow-x-auto no-scrollbar">
            {[
              { id: 'runner', icon: Cpu, label: 'RUNNER' },
              { id: 'ide', icon: FileCode, label: 'IDE' },
              { id: 'evolve', icon: Sparkles, label: 'EVOLVE' },
              { id: 'game', icon: Gamepad2, label: 'GAME' },
            ].map((mode) => (
              <button
                key={mode.id}
                onClick={() => onModeChange(mode.id)}
                className={cn(
                  "flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-sm font-mono text-sm transition-all duration-300 relative overflow-hidden group whitespace-nowrap",
                  activeMode === mode.id 
                    ? "bg-primary/20 text-primary border border-primary/50 shadow-[0_0_15px_rgba(0,255,42,0.3)]" 
                    : "text-muted-foreground hover:text-white hover:bg-white/5"
                )}
              >
                <mode.icon className="w-4 h-4" />
                {mode.label}
                {activeMode === mode.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-primary shadow-[0_0_10px_#00ff2a]"
                  />
                )}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs font-mono text-primary">{currentTime.toLocaleTimeString()}</div>
              <div className="text-[10px] font-mono text-muted-foreground tracking-widest">SYSTEM READY</div>
            </div>
            <button 
              onClick={onOpenSettings}
              className="p-2 rounded-full hover:bg-white/10 text-primary transition-colors border border-transparent hover:border-primary/50"
            >
              <Settings className="w-5 h-5 animate-[spin_10s_linear_infinite]" />
            </button>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-hidden relative glass-panel rounded-lg border-glow animate-in zoom-in-95 duration-500 delay-100">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeMode}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="h-full w-full p-6"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>
    </div>
  );
}
