import React, { useState, useEffect, useRef } from 'react';
import Editor from '@monaco-editor/react';
import { 
  File, FilePlus, Save, Trash2, Play, Layout as LayoutIcon, 
  ChevronRight, ChevronLeft, Menu, FileCode, FileJson, FileType, Code2, Folder, X, Eye, EyeOff,
  Share2, Upload, Check, Copy
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';

interface FileItem {
  id: string;
  name: string;
  content: string;
  language: string;
}

const defaultFiles: FileItem[] = [
  {
    id: '1',
    name: 'index.html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GNN Project</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>Welcome to GNN</h1>
    <p>Edit files to see live preview</p>
    <button id="btn">Click Me</button>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
    language: 'html'
  },
  {
    id: '2',
    name: 'style.css',
    content: `* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, sans-serif;
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
}

.container {
  text-align: center;
  padding: 2rem;
}

h1 {
  font-size: 3rem;
  margin-bottom: 1rem;
  background: linear-gradient(90deg, #00ff2a, #a633e6);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

p {
  color: #888;
  margin-bottom: 2rem;
}

button {
  padding: 1rem 2rem;
  font-size: 1rem;
  border: 2px solid #00ff2a;
  background: transparent;
  color: #00ff2a;
  cursor: pointer;
  transition: all 0.3s;
  border-radius: 8px;
}

button:hover {
  background: #00ff2a;
  color: #000;
}`,
    language: 'css'
  },
  {
    id: '3',
    name: 'script.js',
    content: `document.getElementById('btn').addEventListener('click', () => {
  alert('Hello from GNN!');
});

console.log('GNN Script Loaded');`,
    language: 'javascript'
  }
];

const FileIcon = ({ name }: { name: string }) => {
  if (name.endsWith('.html')) return <Code2 className="h-4 w-4 text-orange-500" />;
  if (name.endsWith('.css')) return <FileType className="h-4 w-4 text-blue-500" />;
  if (name.endsWith('.js') || name.endsWith('.ts')) return <FileCode className="h-4 w-4 text-yellow-500" />;
  if (name.endsWith('.json')) return <FileJson className="h-4 w-4 text-green-500" />;
  if (name.endsWith('.py')) return <FileCode className="h-4 w-4 text-primary" />;
  return <File className="h-4 w-4 text-muted-foreground" />;
};

interface GlitchIDEProps {
  onRun?: (code: string, language: string) => Promise<string | void>;
  isProcessing?: boolean;
}

export function GlitchIDE({ onRun, isProcessing = false }: GlitchIDEProps) {
  const [files, setFiles] = useState<FileItem[]>(defaultFiles);
  const [activeFileId, setActiveFileId] = useState<string>('1');
  const [previewHtml, setPreviewHtml] = useState<string>('');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [showPublish, setShowPublish] = useState(false);
  const [publishTitle, setPublishTitle] = useState('');
  const [publishAuthor, setPublishAuthor] = useState('');
  const [publishDescription, setPublishDescription] = useState('');
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishedSlug, setPublishedSlug] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const saveTimeoutRef = useRef<NodeJS.Timeout>(undefined);

  const activeFile = files.find(f => f.id === activeFileId);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        setShowSidebar(true);
        setShowPreview(true);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    updatePreview();
  }, [files]);

  const updatePreview = () => {
    const indexFile = files.find(f => f.name === 'index.html');
    if (!indexFile) return;

    let html = indexFile.content;

    files.forEach(f => {
      if (f.name.endsWith('.css')) {
        html = html.replace(
          `<link rel="stylesheet" href="${f.name}">`,
          `<style>${f.content}</style>`
        );
      }
      if (f.name.endsWith('.js')) {
        html = html.replace(
          `<script src="${f.name}"></script>`,
          `<script>${f.content}</script>`
        );
      }
    });

    setPreviewHtml(html);
  };

  const handleEditorChange = (value: string | undefined) => {
    if (value === undefined || !activeFileId) return;

    setFiles(prev => prev.map(f => 
      f.id === activeFileId ? { ...f, content: value } : f
    ));

    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      updatePreview();
    }, 500);
  };

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName) return;

    const ext = newFileName.split('.').pop() || '';
    const langMap: Record<string, string> = {
      'html': 'html', 'css': 'css', 'js': 'javascript', 'ts': 'typescript',
      'json': 'json', 'py': 'python', 'md': 'markdown'
    };

    const newFile: FileItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: newFileName,
      content: '',
      language: langMap[ext] || 'plaintext'
    };

    setFiles(prev => [...prev, newFile]);
    setActiveFileId(newFile.id);
    setIsCreateOpen(false);
    setNewFileName('');
    if (isMobile) setShowSidebar(false);
  };

  const handleDeleteFile = (e: React.MouseEvent, fileId: string) => {
    e.stopPropagation();
    const file = files.find(f => f.id === fileId);
    if (file?.name === 'index.html') return;

    if (confirm('Delete this file?')) {
      setFiles(prev => prev.filter(f => f.id !== fileId));
      if (activeFileId === fileId) {
        setActiveFileId(files[0]?.id || '');
      }
    }
  };

  const handleFileSelect = (fileId: string) => {
    setActiveFileId(fileId);
    if (isMobile) {
      setShowSidebar(false);
      setShowPreview(false);
    }
  };

  const getLanguage = (filename: string): string => {
    if (filename.endsWith('.html')) return 'html';
    if (filename.endsWith('.css')) return 'css';
    if (filename.endsWith('.js')) return 'javascript';
    if (filename.endsWith('.ts')) return 'typescript';
    if (filename.endsWith('.json')) return 'json';
    if (filename.endsWith('.py')) return 'python';
    return 'plaintext';
  };

  const handlePublish = async () => {
    if (!publishTitle.trim()) return;
    
    setIsPublishing(true);
    try {
      const res = await apiRequest('POST', '/api/projects', {
        title: publishTitle.trim(),
        description: publishDescription.trim(),
        authorName: publishAuthor.trim() || 'Anonymous',
        files: files.map(f => ({
          name: f.name,
          content: f.content,
          language: f.language
        }))
      });
      const project = await res.json();
      setPublishedSlug(project.slug);
    } catch (error) {
      console.error('Publish error:', error);
    } finally {
      setIsPublishing(false);
    }
  };

  const copyShareLink = () => {
    if (!publishedSlug) return;
    const url = `${window.location.origin}/game/${publishedSlug}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const resetPublish = () => {
    setShowPublish(false);
    setPublishTitle('');
    setPublishAuthor('');
    setPublishDescription('');
    setPublishedSlug(null);
  };

  return (
    <div className="h-full flex flex-col bg-background rounded-lg overflow-hidden border border-white/10">
      {/* Top Bar - Mobile Friendly */}
      <div className="h-14 md:h-12 border-b border-white/10 flex items-center justify-between px-2 md:px-4 bg-card/50 backdrop-blur-md">
        <div className="flex items-center gap-2 md:gap-3">
          <button
            onClick={() => setShowSidebar(!showSidebar)}
            className="p-3 md:p-2 hover:bg-white/10 rounded-lg transition-colors touch-manipulation"
            data-testid="button-toggle-sidebar"
          >
            <Menu className="w-5 h-5 md:w-4 md:h-4 text-muted-foreground" />
          </button>
          <span className="text-sm md:text-xs font-mono text-muted-foreground truncate max-w-[120px] md:max-w-none">
            {activeFile?.name || 'GNN Project'}
          </span>
        </div>

        <div className="flex items-center gap-1 md:gap-2">
          <button
            onClick={() => {
              setShowPreview(!showPreview);
              if (isMobile && !showPreview) setShowSidebar(false);
            }}
            className={cn(
              "flex items-center gap-1 md:gap-2 px-3 py-2 md:py-1.5 rounded-lg text-sm md:text-xs font-mono transition-colors touch-manipulation min-h-[44px] md:min-h-0",
              showPreview ? "bg-primary/20 text-primary" : "bg-white/5 text-muted-foreground hover:text-white"
            )}
            data-testid="button-toggle-preview"
          >
            {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span className="hidden md:inline">Preview</span>
          </button>
          <button 
            onClick={() => setShowPublish(true)}
            className="flex items-center gap-1 md:gap-2 px-3 py-2 md:py-1.5 bg-purple-600 text-white hover:bg-purple-700 rounded-lg text-sm md:text-xs font-mono font-bold transition-colors touch-manipulation min-h-[44px] md:min-h-0"
            data-testid="button-publish"
          >
            <Upload className="w-4 h-4" />
            <span className="hidden sm:inline">Publish</span>
          </button>
          <button 
            className="flex items-center gap-1 md:gap-2 px-4 py-2 md:py-1.5 bg-primary text-black hover:bg-primary/90 rounded-lg text-sm md:text-xs font-mono font-bold transition-colors touch-manipulation min-h-[44px] md:min-h-0"
            data-testid="button-run-live"
          >
            <Play className="w-4 h-4 fill-current" />
            <span className="hidden sm:inline">Live</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar - Mobile Overlay / Desktop Fixed */}
        {showSidebar && (
          <>
            {isMobile && (
              <div 
                className="absolute inset-0 bg-black/50 z-10"
                onClick={() => setShowSidebar(false)}
              />
            )}
            <div className={cn(
              "bg-card/95 md:bg-card/30 border-r border-white/5 flex flex-col flex-shrink-0 z-20",
              isMobile 
                ? "absolute left-0 top-0 bottom-0 w-72 shadow-2xl" 
                : "w-56"
            )}>
              <div className="p-4 md:p-3 border-b border-white/5 flex items-center justify-between">
                <span className="text-sm md:text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Folder className="w-4 h-4 md:w-3 md:h-3" /> Files
                </span>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setIsCreateOpen(true)}
                    className="p-2 md:p-1 hover:bg-white/10 rounded-lg text-muted-foreground hover:text-primary transition-colors touch-manipulation"
                    data-testid="button-create-file"
                  >
                    <FilePlus className="h-5 w-5 md:h-4 md:w-4" />
                  </button>
                  {isMobile && (
                    <button 
                      onClick={() => setShowSidebar(false)}
                      className="p-2 hover:bg-white/10 rounded-lg text-muted-foreground hover:text-white transition-colors touch-manipulation"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
                {files.map(file => (
                  <div
                    key={file.id}
                    onClick={() => handleFileSelect(file.id)}
                    className={cn(
                      "group flex items-center justify-between px-4 py-3 md:px-3 md:py-2 rounded-lg text-base md:text-sm cursor-pointer transition-all touch-manipulation",
                      activeFileId === file.id
                        ? "bg-primary/10 text-primary border-l-2 border-primary"
                        : "text-muted-foreground hover:bg-white/5 hover:text-foreground active:bg-white/10"
                    )}
                    data-testid={`file-item-${file.id}`}
                  >
                    <div className="flex items-center gap-3 md:gap-2 truncate">
                      <FileIcon name={file.name} />
                      <span className="truncate font-mono">{file.name}</span>
                    </div>

                    {file.name !== 'index.html' && (
                      <button
                        onClick={(e) => handleDeleteFile(e, file.id)}
                        className="opacity-100 md:opacity-0 md:group-hover:opacity-100 p-2 md:p-1 hover:text-destructive transition-opacity touch-manipulation"
                        data-testid={`button-delete-file-${file.id}`}
                      >
                        <Trash2 className="h-4 w-4 md:h-3 md:w-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Main Content - Editor or Preview */}
        <div className="flex-1 flex flex-col md:flex-row min-w-0">
          {/* Editor Panel */}
          {!showPreview && (
            <div className="flex-1 flex flex-col min-w-0">
              {activeFile && (
                <div className="h-10 md:h-9 bg-card/20 border-b border-white/5 flex items-center px-3 md:px-2">
                  <div className="flex items-center gap-2 px-3 py-1.5 md:py-1 bg-card/50 rounded-t text-sm md:text-xs border-t border-x border-white/10 relative top-[1px]">
                    <FileIcon name={activeFile.name} />
                    <span className="font-mono">{activeFile.name}</span>
                  </div>
                </div>
              )}

              <div className="flex-1 relative">
                {activeFile ? (
                  <Editor
                    height="100%"
                    language={getLanguage(activeFile.name)}
                    value={activeFile.content}
                    theme="vs-dark"
                    onChange={handleEditorChange}
                    options={{
                      minimap: { enabled: false },
                      fontSize: isMobile ? 16 : 14,
                      fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                      padding: { top: 16 },
                      scrollBeyondLastLine: false,
                      lineNumbers: isMobile ? 'off' : 'on',
                      roundedSelection: false,
                      automaticLayout: true,
                      scrollbar: {
                        useShadows: false,
                        verticalScrollbarSize: isMobile ? 12 : 8,
                        horizontalScrollbarSize: isMobile ? 12 : 8,
                      },
                      wordWrap: 'on',
                      glyphMargin: false,
                      folding: !isMobile,
                      lineDecorationsWidth: isMobile ? 0 : 10,
                      lineNumbersMinChars: isMobile ? 0 : 3,
                    }}
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-lg md:text-base">
                    Select a file to start editing
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Preview Panel */}
          {showPreview && (
            <div className={cn(
              "bg-white border-l border-white/10 flex flex-col",
              isMobile ? "absolute inset-0 z-10" : "w-[40%] flex-shrink-0"
            )}>
              <div className="h-12 md:h-9 bg-zinc-100 border-b border-zinc-200 flex items-center px-4 justify-between">
                <span className="text-sm md:text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-2">
                  <LayoutIcon className="h-4 w-4 md:h-3 md:w-3" /> Preview
                </span>
                <button 
                  onClick={() => setShowPreview(false)}
                  className="p-2 md:p-1 hover:bg-zinc-200 rounded-lg transition-colors touch-manipulation"
                >
                  <X className="h-5 w-5 md:h-4 md:w-4 text-zinc-500" />
                </button>
              </div>
              <div className="flex-1 bg-white relative">
                {previewHtml ? (
                  <iframe
                    srcDoc={previewHtml}
                    className="w-full h-full border-0"
                    title="Preview"
                    sandbox="allow-scripts"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-zinc-400 text-base md:text-sm">
                    Create an index.html to preview
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Create File Modal */}
      {isCreateOpen && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setIsCreateOpen(false)}>
          <div className="bg-card border border-white/10 rounded-xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl md:text-lg font-semibold">New File</h3>
              <button onClick={() => setIsCreateOpen(false)} className="p-2 text-muted-foreground hover:text-white touch-manipulation">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateFile}>
              <input
                type="text"
                placeholder="filename.js"
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                autoFocus
                className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-base md:text-sm font-mono focus:border-primary outline-none mb-2"
              />
              <p className="text-sm md:text-xs text-muted-foreground mb-4">Include extension (.js, .css, .html, .py)</p>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setIsCreateOpen(false)} className="px-4 py-3 md:py-2 text-base md:text-sm text-muted-foreground hover:text-white touch-manipulation">
                  Cancel
                </button>
                <button type="submit" className="px-6 py-3 md:py-2 bg-primary text-black rounded-lg text-base md:text-sm font-medium hover:bg-primary/90 touch-manipulation">
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Publish Modal */}
      {showPublish && (
        <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={resetPublish}>
          <div className="bg-card border border-white/10 rounded-xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
            {publishedSlug ? (
              <>
                <div className="text-center mb-6">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center">
                    <Check className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">Published!</h3>
                  <p className="text-muted-foreground">Your creation is now live and shareable</p>
                </div>
                <div className="bg-black/30 rounded-lg p-4 mb-4">
                  <p className="text-xs text-muted-foreground mb-2">Share Link</p>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-sm text-primary truncate">
                      {window.location.origin}/game/{publishedSlug}
                    </code>
                    <button
                      onClick={copyShareLink}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                      data-testid="button-copy-link"
                    >
                      {copied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={resetPublish}
                    className="flex-1 px-4 py-3 bg-white/10 rounded-lg text-sm font-medium hover:bg-white/20 transition-colors"
                  >
                    Close
                  </button>
                  <a
                    href={`/game/${publishedSlug}`}
                    className="flex-1 px-4 py-3 bg-primary text-black rounded-lg text-sm font-medium text-center hover:bg-primary/90 transition-colors"
                    data-testid="link-view-project"
                  >
                    View Project
                  </a>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-600/20 flex items-center justify-center">
                      <Upload className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Publish Creation</h3>
                      <p className="text-sm text-muted-foreground">Share your work with the world</p>
                    </div>
                  </div>
                  <button onClick={resetPublish} className="p-2 text-muted-foreground hover:text-white touch-manipulation">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Title *</label>
                    <input
                      type="text"
                      placeholder="My Awesome Project"
                      value={publishTitle}
                      onChange={(e) => setPublishTitle(e.target.value)}
                      className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-base focus:border-primary outline-none"
                      data-testid="input-publish-title"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Your Name</label>
                    <input
                      type="text"
                      placeholder="Anonymous"
                      value={publishAuthor}
                      onChange={(e) => setPublishAuthor(e.target.value)}
                      className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-base focus:border-primary outline-none"
                      data-testid="input-publish-author"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1 block">Description</label>
                    <textarea
                      placeholder="Tell us about your creation..."
                      value={publishDescription}
                      onChange={(e) => setPublishDescription(e.target.value)}
                      rows={3}
                      className="w-full bg-black/30 border border-white/10 rounded-lg px-4 py-3 text-base focus:border-primary outline-none resize-none"
                      data-testid="input-publish-description"
                    />
                  </div>
                </div>
                <div className="flex gap-2 mt-6">
                  <button
                    type="button"
                    onClick={resetPublish}
                    className="flex-1 px-4 py-3 text-muted-foreground hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handlePublish}
                    disabled={isPublishing || !publishTitle.trim()}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    data-testid="button-confirm-publish"
                  >
                    {isPublishing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Publishing...
                      </>
                    ) : (
                      <>
                        <Share2 className="w-4 h-4" />
                        Publish
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
