import React, { useEffect, useRef, useState } from 'react';
import { Play, Pause, Maximize2, Minimize2, RefreshCw, Code2, Heart, GitFork, Eye, Grid, Sparkles, ExternalLink } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLocation } from 'wouter';

interface FileItem {
  id: string;
  name: string;
  content: string;
  language: string;
}

interface Project {
  id: number;
  title: string;
  description: string | null;
  slug: string;
  authorName: string;
  likesCount: number;
  forksCount: number;
  createdAt: string;
}

interface GameModeProps {
  files?: FileItem[];
}

export function GameMode({ files = [] }: GameModeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [previewHtml, setPreviewHtml] = useState<string>('');
  const [showCreation, setShowCreation] = useState(true);
  const [viewMode, setViewMode] = useState<'creation' | 'explore' | 'sim'>('creation');
  const [projects, setProjects] = useState<Project[]>([]);
  const [loadingProjects, setLoadingProjects] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (files.length > 0) {
      const indexFile = files.find(f => f.name === 'index.html');
      if (indexFile) {
        let html = indexFile.content;
        
        files.forEach(f => {
          if (f.name.endsWith('.css')) {
            html = html.replace(
              `<link rel="stylesheet" href="${f.name}">`,
              `<style>${f.content}</style>`
            );
          }
          if (f.name.endsWith('.js')) {
            html = html.replace(
              `<script src="${f.name}"></script>`,
              `<script>${f.content}</script>`
            );
          }
        });
        
        setPreviewHtml(html);
        setViewMode('creation');
      }
    }
  }, [files]);

  useEffect(() => {
    if (viewMode === 'explore' && projects.length === 0) {
      fetchProjects();
    }
  }, [viewMode]);

  const fetchProjects = async () => {
    setLoadingProjects(true);
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      setProjects(data);
    } catch (err) {
      console.error('Failed to fetch projects:', err);
    } finally {
      setLoadingProjects(false);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || viewMode !== 'sim') return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: {x: number, y: number, vx: number, vy: number, size: number, color: string}[] = [];

    const resize = () => {
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 600;
    };
    
    window.addEventListener('resize', resize);
    resize();

    for(let i=0; i<50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        color: Math.random() > 0.5 ? '#00ff2a' : '#a633e6'
      });
    }

    const render = () => {
      if (!isPlaying) return;
      
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
        
        particles.forEach(p2 => {
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx*dx + dy*dy);
          if (dist < 100) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(0, 255, 42, ${1 - dist/100})`;
            ctx.stroke();
          }
        });
      });

      animationFrameId = requestAnimationFrame(render);
    };

    if (isPlaying) render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, viewMode]);

  const handleRefresh = () => {
    if (iframeRef.current && previewHtml) {
      iframeRef.current.srcdoc = previewHtml;
    }
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const hasCreation = files.length > 0 && previewHtml;

  return (
    <div className={cn(
      "h-full flex flex-col relative",
      isFullscreen && "fixed inset-0 z-50 bg-black"
    )}>
      <div className="h-14 md:h-12 bg-card/50 border-b border-white/10 flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-mono text-primary">
              {viewMode === 'creation' ? 'YOUR CREATION' : viewMode === 'explore' ? 'EXPLORE' : 'NEURAL SIM'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasCreation && (
            <button
              onClick={() => setViewMode('creation')}
              className={cn(
                "flex items-center gap-2 px-3 py-2 md:py-1.5 rounded-lg text-sm md:text-xs font-mono transition-colors touch-manipulation min-h-[44px] md:min-h-0",
                viewMode === 'creation'
                  ? "bg-primary/20 text-primary" 
                  : "bg-white/5 text-muted-foreground hover:text-white"
              )}
              data-testid="button-view-creation"
            >
              <Code2 className="w-4 h-4" />
              <span className="hidden sm:inline">Creation</span>
            </button>
          )}

          <button
            onClick={() => setViewMode('explore')}
            className={cn(
              "flex items-center gap-2 px-3 py-2 md:py-1.5 rounded-lg text-sm md:text-xs font-mono transition-colors touch-manipulation min-h-[44px] md:min-h-0",
              viewMode === 'explore'
                ? "bg-purple-500/20 text-purple-400" 
                : "bg-white/5 text-muted-foreground hover:text-white"
            )}
            data-testid="button-view-explore"
          >
            <Grid className="w-4 h-4" />
            <span className="hidden sm:inline">Explore</span>
          </button>

          <button
            onClick={() => setViewMode('sim')}
            className={cn(
              "flex items-center gap-2 px-3 py-2 md:py-1.5 rounded-lg text-sm md:text-xs font-mono transition-colors touch-manipulation min-h-[44px] md:min-h-0",
              viewMode === 'sim'
                ? "bg-primary/20 text-primary" 
                : "bg-white/5 text-muted-foreground hover:text-white"
            )}
            data-testid="button-view-sim"
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Sim</span>
          </button>
          
          {viewMode === 'creation' && hasCreation && (
            <button
              onClick={handleRefresh}
              className="p-3 md:p-2 hover:bg-white/10 rounded-lg text-muted-foreground hover:text-primary transition-colors touch-manipulation"
              data-testid="button-refresh-preview"
            >
              <RefreshCw className="w-5 h-5 md:w-4 md:h-4" />
            </button>
          )}

          {viewMode === 'sim' && (
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-3 md:p-2 hover:bg-white/10 rounded-lg text-muted-foreground hover:text-primary transition-colors touch-manipulation"
              data-testid="button-play-pause"
            >
              {isPlaying ? <Pause className="w-5 h-5 md:w-4 md:h-4" /> : <Play className="w-5 h-5 md:w-4 md:h-4" />}
            </button>
          )}

          <button
            onClick={toggleFullscreen}
            className="p-3 md:p-2 hover:bg-white/10 rounded-lg text-muted-foreground hover:text-primary transition-colors touch-manipulation"
            data-testid="button-fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5 md:w-4 md:h-4" /> : <Maximize2 className="w-5 h-5 md:w-4 md:h-4" />}
          </button>
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden">
        {viewMode === 'creation' && hasCreation ? (
          <iframe
            ref={iframeRef}
            srcDoc={previewHtml}
            className="w-full h-full border-0 bg-white"
            title="Your Creation"
            sandbox="allow-scripts allow-same-origin"
          />
        ) : viewMode === 'creation' && !hasCreation ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8">
            <Code2 className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-display text-primary mb-2">No Creation Yet</h3>
            <p className="text-muted-foreground max-w-md">
              Go to the IDE and create your project with HTML, CSS, and JavaScript. 
              Your creation will appear here!
            </p>
          </div>
        ) : viewMode === 'explore' ? (
          <div className="h-full overflow-y-auto p-4 md:p-6">
            {loadingProjects ? (
              <div className="flex items-center justify-center h-full">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : projects.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Grid className="w-16 h-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-display text-primary mb-2">No Projects Yet</h3>
                <p className="text-muted-foreground max-w-md">
                  Be the first to publish a creation! Go to the IDE and click Publish.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {projects.map(project => (
                  <div
                    key={project.id}
                    onClick={() => setLocation(`/game/${project.slug}`)}
                    className="group bg-card/50 border border-white/10 rounded-xl p-4 cursor-pointer hover:border-primary/50 hover:bg-card/70 transition-all"
                    data-testid={`project-card-${project.id}`}
                  >
                    <div className="aspect-video bg-gradient-to-br from-primary/20 to-purple-500/20 rounded-lg mb-3 flex items-center justify-center group-hover:from-primary/30 group-hover:to-purple-500/30 transition-colors">
                      <Code2 className="w-10 h-10 text-primary/50 group-hover:text-primary/70" />
                    </div>
                    <h4 className="font-semibold truncate mb-1 group-hover:text-primary transition-colors" data-testid={`project-title-${project.id}`}>
                      {project.title}
                    </h4>
                    <p className="text-sm text-muted-foreground truncate mb-3">
                      by {project.authorName}
                    </p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Heart className="w-4 h-4" />
                        {project.likesCount}
                      </span>
                      <span className="flex items-center gap-1">
                        <GitFork className="w-4 h-4" />
                        {project.forksCount}
                      </span>
                      <span className="ml-auto flex items-center gap-1 text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                        <Eye className="w-4 h-4" />
                        View
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            <div className="absolute top-4 left-4 z-10 bg-black/50 p-3 rounded-lg border border-white/10 font-mono text-sm md:text-xs">
              <div className="text-primary mb-1">NEURAL SIMULATION</div>
              <div className="text-muted-foreground">Particle Network Active</div>
            </div>
            <canvas ref={canvasRef} className="w-full h-full bg-black/20" />
          </>
        )}
      </div>

      <div className="h-8 bg-black/40 border-t border-white/5 flex items-center justify-between px-4 text-xs font-mono text-muted-foreground shrink-0">
        <span>
          {viewMode === 'creation' && hasCreation 
            ? `${files.length} files loaded` 
            : viewMode === 'explore'
            ? `${projects.length} projects`
            : 'Neural particles: 50'}
        </span>
        <span className="flex items-center gap-2">
          <span className={cn("w-2 h-2 rounded-full", isPlaying || viewMode !== 'sim' ? "bg-primary animate-pulse" : "bg-muted")} />
          {viewMode === 'sim' ? (isPlaying ? 'RUNNING' : 'PAUSED') : 'ACTIVE'}
        </span>
      </div>
    </div>
  );
}
