import React, { useState, useEffect } from 'react';
import { GNNLayout } from '@/components/gnn/layout';
import { ZipRunner } from '@/components/gnn/zip-runner';
import { MiniIDE } from '@/components/gnn/mini-ide';
import { GlitchIDE } from '@/components/gnn/glitch-ide';
import { GameMode } from '@/components/gnn/game-mode';
import { GNNTerminal, LogEntry } from '@/components/gnn/terminal';
import { SettingsPanel } from '@/components/gnn/settings-panel';
import { EvolutionPanel } from '@/components/gnn/evolution-panel';
import { AnimatePresence } from 'framer-motion';
import { usePyodide } from '@/hooks/use-pyodide';
import { SENTENCE_SYSTEM_PY } from '@/lib/sentence-system';

export default function Home() {
  const [activeMode, setActiveMode] = useState('runner');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', timestamp: new Date(), type: 'info', message: 'GNN Kernel initializing...' },
  ]);
  const [currentCode, setCurrentCode] = useState(SENTENCE_SYSTEM_PY);

  const { pyodide, isLoading: isPyodideLoading, error: pyodideError, runPython } = usePyodide();

  useEffect(() => {
    if (!isPyodideLoading && pyodide) {
      addLog('success', 'Pyodide Runtime v0.25.0 Loaded.');
      addLog('info', 'Neural bindings ready.');
    }
    if (pyodideError) {
      addLog('error', `Runtime Error: ${pyodideError}`);
    }
  }, [isPyodideLoading, pyodide, pyodideError]);

  const addLog = (type: 'info' | 'success' | 'warning' | 'error', message: string) => {
    setLogs(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
      type,
      message
    }]);
  };

  const handleRunZip = async (file: File) => {
    addLog('info', `Mounting archive: ${file.name}...`);
    
    // Convert file to base64
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      const base64Content = base64.split(',')[1]; // Remove data:application/zip;base64,
      
      try {
        const response = await fetch('/api/modules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: file.name.replace('.zip', ''),
            filename: file.name,
            size: file.size,
            content: base64Content
          })
        });
        
        if (response.ok) {
          addLog('success', `Archive ${file.name} saved to library.`);
          addLog('info', `Executing entry point...`);
          setActiveMode('ide');
        } else {
          addLog('error', `Failed to save archive.`);
        }
      } catch (err) {
        addLog('error', `Archive upload failed: ${err}`);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRunCode = async (code: string, language: string) => {
    addLog('info', `Executing ${language.toUpperCase()} sequence...`);
    
    if (language === 'python') {
      if (!pyodide) {
        addLog('error', 'Pyodide runtime not ready.');
        return "Error: Runtime not ready";
      }
      try {
        const result = await runPython(code);
        addLog('success', 'Execution completed.');
        return result;
      } catch (err: any) {
        addLog('error', `Execution failed: ${err.message}`);
        return `Traceback:\n${err.message}`;
      }
    } else {
      // Mock execution for JS/CSS for now
      addLog('warning', 'JS/CSS execution running in simulation mode (not implemented).');
      return "Simulation mode: Execution successful (No output)";
    }
  };

  return (
    <GNNLayout 
      activeMode={activeMode} 
      onModeChange={setActiveMode}
      onOpenSettings={() => setIsSettingsOpen(true)}
    >
      {activeMode === 'runner' && <ZipRunner onRun={handleRunZip} />}
      
      {activeMode === 'ide' && (
        <GlitchIDE 
          onRun={handleRunCode}
          isProcessing={isPyodideLoading}
        />
      )}
      
      {activeMode === 'evolve' && (
        <EvolutionPanel 
          currentCode={currentCode}
          onApplyEvolution={(code) => {
            setCurrentCode(code);
            addLog('success', 'Evolution applied! Check IDE for updated code.');
            setActiveMode('ide');
          }}
        />
      )}
      
      {activeMode === 'game' && <GameMode />}

      <GNNTerminal 
        logs={logs} 
        isOpen={isTerminalOpen} 
        onToggle={() => setIsTerminalOpen(!isTerminalOpen)} 
      />

      <AnimatePresence>
        {isSettingsOpen && (
          <SettingsPanel isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
        )}
      </AnimatePresence>
    </GNNLayout>
  );
}
