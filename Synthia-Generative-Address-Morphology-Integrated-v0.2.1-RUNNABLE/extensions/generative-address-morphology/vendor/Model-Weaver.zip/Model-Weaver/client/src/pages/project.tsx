import React, { useState, useEffect, useRef } from 'react';
import { useParams, useLocation } from 'wouter';
import { Heart, GitFork, Share2, MessageCircle, ArrowLeft, Copy, Check, Send, User, RefreshCw, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';

interface ProjectFile {
  id: number;
  name: string;
  content: string;
  language: string;
}

interface Comment {
  id: number;
  authorName: string;
  content: string;
  createdAt: string;
}

interface Project {
  id: number;
  title: string;
  description: string | null;
  slug: string;
  authorName: string;
  likesCount: number;
  forksCount: number;
  parentProjectId: number | null;
  createdAt: string;
  files: ProjectFile[];
  comments: Comment[];
}

function getVisitorId(): string {
  let id = localStorage.getItem('gnn_visitor_id');
  if (!id) {
    id = 'v_' + Math.random().toString(36).substr(2, 16);
    localStorage.setItem('gnn_visitor_id', id);
  }
  return id;
}

export default function ProjectPage() {
  const { slug } = useParams<{ slug: string }>();
  const [, setLocation] = useLocation();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [previewHtml, setPreviewHtml] = useState('');
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [copied, setCopied] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [commentAuthor, setCommentAuthor] = useState('');
  const [comments, setComments] = useState<Comment[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const visitorId = getVisitorId();

  useEffect(() => {
    if (!slug) return;
    
    const fetchProject = async () => {
      try {
        const res = await fetch(`/api/projects/${slug}`);
        if (!res.ok) throw new Error('Project not found');
        const data = await res.json();
        setProject(data);
        setLikesCount(data.likesCount);
        setComments(data.comments || []);
        buildPreview(data.files);
        
        const likeRes = await fetch(`/api/projects/${data.id}/liked?visitorId=${visitorId}`);
        const likeData = await likeRes.json();
        setLiked(likeData.liked);
      } catch (err) {
        setError('Project not found');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProject();
  }, [slug]);

  const buildPreview = (files: ProjectFile[]) => {
    const indexFile = files.find(f => f.name === 'index.html');
    if (!indexFile) return;

    let html = indexFile.content;
    files.forEach(f => {
      if (f.name.endsWith('.css')) {
        html = html.replace(`<link rel="stylesheet" href="${f.name}">`, `<style>${f.content}</style>`);
      }
      if (f.name.endsWith('.js')) {
        html = html.replace(`<script src="${f.name}"></script>`, `<script>${f.content}</script>`);
      }
    });
    setPreviewHtml(html);
  };

  const handleLike = async () => {
    if (!project) return;
    
    try {
      const res = await apiRequest('POST', `/api/projects/${project.id}/like`, { visitorId });
      const data = await res.json();
      setLiked(data.liked);
      setLikesCount(prev => data.liked ? prev + 1 : prev - 1);
    } catch (err) {
      console.error('Like error:', err);
    }
  };

  const handleFork = async () => {
    if (!project) return;
    
    try {
      const res = await apiRequest('POST', `/api/projects/${project.id}/fork`, {
        authorName: commentAuthor || 'Anonymous'
      });
      const forked = await res.json();
      setLocation(`/game/${forked.slug}`);
    } catch (err) {
      console.error('Fork error:', err);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!project || !commentText.trim()) return;
    
    setIsSubmitting(true);
    try {
      const res = await apiRequest('POST', `/api/projects/${project.id}/comments`, {
        authorName: commentAuthor.trim() || 'Anonymous',
        content: commentText.trim()
      });
      const newComment = await res.json();
      setComments(prev => [newComment, ...prev]);
      setCommentText('');
    } catch (err) {
      console.error('Comment error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefresh = () => {
    if (iframeRef.current && previewHtml) {
      iframeRef.current.srcdoc = previewHtml;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Project Not Found</h1>
          <button onClick={() => setLocation('/')} className="text-primary hover:underline">
            Go Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "min-h-screen bg-black text-white",
      isFullscreen && "fixed inset-0 z-50"
    )}>
      {!isFullscreen && (
        <header className="border-b border-white/10 bg-card/50 backdrop-blur-md sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4 min-w-0">
                <button
                  onClick={() => setLocation('/')}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors shrink-0"
                  data-testid="button-back"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="min-w-0">
                  <h1 className="text-xl font-bold truncate" data-testid="text-project-title">
                    {project.title}
                  </h1>
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <User className="w-3 h-3" />
                    <span data-testid="text-author">{project.authorName}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleLike}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all touch-manipulation min-h-[44px]",
                    liked 
                      ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                      : "bg-white/5 hover:bg-white/10"
                  )}
                  data-testid="button-like"
                >
                  <Heart className={cn("w-5 h-5", liked && "fill-current")} />
                  <span>{likesCount}</span>
                </button>

                <button
                  onClick={handleFork}
                  className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg font-medium transition-colors touch-manipulation min-h-[44px]"
                  data-testid="button-fork"
                >
                  <GitFork className="w-5 h-5" />
                  <span className="hidden sm:inline">{project.forksCount}</span>
                </button>

                <button
                  onClick={handleShare}
                  className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg font-medium transition-colors touch-manipulation min-h-[44px]"
                  data-testid="button-share"
                >
                  {copied ? <Check className="w-5 h-5 text-primary" /> : <Share2 className="w-5 h-5" />}
                  <span className="hidden sm:inline">{copied ? 'Copied!' : 'Share'}</span>
                </button>

                <button
                  onClick={() => setShowComments(!showComments)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors touch-manipulation min-h-[44px]",
                    showComments ? "bg-primary/20 text-primary" : "bg-white/5 hover:bg-white/10"
                  )}
                  data-testid="button-comments"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="hidden sm:inline">{comments.length}</span>
                </button>
              </div>
            </div>

            {project.description && (
              <p className="mt-3 text-muted-foreground text-sm" data-testid="text-description">
                {project.description}
              </p>
            )}
          </div>
        </header>
      )}

      <div className="flex flex-col lg:flex-row">
        <div className={cn(
          "flex-1",
          isFullscreen ? "h-screen" : "min-h-[60vh] lg:min-h-[calc(100vh-120px)]"
        )}>
          <div className="h-full relative bg-white">
            {!isFullscreen && (
              <div className="absolute top-4 right-4 z-10 flex gap-2">
                <button
                  onClick={handleRefresh}
                  className="p-2 bg-black/50 hover:bg-black/70 rounded-lg transition-colors backdrop-blur-sm"
                  data-testid="button-refresh"
                >
                  <RefreshCw className="w-4 h-4 text-white" />
                </button>
                <button
                  onClick={() => setIsFullscreen(true)}
                  className="p-2 bg-black/50 hover:bg-black/70 rounded-lg transition-colors backdrop-blur-sm"
                  data-testid="button-fullscreen"
                >
                  <Maximize2 className="w-4 h-4 text-white" />
                </button>
              </div>
            )}
            {isFullscreen && (
              <button
                onClick={() => setIsFullscreen(false)}
                className="absolute top-4 right-4 z-10 p-2 bg-black/50 hover:bg-black/70 rounded-lg transition-colors backdrop-blur-sm"
                data-testid="button-exit-fullscreen"
              >
                <Minimize2 className="w-4 h-4 text-white" />
              </button>
            )}
            {previewHtml ? (
              <iframe
                ref={iframeRef}
                srcDoc={previewHtml}
                className="w-full h-full border-0"
                title="Project Preview"
                sandbox="allow-scripts"
              />
            ) : (
              <div className="flex items-center justify-center h-full text-zinc-400">
                No preview available
              </div>
            )}
          </div>
        </div>

        {showComments && !isFullscreen && (
          <div className="w-full lg:w-96 border-t lg:border-t-0 lg:border-l border-white/10 bg-card/50 flex flex-col max-h-[50vh] lg:max-h-[calc(100vh-120px)]">
            <div className="p-4 border-b border-white/10">
              <h3 className="font-semibold flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                Comments ({comments.length})
              </h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {comments.length === 0 ? (
                <p className="text-muted-foreground text-sm text-center py-8">
                  No comments yet. Be the first!
                </p>
              ) : (
                comments.map(comment => (
                  <div key={comment.id} className="bg-white/5 rounded-lg p-3" data-testid={`comment-${comment.id}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                        <User className="w-3 h-3 text-primary" />
                      </div>
                      <span className="font-medium text-sm">{comment.authorName}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{comment.content}</p>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={handleComment} className="p-4 border-t border-white/10">
              <input
                type="text"
                placeholder="Your name (optional)"
                value={commentAuthor}
                onChange={e => setCommentAuthor(e.target.value)}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm mb-2 focus:border-primary outline-none"
                data-testid="input-comment-author"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Write a comment..."
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  className="flex-1 bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm focus:border-primary outline-none"
                  data-testid="input-comment-text"
                />
                <button
                  type="submit"
                  disabled={isSubmitting || !commentText.trim()}
                  className="p-2 bg-primary text-black rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
                  data-testid="button-submit-comment"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
