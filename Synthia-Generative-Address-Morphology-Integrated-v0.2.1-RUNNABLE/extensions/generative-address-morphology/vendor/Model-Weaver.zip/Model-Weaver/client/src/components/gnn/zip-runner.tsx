import React, { useCallback, useState } from 'react';
import { Upload, FileArchive, Play, Trash2, Download } from 'lucide-react';
import { motion } from 'framer-motion';

interface ZipRunnerProps {
  onRun: (file: File) => void;
}

export function ZipRunner({ onRun }: ZipRunnerProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(e.dataTransfer.files).filter(f => f.name.endsWith('.zip'));
      setFiles(prev => [...prev, ...droppedFiles]);
    }
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles = Array.from(e.target.files).filter(f => f.name.endsWith('.zip'));
      setFiles(prev => [...prev, ...selectedFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-display text-primary tracking-wider">ZIP RUNTIME MODULE</h2>
        <div className="text-xs font-mono text-muted-foreground">READY FOR INJECTION</div>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileSelect} 
        className="hidden" 
        accept=".zip" 
        multiple 
      />

      <div 
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
        className={`
          flex-1 border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-4 transition-all duration-300 cursor-pointer
          ${isDragging 
            ? 'border-primary bg-primary/10 scale-[1.01]' 
            : 'border-white/10 hover:border-primary/50 hover:bg-white/5'
          }
        `}
      >
        <Upload className={`w-12 h-12 ${isDragging ? 'text-primary animate-bounce' : 'text-muted-foreground'}`} />
        <div className="text-center">
          <p className="font-mono text-lg text-foreground">TAP OR DROP GNN ARCHIVES HERE</p>
          <p className="font-mono text-xs text-muted-foreground mt-2">SUPPORTED FORMATS: .ZIP</p>
        </div>
      </div>

      <div className="h-1/3 glass-panel rounded-lg p-4 overflow-y-auto">
        <h3 className="text-sm font-display text-muted-foreground mb-4">LOADED MODULES</h3>
        <div className="space-y-2">
          {files.map((file, idx) => (
            <motion.div 
              key={`${file.name}-${idx}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-3 bg-white/5 rounded border border-white/5 hover:border-primary/30 group"
            >
              <div className="flex items-center gap-3">
                <FileArchive className="w-5 h-5 text-secondary" />
                <div>
                  <div className="font-mono text-sm text-foreground">{file.name}</div>
                  <div className="font-mono text-[10px] text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</div>
                </div>
              </div>
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => onRun(file)}
                  className="p-2 hover:bg-primary/20 text-primary rounded transition-colors"
                  title="Run Module"
                >
                  <Play className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => removeFile(idx)}
                  className="p-2 hover:bg-destructive/20 text-destructive rounded transition-colors"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
          {files.length === 0 && (
             <div className="text-center py-8 text-muted-foreground font-mono text-xs opacity-50">
               NO MODULES LOADED
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
