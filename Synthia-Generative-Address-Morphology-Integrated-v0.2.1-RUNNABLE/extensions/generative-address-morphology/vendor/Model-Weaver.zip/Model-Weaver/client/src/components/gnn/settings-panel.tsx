import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Upload, Cpu, Zap, Box, Save, Cloud, Monitor, Server, Check, AlertCircle, Loader2, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

type AIBackend = 'openai' | 'webllm' | 'llamacpp' | 'huggingface';

interface ModelConfig {
  backend: AIBackend;
  modelId: string;
  temperature: number;
  maxTokens: number;
}

const WEBLLM_MODELS = [
  { id: 'SmolLM2-360M-Instruct-q4f16_1-MLC', name: 'SmolLM2 (360M, Q4) - Lightweight', size: '~300MB' },
  { id: 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC', name: 'Qwen 2.5 (1.5B, Q4)', size: '~1GB' },
  { id: 'Phi-3.5-mini-instruct-q4f16_1-MLC', name: 'Phi-3.5 Mini (3.8B, Q4)', size: '~2.5GB' },
  { id: 'Llama-3.1-8B-Instruct-q4f32_1-MLC', name: 'Llama 3.1 (8B, Q4)', size: '~5GB' },
];

const LLAMACPP_MODELS = [
  { id: 'tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf', name: 'TinyLlama (1.1B, Q4_K_M)', size: '~600MB' },
  { id: 'phi-2.Q4_K_M.gguf', name: 'Phi-2 (2.7B, Q4_K_M)', size: '~1.6GB' },
];

const HUGGINGFACE_MODELS = [
  { id: 'microsoft/Phi-3-mini-4k-instruct', name: 'Phi-3 Mini (3.8B)', provider: 'Microsoft' },
  { id: 'mistralai/Mistral-7B-Instruct-v0.3', name: 'Mistral 7B Instruct', provider: 'Mistral AI' },
  { id: 'meta-llama/Llama-3.2-3B-Instruct', name: 'Llama 3.2 (3B)', provider: 'Meta' },
  { id: 'Qwen/Qwen2.5-3B-Instruct', name: 'Qwen 2.5 (3B)', provider: 'Alibaba' },
  { id: 'google/gemma-2-2b-it', name: 'Gemma 2 (2B)', provider: 'Google' },
];

export function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const [config, setConfig] = useState<ModelConfig>({
    backend: 'openai',
    modelId: 'gpt-4o',
    temperature: 0.7,
    maxTokens: 2000,
  });
  const [customModelPath, setCustomModelPath] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    const loadConfig = async () => {
      try {
        const response = await fetch('/api/settings/ai_config');
        if (response.ok) {
          const setting = await response.json();
          if (setting?.value) {
            setConfig(setting.value as ModelConfig);
          }
        }
      } catch (err) {
        console.error('Failed to load config:', err);
      }
    };
    if (isOpen) loadConfig();
  }, [isOpen]);

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('idle');
    try {
      const response = await fetch('/api/settings/ai_config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: config }),
      });
      setSaveStatus(response.ok ? 'success' : 'error');
    } catch (err) {
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
      setTimeout(() => setSaveStatus('idle'), 2000);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = e.target.files[0];
      setCustomModelPath(file.name);
      setConfig(prev => ({ ...prev, modelId: file.name }));
    }
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-lg glass-panel border border-primary/30 rounded-lg shadow-[0_0_50px_rgba(0,255,42,0.1)] overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/5 shrink-0">
          <h2 className="text-lg font-display text-primary flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            AI MODEL CONFIGURATION
          </h2>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-white/10 rounded-full transition-colors text-muted-foreground hover:text-white"
            data-testid="button-close-settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto">
          
          <div className="space-y-3">
            <label className="text-xs font-mono text-secondary tracking-wider">SELECT AI BACKEND</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setConfig(prev => ({ ...prev, backend: 'openai', modelId: 'gpt-4o' }))}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-lg border transition-all",
                  config.backend === 'openai'
                    ? "bg-primary/20 border-primary/50 text-primary"
                    : "bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10"
                )}
                data-testid="button-backend-openai"
              >
                <Cloud className="w-6 h-6" />
                <span className="text-xs font-mono">OPENAI</span>
                <span className="text-[10px] opacity-60">Cloud API</span>
              </button>
              <button
                onClick={() => setConfig(prev => ({ ...prev, backend: 'webllm', modelId: WEBLLM_MODELS[0].id }))}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-lg border transition-all",
                  config.backend === 'webllm'
                    ? "bg-secondary/20 border-secondary/50 text-secondary"
                    : "bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10"
                )}
                data-testid="button-backend-webllm"
              >
                <Monitor className="w-6 h-6" />
                <span className="text-xs font-mono">WEBLLM</span>
                <span className="text-[10px] opacity-60">Browser GPU</span>
              </button>
              <button
                onClick={() => setConfig(prev => ({ ...prev, backend: 'llamacpp', modelId: LLAMACPP_MODELS[0].id }))}
                className={cn(
                  "flex flex-col items-center gap-2 p-4 rounded-lg border transition-all",
                  config.backend === 'llamacpp'
                    ? "bg-orange-500/20 border-orange-500/50 text-orange-400"
                    : "bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10"
                )}
                data-testid="button-backend-llamacpp"
              >
                <Server className="w-6 h-6" />
                <span className="text-xs font-mono">LLAMA.CPP</span>
                <span className="text-[10px] opacity-60">Local Server</span>
              </button>
            </div>
            
            <button
              onClick={() => setConfig(prev => ({ ...prev, backend: 'huggingface', modelId: HUGGINGFACE_MODELS[0].id }))}
              className={cn(
                "w-full flex items-center gap-3 p-4 rounded-lg border transition-all",
                config.backend === 'huggingface'
                  ? "bg-yellow-500/20 border-yellow-500/50 text-yellow-400"
                  : "bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10"
              )}
              data-testid="button-backend-huggingface"
            >
              <Zap className="w-6 h-6" />
              <div className="text-left">
                <span className="text-xs font-mono block">HUGGING FACE</span>
                <span className="text-[10px] opacity-60">Free Tier - Open Models</span>
              </div>
            </button>
          </div>

          {config.backend === 'openai' && (
            <div className="space-y-2 animate-in fade-in">
              <label className="text-xs font-mono text-secondary tracking-wider">OPENAI MODEL</label>
              <select
                value={config.modelId}
                onChange={(e) => setConfig(prev => ({ ...prev, modelId: e.target.value }))}
                className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-sm font-mono text-primary outline-none focus:border-primary"
                data-testid="select-openai-model"
              >
                <option value="gpt-4o">GPT-4o (Latest)</option>
                <option value="gpt-4o-mini">GPT-4o Mini (Fast)</option>
                <option value="gpt-4-turbo">GPT-4 Turbo</option>
              </select>
              <p className="text-[10px] text-muted-foreground">Uses Replit AI credits</p>
            </div>
          )}

          {config.backend === 'webllm' && (
            <div className="space-y-2 animate-in fade-in">
              <label className="text-xs font-mono text-secondary tracking-wider">WEBLLM MODEL (BROWSER)</label>
              <select
                value={config.modelId}
                onChange={(e) => setConfig(prev => ({ ...prev, modelId: e.target.value }))}
                className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-sm font-mono text-secondary outline-none focus:border-secondary"
                data-testid="select-webllm-model"
              >
                {WEBLLM_MODELS.map(model => (
                  <option key={model.id} value={model.id}>{model.name} ({model.size})</option>
                ))}
              </select>
              <p className="text-[10px] text-muted-foreground">Runs locally in browser via WebGPU. Download once, use offline.</p>
            </div>
          )}

          {config.backend === 'llamacpp' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="space-y-2">
                <label className="text-xs font-mono text-secondary tracking-wider">GGUF MODEL FILE</label>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  className="hidden"
                  accept=".gguf,.bin"
                  onChange={handleFileSelect}
                />
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-white/10 hover:border-orange-500/50 rounded-lg p-6 flex flex-col items-center gap-2 transition-colors bg-black/20 group cursor-pointer active:bg-orange-500/5"
                >
                  <Upload className="w-6 h-6 text-muted-foreground group-hover:text-orange-400 transition-colors" />
                  <p className="text-xs font-mono text-muted-foreground group-hover:text-white">
                    {customModelPath || 'TAP TO UPLOAD .GGUF MODEL'}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-xs font-mono text-secondary tracking-wider">OR SELECT PRESET</label>
                <select
                  value={config.modelId}
                  onChange={(e) => setConfig(prev => ({ ...prev, modelId: e.target.value }))}
                  className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-sm font-mono text-orange-400 outline-none focus:border-orange-500"
                  data-testid="select-llamacpp-model"
                >
                  {LLAMACPP_MODELS.map(model => (
                    <option key={model.id} value={model.id}>{model.name} ({model.size})</option>
                  ))}
                </select>
              </div>
              
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 text-xs text-orange-300">
                <AlertCircle className="w-4 h-4 inline mr-2" />
                Requires model file in server. Use Hugging Face download.
              </div>
            </div>
          )}

          {config.backend === 'huggingface' && (
            <div className="space-y-3 animate-in fade-in">
              <label className="text-xs font-mono text-secondary tracking-wider">HUGGING FACE MODEL</label>
              <select
                value={config.modelId}
                onChange={(e) => setConfig(prev => ({ ...prev, modelId: e.target.value }))}
                className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-sm font-mono text-yellow-400 outline-none focus:border-yellow-500"
                data-testid="select-huggingface-model"
              >
                {HUGGINGFACE_MODELS.map(model => (
                  <option key={model.id} value={model.id}>{model.name} ({model.provider})</option>
                ))}
              </select>
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 text-xs text-yellow-300 space-y-1">
                <p><Zap className="w-3 h-3 inline mr-1" /> <strong>Free Tier:</strong> Monthly credits included</p>
                <p className="opacity-70">No charges until you exceed the free limit. Uses Inference API.</p>
              </div>
            </div>
          )}

          <div className="space-y-4 pt-4 border-t border-white/10">
            <div className="space-y-2">
              <label className="text-xs font-mono text-secondary tracking-wider flex justify-between">
                <span>TEMPERATURE</span>
                <span className="text-primary">{config.temperature}</span>
              </label>
              <input 
                type="range" 
                min="0" 
                max="2" 
                step="0.1" 
                value={config.temperature}
                onChange={(e) => setConfig(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:shadow-[0_0_10px_#00ff2a]"
                data-testid="slider-temperature"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-secondary tracking-wider flex justify-between">
                <span>MAX TOKENS</span>
                <span className="text-primary">{config.maxTokens}</span>
              </label>
              <input 
                type="range" 
                min="256" 
                max="4096" 
                step="256" 
                value={config.maxTokens}
                onChange={(e) => setConfig(prev => ({ ...prev, maxTokens: parseInt(e.target.value) }))}
                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:shadow-[0_0_10px_#00ff2a]"
                data-testid="slider-max-tokens"
              />
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={handleSave}
                disabled={isSaving}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-3 rounded font-mono text-sm transition-all",
                  isSaving ? "bg-muted text-muted-foreground" :
                  saveStatus === 'success' ? "bg-green-500/20 text-green-400 border border-green-500/30" :
                  saveStatus === 'error' ? "bg-red-500/20 text-red-400 border border-red-500/30" :
                  "bg-primary/10 border border-primary/20 text-primary hover:bg-primary/20"
                )}
                data-testid="button-save-config"
              >
                {isSaving ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> SAVING...</>
                ) : saveStatus === 'success' ? (
                  <><Check className="w-4 h-4" /> SAVED!</>
                ) : saveStatus === 'error' ? (
                  <><AlertCircle className="w-4 h-4" /> FAILED</>
                ) : (
                  <><Save className="w-4 h-4" /> SAVE</>
                )}
              </button>
              
              <button 
                onClick={onClose}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded font-mono text-sm transition-all bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20"
                data-testid="button-exit-settings"
              >
                <LogOut className="w-4 h-4" /> EXIT
              </button>
            </div>
          </div>

        </div>
        
        <div className="p-4 bg-black/40 border-t border-white/5 text-[10px] font-mono text-muted-foreground text-center">
          GNN RUNTIME ENVIRONMENT v2.4.9 // EVOLUTION ENGINE READY
        </div>
      </motion.div>
    </div>
  );
}
