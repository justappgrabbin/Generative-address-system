import type { Module, InsertModule, Snippet, InsertSnippet, Setting, InsertSetting } from "@shared/schema";

// Modules
export async function getModules(): Promise<Module[]> {
  const res = await fetch("/api/modules");
  if (!res.ok) throw new Error("Failed to fetch modules");
  return res.json();
}

export async function createModule(module: InsertModule): Promise<Module> {
  const res = await fetch("/api/modules", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(module),
  });
  if (!res.ok) throw new Error("Failed to create module");
  return res.json();
}

export async function deleteModule(id: number): Promise<void> {
  const res = await fetch(`/api/modules/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete module");
}

// Snippets
export async function getSnippets(): Promise<Snippet[]> {
  const res = await fetch("/api/snippets");
  if (!res.ok) throw new Error("Failed to fetch snippets");
  return res.json();
}

export async function getSnippet(id: number): Promise<Snippet> {
  const res = await fetch(`/api/snippets/${id}`);
  if (!res.ok) throw new Error("Failed to fetch snippet");
  return res.json();
}

export async function createSnippet(snippet: InsertSnippet): Promise<Snippet> {
  const res = await fetch("/api/snippets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(snippet),
  });
  if (!res.ok) throw new Error("Failed to create snippet");
  return res.json();
}

export async function updateSnippet(id: number, snippet: Partial<InsertSnippet>): Promise<Snippet> {
  const res = await fetch(`/api/snippets/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(snippet),
  });
  if (!res.ok) throw new Error("Failed to update snippet");
  return res.json();
}

export async function deleteSnippet(id: number): Promise<void> {
  const res = await fetch(`/api/snippets/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete snippet");
}

// Settings
export async function getSetting(key: string): Promise<Setting | null> {
  const res = await fetch(`/api/settings/${key}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new Error("Failed to fetch setting");
  return res.json();
}

export async function setSetting(key: string, value: any): Promise<Setting> {
  const res = await fetch(`/api/settings/${key}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ value }),
  });
  if (!res.ok) throw new Error("Failed to save setting");
  return res.json();
}
