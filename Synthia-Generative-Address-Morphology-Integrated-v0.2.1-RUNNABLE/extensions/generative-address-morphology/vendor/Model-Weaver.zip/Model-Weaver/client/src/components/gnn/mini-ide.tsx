import React, { useState, useEffect } from 'react';
import Editor from 'react-simple-code-editor';
import { highlight, languages } from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-python';
import { Save, Play, RotateCcw, Copy, Terminal as TerminalIcon, FolderOpen } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { getSnippets } from '@/lib/api';

interface MiniIDEProps {
  defaultCode?: string;
  defaultLanguage?: string;
  onRun?: (code: string, language: string) => Promise<string | void>;
  isProcessing?: boolean;
}

export function MiniIDE({ 
  defaultCode = "", 
  defaultLanguage = "python", 
  onRun,
  isProcessing = false
}: MiniIDEProps) {
  const [code, setCode] = useState(defaultCode);
  const [language, setLanguage] = useState(defaultLanguage);
  const [output, setOutput] = useState<string>("");
  const [title, setTitle] = useState<string>("Untitled");
  const [showLoadMenu, setShowLoadMenu] = useState(false);
  
  const { data: snippets = [] } = useQuery({
    queryKey: ['snippets'],
    queryFn: getSnippets,
  });

  useEffect(() => {
    if (defaultCode) setCode(defaultCode);
  }, [defaultCode]);

  const handleRun = async () => {
    if (!onRun) return;
    try {
      setOutput(">> Executing sequence...\n");
      const result = await onRun(code, language);
      if (typeof result === 'string') {
        setOutput(prev => prev + result);
      }
    } catch (error: any) {
      setOutput(prev => prev + `\n[ERROR]: ${error.message || error}`);
    }
  };

  const handleSave = async () => {
    try {
      const promptTitle = prompt("Save as:", title);
      if (!promptTitle) return;
      
      setTitle(promptTitle);
      const response = await fetch('/api/snippets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: promptTitle, code, language })
      });
      
      if (response.ok) {
        setOutput(prev => prev + `\n[SAVED]: ${promptTitle}`);
      }
    } catch (error) {
      setOutput(prev => prev + `\n[ERROR]: Failed to save`);
    }
  };

  const handleLoad = async (id: number) => {
    try {
      const response = await fetch(`/api/snippets/${id}`);
      if (response.ok) {
        const snippet = await response.json();
        setCode(snippet.code);
        setLanguage(snippet.language);
        setTitle(snippet.title);
        setShowLoadMenu(false);
        setOutput(prev => prev + `\n[LOADED]: ${snippet.title}`);
      }
    } catch (error) {
      setOutput(prev => prev + `\n[ERROR]: Failed to load snippet`);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-display text-secondary tracking-wider">MINI IDE</h2>
          <select 
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-black/40 border border-white/10 rounded px-2 py-1 text-xs font-mono text-primary outline-none focus:border-primary"
          >
            <option value="python">PYTHON (PYODIDE)</option>
            <option value="javascript">JAVASCRIPT</option>
            <option value="css">CSS</option>
          </select>
        </div>
        
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded text-xs font-mono transition-colors">
            <Save className="w-3 h-3" /> SAVE
          </button>
          <button 
            onClick={handleRun}
            disabled={isProcessing}
            className={cn(
              "flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono transition-colors",
              isProcessing 
                ? "bg-muted text-muted-foreground cursor-not-allowed" 
                : "bg-secondary/10 text-secondary hover:bg-secondary/20"
            )}
          >
            <Play className={cn("w-3 h-3", isProcessing && "animate-spin")} /> 
            {isProcessing ? "PROCESSING..." : "EXECUTE"}
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row gap-4 min-h-0">
        <div className="flex-1 glass-panel rounded-lg overflow-hidden border border-white/5 font-mono text-sm relative group flex flex-col">
          <div className="flex-1 overflow-auto custom-scrollbar">
            <Editor
              value={code}
              onValueChange={setCode}
              highlight={code => highlight(code, languages[language] || languages.js, language)}
              padding={24}
              className="font-mono min-h-full"
              style={{
                fontFamily: '"JetBrains Mono", monospace',
                fontSize: 14,
                backgroundColor: 'rgba(0,0,0,0.3)',
                color: '#a9b7c6'
              }}
            />
          </div>
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2 z-10">
             <button className="p-1 hover:bg-white/10 rounded text-muted-foreground hover:text-white" title="Copy">
               <Copy className="w-4 h-4" />
             </button>
             <button 
               onClick={() => setCode(defaultCode)}
               className="p-1 hover:bg-white/10 rounded text-muted-foreground hover:text-white" 
               title="Reset"
             >
               <RotateCcw className="w-4 h-4" />
             </button>
          </div>
        </div>

        {/* Output Panel for immediate feedback */}
        {output && (
          <div className="h-48 md:h-auto md:w-1/3 glass-panel rounded-lg border border-white/5 flex flex-col">
            <div className="px-4 py-2 bg-black/40 border-b border-white/5 flex items-center justify-between">
              <span className="text-xs font-mono text-muted-foreground flex items-center gap-2">
                <TerminalIcon className="w-3 h-3" /> OUTPUT STREAM
              </span>
              <button onClick={() => setOutput("")} className="text-[10px] text-destructive hover:text-destructive/80">CLEAR</button>
            </div>
            <div className="flex-1 p-4 font-mono text-xs overflow-auto whitespace-pre-wrap text-foreground/80">
              {output}
            </div>
          </div>
        )}
      </div>
      
      <div className="h-6 flex items-center justify-between text-[10px] font-mono text-muted-foreground px-2">
        <span>Ln {code.split('\n').length}, Col 1</span>
        <span>UTF-8</span>
        <span>{language.toUpperCase()}</span>
      </div>
    </div>
  );
}
