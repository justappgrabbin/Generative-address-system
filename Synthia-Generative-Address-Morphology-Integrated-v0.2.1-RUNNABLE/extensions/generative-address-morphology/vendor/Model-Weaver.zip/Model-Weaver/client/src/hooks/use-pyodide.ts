import { useState, useEffect, useRef } from 'react';

declare global {
  interface Window {
    loadPyodide: any;
  }
}

export function usePyodide() {
  const [pyodide, setPyodide] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function initPyodide() {
      try {
        if (!window.loadPyodide) {
          throw new Error("Pyodide script not loaded");
        }
        
        console.log("Initializing Pyodide...");
        const py = await window.loadPyodide();
        await py.loadPackage("numpy");
        setPyodide(py);
        setIsLoading(false);
        console.log("Pyodide ready.");
      } catch (err: any) {
        console.error("Failed to load Pyodide:", err);
        setError(err.message);
        setIsLoading(false);
      }
    }

    // Small delay to ensure script tag is processed
    const timer = setTimeout(initPyodide, 1000);
    return () => clearTimeout(timer);
  }, []);

  const runPython = async (code: string) => {
    if (!pyodide) throw new Error("Pyodide not ready");
    try {
      // Capture stdout
      pyodide.runPython(`
import sys
import io
sys.stdout = io.StringIO()
`);
      await pyodide.runPythonAsync(code);
      const stdout = pyodide.runPython("sys.stdout.getvalue()");
      return stdout;
    } catch (err: any) {
      throw err;
    }
  };

  return { pyodide, isLoading, error, runPython };
}
