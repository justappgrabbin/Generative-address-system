import * as webllm from '@mlc-ai/web-llm';

export type AIProvider = 'openai' | 'webllm' | 'llamacpp' | 'huggingface';

export interface EvolutionRequest {
  prompt: string;
  originalCode: string;
  provider: AIProvider;
}

export interface EvolutionResult {
  id?: number;
  prompt: string;
  originalCode: string;
  generatedCode: string;
  status: string;
  provider: string;
  validationResult?: string;
}

let webllmEngine: webllm.MLCEngine | null = null;
let webllmInitializing = false;
let webllmProgress = 0;

export async function initWebLLM(
  onProgress?: (progress: number, status: string) => void
): Promise<boolean> {
  if (webllmEngine) return true;
  if (webllmInitializing) return false;
  
  webllmInitializing = true;
  
  try {
    webllmEngine = new webllm.MLCEngine();
    
    webllmEngine.setInitProgressCallback((report) => {
      webllmProgress = Math.round(report.progress * 100);
      onProgress?.(webllmProgress, report.text);
    });
    
    await webllmEngine.reload("SmolLM2-360M-Instruct-q4f16_1-MLC");
    
    webllmInitializing = false;
    return true;
  } catch (error) {
    console.error('WebLLM initialization failed:', error);
    webllmInitializing = false;
    return false;
  }
}

export function getWebLLMProgress(): number {
  return webllmProgress;
}

export function isWebLLMReady(): boolean {
  return webllmEngine !== null;
}

export async function generateWithWebLLM(
  prompt: string,
  originalCode: string,
  onStream?: (chunk: string) => void
): Promise<string> {
  if (!webllmEngine) {
    throw new Error('WebLLM not initialized. Call initWebLLM first.');
  }
  
  const systemPrompt = `You are an expert Python code generator for the Generative Neural Nexus (GNN) runtime.
Your task is to evolve and improve the given code based on the user's request.
You MUST return ONLY valid Python code, no explanations or markdown.
The code should integrate with the GNN Sentence System which includes:
- SSV (Sentence Significance Value) calculations
- Resonance Function for harmonic analysis
- Collapse Engine for dimensional reduction
Focus on mathematical elegance and neural-inspired algorithms.`;

  const messages: webllm.ChatCompletionMessageParam[] = [
    { role: 'system', content: systemPrompt },
    { 
      role: 'user', 
      content: `Original code:\n\`\`\`python\n${originalCode}\n\`\`\`\n\nEvolution request: ${prompt}\n\nGenerate the evolved Python code:` 
    }
  ];

  let fullResponse = '';
  
  const response = await webllmEngine.chat.completions.create({
    messages,
    temperature: 0.7,
    max_tokens: 2000,
    stream: true,
  });

  for await (const chunk of response) {
    const content = chunk.choices[0]?.delta?.content || '';
    fullResponse += content;
    onStream?.(content);
  }

  return fullResponse;
}

export async function generateEvolution(
  request: EvolutionRequest,
  onStream?: (chunk: string) => void
): Promise<EvolutionResult> {
  const { prompt, originalCode, provider } = request;
  
  if (provider === 'webllm') {
    const generatedCode = await generateWithWebLLM(prompt, originalCode, onStream);
    
    const saveResponse = await fetch('/api/evolution', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, originalCode, generatedCode, status: 'pending', provider: 'webllm' }),
    });
    
    if (saveResponse.ok) {
      return saveResponse.json();
    }
    
    return {
      prompt,
      originalCode,
      generatedCode,
      status: 'pending',
      provider: 'webllm',
    };
  }
  
  const response = await fetch('/api/evolution/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, originalCode, provider }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to generate evolution');
  }
  
  return response.json();
}

export async function getEvolutionHistory(): Promise<EvolutionResult[]> {
  const response = await fetch('/api/evolution');
  if (!response.ok) {
    throw new Error('Failed to fetch evolution history');
  }
  return response.json();
}

export async function updateEvolutionStatus(
  id: number,
  status: string,
  validationResult?: string
): Promise<EvolutionResult> {
  const response = await fetch(`/api/evolution/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, validationResult }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to update evolution status');
  }
  
  return response.json();
}
