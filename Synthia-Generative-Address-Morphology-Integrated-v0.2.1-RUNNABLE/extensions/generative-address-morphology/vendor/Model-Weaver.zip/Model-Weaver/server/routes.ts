import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertModuleSchema, insertSnippetSchema, insertSettingSchema, insertEvolutionSchema } from "@shared/schema";
import OpenAI from "openai";
import { HfInference } from "@huggingface/inference";
import path from "path";
import fs from "fs";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const hf = new HfInference(process.env.HUGGINGFACE_API_KEY || undefined);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Serve standalone GNN HTML
  app.get("/gnn.html", async (req, res) => {
    const gnnPath = path.resolve(process.cwd(), "public", "gnn.html");
    try {
      const content = await fs.promises.readFile(gnnPath, "utf-8");
      res.status(200).set({ "Content-Type": "text/html" }).end(content);
    } catch (e) {
      res.status(404).send("GNN standalone not found");
    }
  });

  // Modules API
  app.get("/api/modules", async (req, res) => {
    try {
      const modules = await storage.getAllModules();
      res.json(modules);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch modules" });
    }
  });

  app.post("/api/modules", async (req, res) => {
    try {
      const validated = insertModuleSchema.parse(req.body);
      const module = await storage.createModule(validated);
      res.status(201).json(module);
    } catch (error) {
      res.status(400).json({ error: "Invalid module data" });
    }
  });

  app.delete("/api/modules/:id", async (req, res) => {
    try {
      await storage.deleteModule(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete module" });
    }
  });

  // Snippets API
  app.get("/api/snippets", async (req, res) => {
    try {
      const snippets = await storage.getAllSnippets();
      res.json(snippets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch snippets" });
    }
  });

  app.get("/api/snippets/:id", async (req, res) => {
    try {
      const snippet = await storage.getSnippet(parseInt(req.params.id));
      if (!snippet) {
        res.status(404).json({ error: "Snippet not found" });
        return;
      }
      res.json(snippet);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch snippet" });
    }
  });

  app.post("/api/snippets", async (req, res) => {
    try {
      const validated = insertSnippetSchema.parse(req.body);
      const snippet = await storage.createSnippet(validated);
      res.status(201).json(snippet);
    } catch (error) {
      res.status(400).json({ error: "Invalid snippet data" });
    }
  });

  app.patch("/api/snippets/:id", async (req, res) => {
    try {
      const snippet = await storage.updateSnippet(parseInt(req.params.id), req.body);
      res.json(snippet);
    } catch (error) {
      res.status(500).json({ error: "Failed to update snippet" });
    }
  });

  app.delete("/api/snippets/:id", async (req, res) => {
    try {
      await storage.deleteSnippet(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete snippet" });
    }
  });

  // Settings API
  app.get("/api/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      if (!setting) {
        res.status(404).json({ error: "Setting not found" });
        return;
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch setting" });
    }
  });

  app.put("/api/settings/:key", async (req, res) => {
    try {
      const validated = insertSettingSchema.parse({
        key: req.params.key,
        value: req.body.value
      });
      const setting = await storage.setSetting(validated);
      res.json(setting);
    } catch (error) {
      res.status(400).json({ error: "Invalid setting data" });
    }
  });

  // Evolution API
  app.get("/api/evolution", async (req, res) => {
    try {
      const evolutions = await storage.getAllEvolutions();
      res.json(evolutions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch evolution history" });
    }
  });

  app.post("/api/evolution", async (req, res) => {
    try {
      const { prompt, originalCode, generatedCode, status, provider } = req.body;
      
      if (!prompt || !originalCode || !generatedCode) {
        res.status(400).json({ error: "Missing required fields" });
        return;
      }

      const evolution = await storage.createEvolution({
        prompt,
        originalCode,
        generatedCode,
        status: status || "pending",
        provider: provider || "webllm",
      });

      res.status(201).json(evolution);
    } catch (error) {
      console.error("Evolution save error:", error);
      res.status(500).json({ error: "Failed to save evolution" });
    }
  });

  app.post("/api/evolution/generate", async (req, res) => {
    try {
      const { prompt, originalCode, provider = "openai", modelId } = req.body;
      
      if (!prompt || !originalCode) {
        res.status(400).json({ error: "Prompt and originalCode are required" });
        return;
      }

      const systemPrompt = `You are an expert Python code generator for the Generative Neural Nexus (GNN) runtime.
Your task is to evolve and improve the given code based on the user's request.
You MUST return ONLY valid Python code, no explanations or markdown.
The code should integrate with the GNN Sentence System which includes:
- SSV (Sentence Significance Value) calculations
- Resonance Function for harmonic analysis
- Collapse Engine for dimensional reduction
Focus on mathematical elegance and neural-inspired algorithms.`;

      const userMessage = `Original code:\n\`\`\`python\n${originalCode}\n\`\`\`\n\nEvolution request: ${prompt}\n\nGenerate the evolved Python code:`;
      
      let generatedCode = "";
      
      if (provider === "huggingface") {
        const model = modelId || "microsoft/Phi-3-mini-4k-instruct";
        
        try {
          const response = await hf.chatCompletion({
            model,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userMessage }
            ],
            max_tokens: 2000,
            temperature: 0.7,
          });
          
          generatedCode = response.choices?.[0]?.message?.content || "";
        } catch (hfError: any) {
          if (hfError?.message?.includes("rate limit") || hfError?.status === 429) {
            res.status(429).json({ error: "Hugging Face rate limit reached. Try again later or switch to OpenAI." });
            return;
          }
          throw hfError;
        }
      } else {
        const completion = await openai.chat.completions.create({
          model: modelId || "gpt-4o",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userMessage }
          ],
          temperature: 0.7,
          max_tokens: 2000,
        });
        
        generatedCode = completion.choices[0]?.message?.content || "";
      }
      
      const evolution = await storage.createEvolution({
        prompt,
        originalCode,
        generatedCode,
        status: "pending",
        provider,
      });

      res.json(evolution);
    } catch (error) {
      console.error("Evolution generation error:", error);
      res.status(500).json({ error: "Failed to generate evolved code" });
    }
  });

  app.patch("/api/evolution/:id/status", async (req, res) => {
    try {
      const { status, validationResult } = req.body;
      const evolution = await storage.updateEvolutionStatus(
        parseInt(req.params.id),
        status,
        validationResult
      );
      res.json(evolution);
    } catch (error) {
      res.status(500).json({ error: "Failed to update evolution status" });
    }
  });

  // Projects API (Social Features)
  app.get("/api/projects", async (req, res) => {
    try {
      const allProjects = await storage.getAllProjects();
      res.json(allProjects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:slug", async (req, res) => {
    try {
      const project = await storage.getProjectBySlug(req.params.slug);
      if (!project) {
        res.status(404).json({ error: "Project not found" });
        return;
      }
      const files = await storage.getProjectFiles(project.id);
      const comments = await storage.getProjectComments(project.id);
      res.json({ ...project, files, comments });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const { title, description, authorName, files } = req.body;
      
      if (!title || !files || files.length === 0) {
        res.status(400).json({ error: "Title and files are required" });
        return;
      }

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now().toString(36);
      
      const project = await storage.createProject({
        title,
        description: description || '',
        slug,
        authorName: authorName || 'Anonymous',
        isPublic: true,
      });

      const projectFiles = files.map((f: any, i: number) => ({
        projectId: project.id,
        name: f.name,
        content: f.content,
        language: f.language || 'plaintext',
        order: i,
      }));
      
      await storage.createProjectFiles(projectFiles);
      
      res.status(201).json(project);
    } catch (error) {
      console.error("Project creation error:", error);
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  app.post("/api/projects/:id/like", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { visitorId } = req.body;
      
      if (!visitorId) {
        res.status(400).json({ error: "Visitor ID required" });
        return;
      }

      const hasLiked = await storage.hasLiked(projectId, visitorId);
      
      if (hasLiked) {
        await storage.removeLike(projectId, visitorId);
        res.json({ liked: false });
      } else {
        await storage.addLike(projectId, visitorId);
        res.json({ liked: true });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to toggle like" });
    }
  });

  app.get("/api/projects/:id/liked", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const visitorId = req.query.visitorId as string;
      
      if (!visitorId) {
        res.json({ liked: false });
        return;
      }

      const liked = await storage.hasLiked(projectId, visitorId);
      res.json({ liked });
    } catch (error) {
      res.status(500).json({ error: "Failed to check like status" });
    }
  });

  app.post("/api/projects/:id/comments", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { authorName, content } = req.body;
      
      if (!content || content.trim().length === 0) {
        res.status(400).json({ error: "Comment content required" });
        return;
      }

      const comment = await storage.createComment({
        projectId,
        authorName: authorName || 'Anonymous',
        content: content.trim().slice(0, 1000),
      });
      
      res.status(201).json(comment);
    } catch (error) {
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  app.post("/api/projects/:id/fork", async (req, res) => {
    try {
      const originalId = parseInt(req.params.id);
      const { authorName } = req.body;
      
      const original = await storage.getProject(originalId);
      if (!original) {
        res.status(404).json({ error: "Project not found" });
        return;
      }

      const originalFiles = await storage.getProjectFiles(originalId);
      
      const slug = original.slug + '-fork-' + Date.now().toString(36);
      
      const forkedProject = await storage.createProject({
        title: original.title + ' (Fork)',
        description: original.description,
        slug,
        authorName: authorName || 'Anonymous',
        isPublic: true,
        parentProjectId: originalId,
      });

      const forkedFiles = originalFiles.map((f, i) => ({
        projectId: forkedProject.id,
        name: f.name,
        content: f.content,
        language: f.language,
        order: i,
      }));
      
      await storage.createProjectFiles(forkedFiles);
      await storage.incrementForkCount(originalId);
      
      res.status(201).json(forkedProject);
    } catch (error) {
      console.error("Fork error:", error);
      res.status(500).json({ error: "Failed to fork project" });
    }
  });

  return httpServer;
}
