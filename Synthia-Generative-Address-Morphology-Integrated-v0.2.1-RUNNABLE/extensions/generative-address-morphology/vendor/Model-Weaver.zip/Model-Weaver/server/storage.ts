import { 
  type User, 
  type InsertUser,
  type Module,
  type InsertModule,
  type Snippet,
  type InsertSnippet,
  type Setting,
  type InsertSetting,
  type Evolution,
  type InsertEvolution,
  type Project,
  type InsertProject,
  type ProjectFile,
  type InsertProjectFile,
  type ProjectLike,
  type InsertProjectLike,
  type ProjectComment,
  type InsertProjectComment,
  users,
  modules,
  snippets,
  settings,
  evolutionHistory,
  projects,
  projectFiles,
  projectLikes,
  projectComments,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Modules
  getAllModules(): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  deleteModule(id: number): Promise<void>;
  
  // Snippets
  getAllSnippets(): Promise<Snippet[]>;
  getSnippet(id: number): Promise<Snippet | undefined>;
  createSnippet(snippet: InsertSnippet): Promise<Snippet>;
  updateSnippet(id: number, snippet: Partial<InsertSnippet>): Promise<Snippet>;
  deleteSnippet(id: number): Promise<void>;
  
  // Settings
  getSetting(key: string): Promise<Setting | undefined>;
  setSetting(setting: InsertSetting): Promise<Setting>;
  
  // Evolution
  getAllEvolutions(): Promise<Evolution[]>;
  getEvolution(id: number): Promise<Evolution | undefined>;
  createEvolution(evolution: InsertEvolution): Promise<Evolution>;
  updateEvolutionStatus(id: number, status: string, validationResult?: string): Promise<Evolution>;
  
  // Projects
  getAllProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  getProjectBySlug(slug: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<void>;
  incrementForkCount(id: number): Promise<void>;
  
  // Project Files
  getProjectFiles(projectId: number): Promise<ProjectFile[]>;
  createProjectFile(file: InsertProjectFile): Promise<ProjectFile>;
  createProjectFiles(files: InsertProjectFile[]): Promise<ProjectFile[]>;
  
  // Likes
  getProjectLikes(projectId: number): Promise<ProjectLike[]>;
  addLike(projectId: number, visitorId: string): Promise<ProjectLike | null>;
  removeLike(projectId: number, visitorId: string): Promise<void>;
  hasLiked(projectId: number, visitorId: string): Promise<boolean>;
  
  // Comments
  getProjectComments(projectId: number): Promise<ProjectComment[]>;
  createComment(comment: InsertProjectComment): Promise<ProjectComment>;
  deleteComment(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Modules
  async getAllModules(): Promise<Module[]> {
    return await db.select().from(modules).orderBy(modules.createdAt);
  }

  async getModule(id: number): Promise<Module | undefined> {
    const result = await db.select().from(modules).where(eq(modules.id, id)).limit(1);
    return result[0];
  }

  async createModule(module: InsertModule): Promise<Module> {
    const result = await db.insert(modules).values(module).returning();
    return result[0];
  }

  async deleteModule(id: number): Promise<void> {
    await db.delete(modules).where(eq(modules.id, id));
  }

  // Snippets
  async getAllSnippets(): Promise<Snippet[]> {
    return await db.select().from(snippets).orderBy(snippets.updatedAt);
  }

  async getSnippet(id: number): Promise<Snippet | undefined> {
    const result = await db.select().from(snippets).where(eq(snippets.id, id)).limit(1);
    return result[0];
  }

  async createSnippet(snippet: InsertSnippet): Promise<Snippet> {
    const result = await db.insert(snippets).values(snippet).returning();
    return result[0];
  }

  async updateSnippet(id: number, snippet: Partial<InsertSnippet>): Promise<Snippet> {
    const result = await db
      .update(snippets)
      .set({ ...snippet, updatedAt: new Date() })
      .where(eq(snippets.id, id))
      .returning();
    return result[0];
  }

  async deleteSnippet(id: number): Promise<void> {
    await db.delete(snippets).where(eq(snippets.id, id));
  }

  // Settings
  async getSetting(key: string): Promise<Setting | undefined> {
    const result = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    return result[0];
  }

  async setSetting(setting: InsertSetting): Promise<Setting> {
    const existing = await this.getSetting(setting.key);
    if (existing) {
      const result = await db
        .update(settings)
        .set({ value: setting.value, updatedAt: new Date() })
        .where(eq(settings.key, setting.key))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(settings).values(setting).returning();
      return result[0];
    }
  }

  // Evolution
  async getAllEvolutions(): Promise<Evolution[]> {
    return await db.select().from(evolutionHistory).orderBy(evolutionHistory.createdAt);
  }

  async getEvolution(id: number): Promise<Evolution | undefined> {
    const result = await db.select().from(evolutionHistory).where(eq(evolutionHistory.id, id)).limit(1);
    return result[0];
  }

  async createEvolution(evolution: InsertEvolution): Promise<Evolution> {
    const result = await db.insert(evolutionHistory).values(evolution).returning();
    return result[0];
  }

  async updateEvolutionStatus(id: number, status: string, validationResult?: string): Promise<Evolution> {
    const result = await db
      .update(evolutionHistory)
      .set({ status, validationResult })
      .where(eq(evolutionHistory.id, id))
      .returning();
    return result[0];
  }

  // Projects
  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.isPublic, true)).orderBy(desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
    return result[0];
  }

  async getProjectBySlug(slug: string): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.slug, slug)).limit(1);
    return result[0];
  }

  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    const result = await db
      .update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return result[0];
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  async incrementForkCount(id: number): Promise<void> {
    await db.update(projects).set({ forksCount: sql`${projects.forksCount} + 1` }).where(eq(projects.id, id));
  }

  // Project Files
  async getProjectFiles(projectId: number): Promise<ProjectFile[]> {
    return await db.select().from(projectFiles).where(eq(projectFiles.projectId, projectId)).orderBy(projectFiles.order);
  }

  async createProjectFile(file: InsertProjectFile): Promise<ProjectFile> {
    const result = await db.insert(projectFiles).values(file).returning();
    return result[0];
  }

  async createProjectFiles(files: InsertProjectFile[]): Promise<ProjectFile[]> {
    if (files.length === 0) return [];
    const result = await db.insert(projectFiles).values(files).returning();
    return result;
  }

  // Likes
  async getProjectLikes(projectId: number): Promise<ProjectLike[]> {
    return await db.select().from(projectLikes).where(eq(projectLikes.projectId, projectId));
  }

  async addLike(projectId: number, visitorId: string): Promise<ProjectLike | null> {
    try {
      const result = await db.insert(projectLikes).values({ projectId, visitorId }).returning();
      await db.update(projects).set({ likesCount: sql`${projects.likesCount} + 1` }).where(eq(projects.id, projectId));
      return result[0];
    } catch {
      return null;
    }
  }

  async removeLike(projectId: number, visitorId: string): Promise<void> {
    const deleted = await db.delete(projectLikes)
      .where(sql`${projectLikes.projectId} = ${projectId} AND ${projectLikes.visitorId} = ${visitorId}`)
      .returning();
    if (deleted.length > 0) {
      await db.update(projects).set({ likesCount: sql`${projects.likesCount} - 1` }).where(eq(projects.id, projectId));
    }
  }

  async hasLiked(projectId: number, visitorId: string): Promise<boolean> {
    const result = await db.select().from(projectLikes)
      .where(sql`${projectLikes.projectId} = ${projectId} AND ${projectLikes.visitorId} = ${visitorId}`)
      .limit(1);
    return result.length > 0;
  }

  // Comments
  async getProjectComments(projectId: number): Promise<ProjectComment[]> {
    return await db.select().from(projectComments).where(eq(projectComments.projectId, projectId)).orderBy(desc(projectComments.createdAt));
  }

  async createComment(comment: InsertProjectComment): Promise<ProjectComment> {
    const result = await db.insert(projectComments).values(comment).returning();
    return result[0];
  }

  async deleteComment(id: number): Promise<void> {
    await db.delete(projectComments).where(eq(projectComments.id, id));
  }
}

export const storage = new DatabaseStorage();
