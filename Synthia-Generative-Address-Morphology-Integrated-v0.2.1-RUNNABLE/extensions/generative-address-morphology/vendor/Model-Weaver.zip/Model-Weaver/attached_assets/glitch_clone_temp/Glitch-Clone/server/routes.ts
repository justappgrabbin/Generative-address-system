import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { insertProjectSchema, insertFileSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Projects
  app.get(api.projects.list.path, async (req, res) => {
    // If authenticated, return user's projects. Else, maybe return public ones?
    // For now, let's return all public projects or user's projects if logged in.
    if (req.isAuthenticated()) {
       const userId = (req.user as any).claims.sub;
       const projects = await storage.getProjectsByUser(userId);
       res.json(projects);
    } else {
       // Return empty list or public projects (not implemented filter yet)
       res.json([]);
    }
  });

  app.post(api.projects.create.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const input = api.projects.create.input.parse(req.body);
      // Force userId from auth
      const userId = (req.user as any).claims.sub;
      
      const project = await storage.createProject({
        ...input,
        userId,
      });

      // Create default index.html
      await storage.createFile({
        projectId: project.id,
        name: "index.html",
        content: `<!DOCTYPE html>
<html>
  <head>
    <title>${project.name}</title>
    <style>
      body { font-family: sans-serif; padding: 2rem; }
      h1 { color: #d0d; }
    </style>
  </head>
  <body>
    <h1>Hello from ${project.name}!</h1>
    <p>Edit this file to see changes.</p>
  </body>
</html>`,
        language: "html"
      });

      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.projects.get.path, async (req, res) => {
    const project = await storage.getProject(Number(req.params.id));
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    
    // Check if public or owner (logic simplified for MVP)
    
    const files = await storage.getFiles(project.id);
    res.json({ ...project, files });
  });

  app.delete(api.projects.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    // Check ownership
    const project = await storage.getProject(Number(req.params.id));
    if (!project) return res.status(404).json({ message: "Not found" });
    
    const userId = (req.user as any).claims.sub;
    if (project.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
    }

    await storage.deleteProject(Number(req.params.id));
    res.status(204).send();
  });

  // Files
  app.get(api.files.list.path, async (req, res) => {
    const files = await storage.getFiles(Number(req.params.projectId));
    res.json(files);
  });

  app.post(api.files.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const input = api.files.create.input.parse(req.body);
      // Verify project ownership
      const project = await storage.getProject(input.projectId);
      if (!project) return res.status(404).json({ message: "Project not found" });
      if (project.userId !== (req.user as any).claims.sub) return res.status(403).json({ message: "Forbidden" });

      const file = await storage.createFile(input);
      res.status(201).json(file);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.files.update.path, async (req, res) => {
     if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

     try {
       const input = api.files.update.input.parse(req.body);
       const fileId = Number(req.params.fileId);
       const file = await storage.getFile(fileId);
       if (!file) return res.status(404).json({ message: "File not found" });

       const project = await storage.getProject(file.projectId);
       if (project?.userId !== (req.user as any).claims.sub) return res.status(403).json({ message: "Forbidden" });

       const updated = await storage.updateFile(fileId, input);
       res.json(updated);
     } catch (err) {
       if (err instanceof z.ZodError) {
         res.status(400).json({ message: err.errors[0].message });
       }
       throw err;
     }
  });

  app.delete(api.files.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const fileId = Number(req.params.fileId);
    const file = await storage.getFile(fileId);
    if (!file) return res.status(404).json({ message: "File not found" });

    const project = await storage.getProject(file.projectId);
    if (project?.userId !== (req.user as any).claims.sub) return res.status(403).json({ message: "Forbidden" });

    await storage.deleteFile(fileId);
    res.status(204).send();
  });

  return httpServer;
}
