import { useState } from "react";
import { Link } from "wouter";
import { useProjects, useCreateProject, useDeleteProject } from "@/hooks/use-projects";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";
import { Button, Input, Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter, Dialog } from "@/components/ui-components";
import { Plus, Folder, Trash2, ArrowRight, Code, Clock, Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: projects, isLoading: projectsLoading } = useProjects();
  const createProject = useCreateProject();
  const deleteProject = useDeleteProject();

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");
  const [newProjectDesc, setNewProjectDesc] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createProject.mutateAsync({
        name: newProjectName,
        description: newProjectDesc,
        isPublic: true,
      });
      setIsCreateOpen(false);
      setNewProjectName("");
      setNewProjectDesc("");
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.preventDefault(); // Prevent link navigation
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this project?")) {
      await deleteProject.mutateAsync(id);
    }
  };

  const filteredProjects = projects?.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (authLoading) return null;

  if (!user) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 text-center">
          <div className="relative mb-8">
            <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />
            <Code className="h-24 w-24 text-primary relative z-10" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Code, Create, <span className="text-primary">Ship.</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mb-8">
            An instant IDE for your web projects. No setup required. Just start coding and share your work with the world.
          </p>
          <Button size="lg" onClick={() => window.location.href = "/api/login"} className="text-lg px-8 py-6 rounded-full shadow-xl shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-1 transition-all">
            Start Coding for Free
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Your Projects</h1>
            <p className="text-muted-foreground mt-1">Manage and create new web experiments.</p>
          </div>
          <Button onClick={() => setIsCreateOpen(true)} className="gap-2 shadow-lg shadow-primary/20">
            <Plus className="h-4 w-4" /> New Project
          </Button>
        </div>

        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search projects..." 
            className="pl-10 bg-card border-white/5"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {projectsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 rounded-xl bg-card/50 animate-pulse border border-white/5" />
            ))}
          </div>
        ) : filteredProjects?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 border border-dashed border-white/10 rounded-2xl bg-card/30">
            <div className="p-4 rounded-full bg-primary/10 mb-4">
              <Folder className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-lg font-medium mb-2">No projects yet</h3>
            <p className="text-muted-foreground mb-6 text-center max-w-sm">Create your first project to start building something amazing.</p>
            <Button onClick={() => setIsCreateOpen(true)} variant="outline">Create Project</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects?.map((project) => (
              <Link key={project.id} href={`/project/${project.id}`}>
                <div className="group block h-full">
                  <Card className="h-full flex flex-col bg-card/50 hover:bg-card border-white/10 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5 cursor-pointer">
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-start justify-between">
                        <span className="group-hover:text-primary transition-colors truncate">{project.name}</span>
                        {project.isPublic && (
                          <span className="text-[10px] uppercase tracking-wider font-bold text-primary/70 bg-primary/10 px-2 py-0.5 rounded-full">
                            Public
                          </span>
                        )}
                      </CardTitle>
                      <CardDescription className="line-clamp-2 min-h-[2.5em]">
                        {project.description || "No description provided."}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      {/* Preview thumbnail placeholder or logic could go here */}
                      <div className="w-full h-24 rounded-md bg-black/20 flex items-center justify-center text-muted-foreground/50 text-sm font-mono border border-white/5 group-hover:border-white/10 transition-colors">
                        index.html
                      </div>
                    </CardContent>
                    <CardFooter className="pt-2 border-t border-white/5 flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{formatDistanceToNow(new Date(project.createdAt), { addSuffix: true })}</span>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity hover:text-destructive hover:bg-destructive/10"
                        onClick={(e) => handleDelete(project.id, e)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      <Dialog isOpen={isCreateOpen} onClose={() => setIsCreateOpen(false)} title="Create New Project">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Project Name</label>
            <Input 
              placeholder="my-awesome-app" 
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              required
              autoFocus
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Description</label>
            <Input 
              placeholder="What are you building?" 
              value={newProjectDesc}
              onChange={(e) => setNewProjectDesc(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createProject.isPending}>Create Project</Button>
          </div>
        </form>
      </Dialog>
    </Layout>
  );
}
