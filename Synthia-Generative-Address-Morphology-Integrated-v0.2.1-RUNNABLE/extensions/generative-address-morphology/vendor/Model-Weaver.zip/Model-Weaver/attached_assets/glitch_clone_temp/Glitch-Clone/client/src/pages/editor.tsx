import { useState, useEffect, useRef } from "react";
import { useRoute, Link } from "wouter";
import Editor from "@monaco-editor/react";
import { useProject, useFiles, useCreateFile, useUpdateFile, useDeleteFile } from "@/hooks/use-projects";
import { Button, Input, Dialog } from "@/components/ui-components";
import { 
  File, FilePlus, Save, Trash2, ArrowLeft, Play, Layout as LayoutIcon, 
  Settings, Download, Loader2, ChevronRight, FileCode, FileJson, FileType, Code2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import type { File as FileTypeModel } from "@shared/schema";

// Simple file icon helper
const FileIcon = ({ name }: { name: string }) => {
  if (name.endsWith('.html')) return <Code2 className="h-4 w-4 text-orange-500" />;
  if (name.endsWith('.css')) return <FileType className="h-4 w-4 text-blue-500" />;
  if (name.endsWith('.js') || name.endsWith('.ts')) return <FileCode className="h-4 w-4 text-yellow-500" />;
  if (name.endsWith('.json')) return <FileJson className="h-4 w-4 text-green-500" />;
  return <File className="h-4 w-4 text-muted-foreground" />;
};

export default function EditorPage() {
  const [match, params] = useRoute("/project/:id");
  const projectId = parseInt(params?.id || "0");
  const { toast } = useToast();

  const { data: project, isLoading: projectLoading } = useProject(projectId);
  const { data: files, isLoading: filesLoading } = useFiles(projectId);
  
  const createFile = useCreateFile();
  const updateFile = useUpdateFile();
  const deleteFile = useDeleteFile();

  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [activeContent, setActiveContent] = useState<string>("");
  const [previewUrl, setPreviewUrl] = useState<string>("");
  
  // Create File Dialog State
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newFileName, setNewFileName] = useState("");

  // Debounce save ref
  const saveTimeoutRef = useRef<NodeJS.Timeout>();

  // Select first file on load
  useEffect(() => {
    if (files && files.length > 0 && !activeFileId) {
      // Prefer index.html if exists
      const indexHtml = files.find(f => f.name === 'index.html');
      if (indexHtml) {
        setActiveFileId(indexHtml.id);
        setActiveContent(indexHtml.content);
      } else {
        setActiveFileId(files[0].id);
        setActiveContent(files[0].content);
      }
    }
  }, [files, activeFileId]);

  // Update preview when files change
  useEffect(() => {
    if (!files) return;
    
    // Construct a blob for the preview
    // For MVP, we'll just try to render index.html and inject css/js if possible
    // A robust solution would use a service worker or a separate domain
    
    const indexFile = files.find(f => f.name === 'index.html');
    if (indexFile) {
      let html = indexFile.content;
      
      // Basic injection for local files (MVP hack)
      files.forEach(f => {
        if (f.name.endsWith('.css')) {
          html = html.replace(`<link rel="stylesheet" href="${f.name}">`, `<style>${f.content}</style>`);
        }
        if (f.name.endsWith('.js')) {
          html = html.replace(`<script src="${f.name}"></script>`, `<script>${f.content}</script>`);
        }
      });

      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      
      return () => URL.revokeObjectURL(url);
    }
  }, [files]); // Re-run when any file content changes (saved)

  const handleFileSelect = (file: FileTypeModel) => {
    // If unsaved changes (basic check), maybe warn? For now auto-save logic handles it
    setActiveFileId(file.id);
    setActiveContent(file.content);
  };

  const handleEditorChange = (value: string | undefined) => {
    if (value === undefined || !activeFileId) return;
    
    setActiveContent(value);
    
    // Auto-save debounce
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    
    saveTimeoutRef.current = setTimeout(() => {
      handleSave(activeFileId, value);
    }, 1000);
  };

  const handleSave = async (fileId: number, content: string) => {
    try {
      await updateFile.mutateAsync({
        projectId,
        fileId,
        content
      });
    } catch (err) {
      console.error("Failed to auto-save", err);
    }
  };

  const handleCreateFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName) return;
    
    try {
      await createFile.mutateAsync({
        projectId,
        name: newFileName,
        content: "",
        language: "plaintext"
      });
      setIsCreateOpen(false);
      setNewFileName("");
      toast({ title: "File created", description: `${newFileName} has been created.` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to create file.", variant: "destructive" });
    }
  };

  const handleDeleteFile = async (e: React.MouseEvent, fileId: number) => {
    e.stopPropagation();
    if (confirm("Delete this file?")) {
      await deleteFile.mutateAsync({ projectId, fileId });
      if (activeFileId === fileId) {
        setActiveFileId(null);
        setActiveContent("");
      }
      toast({ title: "File deleted", description: "File has been removed." });
    }
  };

  if (projectLoading || filesLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background text-muted-foreground">
        <Loader2 className="h-8 w-8 animate-spin mr-2" />
        Loading project...
      </div>
    );
  }

  if (!project) return <div>Project not found</div>;

  const activeFile = files?.find(f => f.id === activeFileId);
  const language = activeFile?.name.endsWith('.html') ? 'html' : 
                   activeFile?.name.endsWith('.css') ? 'css' : 
                   activeFile?.name.endsWith('.js') ? 'javascript' : 
                   activeFile?.name.endsWith('.json') ? 'json' : 'plaintext';

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden font-sans">
      {/* Top Bar */}
      <div className="h-14 border-b border-white/10 flex items-center justify-between px-4 bg-card/50 backdrop-blur-md z-10">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
          </Link>
          <div className="h-6 w-px bg-white/10" />
          <div>
            <h1 className="font-semibold text-sm">{project.name}</h1>
            <p className="text-xs text-muted-foreground hidden sm:block">Edited just now</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {updateFile.isPending && (
            <span className="text-xs text-muted-foreground flex items-center animate-pulse mr-2">
              <Save className="h-3 w-3 mr-1" /> Saving...
            </span>
          )}
          <Button size="sm" variant="secondary" className="gap-2 hidden sm:flex">
             <Download className="h-4 w-4" /> Export
          </Button>
          <Button size="sm" className="gap-2 bg-green-600 hover:bg-green-700 text-white border-none shadow-lg shadow-green-900/20">
             <Play className="h-3 w-3 fill-current" /> Live
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - File Explorer */}
        <div className="w-64 bg-card border-r border-white/5 flex flex-col flex-shrink-0">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Files</span>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setIsCreateOpen(true)}>
              <FilePlus className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {files?.map(file => (
              <div 
                key={file.id}
                onClick={() => handleFileSelect(file)}
                className={cn(
                  "group flex items-center justify-between px-3 py-2 rounded-md text-sm cursor-pointer transition-colors border border-transparent",
                  activeFileId === file.id 
                    ? "bg-primary/10 text-primary border-primary/20 font-medium" 
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                )}
              >
                <div className="flex items-center gap-2 truncate">
                  <FileIcon name={file.name} />
                  <span className="truncate">{file.name}</span>
                </div>
                
                {file.name !== 'index.html' && (
                  <button 
                    onClick={(e) => handleDeleteFile(e, file.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-destructive transition-opacity"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-white/5 text-xs text-muted-foreground">
             <div className="flex items-center gap-2">
               <Settings className="h-3 w-3" /> Project Settings
             </div>
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Editor Tabs/Header */}
          {activeFile && (
             <div className="h-10 bg-background border-b border-white/5 flex items-center px-4 gap-2">
                <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-t-md text-xs border-t border-x border-white/5 relative top-[1px]">
                   <FileIcon name={activeFile.name} />
                   {activeFile.name}
                </div>
             </div>
          )}

          <div className="flex-1 relative">
            {activeFileId ? (
              <Editor
                height="100%"
                defaultLanguage="javascript"
                language={language}
                value={activeContent}
                theme="vs-dark"
                onChange={handleEditorChange}
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                  fontFamily: "'JetBrains Mono', monospace",
                  padding: { top: 20 },
                  scrollBeyondLastLine: false,
                  lineNumbers: "on",
                  roundedSelection: false,
                  scrollbar: {
                    useShadows: false,
                    verticalScrollbarSize: 10,
                  }
                }}
              />
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                Select a file to start editing
              </div>
            )}
          </div>
        </div>

        {/* Preview Pane */}
        <div className="w-[40%] bg-white border-l border-white/10 flex flex-col flex-shrink-0">
          <div className="h-10 bg-zinc-100 border-b border-zinc-200 flex items-center px-4 justify-between">
            <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-2">
              <LayoutIcon className="h-3 w-3" /> Preview
            </span>
            <div className="flex gap-1">
              <div className="w-2 h-2 rounded-full bg-zinc-300" />
              <div className="w-2 h-2 rounded-full bg-zinc-300" />
            </div>
          </div>
          <div className="flex-1 bg-white relative">
            {previewUrl ? (
              <iframe 
                src={previewUrl}
                className="w-full h-full border-0"
                title="Preview"
                sandbox="allow-scripts"
              />
            ) : (
              <div className="flex items-center justify-center h-full text-zinc-400 text-sm">
                No preview available
              </div>
            )}
          </div>
        </div>
      </div>

      <Dialog isOpen={isCreateOpen} onClose={() => setIsCreateOpen(false)} title="New File">
        <form onSubmit={handleCreateFile} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Filename</label>
            <Input 
              placeholder="style.css" 
              value={newFileName} 
              onChange={(e) => setNewFileName(e.target.value)} 
              autoFocus
            />
            <p className="text-xs text-muted-foreground mt-1">Include extension (e.g. .js, .css, .html)</p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createFile.isPending}>Create File</Button>
          </div>
        </form>
      </Dialog>
    </div>
  );
}
