/**
 * PAPER GNN ENGINE v1.0
 * 64-Node Graph Neural Network for Human Design Consciousness Calculation
 * 
 * Architecture:
 * - 64 nodes (HD Gates/Codons)
 * - 36 channels (official HD channel map)
 * - Node features: planetary placements, lines, definitions
 * - Output: Gate activations, awareness scores, coherence
 * 
 * Usage:
 *   const engine = new PaperGNN();
 *   const state = engine.calculate(birthData);
 */

class PaperGNN {
  constructor() {
    this.initializeGraph();
    this.initializeChannels();
    this.initializeCenters();
  }

  /**
   * Initialize 64-node graph structure (HD Gates)
   */
  initializeGraph() {
    this.gates = Array.from({ length: 64 }, (_, i) => ({
      id: i + 1,
      activation: 0.0,
      features: {},
      center: this.gateToCenter(i + 1),
      definition: false
    }));
  }

  /**
   * Initialize 36 channels (edges between gates)
   * Official Human Design channel map
   */
  initializeChannels() {
    this.channels = [
      // FORMAT CHANNELS (Identity)
      [1, 8], [2, 14], [7, 31], [13, 33], [10, 20], [10, 34], [10, 57],
      
      // TRIBAL CHANNELS (Support)
      [19, 49], [37, 40], [18, 58], [38, 28], [54, 32], [44, 26],
      
      // INDIVIDUAL CHANNELS (Empowerment)
      [12, 22], [35, 36], [3, 60], [51, 25], [21, 45], [26, 44],
      
      // INTEGRATION CHANNELS (Sharing)
      [20, 34], [20, 57], [34, 57], [11, 56], [23, 43], [17, 62],
      [16, 48], [64, 47], [61, 24], [63, 4], [5, 15], [29, 46],
      
      // EMOTIONAL CHANNELS
      [6, 59], [37, 40], [22, 12], [36, 35], [30, 41], [55, 39]
    ];
  }

  /**
   * Initialize 9 centers (consciousness nodes)
   */
  initializeCenters() {
    this.centers = {
      head: { gates: [64, 61, 63], awareness: 'inspiration' },
      ajna: { gates: [47, 24, 4, 17, 43, 11], awareness: 'conceptualization' },
      throat: { gates: [62, 23, 56, 35, 12, 45, 33, 8, 31, 20, 16], awareness: 'manifestation' },
      g: { gates: [7, 1, 13, 10, 25, 46, 15, 2], awareness: 'identity' },
      sacral: { gates: [5, 14, 29, 59, 9, 3, 42, 27, 34], awareness: 'life_force' },
      spleen: { gates: [48, 57, 44, 50, 32, 28, 18], awareness: 'survival' },
      solar_plexus: { gates: [6, 37, 22, 36, 30, 55, 49], awareness: 'emotion' },
      heart: { gates: [51, 21, 40, 26], awareness: 'willpower' },
      root: { gates: [52, 19, 39, 41, 60, 53, 54, 58, 38], awareness: 'pressure' }
    };
  }

  /**
   * Map gate number to center
   */
  gateToCenter(gateNum) {
    for (const [center, data] of Object.entries(this.centers)) {
      if (data.gates.includes(gateNum)) return center;
    }
    return 'undefined';
  }

  /**
   * MAIN CALCULATION: Process input and compute GNN state
   * 
   * @param {Object} input - Birth data or text input
   * @param {string} input.birthTime - ISO datetime
   * @param {number} input.latitude - Birth location lat
   * @param {number} input.longitude - Birth location lon
   * @param {string} input.text - Alternative: text input for analysis
   * @returns {Object} GNN state vector
   */
  calculate(input) {
    // Extract features from input
    const features = this.extractFeatures(input);
    
    // Activate gates based on planetary placements
    this.activateGates(features);
    
    // Process channels (message passing)
    this.processChannels();
    
    // Calculate center awareness scores
    const awarenessScores = this.calculateAwareness();
    
    // Calculate coherence score
    const coherenceScore = this.calculateCoherence(awarenessScores);
    
    // Determine optimal action
    const optimalAction = this.determineOptimalAction(awarenessScores);
    
    return {
      gateActivations: this.gates.map(g => g.activation),
      awarenessScores,
      coherenceScore,
      optimalAction,
      definedCenters: this.getDefinedCenters(),
      activeChannels: this.getActiveChannels()
    };
  }

  /**
   * Extract features from input
   */
  extractFeatures(input) {
    if (input.text) {
      // Text-based feature extraction
      return this.extractTextFeatures(input.text);
    } else if (input.birthTime) {
      // Astronomical calculation (placeholder)
      return this.extractAstroFeatures(input);
    }
    
    // Default: random initialization for testing
    return this.extractDefaultFeatures();
  }

  /**
   * Extract features from text input (NLP-style)
   */
  extractTextFeatures(text) {
    const features = {
      movement: 0,
      evolution: 0,
      being: 0,
      design: 0,
      space: 0
    };

    // Simple heuristics (can be replaced with ML model)
    const words = text.toLowerCase().split(/\s+/);
    
    // Movement indicators
    const movementWords = ['do', 'go', 'action', 'move', 'create', 'make', 'start', 'begin'];
    features.movement = words.filter(w => movementWords.includes(w)).length / words.length;
    
    // Evolution indicators
    const evolutionWords = ['learn', 'grow', 'understand', 'realize', 'discover', 'change'];
    features.evolution = words.filter(w => evolutionWords.includes(w)).length / words.length;
    
    // Being indicators
    const beingWords = ['am', 'is', 'feel', 'sense', 'embody', 'experience', 'exist'];
    features.being = words.filter(w => beingWords.includes(w)).length / words.length;
    
    // Design indicators
    const designWords = ['plan', 'structure', 'organize', 'system', 'pattern', 'design'];
    features.design = words.filter(w => designWords.includes(w)).length / words.length;
    
    // Space indicators
    const spaceWords = ['all', 'universe', 'consciousness', 'awareness', 'field', 'universal'];
    features.space = words.filter(w => spaceWords.includes(w)).length / words.length;

    // Normalize to 0-1 range
    const max = Math.max(...Object.values(features), 0.1);
    for (const key in features) {
      features[key] = Math.min(features[key] / max, 1.0);
    }

    return features;
  }

  /**
   * Extract features from astronomical data
   */
  extractAstroFeatures(birthData) {
    // TODO: Implement Swiss Ephemeris calculation
    // For now, return placeholder based on hash
    const hash = this.hashString(birthData.birthTime);
    
    return {
      sunGate: (hash % 64) + 1,
      earthGate: ((hash * 2) % 64) + 1,
      moonGate: ((hash * 3) % 64) + 1,
      design: (hash * 0.1) % 1.0,
      personality: (hash * 0.2) % 1.0
    };
  }

  /**
   * Default features for testing
   */
  extractDefaultFeatures() {
    return {
      movement: Math.random(),
      evolution: Math.random(),
      being: Math.random(),
      design: Math.random(),
      space: Math.random()
    };
  }

  /**
   * Activate gates based on features
   */
  activateGates(features) {
    // If astro features, activate specific gates
    if (features.sunGate) {
      this.gates[features.sunGate - 1].activation = 1.0;
      this.gates[features.sunGate - 1].definition = true;
      
      if (features.earthGate) {
        this.gates[features.earthGate - 1].activation = 1.0;
        this.gates[features.earthGate - 1].definition = true;
      }
      
      if (features.moonGate) {
        this.gates[features.moonGate - 1].activation = 0.8;
        this.gates[features.moonGate - 1].definition = true;
      }
    }
    
    // If text features, activate gates based on dimensions
    if (features.movement !== undefined) {
      // Map dimensions to center activations
      const centerActivations = {
        sacral: features.movement,
        ajna: features.evolution,
        g: features.being,
        throat: features.design,
        head: features.space
      };
      
      // Activate gates in those centers
      for (const [center, activation] of Object.entries(centerActivations)) {
        const centerGates = this.centers[center]?.gates || [];
        centerGates.forEach(gateNum => {
          this.gates[gateNum - 1].activation = Math.max(
            this.gates[gateNum - 1].activation,
            activation
          );
        });
      }
    }
  }

  /**
   * Process channels (message passing between gates)
   * GraphSAGE-style aggregation
   */
  processChannels() {
    // For each channel, propagate activation
    this.channels.forEach(([gate1, gate2]) => {
      const g1 = this.gates[gate1 - 1];
      const g2 = this.gates[gate2 - 1];
      
      // If both gates activated, strengthen connection
      if (g1.activation > 0.5 && g2.activation > 0.5) {
        // Average activation (simple message passing)
        const avg = (g1.activation + g2.activation) / 2;
        g1.activation = Math.min(avg * 1.1, 1.0);
        g2.activation = Math.min(avg * 1.1, 1.0);
        
        // Mark as defined if threshold met
        if (avg > 0.7) {
          g1.definition = true;
          g2.definition = true;
        }
      }
    });
  }

  /**
   * Calculate awareness scores for each center
   */
  calculateAwareness() {
    const scores = {};
    
    for (const [centerName, centerData] of Object.entries(this.centers)) {
      // Average activation of gates in this center
      const activations = centerData.gates.map(gateNum => 
        this.gates[gateNum - 1].activation
      );
      
      const avgActivation = activations.reduce((sum, a) => sum + a, 0) / activations.length;
      
      // Check if center is defined (any channel completes it)
      const isDefined = this.isCenterDefined(centerName);
      
      scores[centerName] = {
        activation: avgActivation,
        defined: isDefined,
        awareness: centerData.awareness
      };
    }
    
    // Special awareness scores (for compatibility with UI)
    return {
      spleen: scores.spleen.activation,
      ajna: scores.ajna.activation,
      solarPlexus: scores.solar_plexus.activation,
      heart: scores.heart.activation,
      mind: (scores.head.activation + scores.ajna.activation) / 2,
      
      // Extended scores
      allCenters: scores
    };
  }

  /**
   * Check if center is defined by channels
   */
  isCenterDefined(centerName) {
    const centerGates = this.centers[centerName].gates;
    
    // Check if any channel connecting this center is fully activated
    return this.channels.some(([g1, g2]) => {
      const g1InCenter = centerGates.includes(g1);
      const g2InCenter = centerGates.includes(g2);
      
      // If channel connects this center and both gates defined
      if (g1InCenter || g2InCenter) {
        return this.gates[g1 - 1].definition && this.gates[g2 - 1].definition;
      }
      return false;
    });
  }

  /**
   * Calculate coherence score
   * Measures alignment between defined and activated gates
   */
  calculateCoherence(awarenessScores) {
    const defined = this.gates.filter(g => g.definition);
    const activated = this.gates.filter(g => g.activation > 0.5);
    
    if (defined.length === 0) return 0.5; // Neutral if nothing defined
    
    // Coherence = overlap between defined and activated
    const overlap = defined.filter(g => g.activation > 0.5).length;
    const coherence = overlap / defined.length;
    
    // Adjust based on center balance
    const definedCenters = Object.values(awarenessScores.allCenters)
      .filter(c => c.defined).length;
    const balanceBonus = definedCenters / 9 * 0.2;
    
    return Math.min(coherence + balanceBonus, 1.0);
  }

  /**
   * Determine optimal action based on awareness pattern
   */
  determineOptimalAction(awarenessScores) {
    const { allCenters } = awarenessScores;
    
    // Check authority (decision-making center)
    if (allCenters.solar_plexus.defined) {
      return "Wait for Emotional Clarity";
    } else if (allCenters.sacral.defined) {
      return "Wait to Respond";
    } else if (allCenters.spleen.defined) {
      return "Trust Spontaneous Knowing";
    } else if (allCenters.heart.defined) {
      return "Follow Will/Ego";
    } else if (allCenters.g.defined) {
      return "Follow Inner Authority";
    }
    
    // No inner authority = mental projector or reflector
    if (Object.values(allCenters).filter(c => c.defined).length < 2) {
      return "Wait 28 Days (Lunar Cycle)"; // Reflector
    }
    
    return "Wait for Recognition"; // Projector
  }

  /**
   * Get list of defined centers
   */
  getDefinedCenters() {
    return Object.entries(this.centers)
      .filter(([name, _]) => {
        const scores = this.calculateAwareness();
        return scores.allCenters[name].defined;
      })
      .map(([name, _]) => name);
  }

  /**
   * Get list of active channels
   */
  getActiveChannels() {
    return this.channels.filter(([g1, g2]) => {
      return this.gates[g1 - 1].definition && this.gates[g2 - 1].definition;
    });
  }

  /**
   * Utility: Hash string to number
   */
  hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
}

// Export for use in browser or Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PaperGNN;
}
