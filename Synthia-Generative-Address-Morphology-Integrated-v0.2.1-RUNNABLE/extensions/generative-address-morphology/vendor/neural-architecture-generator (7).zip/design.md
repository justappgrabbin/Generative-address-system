# Neural Architecture Generator — Mobile Interface Design

## Product Direction

Neural Architecture Generator is a focused, portrait-first iOS-style workspace for turning a plain-language modeling brief into a composable neural network. The experience should feel like a calm engineering instrument: dark graphite surfaces, electric violet for active composition, cyan for data flow, and restrained green for validated reusable functions. Every primary action is reachable near the lower half of the screen for one-handed use.

## Screen List

| Screen | Primary content and functionality |
|---|---|
| **Compose** | Instruction input, recent prompts, resolved architecture summary, and the primary “Resolve architecture” action. This is the default landing screen. |
| **Graph** | A workbench-style inspector with Graph, Faces, and Code modes. Graph shows the stacked node path, tensor shapes, connections, and a “Run dry pass” action; Faces shows primitive family, contracts, status, and lineage; Code shows a serializable manifest preview without executing generated source. |
| **Primitives** | Searchable catalog of all 64 interchangeable primitives, grouped by family: input, normalization, convolution, attention, recurrent, activation, pooling, regularization, routing, output, and utility. Tapping a primitive opens its contract and example usage. |
| **Library** | Saved higher-order functions, compression metadata, usage count, and “Insert into composition” action. |
| **Function detail** | Expanded composition definition, primitive sequence, input/output contract, compression ratio, and rename/delete actions. |
| **Settings** | Theme preference, local persistence status, and app explanation. No authentication or cloud sync is required for the first version. |

## Key User Flows

### Resolve an instruction

1. User opens **Compose** and sees a prefilled example instruction plus a multiline prompt field.
2. User enters a brief such as “Classify short audio clips with a compact attention model.”
3. User taps **Resolve architecture**.
4. The resolver maps intent keywords to primitive families, creates a typed sequence, and shows a concise resolution summary.
5. User taps **View graph** to inspect the composed network.

### Inspect and run a graph

1. User opens **Graph** from a resolved composition.
2. User reviews the ordered node stack, tensor-flow badges, parameter notes, and graph health indicator.
3. User taps a node to view its primitive contract.
4. User taps **Run dry pass** to simulate shape propagation and receive a success/failure result without training a model on-device.
5. User taps **Promote to function** to save the successful composition.

### Reuse a higher-order function

1. User opens **Library** and selects a saved function.
2. User reviews its primitive signature and compression metadata.
3. User taps **Insert into composition**.
4. The higher-order function appears as a reusable macro node in the current graph.
5. User may expand the macro to inspect the underlying primitives.

### Explore the primitive catalog

1. User opens **Primitives**.
2. User searches by name or family, for example “attention” or “regularization.”
3. User taps a primitive card to view input/output types, configurable parameters, and compatible neighbors.
4. User taps **Add to composition** to append the primitive to the active graph.

## Layout and Interaction Rules

The app uses portrait orientation and `ScreenContainer` on every screen. The primary header is compact, with a small overline for workspace context, a strong screen title, and a trailing status chip. Cards use 18–22px corner radii, one-pixel borders, and subtle elevation. Primary buttons use a 0.97 pressed scale and light haptic feedback. Lists use `FlatList`; graph nodes are rendered as a vertical, readable mobile representation rather than relying on a dense desktop canvas.

The bottom tab bar contains **Compose**, **Graph**, **Primitives**, and **Library**. Settings is reachable from the top-right gear action. Empty states should explain what the user can do next rather than display inert placeholders.

## Color Choices

| Token | Value | Use |
|---|---|---|
| `background` | `#0B0D12` | Main canvas and app chrome |
| `surface` | `#141923` | Cards, node containers, and sheets |
| `surfaceElevated` | `#1B2230` | Selected cards and graph emphasis |
| `foreground` | `#F7F7FB` | Primary text |
| `muted` | `#8F98AA` | Secondary labels and helper text |
| `border` | `#283143` | Dividers and card outlines |
| `primary` | `#8B5CF6` | Composition actions and active selections |
| `cyan` | `#22D3EE` | Data-flow accents and input/output badges |
| `success` | `#34D399` | Validated graphs and promoted functions |
| `warning` | `#FBBF24` | Configuration warnings |
| `error` | `#FB7185` | Invalid graph states |

## Domain Model

A `Primitive` has an id, name, family, short description, input contract, output contract, configurable parameters, and a compact color category. A `GraphNode` references a primitive or higher-order function and stores display metadata plus resolved parameters. A `Composition` contains an instruction, ordered nodes, graph status, estimated parameter count, created timestamp, deterministic manifest version, and lineage from instruction to primitive ids. A `HigherOrderFunction` contains a reusable composition signature, the primitive ids it compresses, an expansion description, usage count, and a serializable snapshot/export record.

The first release uses deterministic local resolution so the app remains useful offline and testable. The resolver selects from the 64 primitives using keyword families, while the graph executor performs local shape/type propagation and reports structural validity. This is an architecture-design tool, not a full training runtime.


## Expanded Architecture Factory

The Primitive Library now has a second **Architecture Factory** mode with exactly 36 major executable model families selected from the supplied landscape. Each family exposes a default block sequence, editable parameters, and a live runtime contract; family blocks can be changed and nested without becoming inert mockups.

Selecting **Edit** opens a live architecture inspector. Tapping a block widens its parameter immutably and increments the blueprint version. **Nest Attention Cell** demonstrates fractal composition by inserting a complete child blueprint as a nested block, increasing depth and extending lineage. This keeps the factory model recursive: a live architecture can become a block inside another live architecture without losing provenance.


## Universal Modulation Contract

All 36 live architectures implement the same modulation boundary: standardized vector input, output, and shared-state ports. Internal tensors are never merged directly across model families. Instead, outputs are adapted to the shared vector port and combined through signed influence edges with clamped weights, optional inhibition, and named shared-state channels.

A composition has a stable address, ordered executable nodes, weighted edges, state, depth, and lineage. A composition can be inserted as a nested node inside another composition, then executed recursively. The neural layer only modulates activation, inhibition, routing, sequencing, and learning signals; the universal capability substrate remains separate and retains its complete capability set without model-specific restrictions.

## Generative and Emergent Substrate Update

The Graph workbench now supports deterministic generation from a seed, reproducible mutation, arbitrary branch edges, parallel influence paths, weight changes, and recursive composition addresses. A generated field is not a fixed sequence: it can be reshaped, rerun, serialized, validated, and imported as a new composition.

## Dataset and Learning Update

The Dataset Lab accepts pasted CSV or JSON records, validates finite numeric features and labels, creates deterministic train/validation/test splits, evaluates validation accuracy and loss, computes a reward signal, and applies that reward through the runtime’s gradient loop using the user’s training records. User data remains local by default. Learned parameter state can be exported and imported as JSON, while nested compositions can be exported and imported through their schema-validated recursive representation.
