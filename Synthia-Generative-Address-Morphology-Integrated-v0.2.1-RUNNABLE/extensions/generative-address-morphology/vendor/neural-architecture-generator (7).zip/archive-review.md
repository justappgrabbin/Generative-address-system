# Archive Review Findings

## Supplied archives

The review covered `Neural-Morphing-Limits(2).zip` and `integrated-tool-factory-v1_6_0.zip`. The first archive contains a large multi-package workspace and a web-only mockup sandbox. Its most relevant transferable ideas are the ATO workbench’s three-view pattern (`graph`, `faces`, `code`), typed relationship records with status/provenance/layer metadata, domain color coding, and explicit source-backed versus derived records. The web component itself is not being copied because it depends on a browser/Radix stack and desktop layout assumptions.

The second archive is a dependency-free JavaScript tool factory. Its reusable ideas are more directly relevant: deterministic routing into bounded structural levels, a generated manifest, typed ports, executable composition, lineage metadata, reversible snapshots, and standalone export. It deliberately avoids `eval`, `new Function`, network access, and untrusted generated source. Those boundaries are appropriate for the mobile generator.

## Selected integrations

The mobile app should gain a **Graph / Faces / Code** inspection concept. Graph remains the current typed node path; Faces becomes a metadata view showing primitive family, input/output contract, status, and provenance; Code becomes a future export surface rather than executing generated code on-device. The current graph model will also add deterministic manifest metadata: composition id, resolver version, primitive count, status, and lineage from source instruction to higher-order function.

The current higher-order compression flow is compatible with the factory’s reusable-tool pattern. Promotion should preserve the primitive id sequence, expose an inspectable macro signature, increment usage on reuse, and support a serializable snapshot/export object. The app will not import the archive’s ATO runtime, web UI, unrelated emotional/Yijing vocabulary, large attached assets, or any generated executable source.

## Safety and compatibility boundary

Only static, reviewed TypeScript data and pure functions should be integrated into the Expo app. The archive’s web-only components, package manifests, embedded `.git` history, and unrelated domain assets are excluded. No backend, cloud sync, authentication, or code execution is required for these integrations.
