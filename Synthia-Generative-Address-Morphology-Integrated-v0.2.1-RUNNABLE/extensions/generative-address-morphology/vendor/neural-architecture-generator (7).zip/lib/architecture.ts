export type PrimitiveFamily =
  | "Input"
  | "Transform"
  | "Convolution"
  | "Attention"
  | "Recurrent"
  | "Activation"
  | "Pooling"
  | "Regularization"
  | "Routing"
  | "Output"
  | "Utility";

export type Primitive = {
  id: string;
  name: string;
  family: PrimitiveFamily;
  description: string;
  input: string;
  output: string;
  color: string;
};

export type GraphNode = Primitive & { nodeId: string; params: string };

export type CompositionManifest = {
  manifestVersion: "nag.composition.v2";
  id: string;
  instruction: string;
  resolver: { version: string; mode: "deterministic" };
  structure: { kind: "sequence"; nodeCount: number };
  lineage: { source: "instruction"; primitiveIds: string[] };
  status: "resolved" | "validated";
  runtime?: { model: string; parameters: number; lastRun?: string; lastConfidence?: number };
};

export type CompositionSnapshot = { manifest: CompositionManifest; nodes: GraphNode[]; exportedAt: string };


const definitions: Array<[string, string, PrimitiveFamily, string, string, string]> = [
  ["input-text", "Text Input", "Input", "Token sequence", "Token embeddings", "#22D3EE"],
  ["input-image", "Image Input", "Input", "Image tensor", "Feature map", "#22D3EE"],
  ["input-audio", "Audio Input", "Input", "Waveform", "Spectrogram", "#22D3EE"],
  ["input-tabular", "Tabular Input", "Input", "Feature vector", "Feature vector", "#22D3EE"],
  ["tokenize", "Tokenizer", "Transform", "Text", "Token sequence", "#A78BFA"],
  ["embed", "Embedding", "Transform", "Token ids", "Dense vectors", "#A78BFA"],
  ["project", "Linear Projection", "Transform", "Feature vector", "Feature vector", "#A78BFA"],
  ["reshape", "Reshape", "Transform", "Tensor", "Tensor", "#A78BFA"],
  ["conv1d", "Conv 1D", "Convolution", "Sequence", "Sequence features", "#F472B6"],
  ["conv2d", "Conv 2D", "Convolution", "Image tensor", "Spatial features", "#F472B6"],
  ["depthwise", "Depthwise Conv", "Convolution", "Feature map", "Feature map", "#F472B6"],
  ["dilated", "Dilated Conv", "Convolution", "Sequence", "Context features", "#F472B6"],
  ["residual", "Residual Block", "Convolution", "Feature map", "Feature map", "#F472B6"],
  ["bottleneck", "Bottleneck Block", "Convolution", "Feature map", "Compressed map", "#F472B6"],
  ["self-attention", "Self Attention", "Attention", "Sequence", "Contextual sequence", "#38BDF8"],
  ["cross-attention", "Cross Attention", "Attention", "Two sequences", "Aligned sequence", "#38BDF8"],
  ["multihead", "Multi-Head Attention", "Attention", "Sequence", "Contextual sequence", "#38BDF8"],
  ["local-attention", "Local Attention", "Attention", "Sequence", "Windowed context", "#38BDF8"],
  ["gated-rnn", "Gated RNN", "Recurrent", "Sequence", "Hidden sequence", "#F59E0B"],
  ["lstm", "LSTM", "Recurrent", "Sequence", "Hidden sequence", "#F59E0B"],
  ["gru", "GRU", "Recurrent", "Sequence", "Hidden sequence", "#F59E0B"],
  ["bidirectional", "Bidirectional RNN", "Recurrent", "Sequence", "Context sequence", "#F59E0B"],
  ["relu", "ReLU", "Activation", "Tensor", "Tensor", "#FB7185"],
  ["gelu", "GELU", "Activation", "Tensor", "Tensor", "#FB7185"],
  ["silu", "SiLU", "Activation", "Tensor", "Tensor", "#FB7185"],
  ["softmax", "Softmax", "Activation", "Logits", "Probabilities", "#FB7185"],
  ["sigmoid", "Sigmoid", "Activation", "Logits", "Probability", "#FB7185"],
  ["tanh", "Tanh", "Activation", "Tensor", "Tensor", "#FB7185"],
  ["maxpool", "Max Pool", "Pooling", "Feature map", "Pooled map", "#34D399"],
  ["avgpool", "Average Pool", "Pooling", "Feature map", "Pooled map", "#34D399"],
  ["globalpool", "Global Pool", "Pooling", "Feature map", "Vector", "#34D399"],
  ["adaptivepool", "Adaptive Pool", "Pooling", "Feature map", "Fixed map", "#34D399"],
  ["dropout", "Dropout", "Regularization", "Tensor", "Tensor", "#FBBF24"],
  ["stochastic-depth", "Stochastic Depth", "Regularization", "Block", "Block", "#FBBF24"],
  ["weight-decay", "Weight Decay", "Regularization", "Parameters", "Parameters", "#FBBF24"],
  ["layernorm", "Layer Norm", "Transform", "Tensor", "Normalized tensor", "#A78BFA"],
  ["batchnorm", "Batch Norm", "Transform", "Feature map", "Normalized map", "#A78BFA"],
  ["instancenorm", "Instance Norm", "Transform", "Feature map", "Normalized map", "#A78BFA"],
  ["groupnorm", "Group Norm", "Transform", "Feature map", "Normalized map", "#A78BFA"],
  ["add", "Add Merge", "Routing", "Two tensors", "Merged tensor", "#818CF8"],
  ["concat", "Concatenate", "Routing", "Tensor list", "Merged tensor", "#818CF8"],
  ["skip", "Skip Route", "Routing", "Tensor", "Routed tensor", "#818CF8"],
  ["mixture", "Mixture of Experts", "Routing", "Tensor", "Routed tensor", "#818CF8"],
  ["topk", "Top-K Router", "Routing", "Scores", "Selected experts", "#818CF8"],
  ["classifier", "Classifier Head", "Output", "Feature vector", "Class logits", "#34D399"],
  ["regressor", "Regressor Head", "Output", "Feature vector", "Continuous value", "#34D399"],
  ["decoder", "Sequence Decoder", "Output", "Context sequence", "Token logits", "#34D399"],
  ["segmentation", "Segmentation Head", "Output", "Feature map", "Mask logits", "#34D399"],
  ["projection-head", "Projection Head", "Output", "Feature vector", "Embedding", "#34D399"],
  ["ctc", "CTC Head", "Output", "Sequence", "Aligned logits", "#34D399"],
  ["flatten", "Flatten", "Utility", "Tensor", "Vector", "#94A3B8"],
  ["clamp", "Clamp", "Utility", "Tensor", "Bounded tensor", "#94A3B8"],
  ["mask", "Mask", "Utility", "Tensor + mask", "Masked tensor", "#94A3B8"],
  ["positional", "Positional Encoding", "Utility", "Sequence", "Position-aware sequence", "#94A3B8"],
  ["augment", "Augmentation", "Utility", "Input tensor", "Augmented tensor", "#94A3B8"],
  ["normalize", "Feature Normalize", "Utility", "Feature vector", "Normalized vector", "#94A3B8"],
  ["cache", "Feature Cache", "Utility", "Feature vector", "Cached feature", "#94A3B8"],
  ["sampler", "Sampler", "Utility", "Dataset", "Batch", "#94A3B8"],
  ["loss-ce", "Cross Entropy Loss", "Utility", "Logits + labels", "Scalar loss", "#94A3B8"],
  ["loss-contrastive", "Contrastive Loss", "Utility", "Embeddings", "Scalar loss", "#94A3B8"],
  ["loss-mse", "MSE Loss", "Utility", "Predictions + targets", "Scalar loss", "#94A3B8"],
  ["metric", "Metric Evaluator", "Utility", "Predictions + labels", "Metric value", "#94A3B8"],
  ["temperature", "Temperature Scale", "Utility", "Logits", "Scaled logits", "#94A3B8"],
  ["quantize", "Quantizer", "Utility", "Weights", "Quantized weights", "#94A3B8"],
  ["ema", "EMA Weights", "Utility", "Parameters", "Smoothed parameters", "#94A3B8"],
  ["stopgrad", "Stop Gradient", "Utility", "Tensor", "Detached tensor", "#94A3B8"],
  ["identity", "Identity", "Utility", "Tensor", "Tensor", "#94A3B8"],
];

export const PRIMITIVES: Primitive[] = definitions.slice(0, 64).map(([id, name, family, input, output, color]) => ({ id, name, family, input, output, color, description: `${name} transforms ${input.toLowerCase()} into ${output.toLowerCase()}.` }));

const byId = Object.fromEntries(PRIMITIVES.map((primitive) => [primitive.id, primitive]));

export function resolveInstruction(instruction: string): GraphNode[] {
  const text = instruction.toLowerCase();
  const ids: string[] = [];
  const add = (id: string) => { if (!ids.includes(id)) ids.push(id); };
  if (text.includes("text") || text.includes("language") || text.includes("token")) { add("input-text"); add("tokenize"); add("embed"); }
  else if (text.includes("audio") || text.includes("sound") || text.includes("speech")) { add("input-audio"); add("conv1d"); }
  else if (text.includes("image") || text.includes("vision") || text.includes("photo")) { add("input-image"); add("conv2d"); add("residual"); }
  else { add("input-tabular"); add("project"); }
  if (text.includes("attention") || text.includes("transformer") || text.includes("context")) { add("layernorm"); add("multihead"); add("skip"); }
  else if (text.includes("sequence") || text.includes("temporal") || text.includes("forecast")) { add("lstm"); add("layernorm"); }
  else { add("relu"); add("dropout"); }
  if (text.includes("segment") || text.includes("mask")) add("segmentation");
  else if (text.includes("generate") || text.includes("translate") || text.includes("caption")) { add("decoder"); add("softmax"); }
  else if (text.includes("regress") || text.includes("predict") || text.includes("forecast")) add("regressor");
  else { add("classifier"); add("softmax"); }
  return ids.map((id, index) => ({ ...byId[id], nodeId: `${id}-${index}`, params: index === 0 ? "source" : index === ids.length - 1 ? "head" : "default" }));
}

export function validateGraph(nodes: GraphNode[]) {
  const issues: string[] = [];
  nodes.forEach((node, index) => {
    const previous = nodes[index - 1];
    if (previous && previous.output !== node.input && previous.family === "Input" && node.family === "Output") {
      issues.push(`${node.name} expects ${node.input.toLowerCase()}, receives ${previous.output.toLowerCase()}.`);
    }
  });
  return { valid: issues.length === 0, issues };
}

export function createManifest(instruction: string, nodes: GraphNode[], validated = false, runtime?: CompositionManifest["runtime"]): CompositionManifest {
  const seed = `${instruction}|${nodes.map((node) => node.id).join(",")}`;
  const id = `composition-${stableHash(seed)}`;
  return { manifestVersion: "nag.composition.v2", id, instruction, resolver: { version: "local-1.0", mode: "deterministic" }, structure: { kind: "sequence", nodeCount: nodes.length }, lineage: { source: "instruction", primitiveIds: nodes.map((node) => node.id) }, status: validated ? "validated" : "resolved", runtime };
}

export function exportSnapshot(instruction: string, nodes: GraphNode[], validated = false, runtime?: CompositionManifest["runtime"]): CompositionSnapshot {
  return { manifest: createManifest(instruction, nodes, validated, runtime), nodes, exportedAt: new Date().toISOString() };
}

function stableHash(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function compressComposition(nodes: GraphNode[], name: string) {
  return { id: `hof-${Date.now()}`, name, primitiveIds: nodes.map((node) => node.id), nodeCount: nodes.length, compressedTo: `${Math.max(1, Math.ceil(nodes.length / 2))} macro nodes`, uses: 0, manifestVersion: "nag.composition.v2", lineage: "instruction → primitives → higher-order function", createdAt: new Date().toISOString() };
}

export type ArchitectureRuntime = "functional" | "blueprint";
export type ArchitectureFamily = {
  id: string;
  name: string;
  group: string;
  description: string;
  runtime: ArchitectureRuntime;
  defaultBlocks: string[];
  editable: string[];
};

const family = (id: string, name: string, group: string, description: string, defaultBlocks: string[], editable: string[] = ["width", "depth", "activation"]) => ({ id, name, group, description, runtime: "blueprint" as ArchitectureRuntime, defaultBlocks, editable });

const allArchitectureFamilies: ArchitectureFamily[] = [
  { id: "mlp", name: "Multilayer Perceptron", group: "Feedforward", description: "Dense feature transformations with nonlinear activations.", runtime: "functional", defaultBlocks: ["input-tabular", "project", "relu", "classifier"], editable: ["width", "depth", "activation"] },
  { id: "conv1d-net", name: "1D Convolutional Network", group: "Convolution", description: "Local temporal pattern extraction for sequences and signals.", runtime: "functional", defaultBlocks: ["input-audio", "conv1d", "maxpool", "classifier"], editable: ["channels", "kernel", "stride"] },
  { id: "rnn-net", name: "Gated Recurrent Network", group: "Recurrent", description: "Hidden-state sequence modeling for temporal context.", runtime: "functional", defaultBlocks: ["input-audio", "gated-rnn", "layernorm", "classifier"], editable: ["hiddenSize", "layers", "bidirectional"] },
  { id: "attention-net", name: "Self-Attention Network", group: "Attention", description: "Context-weighted token or feature interactions.", runtime: "functional", defaultBlocks: ["input-text", "embed", "multihead", "classifier"], editable: ["heads", "context", "dropout"] },
  family("perceptron", "Perceptron", "Feedforward", "Single-layer linear decision unit.", ["input-tabular", "project", "classifier"]),
  family("deep-feedforward", "Deep Feedforward Network", "Feedforward", "Stacked dense transformations for general approximation.", ["input-tabular", "project", "relu", "project", "classifier"]),
  family("rbf", "Radial Basis Function Network", "Feedforward", "Distance-sensitive radial basis feature mapping.", ["input-tabular", "project", "classifier"], ["centers", "spread", "regularization"]),
  family("highway", "Highway Network", "Feedforward", "Gated transform and carry paths over dense blocks.", ["input-tabular", "project", "skip", "classifier"], ["width", "carryBias", "depth"]),
  family("resnet", "Residual Network", "Convolution", "Residual skip blocks that stabilize deep feature learning.", ["input-image", "conv2d", "residual", "globalpool", "classifier"], ["blocks", "channels", "bottleneck"]),
  family("densenet", "DenseNet", "Convolution", "Dense feature reuse through concatenated block connections.", ["input-image", "conv2d", "concat", "globalpool", "classifier"], ["growthRate", "blocks", "compression"]),
  family("cnn2d", "2D CNN", "Convolution", "Spatial convolutional feature extractor.", ["input-image", "conv2d", "maxpool", "classifier"], ["channels", "kernel", "pool"]),
  family("cnn3d", "3D CNN", "Convolution", "Volumetric or spatiotemporal convolutional model.", ["input-image", "conv2d", "conv2d", "globalpool", "classifier"], ["channels", "kernel", "frames"]),
  family("unet", "U-Net", "Convolution", "Encoder-decoder with skip connections for dense prediction.", ["input-image", "conv2d", "skip", "decoder", "segmentation"], ["levels", "baseChannels", "skipMode"]),
  family("efficientnet", "EfficientNet", "Convolution", "Compound-scaled mobile-friendly convolutional network.", ["input-image", "bottleneck", "depthwise", "globalpool", "classifier"], ["widthScale", "depthScale", "resolution"]),
  family("mobilenet", "MobileNet", "Convolution", "Depthwise-separable convolution for efficient inference.", ["input-image", "depthwise", "project", "globalpool", "classifier"], ["widthMultiplier", "resolution", "stride"]),
  family("convnext", "ConvNeXt", "Convolution", "Modernized convolutional blocks with large receptive fields.", ["input-image", "conv2d", "layernorm", "residual", "classifier"], ["kernel", "stages", "channels"]),
  family("capsule", "Capsule Network", "Convolution", "Vector capsules that preserve pose relationships.", ["input-image", "conv2d", "project", "classifier"], ["capsuleDim", "routingIters", "capsules"]),
  family("vanilla-rnn", "Vanilla RNN", "Recurrent", "Simple recurrent hidden-state sequence model.", ["input-audio", "gated-rnn", "classifier"], ["hiddenSize", "layers", "activation"]),
  family("elman", "Elman Network", "Recurrent", "Context-layer recurrent architecture.", ["input-audio", "gated-rnn", "skip", "classifier"], ["contextSize", "hiddenSize", "layers"]),
  family("jordan", "Jordan Network", "Recurrent", "Output-feedback recurrent architecture.", ["input-audio", "gated-rnn", "classifier"], ["feedback", "hiddenSize", "delay"]),
  family("bilstm", "Bidirectional LSTM", "Recurrent", "Forward and backward sequence context encoder.", ["input-audio", "bidirectional", "lstm", "classifier"], ["hiddenSize", "merge", "layers"]),
  family("echo-state", "Echo State Network", "Reservoir", "Fixed recurrent reservoir with trained readout.", ["input-audio", "gated-rnn", "projection-head"], ["reservoirSize", "spectralRadius", "leak"]),
  family("neural-ode", "Neural ODE", "Continuous", "Continuous-depth dynamics defined by a learned vector field.", ["input-tabular", "project", "project", "classifier"], ["solver", "tolerance", "steps"]),
  family("transformer", "Transformer", "Attention", "Attention-plus-feedforward sequence architecture.", ["input-text", "embed", "multihead", "layernorm", "decoder"], ["heads", "layers", "context"]),
  family("encoder-transformer", "Encoder-only Transformer", "Attention", "Bidirectional contextual encoder for understanding tasks.", ["input-text", "embed", "multihead", "layernorm", "classifier"], ["heads", "layers", "context"]),
  family("decoder-transformer", "Decoder-only Transformer", "Attention", "Autoregressive causal sequence generator.", ["input-text", "embed", "multihead", "mask", "decoder"], ["heads", "layers", "context"]),
  family("encoder-decoder", "Encoder–Decoder Transformer", "Attention", "Conditional sequence-to-sequence transformer.", ["input-text", "embed", "cross-attention", "decoder"], ["heads", "layers", "context"]),
  family("vit", "Vision Transformer", "Attention", "Patch-token image encoder with global attention.", ["input-image", "reshape", "embed", "multihead", "classifier"], ["patchSize", "heads", "layers"]),
  family("swin", "Swin Transformer", "Attention", "Hierarchical shifted-window vision transformer.", ["input-image", "reshape", "local-attention", "globalpool", "classifier"], ["windowSize", "stages", "heads"]),
  family("perceiver", "Perceiver", "Attention", "Latent bottleneck for high-dimensional inputs.", ["input-image", "cross-attention", "self-attention", "classifier"], ["latentCount", "latentDim", "heads"]),
  family("gcn", "Graph Convolutional Network", "Graph", "Neighborhood aggregation over graph-connected features.", ["input-tabular", "project", "add", "classifier"], ["layers", "hiddenSize", "normalization"]),
  family("gat", "Graph Attention Network", "Graph", "Attention-weighted message passing across graph edges.", ["input-tabular", "multihead", "add", "classifier"], ["heads", "layers", "edgeDropout"]),
  family("graphsage", "GraphSAGE", "Graph", "Sample-and-aggregate inductive graph encoder.", ["input-tabular", "project", "concat", "classifier"], ["neighborSample", "aggregator", "layers"]),
  family("mpnn", "Message Passing Neural Network", "Graph", "General message, aggregate, and update graph processor.", ["input-tabular", "project", "add", "project", "classifier"], ["steps", "messageDim", "aggregator"]),
  family("hopfield", "Modern Hopfield Network", "Memory", "Continuous associative memory with attention retrieval.", ["input-tabular", "embed", "self-attention", "projection-head"], ["memorySize", "temperature", "updates"]),
  family("vae", "Variational Autoencoder", "Generative", "Probabilistic encoder-decoder latent model.", ["input-image", "project", "project", "decoder"], ["latentDim", "beta", "decoderDepth"]),
  family("gan", "Generative Adversarial Network", "Generative", "Generator and discriminator adversarial training pair.", ["input-tabular", "project", "project", "classifier"], ["latentDim", "criticSteps", "learningRate"]),
  family("diffusion", "Diffusion Model", "Generative", "Iterative denoising process for generative modeling.", ["input-image", "augment", "residual", "decoder"], ["timesteps", "schedule", "conditioning"]),
  family("moe", "Mixture of Experts", "Routing", "Sparse expert routing with learned gates.", ["input-tabular", "mixture", "topk", "classifier"], ["experts", "topK", "capacity"]),
  family("siamese", "Siamese Network", "Comparison", "Weight-shared twin encoder for pair similarity.", ["input-image", "project", "projection-head", "loss-ce"], ["embeddingDim", "distance", "margin"]),
  family("nerf", "Neural Radiance Field", "Implicit", "Coordinate-conditioned scene radiance field.", ["input-tabular", "project", "silu", "regressor"], ["frequencyBands", "depth", "viewDependence"]),
  family("dqn", "Deep Q-Network", "Reinforcement", "Value estimator for discrete action selection.", ["input-tabular", "project", "relu", "regressor"], ["actions", "targetSync", "discount"]),
  family("hypernetwork", "Hypernetwork", "Meta", "Network that generates parameters for another network.", ["input-tabular", "project", "project", "project"], ["generatedLayers", "conditioning", "hyperWidth"]),
];

const LIVE_FAMILY_IDS = new Set(["mlp", "conv1d-net", "rnn-net", "attention-net", "deep-feedforward", "highway", "resnet", "densenet", "cnn2d", "cnn3d", "unet", "efficientnet", "mobilenet", "convnext", "capsule", "vanilla-rnn", "bilstm", "transformer", "encoder-transformer", "decoder-transformer", "encoder-decoder", "vit", "swin", "perceiver", "gcn", "gat", "graphsage", "mpnn", "vae", "gan", "diffusion", "moe", "siamese", "nerf", "dqn", "hypernetwork"]);
export const ARCHITECTURE_FAMILIES: ArchitectureFamily[] = allArchitectureFamilies.filter((item) => LIVE_FAMILY_IDS.has(item.id)).map((item) => ({ ...item, runtime: "functional" as ArchitectureRuntime }));

export type BlueprintBlock = { id: string; label: string; primitiveId?: string; familyId?: string; params: Record<string, string | number>; children?: BlueprintBlock[] };
export type ArchitectureBlueprint = { id: string; name: string; familyId: string; version: number; blocks: BlueprintBlock[]; depth: number; lineage: string[] };

export function createBlueprint(familyId: string, name?: string): ArchitectureBlueprint {
  const definition = ARCHITECTURE_FAMILIES.find((item) => item.id === familyId) ?? ARCHITECTURE_FAMILIES[0];
  const blocks = definition.defaultBlocks.map((primitiveId, index) => ({ id: `${familyId}-block-${index}`, label: PRIMITIVES.find((item) => item.id === primitiveId)?.name ?? primitiveId, primitiveId, params: { width: index === 0 ? 4 : 8, activation: index === definition.defaultBlocks.length - 1 ? "linear" : "relu" } }));
  return { id: `blueprint-${familyId}`, name: name ?? definition.name, familyId: definition.id, version: 1, blocks, depth: 1, lineage: [definition.id] };
}

export function editBlueprint(blueprint: ArchitectureBlueprint, blockId: string, params: Record<string, string | number>): ArchitectureBlueprint { return { ...blueprint, version: blueprint.version + 1, blocks: blueprint.blocks.map((block) => block.id === blockId ? { ...block, params: { ...block.params, ...params } } : block) }; }
export function blueprintExecutionOptions(blueprint: ArchitectureBlueprint): Record<string, string | number> { return blueprint.blocks.reduce<Record<string, string | number>>((options, block) => { Object.entries(block.params).forEach(([key, value]) => { options[key] = value; }); return options; }, {}); }
export function nestBlueprint(parent: ArchitectureBlueprint, child: ArchitectureBlueprint): ArchitectureBlueprint { return { ...parent, version: parent.version + 1, depth: parent.depth + child.depth, lineage: [...parent.lineage, ...child.lineage], blocks: [...parent.blocks, { id: `${parent.id}-nested-${child.id}`, label: child.name, familyId: child.familyId, params: { mode: "fractal", version: child.version }, children: child.blocks }] }; }
