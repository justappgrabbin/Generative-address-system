import { ARCHITECTURE_FAMILIES } from "./architecture";
import { forwardArchitecture, type ArchitecturePrediction, type Tensor } from "./neural-runtime";

export type PortKind = "input" | "output" | "state";
export type StandardPort = { id: string; kind: PortKind; width: 4; tensorFamily: "vector" };
export type ModulationNode = { id: string; architectureId: string; inputPort: StandardPort; outputPort: StandardPort; statePort: StandardPort; nestedComposition?: ModulationComposition };
export type InfluenceEdge = { id: string; from: string; to: string; fromPort: string; toPort: string; weight: number; inhibition: boolean; sharedStateKey?: string };
export type ModulationComposition = { id: string; name: string; nodes: ModulationNode[]; edges: InfluenceEdge[]; state: Record<string, Tensor>; depth: number; lineage: string[] };
export type CompositionRun = { compositionId: string; outputs: Record<string, Tensor>; predictions: Record<string, ArchitecturePrediction>; state: Record<string, Tensor>; terminal: Tensor; steps: number };

const clampWeight = (value: number) => Math.max(-1, Math.min(1, value));
const port = (id: string, kind: PortKind): StandardPort => ({ id, kind, width: 4, tensorFamily: "vector" });

export function createModulationNode(architectureId: string, id = `${architectureId}-${Date.now()}`): ModulationNode {
  if (!ARCHITECTURE_FAMILIES.some((family) => family.id === architectureId)) throw new Error(`Unknown architecture: ${architectureId}`);
  return { id, architectureId, inputPort: port(`${id}:in`, "input"), outputPort: port(`${id}:out`, "output"), statePort: port(`${id}:state`, "state") };
}

export function createComposition(name: string, architectureIds: string[]): ModulationComposition {
  const nodes = architectureIds.map((architectureId, index) => createModulationNode(architectureId, `node-${index + 1}-${architectureId}`));
  const edges = nodes.slice(1).map((node, index) => connectInfluence(nodes[index], node, { weight: 1, inhibition: false }));
  return { id: `composition-${stableHash(`${name}|${architectureIds.join(",")}`)}`, name, nodes, edges, state: {}, depth: 1, lineage: architectureIds.slice() };
}

export function connectInfluence(from: ModulationNode, to: ModulationNode, options: { weight?: number; inhibition?: boolean; sharedStateKey?: string } = {}): InfluenceEdge { return { id: `edge-${from.id}-${to.id}`, from: from.id, to: to.id, fromPort: from.outputPort.id, toPort: to.inputPort.id, weight: clampWeight(options.weight ?? 1), inhibition: options.inhibition ?? false, sharedStateKey: options.sharedStateKey }; }

export function setInfluence(composition: ModulationComposition, edgeId: string, weight: number, inhibition = false): ModulationComposition { return { ...composition, edges: composition.edges.map((edge) => edge.id === edgeId ? { ...edge, weight: clampWeight(weight), inhibition } : edge) }; }

export function adaptToStandardPort(tensor: Tensor): Tensor { if (tensor.length === 4) return tensor.slice(); if (tensor.length === 0) return [0, 0, 0, 0]; const result = [0, 0, 0, 0]; tensor.forEach((value, index) => { result[index % 4] += value / Math.ceil(tensor.length / 4); }); return result; }

function influence(base: Tensor, source: Tensor, edge: InfluenceEdge): Tensor { const sign = edge.inhibition ? -1 : 1; const scaled = adaptToStandardPort(source).map((value) => value * edge.weight * sign); return base.map((value, index) => value + scaled[index]); }

export function runComposition(composition: ModulationComposition, input: Tensor): CompositionRun {
  const outputs: Record<string, Tensor> = {}; const predictions: Record<string, ArchitecturePrediction> = {}; const state = { ...composition.state }; const order = composition.nodes.slice();
  order.forEach((node) => {
    let nodeInput = adaptToStandardPort(input);
    composition.edges.filter((edge) => edge.to === node.id).forEach((edge) => { if (outputs[edge.from]) nodeInput = influence(nodeInput, outputs[edge.from], edge); if (edge.sharedStateKey && state[edge.sharedStateKey]) nodeInput = influence(nodeInput, state[edge.sharedStateKey], { ...edge, weight: edge.weight * 0.5 }); });
    const childRun = node.nestedComposition ? runComposition(node.nestedComposition, nodeInput) : null;
    const prediction = childRun ? (childRun.predictions[node.nestedComposition!.nodes[node.nestedComposition!.nodes.length - 1].id] ?? forwardArchitecture("mlp", nodeInput)) : forwardArchitecture(node.architectureId, nodeInput);
    const output = childRun ? childRun.terminal : adaptToStandardPort(prediction.probabilities);
    outputs[node.id] = output; predictions[node.id] = prediction; state[node.statePort.id] = output.map((value, index) => ((state[node.statePort.id]?.[index] ?? 0) * 0.7) + value * 0.3);
  });
  const terminal = order.length ? outputs[order[order.length - 1].id] : adaptToStandardPort(input);
  return { compositionId: composition.id, outputs, predictions, state, terminal, steps: order.length };
}

export function nestComposition(parent: ModulationComposition, child: ModulationComposition, edgeWeight = 0.5): ModulationComposition {
  const nestedNode: ModulationNode = { id: `${parent.id}:nested:${child.id}`, architectureId: child.id, inputPort: port(`${parent.id}:nested:${child.id}:in`, "input"), outputPort: port(`${parent.id}:nested:${child.id}:out`, "output"), statePort: port(`${parent.id}:nested:${child.id}:state`, "state"), nestedComposition: child };
  const childEdges = child.edges.map((edge) => ({ ...edge, id: `${nestedNode.id}:${edge.id}`, from: edge.from === child.nodes[0]?.id ? nestedNode.id : edge.from, to: edge.to === child.nodes[0]?.id ? nestedNode.id : edge.to }));
  const edge = parent.nodes.length ? connectInfluence(parent.nodes[parent.nodes.length - 1], nestedNode, { weight: edgeWeight, sharedStateKey: `${parent.id}:shared` }) : undefined;
  return { ...parent, id: `composition-${stableHash(`${parent.id}|${child.id}|${parent.depth}`)}`, depth: parent.depth + child.depth, lineage: [...parent.lineage, ...child.lineage], nodes: [...parent.nodes, nestedNode], edges: [...parent.edges, ...(edge ? [edge] : []), ...childEdges], state: { ...parent.state, ...child.state } };
}

export function serializeComposition(composition: ModulationComposition): string { return JSON.stringify({ schema: "nag.modulation.v1", ...composition }); }
function stableHash(value: string) { let hash = 2166136261; for (let index = 0; index < value.length; index += 1) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619); return (hash >>> 0).toString(16).padStart(8, "0"); }


export type GenerationOptions = { seed: number; nodeCount: number; allowInhibition?: boolean; architectureIds?: string[] };
export type GraphEdit = { kind: "add-node" | "remove-node" | "connect" | "disconnect" | "set-weight" | "set-inhibition"; nodeId?: string; architectureId?: string; from?: string; to?: string; edgeId?: string; weight?: number; inhibition?: boolean };

function seeded(seed: number) { let value = Math.abs(Math.floor(seed)) || 1; return () => { value = (value * 1664525 + 1013904223) >>> 0; return value / 4294967296; }; }

export function generateEmergentComposition(options: GenerationOptions): ModulationComposition {
  const random = seeded(options.seed); const ids = options.architectureIds?.length ? options.architectureIds : ARCHITECTURE_FAMILIES.map((family) => family.id); const count = Math.max(2, Math.min(32, Math.floor(options.nodeCount)));
  const nodes = Array.from({ length: count }, (_, index) => createModulationNode(ids[Math.floor(random() * ids.length)] ?? "mlp", `generated-${options.seed}-${index + 1}`));
  const edges: InfluenceEdge[] = [];
  nodes.forEach((node, index) => { if (index > 0) edges.push(connectInfluence(nodes[Math.floor(random() * index)], node, { weight: 0.25 + random() * 0.75, inhibition: Boolean(options.allowInhibition && random() > 0.82), sharedStateKey: `emergent-state-${Math.floor(random() * 3)}` })); if (index > 1 && random() > 0.45) edges.push(connectInfluence(nodes[Math.floor(random() * index)], node, { weight: -0.5 + random(), inhibition: Boolean(options.allowInhibition && random() > 0.88) })); });
  return { id: `composition-${stableHash(`generated|${options.seed}|${nodes.map((node) => node.architectureId).join(",")}`)}`, name: `Emergent field ${options.seed}`, nodes, edges, state: {}, depth: 1, lineage: ["generated", ...nodes.map((node) => node.architectureId)] };
}

export function applyGraphEdit(composition: ModulationComposition, edit: GraphEdit): ModulationComposition {
  if (edit.kind === "add-node" && edit.architectureId) { const node = createModulationNode(edit.architectureId, edit.nodeId ?? `node-${Date.now()}`); return { ...composition, nodes: [...composition.nodes, node] }; }
  if (edit.kind === "remove-node" && edit.nodeId) return { ...composition, nodes: composition.nodes.filter((node) => node.id !== edit.nodeId), edges: composition.edges.filter((edge) => edge.from !== edit.nodeId && edge.to !== edit.nodeId) };
  if (edit.kind === "connect" && edit.from && edit.to) { const from = composition.nodes.find((node) => node.id === edit.from); const to = composition.nodes.find((node) => node.id === edit.to); if (!from || !to || from.id === to.id) return composition; const base = connectInfluence(from, to, { weight: edit.weight, inhibition: edit.inhibition }); const duplicateCount = composition.edges.filter((item) => item.from === from.id && item.to === to.id).length; const edge = { ...base, id: duplicateCount ? `${base.id}-${duplicateCount + 1}` : base.id }; return { ...composition, edges: [...composition.edges, edge] }; }
  if (edit.kind === "disconnect" && edit.edgeId) return { ...composition, edges: composition.edges.filter((edge) => edge.id !== edit.edgeId) };
  if (edit.kind === "set-weight" && edit.edgeId !== undefined) return setInfluence(composition, edit.edgeId, edit.weight ?? 0, Boolean(edit.inhibition));
  if (edit.kind === "set-inhibition" && edit.edgeId !== undefined) return setInfluence(composition, edit.edgeId, composition.edges.find((edge) => edge.id === edit.edgeId)?.weight ?? 0, Boolean(edit.inhibition));
  return composition;
}

export function validateComposition(composition: ModulationComposition) { const nodeIds = new Set(composition.nodes.map((node) => node.id)); const issues: string[] = []; composition.edges.forEach((edge) => { if (!nodeIds.has(edge.from) || !nodeIds.has(edge.to)) issues.push(`Dangling edge ${edge.id}`); if (edge.from === edge.to) issues.push(`Self-edge ${edge.id}`); }); return { valid: issues.length === 0, issues }; }
export function deserializeComposition(serialized: string): ModulationComposition { const parsed = JSON.parse(serialized) as { schema?: string } & ModulationComposition; if (parsed.schema !== "nag.modulation.v1") throw new Error("Unsupported composition schema"); const composition = { id: parsed.id, name: parsed.name, nodes: parsed.nodes, edges: parsed.edges, state: parsed.state ?? {}, depth: parsed.depth, lineage: parsed.lineage }; const validation = validateComposition(composition); if (!validation.valid) throw new Error(validation.issues.join("; ")); return composition; }


export function mutateComposition(composition: ModulationComposition, seed: number): ModulationComposition {
  const random = seeded(seed); let next = composition; const operation = Math.floor(random() * 3);
  if (operation === 0) { const family = ARCHITECTURE_FAMILIES[Math.floor(random() * ARCHITECTURE_FAMILIES.length)]; const node = createModulationNode(family.id, `mutant-${seed}-${composition.nodes.length + 1}`); next = { ...composition, nodes: [...composition.nodes, node], lineage: [...composition.lineage, family.id] }; const target = composition.nodes[Math.floor(random() * composition.nodes.length)]; if (target) next = applyGraphEdit(next, { kind: "connect", from: target.id, to: node.id, weight: 0.2 + random() * 0.8, inhibition: random() > 0.85 }); }
  else if (operation === 1 && composition.edges.length) { const edge = composition.edges[Math.floor(random() * composition.edges.length)]; next = applyGraphEdit(composition, { kind: "set-weight", edgeId: edge.id, weight: -1 + random() * 2, inhibition: random() > 0.78 }); }
  else if (composition.nodes.length > 2) { const from = composition.nodes[Math.floor(random() * composition.nodes.length)]; const to = composition.nodes[Math.floor(random() * composition.nodes.length)]; if (from && to && from.id !== to.id) next = applyGraphEdit(composition, { kind: "connect", from: from.id, to: to.id, weight: 0.15 + random() * 0.85, inhibition: random() > 0.82 }); }
  return { ...next, id: `composition-${stableHash(`${composition.id}|mutation|${seed}`)}`, name: `${composition.name} · mutation ${seed}`, lineage: [...next.lineage, `mutation:${seed}`] };
}
