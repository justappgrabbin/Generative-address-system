import { forwardArchitecture, trainArchitecture, type ArchitecturePrediction, type Tensor } from "./neural-runtime";

export type DatasetRecord = { id: string; features: Tensor; label: number; metadata?: Record<string, string> };
export type DatasetSplit = { train: DatasetRecord[]; validation: DatasetRecord[]; test: DatasetRecord[]; featureCount: number; classCount: number };
export type ValidationFeedback = { accuracy: number; loss: number; samples: number; reward: number; accepted: boolean };

function finiteFeatures(values: unknown[]): Tensor { return values.map((value) => Number(value)).filter(Number.isFinite).slice(0, 64); }
function normalize(values: Tensor): Tensor { const max = Math.max(1, ...values.map((value) => Math.abs(value))); return values.map((value) => value / max); }

export function parseDatasetText(text: string, format: "csv" | "json" = "csv"): DatasetRecord[] {
  if (!text.trim()) throw new Error("Dataset is empty");
  if (format === "json") { const parsed = JSON.parse(text) as Array<Record<string, unknown>>; return parsed.map((row, index) => { const features = finiteFeatures((row.features ?? row.x ?? []) as unknown[]); const label = Number(row.label ?? row.y); if (features.length === 0 || !Number.isFinite(label)) throw new Error(`Invalid JSON row ${index + 1}`); return { id: String(row.id ?? index + 1), features: normalize(features), label: Math.max(0, Math.floor(label)), metadata: { source: "json" } }; }); }
  const lines = text.trim().split(/\r?\n/).filter(Boolean); const rows = lines[0].split(",").map((value) => value.trim().toLowerCase()); const hasHeader = rows.includes("label") || rows.includes("target"); const start = hasHeader ? 1 : 0; return lines.slice(start).map((line, offset) => { const values = line.split(",").map((value) => value.trim()); const label = Number(values[values.length - 1]); const features = finiteFeatures(values.slice(0, -1)); if (features.length === 0 || !Number.isFinite(label)) throw new Error(`Invalid CSV row ${offset + start + 1}`); return { id: String(offset + start + 1), features: normalize(features), label: Math.max(0, Math.floor(label)), metadata: { source: "csv" } }; });
}

export function splitDataset(records: DatasetRecord[], validationFraction = 0.25, testFraction = 0.1): DatasetSplit { if (records.length < 3) throw new Error("At least three records are required"); const ordered = records.slice().sort((a, b) => a.id.localeCompare(b.id)); const testCount = Math.max(1, Math.floor(ordered.length * testFraction)); const validationCount = Math.max(1, Math.floor(ordered.length * validationFraction)); const trainEnd = Math.max(1, ordered.length - validationCount - testCount); const train = ordered.slice(0, trainEnd); const validation = ordered.slice(trainEnd, ordered.length - testCount); const test = ordered.slice(ordered.length - testCount); return { train, validation, test, featureCount: Math.max(...ordered.map((record) => record.features.length)), classCount: Math.max(...ordered.map((record) => record.label)) + 1 }; }

export function evaluateDataset(modelId: string, split: DatasetSplit): ValidationFeedback { const predictions = split.validation.map((record) => ({ record, prediction: forwardArchitecture(modelId, record.features) })); const accuracy = predictions.length ? predictions.filter(({ record, prediction }) => prediction.classIndex === record.label).length / predictions.length : 0; const loss = predictions.length ? predictions.reduce((sum, { record, prediction }) => sum - Math.log(Math.max(1e-6, prediction.probabilities[record.label] ?? 1e-6)), 0) / predictions.length : 0; const reward = (accuracy * 2) - loss * 0.1; return { accuracy, loss, samples: predictions.length, reward, accepted: accuracy >= 0.5 }; }

export function trainOnDataset(modelId: string, split: DatasetSplit, reward: number) { const report = trainArchitecture(modelId, Math.max(1, Math.min(12, split.train.length)), reward, {}, split.train.map((record) => ({ input: record.features, label: record.label }))); const feedback = evaluateDataset(modelId, split); return { report, feedback }; }

export function toRuntimeSample(record: DatasetRecord) { return { input: record.features, label: record.label }; }
