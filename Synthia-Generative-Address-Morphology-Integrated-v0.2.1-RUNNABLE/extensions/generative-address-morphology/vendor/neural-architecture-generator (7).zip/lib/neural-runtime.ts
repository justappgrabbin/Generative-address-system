export type ModelKind = "mlp" | "conv1d" | "rnn" | "attention";
export type Tensor = number[];
export type Prediction = { model: ModelKind; logits: number[]; probabilities: number[]; classIndex: number; confidence: number; latencyMs: number; parameters: number };
export type TrainingReport = { model: ModelKind; beforeLoss: number; afterLoss: number; epochs: number; accuracy: number };

export const MODEL_CATALOG: Array<{ id: ModelKind; name: string; detail: string; shape: string; family: string }> = [
  { id: "mlp", name: "Dense MLP", detail: "Compact feature classifier", shape: "4 → 8 → 3", family: "FEEDFORWARD" },
  { id: "conv1d", name: "Conv 1D", detail: "Local pattern detector", shape: "8 → 4 → 3", family: "CONVOLUTION" },
  { id: "rnn", name: "Gated RNN", detail: "Temporal state encoder", shape: "4 → 6 → 3", family: "RECURRENT" },
  { id: "attention", name: "Self Attention", detail: "Context-weighted encoder", shape: "4 tokens → 3", family: "ATTENTION" },
];

export const DEMO_SAMPLES: Array<{ name: string; input: Tensor; label: number }> = [
  { name: "low energy", input: [0.1, 0.2, 0.1, 0.2], label: 0 },
  { name: "rising pattern", input: [0.1, 0.4, 0.7, 0.9], label: 1 },
  { name: "high texture", input: [0.9, 0.7, 0.8, 0.6], label: 2 },
  { name: "steady mid", input: [0.45, 0.5, 0.48, 0.52], label: 1 },
];

const relu = (x: number) => Math.max(0, x);
const softmax = (values: number[]) => { const max = Math.max(...values); const exps = values.map((v) => Math.exp(v - max)); const sum = exps.reduce((a, b) => a + b, 0); return exps.map((v) => v / sum); };
const dot = (a: number[], b: number[]) => a.reduce((sum, value, index) => sum + value * (b[index] ?? 0), 0);
const dense = (input: number[], weights: number[][], bias: number[], activation = true) => weights.map((row, index) => { const value = dot(row, input) + bias[index]; return activation ? relu(value) : value; });
const argmax = (values: number[]) => values.reduce((best, value, index) => value > values[best] ? index : best, 0);

const learnedBiases: Record<ModelKind, number[]> = { mlp: [0, 0, 0], conv1d: [0, 0, 0], rnn: [0, 0, 0], attention: [0, 0, 0] };

const weights = {
  mlp1: [[0.4, 0.2, -0.3, 0.5], [-0.2, 0.6, 0.4, -0.1], [0.3, -0.5, 0.7, 0.2], [0.5, 0.1, 0.2, 0.6], [-0.4, 0.3, 0.1, 0.4], [0.2, 0.7, -0.2, 0.2], [0.6, -0.1, 0.4, -0.4], [-0.1, 0.5, 0.5, 0.3]],
  mlp2: [[0.6, -0.2, 0.4, 0.1, -0.3, 0.5, 0.2, -0.1], [-0.1, 0.6, 0.2, -0.4, 0.5, 0.1, -0.3, 0.4], [0.2, 0.1, 0.6, 0.4, -0.2, -0.1, 0.5, 0.3]],
};
const biases = { mlp1: [0.1, 0.05, 0.1, 0, 0.1, 0, 0.05, 0.1], mlp2: [0.1, -0.05, 0.05] };

function runMLP(input: Tensor) { const hidden = dense(input, weights.mlp1, biases.mlp1); return dense(hidden, weights.mlp2, biases.mlp2, false); }
function runConv(input: Tensor) { const windows = [input.slice(0, 2), input.slice(1, 3), input.slice(2, 4)]; const features = windows.map((window) => relu(dot(window, [0.7, -0.4]) + 0.2)); return [features[0] + features[1], features[1] + features[2], features[0] + features[2]].map((value, index) => value * [0.9, 1.05, 0.8][index] - 0.15); }
function runRNN(input: Tensor) { let hidden = [0.1, -0.05, 0.08, 0.02, -0.04, 0.06]; input.forEach((value) => { hidden = hidden.map((state, index) => Math.tanh(state * 0.65 + value * (0.12 + index * 0.03) + (hidden[(index + 1) % hidden.length] ?? 0) * 0.08)); }); return [dot(hidden, [0.3, -0.2, 0.4, 0.1, 0.2, -0.1]), dot(hidden, [-0.2, 0.4, 0.1, 0.3, -0.2, 0.2]), dot(hidden, [0.1, 0.2, -0.3, 0.4, 0.1, 0.3])]; }
function runAttention(input: Tensor) { const scores = input.map((value, index) => value * 1.5 + index * 0.04); const attention = softmax(scores); const context = dot(attention, input); return [context * 0.8 + input[0] * 0.2, context * 0.7 + input[2] * 0.3, context * 0.6 + input[3] * 0.4]; }

export function forward(model: ModelKind, input: Tensor): Prediction {
  const started = Date.now();
  const baseLogits = model === "mlp" ? runMLP(input) : model === "conv1d" ? runConv(input) : model === "rnn" ? runRNN(input) : runAttention(input);
  const logits = baseLogits.map((value, index) => value + learnedBiases[model][index]);
  const probabilities = softmax(logits); const classIndex = argmax(probabilities);
  return { model, logits, probabilities, classIndex, confidence: probabilities[classIndex], latencyMs: Math.max(1, Date.now() - started), parameters: model === "mlp" ? 67 : model === "conv1d" ? 27 : model === "rnn" ? 81 : 48 };
}

function crossEntropy(model: ModelKind, samples = DEMO_SAMPLES) { return samples.reduce((sum, sample) => sum - Math.log(Math.max(1e-6, forward(model, sample.input).probabilities[sample.label])), 0) / samples.length; }

export function train(model: ModelKind, epochs = 3): TrainingReport {
  const beforeLoss = crossEntropy(model);
  const learningRate = model === "mlp" ? 0.08 : model === "conv1d" ? 0.055 : model === "rnn" ? 0.045 : 0.05;
  for (let epoch = 0; epoch < epochs; epoch += 1) {
    DEMO_SAMPLES.forEach((sample) => {
      const probabilities = forward(model, sample.input).probabilities;
      const gradient = probabilities.map((probability, index) => probability - (index === sample.label ? 1 : 0));
      learnedBiases[model] = learnedBiases[model].map((bias, index) => bias - learningRate * gradient[index]);
    });
  }
  const afterLoss = crossEntropy(model);
  const familyId = model === "conv1d" ? "conv1d-net" : model === "rnn" ? "rnn-net" : model === "attention" ? "attention-net" : "mlp";
  trainArchitecture(familyId, epochs, 1);
  const accuracy = DEMO_SAMPLES.filter((sample) => forward(model, sample.input).classIndex === sample.label).length / DEMO_SAMPLES.length;
  return { model, beforeLoss, afterLoss, epochs, accuracy };
}

export function runDemo(model: ModelKind, sample = DEMO_SAMPLES[1]) { return { prediction: forward(model, sample.input), sample }; }


export type ArchitecturePrediction = Omit<Prediction, "model"> & { model: string };

const affine3 = (input: Tensor, matrix: number[][], bias: number[] = [0, 0, 0]) => matrix.map((row, index) => dot(row, input) + bias[index]);
const familyDense = (input: Tensor, seed: number, activation = true) => affine3(input, [[0.15 + seed * 0.01, -0.08, 0.11], [-0.12, 0.17 + seed * 0.008, 0.06], [0.09, 0.04, 0.13 + seed * 0.006]], [seed * 0.01, -seed * 0.005, seed * 0.003]).map((value) => activation ? Math.tanh(value) : value);
const familyStack = (input: Tensor, seed: number) => familyDense(familyDense(input, seed, true), seed + 2, true);
const residual3 = (input: Tensor, seed: number) => familyDense(input, seed).map((value, index) => value + (input[index % input.length] ?? 0) * 0.25);
const logitsFor = (model: string, logits: number[], parameters: number): ArchitecturePrediction => { const probabilities = softmax(logits); const classIndex = argmax(probabilities); return { model, logits, probabilities, classIndex, confidence: probabilities[classIndex], latencyMs: 1, parameters }; };

function familyLogits(id: string, input: Tensor, options: Record<string, string | number> = {}): { logits: number[]; parameters: number } {
  const numeric = Object.values(options).reduce<number>((sum, value) => sum + (typeof value === "number" ? value : value.length * 0.1), 0);
  const configured = input.map((value, index) => value * (1 + Math.tanh(numeric * 0.01)) + numeric * 0.0007 * (index + 1));
  input = configured;
  switch (id) {
    case "mlp": return { logits: runMLP(input), parameters: 67 };
    case "conv1d-net": return { logits: runConv(input), parameters: 27 };
    case "rnn-net": return { logits: runRNN(input), parameters: 81 };
    case "rnn": return { logits: runRNN(input), parameters: 81 };
    case "attention-net": return { logits: runAttention(input), parameters: 48 };
    case "deep-feedforward": return { logits: familyStack(input, 2), parameters: 132 };
    case "highway": { const gate = softmax([input[0], input[1], input[2] ?? 0]); const transformed = familyDense(input, 4); return { logits: transformed.map((value, index) => value * gate[index] + (input[index] ?? 0) * (1 - gate[index])), parameters: 148 }; }
    case "resnet": return { logits: residual3(input, 5), parameters: 186 };
    case "densenet": { const first = familyDense(input, 6); return { logits: familyDense([...input, ...first].slice(0, 4), 8), parameters: 214 }; }
    case "cnn2d": return { logits: runConv(input.map((value, index) => value * (index % 2 ? 0.85 : 1.1))), parameters: 96 };
    case "cnn3d": return { logits: runConv([input[0], (input[1] + input[2]) / 2, (input[2] + input[3]) / 2, input[3]]), parameters: 144 };
    case "unet": { const encoded = familyDense(input, 10); return { logits: encoded.map((value, index) => value + (input[(index + 1) % input.length] ?? 0) * 0.18), parameters: 292 }; }
    case "efficientnet": return { logits: familyDense(input.map((value) => value * 0.92), 11), parameters: 178 };
    case "mobilenet": return { logits: familyDense(input.map((value, index) => value - (input[(index + 1) % input.length] ?? 0) * 0.12), 12), parameters: 82 };
    case "convnext": return { logits: residual3(input, 13), parameters: 238 };
    case "capsule": { const norm = Math.sqrt(input.reduce((sum, value) => sum + value * value, 0)) || 1; return { logits: familyDense(input.map((value) => value / norm), 14), parameters: 264 }; }
    case "vanilla-rnn": return { logits: runRNN(input.map((value) => value * 0.8)), parameters: 56 };
    case "bilstm": { const forward = runRNN(input); const backward = runRNN(input.slice().reverse()); return { logits: forward.map((value, index) => (value + backward[index]) * 0.5 + (forward[index] - backward[index]) * 0.18), parameters: 128 }; }
    case "transformer": return { logits: familyDense([...input].sort((a, b) => b - a), 17), parameters: 318 };
    case "encoder-transformer": return { logits: familyDense(input, 18), parameters: 302 };
    case "decoder-transformer": return { logits: familyDense(input.map((value, index) => index === 0 ? 0 : value), 19), parameters: 306 };
    case "encoder-decoder": return { logits: familyDense(input.map((value, index) => (value + (input[(index + 1) % input.length] ?? 0)) / 2), 20), parameters: 376 };
    case "vit": return { logits: runAttention([input[0], input[2], input[1], input[3]]), parameters: 344 };
    case "swin": return { logits: runAttention([input[0], input[1], input[3], input[2]]), parameters: 286 };
    case "perceiver": return { logits: familyDense(input.map((value) => value * 0.5 + 0.25), 23), parameters: 358 };
    case "gcn": return { logits: familyDense(input.map((value, index) => (value + (input[(index + 1) % input.length] ?? 0)) / 2), 24), parameters: 118 };
    case "gat": { const neighbor = input.map((value, index) => (value + input[(index + 1) % input.length] * 0.7 + input[(index + 3) % input.length] * 0.3) / 2); return { logits: runAttention(neighbor).map((value, index) => value + input[index] * 0.08), parameters: 146 }; }
    case "graphsage": return { logits: familyDense(input.map((value, index) => (value + (input[(index + 2) % input.length] ?? 0)) / 2), 26), parameters: 124 };
    case "mpnn": return { logits: familyStack(input.map((value, index) => value + (input[(index + 1) % input.length] ?? 0) * 0.1), 27), parameters: 172 };
    case "hopfield": { const memories = input.map((value, index) => Math.exp(value * (index + 1))); const total = memories.reduce((sum, value) => sum + value, 0); const recalled = input.map((value, index) => (value * 0.55) + (memories[index] / total) * 0.45); return { logits: familyDense(recalled, 25), parameters: 196 }; }
    case "echo-state": { let reservoir = [0.05, -0.02, 0.08, 0.01]; for (let step = 0; step < 5; step += 1) reservoir = reservoir.map((value, index) => Math.tanh(value * 0.82 + input[(index + step) % input.length] * 0.14 + reservoir[(index + 1) % reservoir.length] * 0.07)); return { logits: familyDense(reservoir, 16), parameters: 212 }; }
    case "neural-ode": { let state = input.slice(); const steps = 4; for (let step = 0; step < steps; step += 1) { const derivative = familyDense(state, 21, false); state = state.map((value, index) => value + derivative[index] * 0.08); } return { logits: familyDense(state, 22), parameters: 188 }; }
    case "vae": { const latent = familyDense(input, 28); return { logits: familyDense(latent.map((value) => value * 0.7), 29), parameters: 224 }; }
    case "gan": { const generated = familyDense(input, 30); const critic = familyDense(input.map((value, index) => value - generated[index] * 0.2), 31, false); return { logits: critic, parameters: 246 }; }
    case "diffusion": { let denoised = input.slice(); for (let step = 0; step < 3; step += 1) denoised = denoised.map((value, index) => value * 0.82 + (denoised[(index + 1) % denoised.length] ?? 0) * 0.09); return { logits: familyDense(denoised, 32), parameters: 388 }; }
    case "moe": { const expertA = familyDense(input, 33); const expertB = familyDense(input.slice().reverse(), 34); const gate = softmax([input[0], input[1], input[2] ?? 0]); return { logits: expertA.map((value, index) => value * gate[index] + expertB[index] * (1 - gate[index])), parameters: 272 }; }
    case "siamese": { const left = familyDense(input, 35); const right = familyDense(input.slice().reverse(), 36); return { logits: left.map((value, index) => 1 - Math.abs(value - right[index])), parameters: 154 }; }
    case "nerf": { const encoded = input.map((value, index) => Math.sin(value * (index + 1) * Math.PI)); return { logits: familyDense(encoded, 37), parameters: 196 }; }
    case "dqn": { const qValues = familyDense(input, 38, false); return { logits: qValues.map((value, index) => value + (index === argmax(qValues) ? 0.12 : 0)), parameters: 138 }; }
    case "hypernetwork": { const generatedScale = 0.7 + Math.abs(input[0] ?? 0) * 0.6; return { logits: familyDense(input.map((value) => value * generatedScale), 39), parameters: 284 }; }
    default: return { logits: runMLP(input), parameters: 67 };
  }
}

const learnedFamilyBiases: Record<string, number[]> = {};
const familyBias = (id: string) => learnedFamilyBiases[id] ?? (learnedFamilyBiases[id] = [0, 0, 0]);

export function forwardArchitecture(id: string, input: Tensor, options: Record<string, string | number> = {}): ArchitecturePrediction { const started = Date.now(); const result = familyLogits(id, input, options); const learned = familyBias(id); const prediction = logitsFor(id, result.logits.map((value, index) => value + learned[index]), result.parameters); return { ...prediction, latencyMs: Math.max(1, Date.now() - started) }; }
export function trainArchitecture(id: string, epochs = 3, reward = 1, options: Record<string, string | number> = {}, samples: Array<{ input: Tensor; label: number }> = DEMO_SAMPLES) { const before = crossEntropyArchitecture(id, options, samples); const bias = familyBias(id); for (let epoch = 0; epoch < epochs; epoch += 1) samples.forEach((sample) => { const prediction = forwardArchitecture(id, sample.input, options); const gradient = prediction.probabilities.map((probability, index) => probability - (index === sample.label ? 1 : 0)); learnedFamilyBiases[id] = bias.map((value, index) => value - 0.04 * reward * gradient[index]); }); const after = crossEntropyArchitecture(id, options, samples); const accuracy = samples.filter((sample) => forwardArchitecture(id, sample.input, options).classIndex === sample.label).length / Math.max(1, samples.length); return { model: id, beforeLoss: before, afterLoss: after, epochs, reward, accuracy }; }
function crossEntropyArchitecture(id: string, options: Record<string, string | number> = {}, samples: Array<{ input: Tensor; label: number }> = DEMO_SAMPLES) { return samples.reduce((sum, sample) => sum - Math.log(Math.max(1e-6, forwardArchitecture(id, sample.input, options).probabilities[sample.label] ?? 1e-6)), 0) / Math.max(1, samples.length); }
export function runArchitectureDemo(id: string, sample = DEMO_SAMPLES[1], options: Record<string, string | number> = {}) { return { prediction: forwardArchitecture(id, sample.input, options), sample }; }


export function exportLearnedArchitectureState(): string { return JSON.stringify(learnedFamilyBiases); }
export function importLearnedArchitectureState(snapshot: string): void { const parsed = JSON.parse(snapshot) as Record<string, number[]>; Object.entries(parsed).forEach(([id, bias]) => { if (Array.isArray(bias) && bias.length === 3 && bias.every(Number.isFinite)) learnedFamilyBiases[id] = bias.slice(); }); }
