import type { Tensor } from "./neural-runtime";
import type { CompositionRun } from "./modulation";

/**
 * The neural layer modulates capability activation; it does not define, remove,
 * or restrict capabilities. The substrate remains an opaque universal set.
 */
export type UniversalCapability = { id: string; activation: number; metadata?: Record<string, string> };
export type CapabilitySubstrate = { capabilities: UniversalCapability[]; sharedState: Record<string, Tensor> };
export type CapabilityRoute = { channels: number[]; gain: number; bias?: number };

export function createCapabilitySubstrate(capabilities: UniversalCapability[], sharedState: Record<string, Tensor> = {}): CapabilitySubstrate { return { capabilities: capabilities.map((capability) => ({ ...capability })), sharedState: { ...sharedState } }; }

export function createSemanticRoutes(capabilityIds: string[]): Record<string, CapabilityRoute> { return Object.fromEntries(capabilityIds.map((id, index) => [id, { channels: [index % 4, (index + 1) % 4], gain: 0.18 }])); }

export function applyModulation(substrate: CapabilitySubstrate, run: CompositionRun, routes: Record<string, CapabilityRoute> = {}): CapabilitySubstrate {
  const globalSignal = run.terminal.reduce((sum, value) => sum + value, 0) / Math.max(1, run.terminal.length);
  return { capabilities: substrate.capabilities.map((capability) => { const route = routes[capability.id]; const signal = route ? route.channels.reduce((sum, channel) => sum + (run.terminal[channel] ?? 0), 0) / Math.max(1, route.channels.length) : globalSignal; const gain = route?.gain ?? 0.15; return { ...capability, activation: Math.max(0, Math.min(1, capability.activation * (0.75 + signal * 0.5) + signal * gain + (route?.bias ?? 0))) }; }), sharedState: { ...substrate.sharedState, ...run.state } };
}
