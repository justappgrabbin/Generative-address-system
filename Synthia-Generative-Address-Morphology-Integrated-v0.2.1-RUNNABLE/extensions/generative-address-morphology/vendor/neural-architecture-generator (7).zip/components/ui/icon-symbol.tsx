import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconName = keyof typeof MAPPING;
const MAPPING = {
  "house.fill": "home", "paperplane.fill": "send", "chevron.left.forwardslash.chevron.right": "code", "chevron.right": "chevron-right",
  "gear": "settings", "sparkles": "auto-awesome", "arrow.right": "arrow-forward", "checkmark": "check", "wand.and.stars": "auto-fix-high", "magnifyingglass": "search", "play.fill": "play-arrow", "square.and.arrow.up": "ios-share", "arrow.triangle.2.circlepath": "sync", "cube": "view-in-ar", "ellipsis": "more-horiz", "plus": "add", "chevron.left": "chevron-left", "hexagon": "hexagon", "internaldrive": "storage", "bolt.fill": "bolt", "point.3.connected.trianglepath.dotted": "account-tree", "account-tree": "account-tree", "layers": "layers", "code": "code", "square.grid.2x2": "apps", "books.vertical": "library-books",
} as const satisfies Record<string, ComponentProps<typeof MaterialIcons>["name"]>;

export function IconSymbol({ name, size = 24, color, style }: { name: IconName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: string }) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
