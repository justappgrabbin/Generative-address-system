/** @type {const} */
const themeColors = {
  primary: { light: '#7C3AED', dark: '#A78BFA' },
  background: { light: '#F7F7FB', dark: '#0B0D12' },
  surface: { light: '#FFFFFF', dark: '#141923' },
  foreground: { light: '#111827', dark: '#F7F7FB' },
  muted: { light: '#667085', dark: '#8F98AA' },
  border: { light: '#E4E7EC', dark: '#283143' },
  success: { light: '#059669', dark: '#34D399' },
  warning: { light: '#D97706', dark: '#FBBF24' },
  error: { light: '#E11D48', dark: '#FB7185' },
};

module.exports = { themeColors };
