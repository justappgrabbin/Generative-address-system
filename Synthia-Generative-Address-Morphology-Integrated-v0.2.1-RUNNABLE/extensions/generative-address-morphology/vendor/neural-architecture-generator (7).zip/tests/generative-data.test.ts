import { describe, expect, it } from "vitest";
import { applyGraphEdit, deserializeComposition, generateEmergentComposition, mutateComposition, runComposition, serializeComposition, validateComposition } from "../lib/modulation";
import { evaluateDataset, parseDatasetText, splitDataset, trainOnDataset } from "../lib/data-lab";
import { exportLearnedArchitectureState, importLearnedArchitectureState, forwardArchitecture } from "../lib/neural-runtime";

describe("generative architecture and data workflows", () => {
  it("generates deterministic but branch-capable compositions", () => {
    const first = generateEmergentComposition({ seed: 42, nodeCount: 6, allowInhibition: true });
    const second = generateEmergentComposition({ seed: 42, nodeCount: 6, allowInhibition: true });
    expect(first.nodes.map((node) => node.architectureId)).toEqual(second.nodes.map((node) => node.architectureId));
    expect(first.edges.length).toBeGreaterThanOrEqual(5);
    expect(validateComposition(first).valid).toBe(true);
    expect(runComposition(first, [0.1, 0.2, 0.5, 0.8]).terminal).toHaveLength(4);
  });

  it("mutates a composition into a new addressable emergent state", () => {
    const composition = generateEmergentComposition({ seed: 8, nodeCount: 4 });
    const mutated = mutateComposition(composition, 99);
    expect(mutated.id).not.toBe(composition.id);
    expect(mutated.lineage.at(-1)).toBe("mutation:99");
  });

  it("supports arbitrary edge creation and removal", () => {
    const composition = generateEmergentComposition({ seed: 8, nodeCount: 4 });
    const edited = applyGraphEdit(composition, { kind: "connect", from: composition.nodes[0].id, to: composition.nodes[3].id, weight: 0.7 });
    expect(edited.edges.length).toBeGreaterThan(composition.edges.length);
    const edge = edited.edges[edited.edges.length - 1];
    const disconnected = applyGraphEdit(edited, { kind: "disconnect", edgeId: edge.id });
    expect(disconnected.edges.some((item) => item.id === edge.id)).toBe(false);
  });

  it("round-trips nested composition state", () => {
    const composition = generateEmergentComposition({ seed: 9, nodeCount: 3 });
    const restored = deserializeComposition(serializeComposition(composition));
    expect(restored.id).toBe(composition.id);
    expect(restored.nodes).toHaveLength(composition.nodes.length);
  });

  it("parses and evaluates a real user-provided CSV dataset", () => {
    const records = parseDatasetText("f1,f2,f3,label\n0.1,0.2,0.1,0\n0.8,0.7,0.9,2\n0.4,0.5,0.4,1\n0.2,0.3,0.2,0");
    const split = splitDataset(records);
    const feedback = evaluateDataset("mlp", split);
    const trained = trainOnDataset("mlp", split, feedback.reward);
    const learned = exportLearnedArchitectureState();
    importLearnedArchitectureState(learned);
    expect(split.featureCount).toBe(3);
    expect(feedback.samples).toBeGreaterThan(0);
    expect(Number.isFinite(feedback.reward)).toBe(true);
    expect(Number.isFinite(trained.report.beforeLoss)).toBe(true);
    expect(Number.isFinite(trained.report.afterLoss)).toBe(true);
    expect(trained.report.afterLoss).not.toBe(trained.report.beforeLoss);
    expect(Number.isFinite(forwardArchitecture("mlp", records[0].features).confidence)).toBe(true);
  });
});
