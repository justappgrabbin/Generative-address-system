import { describe, expect, it } from "vitest";
import { PRIMITIVES, compressComposition, resolveInstruction, validateGraph } from "../lib/architecture";

describe("architecture primitives", () => {
  it("exposes exactly 64 interchangeable primitives", () => {
    expect(PRIMITIVES).toHaveLength(64);
    expect(new Set(PRIMITIVES.map((primitive) => primitive.id)).size).toBe(64);
  });

  it("resolves audio attention instructions into a typed sequence", () => {
    const nodes = resolveInstruction("Classify short audio clips with a compact attention model");
    expect(nodes.map((node) => node.id)).toEqual(["input-audio", "conv1d", "layernorm", "multihead", "skip", "classifier", "softmax"]);
    expect(validateGraph(nodes).valid).toBe(true);
  });

  it("compresses a successful composition into a macro signature", () => {
    const nodes = resolveInstruction("Segment satellite images with a residual vision network");
    const macro = compressComposition(nodes, "Residual Vision Stem");
    expect(macro.name).toBe("Residual Vision Stem");
    expect(macro.primitiveIds).toHaveLength(nodes.length);
    expect(macro.compressedTo).toContain("macro nodes");
  });
});
