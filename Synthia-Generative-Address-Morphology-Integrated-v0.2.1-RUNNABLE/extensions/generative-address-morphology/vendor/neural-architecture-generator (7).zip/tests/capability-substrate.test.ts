import { describe, expect, it } from "vitest";
import { applyModulation, createCapabilitySubstrate, createSemanticRoutes } from "../lib/capability-substrate";
import { createComposition, runComposition } from "../lib/modulation";

describe("universal capability substrate boundary", () => {
  it("preserves every capability while applying modulation signals", () => {
    const substrate = createCapabilitySubstrate([{ id: "vision", activation: 0.5 }, { id: "language", activation: 0.5 }, { id: "planning", activation: 0.5 }]);
    const run = runComposition(createComposition("modulation", ["mlp", "attention-net"]), [0.1, 0.4, 0.7, 0.9]);
    const routes = createSemanticRoutes(["vision", "language", "planning"]);
    routes.vision = { channels: [0], gain: 0.8 };
    routes.language = { channels: [3], gain: 0.1 };
    const modulated = applyModulation(substrate, run, routes);
    expect(modulated.capabilities.map((item) => item.id)).toEqual(["vision", "language", "planning"]);
    expect(modulated.capabilities.every((item) => item.activation >= 0 && item.activation <= 1)).toBe(true);
    expect(Object.keys(modulated.sharedState).length).toBeGreaterThan(0);
    expect(modulated.capabilities[0].activation).not.toBe(modulated.capabilities[1].activation);
  });
});
