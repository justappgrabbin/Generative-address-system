import { describe, expect, it } from "vitest";
import { createComposition, createModulationNode, connectInfluence, nestComposition, runComposition, setInfluence } from "../lib/modulation";

describe("universal modulation layer", () => {
  it("connects independently executable architectures through standardized ports", () => {
    const first = createModulationNode("resnet", "first");
    const second = createModulationNode("transformer", "second");
    const edge = connectInfluence(first, second, { weight: 0.6, sharedStateKey: "global" });
    expect(first.outputPort.width).toBe(4);
    expect(second.inputPort.tensorFamily).toBe("vector");
    expect(edge.weight).toBe(0.6);
    expect(edge.inhibition).toBe(false);
  });

  it("supports continuous weighted influence and inhibition without tensor mismatch", () => {
    const composition = createComposition("weighted", ["resnet", "gat"]);
    const weighted = setInfluence(composition, composition.edges[0].id, 0.35);
    const inhibited = setInfluence(weighted, weighted.edges[0].id, 0.35, true);
    const positive = runComposition(weighted, [0.1, 0.4, 0.7, 0.9]);
    const negative = runComposition(inhibited, [0.1, 0.4, 0.7, 0.9]);
    expect(positive.steps).toBe(2);
    expect(positive.terminal).toHaveLength(4);
    expect(positive.terminal).not.toEqual(negative.terminal);
    expect(Object.keys(positive.predictions)).toHaveLength(2);
  });

  it("makes composed configurations addressable and recursively composable", () => {
    const parent = createComposition("parent", ["mlp", "moe"]);
    const child = createComposition("child", ["attention-net", "gcn"]);
    const nested = nestComposition(parent, child, 0.4);
    const result = runComposition(nested, [0.2, 0.3, 0.5, 0.8]);
    expect(nested.id).toMatch(/^composition-/);
    expect(nested.depth).toBe(2);
    expect(nested.lineage).toEqual(["mlp", "moe", "attention-net", "gcn"]);
    expect(result.steps).toBe(3);
    expect(Object.keys(result.state).length).toBeGreaterThan(0);
  });
});
