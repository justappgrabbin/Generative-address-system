import { describe, expect, it } from "vitest";
import { MODEL_CATALOG, DEMO_SAMPLES, forward, train } from "../lib/neural-runtime";

describe("local neural runtime", () => {
  it("runs a real forward pass for all four model families", () => {
    MODEL_CATALOG.forEach((model) => {
      const prediction = forward(model.id, DEMO_SAMPLES[1].input);
      expect(prediction.model).toBe(model.id);
      expect(prediction.logits).toHaveLength(3);
      expect(prediction.probabilities.reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 5);
      expect(prediction.confidence).toBeGreaterThan(0);
      expect(prediction.parameters).toBeGreaterThan(0);
    });
  });

  it("updates model parameters through a measured training step", () => {
    const report = train("attention", 3);
    expect(report.epochs).toBe(3);
    expect(report.afterLoss).not.toBe(report.beforeLoss);
    expect(report.accuracy).toBeGreaterThanOrEqual(0);
    expect(report.accuracy).toBeLessThanOrEqual(1);
  });
});
