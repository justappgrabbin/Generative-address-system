import { describe, expect, it } from "vitest";
import { ARCHITECTURE_FAMILIES, blueprintExecutionOptions, createBlueprint, editBlueprint, nestBlueprint } from "../lib/architecture";
import { DEMO_SAMPLES, forwardArchitecture, trainArchitecture } from "../lib/neural-runtime";

describe("architecture family factory", () => {
  it("ships exactly 36 live executable major families", () => {
    expect(ARCHITECTURE_FAMILIES).toHaveLength(36);
    expect(ARCHITECTURE_FAMILIES.every((item) => item.runtime === "functional")).toBe(true);
    expect(ARCHITECTURE_FAMILIES.some((item) => item.name === "Vision Transformer")).toBe(true);
    expect(ARCHITECTURE_FAMILIES.some((item) => item.name === "Mixture of Experts")).toBe(true);
  });

  it("executes every catalog family as a real forward network", () => {
    ARCHITECTURE_FAMILIES.forEach((family) => {
      const prediction = forwardArchitecture(family.id, DEMO_SAMPLES[1].input);
      expect(prediction.model).toBe(family.id);
      expect(prediction.logits.every(Number.isFinite)).toBe(true);
      expect(prediction.probabilities.reduce((sum, value) => sum + value, 0)).toBeCloseTo(1, 5);
      expect(prediction.parameters).toBeGreaterThan(0);
    });
  });

  it("makes edited blueprint parameters alter the executed network", () => {
    const blueprint = createBlueprint("resnet");
    const edited = editBlueprint(blueprint, blueprint.blocks[1].id, { width: 96, depth: 7 });
    const before = forwardArchitecture(blueprint.familyId, DEMO_SAMPLES[1].input, blueprintExecutionOptions(blueprint));
    const after = forwardArchitecture(edited.familyId, DEMO_SAMPLES[1].input, blueprintExecutionOptions(edited));
    expect(after.logits).not.toEqual(before.logits);
  });

  it("keeps the 36 live families mathematically distinguishable on the demo sample", () => {
    const signatures = ARCHITECTURE_FAMILIES.map((family) => forwardArchitecture(family.id, DEMO_SAMPLES[1].input).logits.map((value) => value.toFixed(8)).join(","));
    expect(new Set(signatures).size).toBe(36);
  });

  it("updates persistent learned parameters for every live family", () => {
    ARCHITECTURE_FAMILIES.forEach((family) => {
      const report = trainArchitecture(family.id, 1, 1);
      expect(report.afterLoss).not.toBe(report.beforeLoss);
    });
  });

  it("edits blocks immutably and nests reusable blueprints fractally", () => {
    const parent = createBlueprint("resnet");
    const edited = editBlueprint(parent, parent.blocks[1].id, { width: 32, blocks: 4 });
    const nested = nestBlueprint(edited, createBlueprint("attention-net", "Attention Cell"));
    expect(edited.version).toBe(parent.version + 1);
    expect(edited.blocks[1].params.width).toBe(32);
    expect(nested.depth).toBeGreaterThan(edited.depth);
    expect(nested.lineage).toContain("attention-net");
    expect(nested.blocks.some((block) => block.children?.length)).toBe(true);
  });
});
