import { useEffect, useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { resolveInstruction } from "@/lib/architecture";
import { useColors } from "@/hooks/use-colors";
import { exportLearnedArchitectureState, importLearnedArchitectureState, MODEL_CATALOG, runDemo, train, type ModelKind, type Prediction, type TrainingReport } from "@/lib/neural-runtime";

const LEARNED_STATE_KEY = "nag.learned-architecture-state.v1";

const examples = [
  "Classify short audio clips with a compact attention model",
  "Segment satellite images with a residual vision network",
  "Forecast demand from a temporal feature sequence",
];

export default function ComposeScreen() {
  const colors = useColors();
  const router = useRouter();
  const [instruction, setInstruction] = useState(examples[0]);
  const [resolved, setResolved] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ModelKind>("attention");
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [trainingReport, setTrainingReport] = useState<TrainingReport | null>(null);
  const nodes = useMemo(() => resolveInstruction(instruction), [instruction]);
  const model = MODEL_CATALOG.find((item) => item.id === selectedModel) ?? MODEL_CATALOG[0];
  useEffect(() => { AsyncStorage.getItem(LEARNED_STATE_KEY).then((snapshot) => { if (snapshot) importLearnedArchitectureState(snapshot); }); }, []);
  useEffect(() => { if (trainingReport) AsyncStorage.setItem(LEARNED_STATE_KEY, exportLearnedArchitectureState()); }, [trainingReport]);

  const resolve = () => {
    setResolved(true);
    setPrediction(null);
    setTrainingReport(null);
    if (process.env.EXPO_OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };
  const runModel = () => { setPrediction(runDemo(selectedModel).prediction); setTrainingReport(null); if (process.env.EXPO_OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); };
  const trainModel = () => { setTrainingReport(train(selectedModel, 3)); };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right"]}>
      <FlatList
        data={examples}
        keyExtractor={(item) => item}
        ListHeaderComponent={
          <View>
            <View style={styles.topRow}>
              <View>
                <Text style={[styles.eyebrow, { color: colors.primary }]}>ARCHITECTURE WORKSPACE</Text>
                <Text style={[styles.title, { color: colors.foreground }]}>Compose a model.</Text>
                <Text style={[styles.subtitle, { color: colors.muted }]}>Describe the behavior. Let primitives do the wiring.</Text>
              </View>
              <View style={styles.headerActions}><Pressable onPress={() => router.push("/data" as any)} style={({ pressed }) => [styles.iconButton, { backgroundColor: `${colors.primary}16`, borderColor: colors.primary }, pressed && styles.pressed]}><IconSymbol name="square.grid.2x2" size={18} color={colors.primary} /></Pressable><Pressable onPress={() => router.push("/settings" as any)} style={({ pressed }) => [styles.iconButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
                <IconSymbol name="gear" size={20} color={colors.muted} />
              </Pressable></View>
            </View>
            <View style={[styles.inputCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.inputHeader}>
                <Text style={[styles.label, { color: colors.muted }]}>INSTRUCTION</Text>
                <View style={[styles.liveDot, { backgroundColor: colors.success }]} />
                <Text style={[styles.liveText, { color: colors.success }]}>LOCAL RESOLVER</Text>
              </View>
              <TextInput
                multiline
                value={instruction}
                onChangeText={(value) => { setInstruction(value); setResolved(false); }}
                placeholder="What should this network do?"
                placeholderTextColor={colors.muted}
                style={[styles.input, { color: colors.foreground }]}
              />
              <Pressable onPress={resolve} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}>
                <IconSymbol name="sparkles" size={18} color="#FFFFFF" />
                <Text style={styles.primaryButtonText}>Resolve architecture</Text>
                <IconSymbol name="arrow.right" size={18} color="#FFFFFF" />
              </Pressable>
            </View>
            {resolved && (
              <View style={[styles.resolutionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={styles.resolutionTop}>
                  <View style={[styles.check, { backgroundColor: `${colors.success}1F` }]}><IconSymbol name="checkmark" size={16} color={colors.success} /></View>
                  <View style={styles.flex}><Text style={[styles.resolutionTitle, { color: colors.foreground }]}>Composition resolved</Text><Text style={[styles.resolutionText, { color: colors.muted }]}>{nodes.length} primitives connected into a typed sequence.</Text></View>
                  <Text style={[styles.count, { color: colors.primary }]}>{nodes.length.toString().padStart(2, "0")}</Text>
                </View>
                <Pressable onPress={() => router.push("/graph" as any)} style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border }, pressed && styles.pressed]}>
                  <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>Open graph</Text><IconSymbol name="arrow.right" size={17} color={colors.primary} />
                </Pressable>
              </View>
            )}
            <View style={styles.modelHeading}><View><Text style={[styles.sectionLabel, { color: colors.muted }]}>SELECT A RUNTIME</Text><Text style={[styles.modelHint, { color: colors.muted }]}>Four local neural nets · real forward passes</Text></View><View style={[styles.localBadge, { backgroundColor: `${colors.success}1A` }]}><View style={[styles.liveDot, { backgroundColor: colors.success, marginLeft: 0 }]} /><Text style={[styles.localBadgeText, { color: colors.success }]}>ON DEVICE</Text></View></View>
            <View style={styles.modelGrid}>{MODEL_CATALOG.map((item) => <Pressable key={item.id} onPress={() => { setSelectedModel(item.id); setPrediction(null); setTrainingReport(null); }} style={({ pressed }) => [styles.modelCard, { backgroundColor: item.id === selectedModel ? `${colors.primary}14` : colors.surface, borderColor: item.id === selectedModel ? colors.primary : colors.border }, pressed && styles.pressed]}><View style={styles.modelCardTop}><Text style={[styles.modelFamily, { color: item.id === selectedModel ? colors.primary : colors.muted }]}>{item.family}</Text>{item.id === selectedModel && <IconSymbol name="checkmark" size={15} color={colors.primary} />}</View><Text style={[styles.modelName, { color: colors.foreground }]}>{item.name}</Text><Text style={[styles.modelDetail, { color: colors.muted }]}>{item.shape} · {item.detail}</Text></Pressable>)}</View>
            <View style={[styles.bench, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.benchCopy}><Text style={[styles.benchTitle, { color: colors.foreground }]}>{model.name} runtime</Text><Text style={[styles.benchText, { color: colors.muted }]}>{prediction ? `Predicted class ${prediction.classIndex + 1} · ${(prediction.confidence * 100).toFixed(1)}% confidence · ${prediction.latencyMs} ms` : "Run a real forward pass against the bundled feature sample."}</Text>{trainingReport && <Text style={[styles.trainText, { color: colors.success }]}>Loss {trainingReport.beforeLoss.toFixed(3)} → {trainingReport.afterLoss.toFixed(3)} · {(trainingReport.accuracy * 100).toFixed(0)}% demo accuracy</Text>}</View><View style={styles.benchActions}><Pressable onPress={runModel} style={({ pressed }) => [styles.runSmall, { backgroundColor: colors.primary }, pressed && styles.pressed]}><IconSymbol name="play.fill" size={15} color="#fff" /><Text style={styles.runSmallText}>Run</Text></Pressable><Pressable onPress={trainModel} style={({ pressed }) => [styles.trainSmall, { borderColor: colors.border }, pressed && styles.pressed]}><IconSymbol name="bolt.fill" size={15} color={colors.primary} /><Text style={[styles.trainSmallText, { color: colors.foreground }]}>Train 3×</Text></Pressable></View></View>
            <Text style={[styles.sectionLabel, { color: colors.muted }]}>TRY A STARTING POINT</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => { setInstruction(item); setResolved(false); }} style={({ pressed }) => [styles.exampleRow, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}>
            <View style={[styles.exampleIcon, { backgroundColor: `${colors.primary}1A` }]}><IconSymbol name="wand.and.stars" size={17} color={colors.primary} /></View>
            <Text style={[styles.exampleText, { color: colors.foreground }]} numberOfLines={2}>{item}</Text>
            <IconSymbol name="chevron.right" size={18} color={colors.muted} />
          </Pressable>
        )}
        ListFooterComponent={<View style={styles.footer}><Text style={[styles.footerText, { color: colors.muted }]}>64 primitives · deterministic graph resolution · offline by default</Text></View>}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { paddingTop: 14, paddingBottom: 32 },
  topRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24 }, headerActions: { flexDirection: "row", gap: 7 },
  eyebrow: { fontSize: 11, fontWeight: "800", letterSpacing: 1.3, marginBottom: 8 },
  title: { fontSize: 30, fontWeight: "800", letterSpacing: -0.7, lineHeight: 36 },
  subtitle: { fontSize: 14, lineHeight: 20, marginTop: 6, maxWidth: 270 },
  iconButton: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  inputCard: { borderRadius: 22, borderWidth: 1, padding: 16, marginBottom: 18 },
  inputHeader: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 10 },
  label: { fontSize: 10, fontWeight: "800", letterSpacing: 1.2 },
  liveDot: { width: 6, height: 6, borderRadius: 3, marginLeft: "auto" },
  liveText: { fontSize: 9, fontWeight: "800", letterSpacing: 0.6 },
  input: { minHeight: 94, fontSize: 18, fontWeight: "600", lineHeight: 25, textAlignVertical: "top", paddingTop: 3, paddingBottom: 12 },
  primaryButton: { borderRadius: 14, minHeight: 50, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", gap: 9 },
  primaryButtonText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800", flex: 1 },
  resolutionCard: { borderRadius: 20, borderWidth: 1, padding: 15, marginBottom: 26 },
  resolutionTop: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 14 },
  check: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  flex: { flex: 1 },
  resolutionTitle: { fontSize: 15, fontWeight: "800", marginBottom: 3 },
  resolutionText: { fontSize: 12, lineHeight: 17 },
  count: { fontSize: 22, fontWeight: "800" },
  secondaryButton: { minHeight: 42, borderRadius: 12, borderWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  secondaryButtonText: { fontSize: 14, fontWeight: "800" },
  sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.3, marginBottom: 10 },
  modelHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 9 },
  modelHint: { fontSize: 11, marginTop: -5, marginBottom: 1 },
  localBadge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: "row", alignItems: "center", gap: 5 },
  localBadgeText: { fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },
  modelGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 10 },
  modelCard: { width: "48.7%", minHeight: 88, borderRadius: 15, borderWidth: 1, padding: 11 },
  modelCardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modelFamily: { fontSize: 8, fontWeight: "900", letterSpacing: 0.8 },
  modelName: { fontSize: 14, fontWeight: "800", marginTop: 7 },
  modelDetail: { fontSize: 10, lineHeight: 14, marginTop: 4 },
  bench: { borderRadius: 18, borderWidth: 1, padding: 13, marginBottom: 24, flexDirection: "row", alignItems: "center" },
  benchCopy: { flex: 1, paddingRight: 9 },
  benchTitle: { fontSize: 14, fontWeight: "800" },
  benchText: { fontSize: 11, lineHeight: 16, marginTop: 4 },
  trainText: { fontSize: 10, fontWeight: "800", marginTop: 6 },
  benchActions: { gap: 7 },
  runSmall: { minWidth: 64, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 5 },
  runSmallText: { color: "#fff", fontSize: 11, fontWeight: "800" },
  trainSmall: { minWidth: 64, height: 34, borderRadius: 10, borderWidth: 1, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 5 },
  trainSmallText: { fontSize: 11, fontWeight: "800" },
  exampleRow: { minHeight: 62, borderRadius: 16, borderWidth: 1, paddingHorizontal: 12, marginBottom: 9, flexDirection: "row", alignItems: "center", gap: 11 },
  exampleIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  exampleText: { flex: 1, fontSize: 14, fontWeight: "600", lineHeight: 19 },
  footer: { alignItems: "center", paddingVertical: 20 },
  footerText: { fontSize: 11, textAlign: "center" },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});
