import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Platform } from "react-native";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.muted, tabBarButton: HapticTab, tabBarStyle: { paddingTop: 7, paddingBottom: bottomPadding, height: 56 + bottomPadding, backgroundColor: colors.background, borderTopColor: colors.border, borderTopWidth: 0.5 } }}>
    <Tabs.Screen name="index" options={{ title: "Compose", tabBarIcon: ({ color }) => <IconSymbol name="wand.and.stars" size={23} color={color} /> }} />
    <Tabs.Screen name="graph" options={{ title: "Graph", tabBarIcon: ({ color }) => <IconSymbol name="point.3.connected.trianglepath.dotted" size={23} color={color} /> }} />
    <Tabs.Screen name="primitives" options={{ title: "Primitives", tabBarIcon: ({ color }) => <IconSymbol name="square.grid.2x2" size={23} color={color} /> }} />
    <Tabs.Screen name="library" options={{ title: "Library", tabBarIcon: ({ color }) => <IconSymbol name="books.vertical" size={23} color={color} /> }} />
  </Tabs>;
}
