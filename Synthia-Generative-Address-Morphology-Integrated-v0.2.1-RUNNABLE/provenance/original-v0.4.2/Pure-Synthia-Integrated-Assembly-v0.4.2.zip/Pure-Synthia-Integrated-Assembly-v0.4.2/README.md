# Pure Synthia Integrated Assembly v0.4.2

This is the root assembly that comes **after** the Klein wiring repair.

It preserves two authorities instead of flattening them:

- `authorities/execution-spine/` — Synthia Universal Execution Spine v0.4.1, with the live Klein context runtime connected to tool chains and deep contact.
- `authorities/trainable-core/` — Pure Synthia Trainable Assembly v0.4.1, preserving registration, source/book fragments, Sentence Mesh, Scientist Loop and Training Journal.

The root facade is `src/unified-synthia-assembly.mjs`.

## What is now actually connected

### Klein first

The execution spine now has a mandatory `KleinContextRuntime`.

A live event can no longer count as "Klein connected" merely because a module named `klein-analogy` exists. The runtime:

1. wraps every mounted automaton as a Klein-capable participant;
2. performs a side-effect-free joint evaluation over the **actual active tool invocations**;
3. returns exactly `{ relation, intensity, direction }`;
4. records an append-only witnessed evaluation;
5. fixes the result for an identical context hash (determinism after collapse);
6. writes the evaluation into the live mesh and semantic triple store;
7. attaches it to the derivation before normal execution proceeds.

The deep contact loop is now a real StatePacket transport path:

`DISEMINER -> language-contact -> historical-monte-carlo -> AutoLing -> computational-grammar-coder -> conversation`

The conversation surface receives the joint Klein result. It is not just displayed after the fact.

Structured internal calls use `engine.invoke()`, which goes through:

`intake -> Klein -> tool -> provenance triples -> experiential return -> derivation -> emergence observers`

So internal adapters do not need to bypass Klein just because their input is an object instead of a text command.

### Root connection

`UnifiedSynthiaAssembly` instantiates the execution spine and the trainable core in one live root.

- `chat()` records the exact Klein evaluation into the Training Journal.
- `call()` and `invoke()` carry the same Klein derivation into training.
- `ingestBook()` uses the real mounted AutoLing and DISEMINER through `engine.invoke()`, then broadcasts the registered source-fragment identities back into the mesh.
- The Scientist Loop and State Registry remain independently addressable organs rather than being rewritten into the execution engine.

## Address boundary intentionally not faked

The two supplied authorities do not currently expose identical 13-field names:

- execution spine uses `arcAxis`
- trainable core uses `arc`

This root does **not** guess that those are interchangeable. Both schemas remain preserved and the audit reports:

`policy: preserve-both-no-silent-conversion`

That is an explicit unresolved integration boundary, not a hidden conversion.

## Verification

Run the full root + both authority suites:

```bash
npm run test:all
```

The root tests verify:

- Klein runtime exists and has no missing mounted operators;
- a witnessed Klein evaluation occurs at boot;
- chat's Klein evaluation reaches the training journal unchanged;
- structured internal tool invocation cannot bypass intake/Klein/provenance;
- book ingestion invokes the live AutoLing + DISEMINER and then shares source fragments to the mesh;
- the address-schema boundary is preserved instead of silently rewritten.

## Provenance

The three original user-supplied ZIPs are retained byte-for-byte in `sources/`.
Their SHA-256 hashes are in `provenance/SOURCE-SHA256.txt`.
